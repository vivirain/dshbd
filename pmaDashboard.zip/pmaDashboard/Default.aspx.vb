﻿Public Class _Default
    Inherits System.Web.UI.Page


    Private pmaUserService As IPmaUserService = New PmaUserService
    Private userService As IUserService = New UserService
    Private menuAuthService As IMenuAuthService = New MenuAuthService
    Private menuService As IMenuService = New MenuService
    Private pmaTeam As IPmaTeamService = New PmaTeamService

    Private dtPmaStaff As DataTable = New DataTable
    Private sLogonId As String = ""

    Protected sAlertMsg As String = ""
    Dim sAlertMessage() As String = {"Sorry, you're not yet assigned to any application roles. Please contact your system admin.", _
                                           "Sorry, you're not yet assigned to any business functions, please contact your system administrator.", _
                                           "Sorry, user details inforamtion is not found, please contact your PMA system administrator."}

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("logon_id") Is Nothing Then
            Server.Transfer("Views/Account/Login.aspx")
        End If

        If Not Session("logon_id") Is Nothing Then
            sLogonId = Session("logon_id")

            'Retrieve user roles list
            Dim sUserRoleString As String = ""
            Dim userRoleList As String() = Nothing
            If Session("userRoles") Is Nothing Then
                sUserRoleString = userService.GetUserRoleString(sLogonId)
            Else
                sUserRoleString = Session("userRoles")
            End If
            If sUserRoleString = "" Then
                sAlertMsg = sAlertMessage(0)
                Return
            Else
                userRoleList = sUserRoleString.Split(",")
            End If

            'Retrieve user menu list
            Dim sUserMenuString As String = ""
            sUserMenuString = menuAuthService.GetMenuIdsByUserRoles(sUserRoleString, sLogonId)
            If sUserMenuString = "" Then
                sAlertMsg = sAlertMessage(1)
                Return
            End If

            'Get staff id card no, team information
            dtPmaStaff = pmaUserService.GetActiveUserByLogonId(sLogonId)
            Dim iTeamCode As Integer
            Dim sLogonIdCard As String = ""
            If Not dtPmaStaff Is Nothing Then
                If dtPmaStaff.Rows.Count > 0 Then
                    sLogonIdCard = dtPmaStaff.Rows(0).Item("id_card")
                    iTeamCode = dtPmaStaff.Rows(0).Item("team_code")
                End If
            End If

            'Get lead teams
            Dim myLeadTeams As String = ""
            If sUserRoleString.Contains(DASHBORADROLES.GM) Or sUserRoleString.Contains(DASHBORADROLES.QAG) Or sUserRoleString.Contains(DASHBORADROLES.EXCO) _
                Or sUserRoleString.Contains(DASHBORADROLES.ADM) Or sUserRoleString.Contains(DASHBORADROLES.AM) Then
            ElseIf String.IsNullOrEmpty(myLeadTeams) And sUserRoleString = DASHBORADROLES.PM Then
                myLeadTeams = iTeamCode
            Else
                Dim pmaTeamService As IPmaTeamService = New PmaTeamService
                myLeadTeams = pmaTeamService.GetMyLeadTeamCodes(sLogonId, sLogonIdCard)
            End If
            

            'Get sytem dateFormat
            Dim lookUpService As ILookupService = New LookupService
            Dim sDateFormat As String = lookUpService.GetLookUpName("S", "MISC", "DATE_FORMAT")
            If String.IsNullOrEmpty(sDateFormat) Then
                sDateFormat = "MM/dd/yyyy"
            End If

            Session("userInfo") = dtPmaStaff
            Session("id_card") = sLogonIdCard
            Session("userRoles") = sUserRoleString
            Session("userRoleList") = userRoleList
            Session("myMenuString") = sUserMenuString
            Session("team_code") = iTeamCode
            Session("my_teams") = myLeadTeams
            Session("date_format") = sDateFormat


            Server.Transfer("Views/Dashboard.aspx")

        End If
    End Sub



End Class