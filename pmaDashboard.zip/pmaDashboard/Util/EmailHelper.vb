﻿Imports System.Net
Imports System.Net.Mail
Imports System.Net.NetworkCredential

Public Class EmailHelper

    Shared lookupService As ILookupService = New LookupService
    Shared pmaEmailTemplateService As IPmaEmailTemplateService = New PmaEmailTemplateService
    Shared pmaSysParmService As IPmaSysParmService = New PmaSysParmService
    Dim logHelper As LogHelper = New LogHelper

    Public Shared Function SendInstantEmail(ByVal emailSubject As String, ByVal emailBody As String, ByVal emailTo As String(), Optional ByVal emailCc As String() = Nothing) As Boolean

        Dim bSent As Boolean = False

        If emailTo Is Nothing OrElse emailTo.Length = 0 Then
            Return bSent
        End If

        'Dim dtEmail As DataTable = New DataTable

        'Dim hsEmail As Hashtable = New Hashtable
        Dim emailServer As SmtpClient = New SmtpClient
        Dim mail As MailMessage = New MailMessage
        Dim sEmailHostIp As String = ""
        Dim sEmailSendFrom As String = ""

        Try
            'dtEmail = lookupService.GetLookUpList("S", "EMAIL")


            'If dtEmail Is Nothing OrElse dtEmail.Rows.Count = 0 Then
            '    logHelper.WriteLog("Email server configuration information is not found.")
            '    Return bSent
            'End If

            'For Each dr As DataRow In dtEmail.Rows
            '    If IsDBNull(dr("lookup_name")) Then
            '        Continue For
            '    End If
            '    If String.IsNullOrEmpty(dr("lookup_name").ToString.Trim) Then
            '        Continue For
            '    End If

            '    hsEmail.Add(dr("lookup_code"), dr("lookup_name"))
            'Next

            ''Email Server
            'If hsEmail.ContainsKey("email_host_ip") Then
            '    emailServer.Host = hsEmail("email_host_ip")
            'Else
            '    logHelper.WriteLog("Email server host configuration information is not found.")
            '    Return bSent
            'End If

            sEmailHostIp = pmaSysParmService.getSystemParamValue("email_host_ip")
            If String.IsNullOrEmpty(sEmailHostIp) Then
                logHelper.WriteLog("Email server host configuration information is not found.")
                Return bSent
            End If
            emailServer.Host = sEmailHostIp
            'emailServer.EnableSsl = False
            'emailServer.Port = 25
            'emailServer.Credentials = New System.Net.NetworkCredential("XXX", "***")
            'emailServer.Credentials = CredentialCache.DefaultNetworkCredentials

            sEmailSendFrom = pmaSysParmService.getSystemParamValue("email_from_account")
            If String.IsNullOrEmpty(sEmailSendFrom) Then
                logHelper.WriteLog("Email from account configuration information is not found.")
                Return bSent
            End If

            'Email Encoding

            mail.IsBodyHtml = True
            mail.Priority = MailPriority.Normal

            'Email sender account
            mail.From = New MailAddress(sEmailSendFrom)
            'If hsEmail.ContainsKey("email_from_account") Then
            '    mail.From = New MailAddress(hsEmail("email_from_account"))
            'Else
            '    logHelper.WriteLog("Email from account configuration information is not found.")
            '    Return bSent
            'End If

            'Email To
            For i As Integer = 0 To emailTo.Length - 1
                mail.To.Add(emailTo(i))
            Next

            'Email Cc
            If Not emailCc Is Nothing Then
                For i As Integer = 0 To emailCc.Length - 1
                    mail.CC.Add(emailCc(i))
                Next
            End If

            mail.Subject = emailSubject
            mail.Body = emailBody

            logHelper.WriteLog("begin to send email...")
            emailServer.Send(mail)
            logHelper.WriteLog("Email is sent out successfully...")

            bSent = True
        Catch ex As Exception
            bSent = False
            logHelper.WriteLog("failed to send email.", ex)
        End Try

        SendInstantEmail = bSent

    End Function

    'Public Shared Function SendAsyncEmail(ByVal emailTo As String(), ByVal emailSubject As String, ByVal emailBody As String, Optional ByVal emailCc As String() = Nothing) As Boolean

    '    Dim bSent As Boolean = False

    '    If emailTo Is Nothing Then
    '        Return bSent
    '    ElseIf emailTo.Length = 0 Then
    '        Return bSent
    '    End If

    '    Dim dtEmail As DataTable = New DataTable
    '    Dim hsEmail As Hashtable = New Hashtable
    '    Dim emailServer As SmtpClient = New SmtpClient
    '    Dim mail As MailMessage = New MailMessage

    '    Try
    '        dtEmail = lookupService.GetLookUpList("S", "EMAIL")

    '        If dtEmail Is Nothing OrElse dtEmail.Rows.Count = 0 Then
    '            logHelper.WriteLog("Email server configuration information is not found.")
    '            Return bSent
    '        End If

    '        For Each dr As DataRow In dtEmail.Rows
    '            If IsDBNull(dr("lookup_name")) Then
    '                Continue For
    '            End If
    '            If String.IsNullOrEmpty(dr("lookup_name").ToString.Trim) Then
    '                Continue For
    '            End If

    '            hsEmail.Add(dr("lookup_code"), dr("lookup_name"))
    '        Next

    '        If hsEmail.ContainsKey("email_host_ip") Then
    '            emailServer.Host = hsEmail("email_host_ip")
    '        Else
    '            logHelper.WriteLog("Email server host configuration information is not found.")
    '            Return bSent
    '        End If

    '        'emailServer.EnableSsl = False
    '        'emailServer.Port = 25
    '        'emailServer.Credentials = New System.Net.NetworkCredential("XXX", "***")

    '        'Email
    '        If hsEmail.ContainsKey("email_from_account") Then
    '            mail.From = New MailAddress(hsEmail("email_from_account"))
    '        Else
    '            logHelper.WriteLog("Email from account configuration information is not found.")
    '            Return bSent
    '        End If

    '        For i As Integer = 0 To emailTo.Length - 1
    '            mail.To.Add(emailTo(i))
    '        Next

    '        If Not emailCc Is Nothing Then
    '            For i As Integer = 0 To emailCc.Length - 1
    '                mail.CC.Add(emailCc(i))
    '            Next
    '        End If

    '        mail.Subject = emailSubject
    '        mail.Body = emailBody
    '        mail.IsBodyHtml = True

    '        logHelper.WriteLog("begin to send email...")
    '        emailServer.SendAsync(mail, "sending Async email...")
    '        'logHelper.WriteLog("Email is sent out successfully...")

    '        bSent = True
    '    Catch ex As Exception
    '        bSent = False
    '        logHelper.WriteLog("failed to send email.", ex)
    '    End Try

    '    SendAsyncEmail = bSent

    'End Function


    Sub EmailSendAsyncCompleted(sender As Object, e As System.ComponentModel.AsyncCompletedEventArgs)

        If e.Cancelled Then
            logHelper.WriteLog("[" & CType(e.UserState, String) & "] send is cancelled ")
        ElseIf Not e.Error Is Nothing Then
            logHelper.WriteLog("[" & CType(e.UserState, String) & "] send error " & e.Error.ToString)
        Else
            logHelper.WriteLog("[" & CType(e.UserState, String) & "] is sent successfully.")
        End If

    End Sub



End Class
