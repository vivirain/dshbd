﻿Imports System
Imports System.Data.OleDb
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports NPOI
Imports NPOI.SS
Imports NPOI.SS.UserModel
Imports NPOI.HSSF
Imports NPOI.HSSF.UserModel
Imports NPOI.XSSF
Imports NPOI.XSSF.UserModel
Imports NPOI.HPSF
Imports NPOI.Util
Imports NPOI.POIFS.FileSystem

Public Class ExcelSheetContent
    Private _sheetName As String
    Property SheetName() As String
        Get
            Return _sheetName
        End Get
        Set(ByVal value As String)
            _sheetName = value
        End Set
    End Property

    Private _dt As DataTable
    Property dt() As DataTable
        Get
            Return _dt
        End Get
        Set(ByVal value As DataTable)
            _dt = value
        End Set
    End Property

    Public Sub New()
    End Sub

    Public Sub New(ByVal sheetName As String, ByVal dt As DataTable)
        _sheetName = sheetName
        _dt = dt
    End Sub
End Class

Public Class ExcelHelper

    Private oleDbExcelConn As OleDbConnection = Nothing

    Private Shared strExcelAceConn As String = ""
    Private Shared strExcelJetConn As String = ""

    Private oleDbDa As OleDbDataAdapter = Nothing
    Private oleDbCmd As OleDbCommand = Nothing
    Private oleDBCmdSelect As OleDbCommand = Nothing

    Dim logHelper As LogHelper = New LogHelper


    Private Function GetExcelJetConnection(filePath As String) As OleDbConnection

        Dim excelConnectionString As String = ""

        If Not String.IsNullOrEmpty(filePath) Then
            strExcelJetConn = ConfigurationManager.ConnectionStrings("dashboardExcelJet").ConnectionString
            excelConnectionString = String.Format(strExcelJetConn, filePath)
        Else
            Return oleDbExcelConn
        End If

        If oleDbExcelConn Is Nothing Then
            oleDbExcelConn = New OleDbConnection(excelConnectionString)
            oleDbExcelConn.Open()
        End If

        If (oleDbExcelConn.State = ConnectionState.Closed) Then
            oleDbExcelConn.Open()
        End If

        GetExcelJetConnection = oleDbExcelConn

    End Function


    Private Function GetExcelAceConnection(filePath As String) As OleDbConnection

        Dim excelConnectionString As String = ""

        If Not String.IsNullOrEmpty(filePath) Then
            strExcelAceConn = ConfigurationManager.ConnectionStrings("dashboardExcelAce").ConnectionString
            excelConnectionString = String.Format(strExcelAceConn, filePath)
        Else
            Return oleDbExcelConn
        End If

        If oleDbExcelConn Is Nothing Then
            oleDbExcelConn = New OleDbConnection(excelConnectionString)
            oleDbExcelConn.Open()
        End If

        If (oleDbExcelConn.State = ConnectionState.Closed) Then
            oleDbExcelConn.Open()
        End If

        'If oleDbExcelConn.State = ConnectionState.Open Then
        '    Dim dtSheetName As DataTable = oleDbExcelConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, New Object() {Nothing, Nothing, Nothing, "TABLE"})

        '    If Not dtSheetName Is Nothing Then
        '        For Each drSheetName As DataRow In dtSheetName.Rows
        '            Dim sheetName As String = drSheetName(2)
        '        Next
        '    End If

        'End If

        GetExcelAceConnection = oleDbExcelConn

    End Function

    Private Sub CloseExcelConnection()
        If Not (oleDbExcelConn.State = ConnectionState.Closed) Then
            oleDbExcelConn.Close()
        End If
    End Sub

    Public Function ExecuteOleDbAdapterQuery(ByVal strCmd As String, ByVal filePath As String) As DataTable
        Dim ds As DataSet = New DataSet()
        Dim dt As DataTable = New DataTable()

        Try

            oleDbCmd = New OleDbCommand(strCmd, GetExcelAceConnection(filePath))

            If oleDbDa Is Nothing Then
                oleDbDa = New OleDbDataAdapter()
            End If
            oleDbDa.SelectCommand = oleDbCmd

            oleDbDa.Fill(dt)

        Catch ex As Exception
            Console.Write(ex.ToString)

        Finally
            oleDbCmd.Dispose()
            CloseExcelConnection()
        End Try

        ExecuteOleDbAdapterQuery = dt
    End Function


    Public Function ExecuteOleDbAdapterInsert(ByVal tgtExcelFile As String, ByVal tgtExcelSheet As String, ByVal dtInsert As DataTable) As Boolean
        Dim sReturn As Boolean = False
        Dim sSQLSel As String = String.Format("SELECT * FROM [{0}$]", tgtExcelSheet)
        Dim ds As DataSet = New DataSet


        Try
            oleDBCmdSelect = New OleDbCommand(sSQLSel, GetExcelAceConnection(tgtExcelFile))
            If oleDbDa Is Nothing Then
                oleDbDa = New OleDbDataAdapter
            End If
            oleDbDa.SelectCommand = oleDBCmdSelect
            oleDbDa.Fill(ds)

            ds.Tables(0).Merge(dtInsert)

            Dim oleDbCmdBuilder = New OleDbCommandBuilder(oleDbDa)

            oleDbDa.Update(ds)

            sReturn = True
        Catch ex As Exception
            Console.Write(ex.ToString)
        End Try

        ExecuteOleDbAdapterInsert = sReturn
    End Function

    Public Shared Function OutputToExcel(ByVal dtOutput As DataTable) As Boolean
        Dim bGood As Boolean = False

        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=" & Now.ToString("yyyyMMddhhmmssffff") & ".xls")
        HttpContext.Current.Response.ContentType = "application/ms-excel"
        'HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

        Dim sw As StringWriter = New StringWriter()
        Dim htw As HtmlTextWriter = New HtmlTextWriter(sw)

        Dim dg As DataGrid = New DataGrid
        dg.DataSource = dtOutput.DefaultView
        dg.DataBind()
        dg.RenderControl(htw)

        HttpContext.Current.Response.Write(sw.ToString)
        HttpContext.Current.Response.Flush()
        HttpContext.Current.Response.End()


        dg.Dispose()
        OutputToExcel = bGood
    End Function

    Public Shared Function OutputToExcel(ByVal sFileName As String, sFileFullName As String) As Boolean
        Dim bGood As Boolean = False

        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" & sFileName)

        HttpContext.Current.Response.AddHeader("Content-Type", "application/vnd.ms-excel")
        HttpContext.Current.Response.ContentType = "application/ms-excel"

        HttpContext.Current.Response.WriteFile(sFileFullName)
        HttpContext.Current.Response.Flush()
        File.Delete(sFileFullName)

        OutputToExcel = bGood
    End Function



    Public Function NpoiExcel2DataTable(ByVal fileName As String, ByVal sheetName As String, ByVal isFirstRowColumn As Boolean) As DataTable
        Dim sheet As ISheet = Nothing
        Dim dt As DataTable = New DataTable
        Dim iStartRow As Integer = 0

        Dim workbook As IWorkbook = Nothing
        Dim worksheet As ISheet = Nothing

        Try
            Dim fs As FileStream = New FileStream(fileName, FileMode.Open, FileAccess.Read)
            If fileName.EndsWith(".xlsx") Then
                workbook = New XSSFWorkbook(fs)
            ElseIf fileName.EndsWith(".xls") Then
                workbook = New HSSFWorkbook(fs)
            End If

            If String.IsNullOrEmpty(sheetName) Then
                worksheet = workbook.GetSheetAt(0)
            Else
                worksheet = workbook.GetSheet(sheetName)
                If worksheet Is Nothing Then
                    worksheet = workbook.GetSheetAt(0)
                End If
            End If

            If Not worksheet Is Nothing Then
                Dim firstRow As IRow = worksheet.GetRow(0)
                Dim cellCount As Integer = firstRow.LastCellNum

                If isFirstRowColumn Then
                    For i As Integer = firstRow.FirstCellNum To cellCount - 1
                        Dim cell As ICell = firstRow.GetCell(i)
                        If Not cell Is Nothing Then
                            Dim cellVal As String = cell.StringCellValue
                            If Not String.IsNullOrEmpty(cellVal) Then
                                Dim col As DataColumn = New DataColumn(cellVal)
                                dt.Columns.Add(col)
                            End If
                        End If
                    Next
                    iStartRow = worksheet.FirstRowNum + 1
                Else
                    iStartRow = worksheet.FirstRowNum
                End If 'End If isFirstRowColumn

                Dim rowCount As Integer = worksheet.LastRowNum
                For i As Integer = iStartRow To rowCount
                    Dim row As IRow = worksheet.GetRow(i)
                    If Not row Is Nothing Then
                        Dim dr As DataRow = dt.NewRow
                        'dr.ItemArray = row.ToArray
                        For j As Integer = row.FirstCellNum To cellCount - 1
                            If Not (row.GetCell(j) Is Nothing) Then
                                Dim rowCellVal As String = DataFormatHelper.StringTrim(row.GetCell(j).ToString)
                                If Not String.IsNullOrEmpty(rowCellVal) Then
                                    dr(j) = rowCellVal
                                End If
                            End If
                        Next
                        dt.Rows.Add(dr)
                    End If
                Next

            End If 'End If Not worksheet Is Nothing
        Catch ex As Exception
            Console.WriteLine("Exception: " + ex.Message)
            dt = Nothing
        End Try

        NpoiExcel2DataTable = dt
    End Function


    'Public Function NpoiDataTable2Excel(ByVal fileName As String, ByVal sheetName As String, ByVal dtExport As DataTable) As Boolean
    Public Function NpoiDataTable2Excel(ByVal fileName As String, ByVal excelSheetContents As ExcelSheetContent()) As Boolean
        Dim bGood As Boolean = False

        Dim workbook As IWorkbook = Nothing
        Dim fileExt As String = ""

        If fileName.EndsWith(".xlsx") Then
            fileExt = ".xlsx"
            workbook = New XSSFWorkbook
        ElseIf fileName.EndsWith(".xls") Then
            fileExt = ".xls"
            workbook = New HSSFWorkbook
        End If


        For Each sheetContent In excelSheetContents
            Dim sheet As ISheet = workbook.CreateSheet(sheetContent.SheetName)


            'Header
            Dim headerRow As IRow = sheet.CreateRow(0)
            For i As Integer = 0 To sheetContent.dt.Columns.Count - 1
                Dim cell As ICell = headerRow.CreateCell(i)
                cell.SetCellValue(sheetContent.dt.Columns(i).ColumnName)
            Next

            'Row Data
            Dim dataRowIndex As Integer = 0
            For Each drExport In sheetContent.dt.Rows
                Dim dataRow As IRow = sheet.CreateRow(dataRowIndex + 1)

                For i As Integer = 0 To sheetContent.dt.Columns.Count - 1
                    Dim cell As ICell = dataRow.CreateCell(i)
                    cell.SetCellValue(drExport(i).ToString)
                Next

                dataRowIndex = dataRowIndex + 1
            Next
        Next
        




        Dim memoryStream As MemoryStream = New MemoryStream
        Dim resp As HttpResponse = HttpContext.Current.Response
        Try

            resp.Clear()
            workbook.Write(memoryStream)

            If fileExt = ".xlsx" Then
                resp.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                resp.AddHeader("Content-Disposition", String.Format("attachment;filename={0}", fileName))
                resp.BinaryWrite(memoryStream.ToArray)
            ElseIf fileExt = ".xls" Then
                resp.ContentType = "application/vnd.ms-excel"
                resp.AddHeader("Content-Disposition", String.Format("attachment;filename={0}", fileName))
                resp.BinaryWrite(memoryStream.GetBuffer())
            End If

            bGood = True
        Catch ex As Exception
            bGood = False
            Throw ex
        Finally
            resp.End()
        End Try




        NpoiDataTable2Excel = bGood
    End Function

    Public Function NpoiExcelTemplate2DataTable(ByVal fileName As String, ByVal sheetName As String) As DataTable
        Dim sheet As ISheet = Nothing
        Dim dt As DataTable = New DataTable

        Dim workbook As IWorkbook = Nothing
        Dim worksheet As ISheet = Nothing

        Dim fs As FileStream = Nothing

        Try
            If Not File.Exists(fileName) Then
                logHelper.WriteLog("Template file is not found. Template File: " & fileName)
                Return Nothing
            End If

            'fs = New FileStream(fileName, FileMode.Open, FileAccess.Read)
            fs = File.OpenRead(fileName)

            If fileName.EndsWith(".xlsx") Then
                workbook = New XSSFWorkbook(fs)
            ElseIf fileName.EndsWith(".xls") Then
                workbook = New HSSFWorkbook(fs)
            End If

            If String.IsNullOrEmpty(sheetName) Then
                worksheet = workbook.GetSheetAt(0)
            Else
                worksheet = workbook.GetSheet(sheetName)
                If worksheet Is Nothing Then
                    worksheet = workbook.GetSheetAt(0)
                End If
            End If

            If Not worksheet Is Nothing Then
                Dim firstRow As IRow = worksheet.GetRow(0)
                If Not firstRow Is Nothing Then
                    Dim cellCount As Integer = firstRow.LastCellNum

                    For i As Integer = firstRow.FirstCellNum To cellCount - 1
                        Dim cell As ICell = firstRow.GetCell(i)
                        If Not cell Is Nothing Then
                            Dim cellVal As String = cell.StringCellValue
                            If Not String.IsNullOrEmpty(cellVal) Then
                                Dim col As DataColumn = New DataColumn(cellVal)
                                dt.Columns.Add(col)
                            End If
                        End If
                    Next
                End If

            End If 'End If Not worksheet Is Nothing

            fs.Close()

        Catch ex As Exception
            'Console.WriteLine("Exception: " + ex.Message)
            If Not fs Is Nothing Then
                fs.Close()
            End If
        End Try

        NpoiExcelTemplate2DataTable = dt

        dt.Dispose()
    End Function
End Class
