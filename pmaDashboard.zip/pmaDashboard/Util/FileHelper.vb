﻿Imports System.Web
Imports System.IO

Public Class PropertyObj
    Property env As String
    Property dbUser As String
    Property dbPassword As String
    Property key As String
End Class

Public Class FileHelper

    Public Shared Function ReadPropertyFile() As PropertyObj
        Dim propertyObj As PropertyObj = New PropertyObj
        Dim propertyFile As String = ""
        Dim propertyHelper As PropertyHelper = New PropertyHelper
        Dim streamReader As StreamReader = Nothing

        Try
            propertyFile = HttpContext.Current.Server.MapPath("~/system.properties")

            If File.Exists(propertyFile) Then
                streamReader = New StreamReader(propertyFile)

                propertyHelper.Load(streamReader)
                propertyObj.env = propertyHelper.GetProperty("[env]")
                propertyObj.dbUser = propertyHelper.GetProperty("[db_user]")
                propertyObj.dbPassword = propertyHelper.GetProperty("[db_psw]")
                propertyObj.key = propertyHelper.GetProperty("[key]")
                streamReader.Close()

                If String.IsNullOrEmpty(propertyObj.dbUser) Or String.IsNullOrEmpty(propertyObj.dbPassword) Then
                    propertyObj = Nothing
                    LogHelper.WriteLog("Database connection is not yet ready.")
                ElseIf String.IsNullOrEmpty(propertyObj.env) Then
                    propertyObj = Nothing
                    LogHelper.WriteLog("Environment parameter is not set.")
                Else
                    LogHelper.WriteLog("System properties file is loaded successfully.")
                End If
            Else
                LogHelper.WriteLog("System properties file is not found.")
            End If
        Catch ex As Exception
            propertyObj = Nothing
            LogHelper.WriteLog("Failed to load property file.", ex)
        End Try

        ReadPropertyFile = propertyObj
        propertyObj = Nothing
    End Function
End Class
