﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO


#Region "Model"
Public Class SqlAdapterUpdate
    Private _sqlSelCmd As String
    Property sqlSelCmd() As String
        Get
            Return _sqlSelCmd
        End Get
        Set(ByVal value As String)
            _sqlSelCmd = value
        End Set
    End Property

    Private _dt As DataTable
    Property dt() As DataTable
        Get
            Return _dt
        End Get
        Set(ByVal value As DataTable)
            _dt = value
        End Set
    End Property

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqlCmd As String, ByVal dt As DataTable)
        _sqlSelCmd = sqlCmd
        _dt = dt
    End Sub
End Class

Public Class SqlAdapterCommand
    Private _sqlCmd As String
    Property sqlCmd() As String
        Get
            Return _sqlCmd
        End Get
        Set(ByVal value As String)
            _sqlCmd = value
        End Set
    End Property

    Private _sqlParams As SqlParameter()
    Property sqlParams() As SqlParameter()
        Get
            Return _sqlParams
        End Get
        Set(ByVal value As SqlParameter())
            _sqlParams = value
        End Set
    End Property

    Public Sub New()
    End Sub
End Class

Public Class SqlAdapterInsert
    Private _sqlSelCmd As String
    Property sqlSelCmd() As String
        Get
            Return _sqlSelCmd
        End Get
        Set(ByVal value As String)
            _sqlSelCmd = value
        End Set
    End Property

    Private _dt As DataTable
    Property dt() As DataTable
        Get
            Return _dt
        End Get
        Set(ByVal value As DataTable)
            _dt = value
        End Set
    End Property

    Private _returnIdentity As Boolean
    Property returnIdentity() As Boolean
        Get
            Return _returnIdentity
        End Get
        Set(ByVal value As Boolean)
            _returnIdentity = value
        End Set
    End Property

    Public Sub New()

    End Sub

    Public Sub New(ByVal sqlCmd As String, ByVal dt As DataTable, ByVal returnId As Boolean)
        _sqlSelCmd = sqlCmd
        _dt = dt
        _returnIdentity = returnId
    End Sub
End Class
#End Region


#Region "Services"
Public Class SqlHelper

    Private sqlConn As SqlConnection = Nothing
    Private sqlCmd As SqlCommand = Nothing
    Private selCmd As SqlCommand = Nothing
    Private sqlDr As SqlDataReader = Nothing
    Private sqlDa As SqlDataAdapter = Nothing
    Private sqlCmdBuilder As SqlCommandBuilder = Nothing

    Private logHelper As LogHelper = New LogHelper

    Private strSqlConn As String = "Server={0};Database={1};User ID={2};Password={3};"
    Shared _strSqlConnDecrypted As String = ""

    Public Sub SqlHelper()

        If Not HttpContext.Current.Session("sqlConn") Is Nothing Then
            sqlConn = HttpContext.Current.Session("sqlConn")
        End If

        If sqlConn Is Nothing Then
            sqlConn = New SqlConnection(PrepareDBConnString(strSqlConn))
            'sqlConn = New SqlConnection(strSqlConn)

            HttpContext.Current.Session("sqlConn") = sqlConn
        End If
    End Sub

    Protected Function PrepareDBConnString(ByVal strSqlConn As String) As String
        Dim dbServer As String = ""
        Dim dbDatabase As String = ""
        Dim dbUser As String = ""
        Dim dbPsw As String = ""

        Try
            Dim propertyFile As String = HttpContext.Current.Server.MapPath("~/system.properties")
            Dim propertyHelper As PropertyHelper = New PropertyHelper
            Dim securityHelper As SecurityHelper = New SecurityHelper

            If File.Exists(propertyFile) Then
                Dim sr As New StreamReader(propertyFile)
                propertyHelper.Load(sr)
                dbServer = propertyHelper.GetProperty("[db_server]")
                dbDatabase = propertyHelper.GetProperty("[db_database]")
                dbUser = propertyHelper.GetProperty("[db_user]")
                dbPsw = securityHelper.AESRijndaelManaged_Decrypt(propertyHelper.GetProperty("[db_psw]"), propertyHelper.GetProperty("[key]"))
                sr.Close()
            End If


            If Not String.IsNullOrEmpty(dbServer) And Not String.IsNullOrEmpty(dbDatabase) And Not String.IsNullOrEmpty(dbUser) And Not String.IsNullOrEmpty(dbPsw) Then
                strSqlConn = String.Format(strSqlConn, dbServer, dbDatabase, dbUser, dbPsw)
            End If
        Catch ex As Exception
            logHelper.WriteLog("failed to retrieve database connection parameters.", ex)
            Throw ex
        End Try


        PrepareDBConnString = strSqlConn
    End Function

    Function GetSqlConnection() As SqlConnection

        Try
            'If Not HttpContext.Current.Session("sqlConn") Is Nothing Then
            '    Return HttpContext.Current.Session("sqlConn")
            'End If
            If String.IsNullOrEmpty(_strSqlConnDecrypted) Then
                _strSqlConnDecrypted = PrepareDBConnString(strSqlConn)
            End If
            If sqlConn Is Nothing Then
                sqlConn = New SqlConnection(_strSqlConnDecrypted)
            End If

            If (sqlConn.State = ConnectionState.Closed) Then
                sqlConn.Open()
            End If
        Catch ex As Exception
            logHelper.WriteLog("Failed to get SQL Connection.", ex)
            Throw ex
        End Try
        

        GetSqlConnection = sqlConn

    End Function

    Private Sub CloseSqlConnection()
        If Not (sqlConn.State = ConnectionState.Closed) Then
            sqlConn.Close()
        End If
    End Sub


    Public Function ExecuteNonQuery(ByVal strCmd As String) As Integer
        Dim iQueryResult As Integer

        Try
            sqlCmd = New SqlCommand(strCmd, GetSqlConnection())
            'sqlCmd.CommandType = ct
            iQueryResult = sqlCmd.ExecuteNonQuery
        Catch ex As Exception
            Throw ex
        Finally
            sqlCmd.Dispose()
            CloseSqlConnection()
        End Try

        ExecuteNonQuery = iQueryResult

    End Function

    Public Function ExecuteNonQuery(ByVal strCmd As String, ByVal sqlParams As SqlParameter()) As Integer
        Dim iQueryResult As Integer

        Try
            sqlCmd = New SqlCommand(strCmd, GetSqlConnection())
            'sqlCmd.CommandType = ct
            sqlCmd.Parameters.AddRange(sqlParams)
            iQueryResult = sqlCmd.ExecuteNonQuery

        Catch ex As Exception
            Throw ex
        Finally
            sqlCmd.Dispose()
            CloseSqlConnection()
        End Try

        ExecuteNonQuery = iQueryResult
    End Function

    Public Function ExecuteReaderQuery(ByVal strCmd As String, Optional ByVal sqlParams As SqlParameter() = Nothing, Optional ByVal ct As CommandType = CommandType.Text) As DataTable
        Dim dt As DataTable = New DataTable()

        'logHelper.WriteLog(strCmd)

        Try
            sqlCmd = New SqlCommand(strCmd, GetSqlConnection)
            sqlCmd.CommandType = ct
            If Not sqlParams Is Nothing Then
                sqlCmd.Parameters.Clear()
                sqlCmd.Parameters.AddRange(sqlParams)
            End If

            sqlDr = sqlCmd.ExecuteReader()

            dt.Load(sqlDr)

        Catch ex As Exception
            'Throw ex
            logHelper.WriteLog("Failed to execute query.", ex)
            Throw ex

        Finally
            sqlParams = Nothing
            sqlCmd.Dispose()
            sqlDr.Close()
            CloseSqlConnection()
        End Try

        ExecuteReaderQuery = dt
    End Function



    Public Function ExecuteReaderScalar(ByVal strCmd As String, Optional ByVal sqlParams As SqlParameter() = Nothing, Optional ByVal ct As CommandType = CommandType.Text) As Integer
        Dim iResultId As Integer = 0
        Dim sResult As String = ""

        Try
            sqlCmd = New SqlCommand(strCmd, GetSqlConnection)
            sqlCmd.Parameters.AddRange(sqlParams)

            sResult = sqlCmd.ExecuteScalar().ToString

            If Not sResult Is Nothing Then
                If Not String.IsNullOrEmpty(sResult) Then
                    iResultId = CInt(sResult)
                End If
            End If

        Catch ex As Exception
            Console.Write(ex.Message)
        Finally
            sqlCmd.Dispose()
            CloseSqlConnection()
        End Try

        Return iResultId
    End Function



    Public Function ExecuteAdapterInsert(ByVal sqlSelCmd As String, ByVal dtInsert As DataTable, ByRef id As Integer) As Boolean
        Dim bReturn As Boolean = False

        Dim dtSrc As DataTable = Nothing

        Dim sqlDaConn As SqlConnection = Nothing
        Dim sqlTrans As SqlTransaction = Nothing

        Try
            sqlDa = New SqlDataAdapter

            sqlDaConn = GetSqlConnection()

            sqlTrans = sqlDaConn.BeginTransaction

            If dtInsert Is Nothing Then
                sqlTrans.Rollback()
            Else

                dtSrc = New DataTable

                selCmd = New SqlCommand(sqlSelCmd, sqlDaConn)
                selCmd.Transaction = sqlTrans

                sqlDa.SelectCommand = selCmd
                sqlDa.Fill(dtSrc)

                sqlCmdBuilder = New SqlCommandBuilder(sqlDa)

                'Insert
                Dim InsCmd As SqlCommand = sqlCmdBuilder.GetInsertCommand
                Dim cmdText As String = InsCmd.CommandText
                InsCmd.CommandText = cmdText & IIf(cmdText.EndsWith(";"), "", ";") & " SELECT SCOPE_IDENTITY(); "

                InsCmd.Parameters.Clear()
                Dim dr As DataRow = dtInsert.Rows(0)
                For i As Integer = 1 To dr.ItemArray.Length - 1
                    InsCmd.Parameters.AddWithValue("@p" & i, dr.ItemArray(i))
                Next

                InsCmd.Connection = sqlDaConn
                InsCmd.Transaction = sqlTrans

                sqlDa.InsertCommand = InsCmd

                Dim tmp As Object = sqlDa.InsertCommand.ExecuteScalar()

                If Not tmp Is Nothing And Not IsDBNull(tmp) Then
                    id = CType(tmp, Integer)
                End If

                sqlTrans.Commit()

                bReturn = True
            End If

        Catch ex As Exception
            If Not sqlTrans Is Nothing Then
                sqlTrans.Rollback()
                bReturn = False
            End If

        End Try

        ExecuteAdapterInsert = bReturn
    End Function

    Public Function ExecuteAdapterInsert(ByVal sqlAdapterInserts As SqlAdapterInsert(), ByRef id As Integer, ByVal idColName As String) As Boolean
        Dim bReturn As Boolean = False
        Dim dtSrc As DataTable = Nothing

        Dim sqlDaConn As SqlConnection = Nothing
        Dim sqlTrans As SqlTransaction = Nothing

        Try
            sqlDa = New SqlDataAdapter

            sqlDaConn = GetSqlConnection()

            sqlTrans = sqlDaConn.BeginTransaction

            If sqlAdapterInserts Is Nothing Then
                sqlTrans.Rollback()
            Else

                For i As Integer = 0 To sqlAdapterInserts.Length - 1
                    dtSrc = New DataTable

                    Dim sqlSelCmd As String = sqlAdapterInserts(i).sqlSelCmd
                    Dim dtInsert As DataTable = sqlAdapterInserts(i).dt

                    selCmd = New SqlCommand(sqlSelCmd, sqlDaConn)
                    selCmd.Transaction = sqlTrans

                    sqlDa.SelectCommand = selCmd
                    sqlDa.Fill(dtSrc)

                    sqlCmdBuilder = New SqlCommandBuilder(sqlDa)

                    'Insert
                    Dim InsCmd As SqlCommand = sqlCmdBuilder.GetInsertCommand
                    Dim cmdText As String = InsCmd.CommandText
                    If sqlAdapterInserts(i).returnIdentity Then
                        InsCmd.CommandText = cmdText & IIf(cmdText.EndsWith(";"), "", ";") & " SELECT SCOPE_IDENTITY(); "
                        InsCmd.Parameters.Clear()
                        Dim dr As DataRow = dtInsert.Rows(0)
                        For j As Integer = 1 To dr.ItemArray.Length - 1
                            InsCmd.Parameters.AddWithValue("@p" & j, dr.ItemArray(j))
                        Next

                        InsCmd.Connection = sqlDaConn
                        InsCmd.Transaction = sqlTrans

                        sqlDa.InsertCommand = InsCmd

                        Dim tmp As Object = sqlDa.InsertCommand.ExecuteScalar()

                        If Not tmp Is Nothing And Not IsDBNull(tmp) Then
                            id = CType(tmp, Integer)
                        End If

                    Else
                        InsCmd.Connection = sqlDaConn
                        InsCmd.Transaction = sqlTrans

                        sqlDa.InsertCommand = InsCmd

                        If id > 0 Then
                            For Each drInsert In dtInsert.Rows
                                drInsert(idColName) = id
                            Next
                        End If
                        sqlDa.Update(dtInsert)
                    End If
                Next

                sqlTrans.Commit()

                bReturn = True
            End If

        Catch ex As Exception
            If Not sqlTrans Is Nothing Then
                sqlTrans.Rollback()
            End If

        End Try

        ExecuteAdapterInsert = bReturn
    End Function


    Public Function ExecuteAdapterUpdate(ByVal sqlAdapterUpdates As SqlAdapterUpdate()) As Boolean
        Dim sReturn As Boolean = False
        Dim dtSrc As DataTable = Nothing

        Dim sqlDaConn As SqlConnection = Nothing
        Dim sqlTrans As SqlTransaction = Nothing

        Try
            sqlDa = New SqlDataAdapter

            sqlDaConn = GetSqlConnection()

            sqlTrans = sqlDaConn.BeginTransaction

            If sqlAdapterUpdates Is Nothing Then
                sqlTrans.Rollback()
            Else

                For i As Integer = 0 To sqlAdapterUpdates.Length - 1
                    dtSrc = New DataTable

                    Dim sqlSelCmd As String = sqlAdapterUpdates(i).sqlSelCmd
                    Dim dtUpdate As DataTable = sqlAdapterUpdates(i).dt

                    selCmd = New SqlCommand(sqlSelCmd, sqlDaConn)
                    selCmd.Transaction = sqlTrans

                    sqlDa.SelectCommand = selCmd
                    sqlDa.Fill(dtSrc)

                    sqlCmdBuilder = New SqlCommandBuilder(sqlDa)

                    'Update
                    Dim updCmd As SqlCommand = sqlCmdBuilder.GetUpdateCommand
                    updCmd.Connection = sqlDaConn
                    updCmd.Transaction = sqlTrans

                    sqlDa.UpdateCommand = updCmd


                    'Insert
                    Dim InsCmd As SqlCommand = sqlCmdBuilder.GetInsertCommand
                    InsCmd.Connection = sqlDaConn
                    InsCmd.Transaction = sqlTrans

                    sqlDa.InsertCommand = InsCmd


                    'Delete
                    Dim DelCmd As SqlCommand = sqlCmdBuilder.GetDeleteCommand
                    DelCmd.Connection = sqlDaConn
                    DelCmd.Transaction = sqlTrans

                    sqlDa.DeleteCommand = DelCmd

                    'Execute Changes
                    sqlDa.Update(dtUpdate)
                Next

                sqlTrans.Commit()

                sReturn = True
            End If

        Catch ex As Exception
            If Not sqlTrans Is Nothing Then
                sqlTrans.Rollback()
            End If
            logHelper.WriteLog("Execute error for command", ex)
        End Try

        ExecuteAdapterUpdate = sReturn
    End Function





    Public Sub BulkCopytoDB(ByVal dt As DataTable, ByVal sTable As String)

        Try
            Dim sqlBulkCopy As SqlBulkCopy = New SqlBulkCopy(GetSqlConnection)
            sqlBulkCopy.BatchSize = 2000
            sqlBulkCopy.BulkCopyTimeout = 60
            sqlBulkCopy.DestinationTableName = sTable

            For i As Integer = 0 To dt.Columns.Count - 1
                Dim colName As String = dt.Columns(i).ColumnName
                sqlBulkCopy.ColumnMappings.Add(colName, colName)
            Next

            sqlBulkCopy.WriteToServer(dt)

        Catch ex As Exception
            Console.Write(ex.ToString)
        Finally
            'CloseSqlConnection()
        End Try


    End Sub



End Class
#End Region



