﻿Imports log4net
Imports System.IO


Public Class LogHelper

    Private Sub LogHelper()
        InitConfig(New FileInfo("../log4net.config"))
    End Sub

    Sub New()
        InitConfig(New FileInfo("../log4net.config"))
    End Sub

    Public Shared ReadOnly logInfo As ILog = LogManager.GetLogger("loggerInfo")
    Public Shared ReadOnly logError As ILog = LogManager.GetLogger("loggerError")
    Public Shared ReadOnly logFatal As ILog = LogManager.GetLogger("loggerFatal")


    Public Shared Sub InitConfig()
        Config.XmlConfigurator.Configure()
    End Sub

    Public Shared Sub InitConfig(ByVal configFile As FileInfo)
        Config.XmlConfigurator.Configure(configFile)
    End Sub


    Public Shared Sub WriteLog(ByVal info As String)
        If (logInfo.IsInfoEnabled) Then
            logInfo.Info(info)
        End If
    End Sub

    Public Shared Sub WriteLog(ByVal err As String, ByVal ex As Exception)
        If (logError.IsErrorEnabled) Then
            logError.Error(err, ex)
        End If

        If (logFatal.IsFatalEnabled) Then
            logFatal.Fatal(err, ex)
        End If
    End Sub

    Public Shared Sub WriteDbLog(ByVal logInfo As String, ByVal logErr As String)
        Dim sqlHelper As SqlHelper = New SqlHelper
    End Sub

End Class
