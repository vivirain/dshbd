﻿

#Region "Model"


'11 CSS
Public Class CSS

    Private _score As Decimal
    Public Property score() As Decimal
        Get
            Return _score
        End Get
        Set(ByVal value As Decimal)
            _score = value
        End Set
    End Property

    Private _actualEffort As Decimal
    Public Property actualEffort() As Decimal
        Get
            Return _actualEffort
        End Get
        Set(ByVal value As Decimal)
            _actualEffort = value
        End Set
    End Property

    Public Sub New()
    End Sub

    Public Sub New(ByVal scoreVal As Decimal, ByVal actualEffortVal As Decimal)
        _score = scoreVal
        _actualEffort = actualEffortVal
    End Sub
End Class


Public Class Defect
    Private _criticalDefect As Integer
    Public Property criticalDefect() As Integer
        Get
            Return _criticalDefect
        End Get
        Set(ByVal value As Integer)
            _criticalDefect = value
        End Set
    End Property

    Private _majorDefect As Integer
    Public Property majorDefect() As Integer
        Get
            Return _majorDefect
        End Get
        Set(ByVal value As Integer)
            _majorDefect = value
        End Set
    End Property

    Private _minorDefect As Integer
    Public Property minorDefect() As Integer
        Get
            Return _minorDefect
        End Get
        Set(ByVal value As Integer)
            _minorDefect = value
        End Set
    End Property

    Private _trivialDefect As Integer
    Public Property trivialDefect() As Integer
        Get
            Return _trivialDefect
        End Get
        Set(ByVal value As Integer)
            _trivialDefect = value
        End Set
    End Property
End Class


Public Class BauDefect
    Private _uatDefect As Defect
    Public Property uatDefect() As Defect
        Get
            Return _uatDefect
        End Get
        Set(ByVal value As Defect)
            _uatDefect = value
        End Set
    End Property

    Private _actualEffort As Decimal
    Public Property actualEffort() As Decimal
        Get
            Return _actualEffort
        End Get
        Set(ByVal value As Decimal)
            _actualEffort = value
        End Set
    End Property
End Class

Public Class PrjDefect
    Private _uatDefect As Defect
    Public Property uatDefect() As Defect
        Get
            Return _uatDefect
        End Get
        Set(ByVal value As Defect)
            _uatDefect = value
        End Set
    End Property

    Private _prdDefect As Defect
    Public Property prdDefect() As Defect
        Get
            Return _prdDefect
        End Get
        Set(ByVal value As Defect)
            _prdDefect = value
        End Set
    End Property

    Private _actualEffort As Decimal
    Public Property actualEffort() As Decimal
        Get
            Return _actualEffort
        End Get
        Set(ByVal value As Decimal)
            _actualEffort = value
        End Set
    End Property
End Class


Public Class DefectRemoval
    Private _sitDefect As Integer
    Public Property sitDefect() As Integer
        Get
            Return _sitDefect
        End Get
        Set(ByVal value As Integer)
            _sitDefect = value
        End Set
    End Property

    Private _uatDefect As Defect
    Public Property uatDefect() As Defect
        Get
            Return _uatDefect
        End Get
        Set(ByVal value As Defect)
            _uatDefect = value
        End Set
    End Property
End Class

Public Class UatInitPass
    Private _uatInitPassCase As Integer
    Public Property uatInitPassCase() As Integer
        Get
            Return _uatInitPassCase
        End Get
        Set(ByVal value As Integer)
            _uatInitPassCase = value
        End Set
    End Property

    Private _uatExecutedCase As Integer
    Public Property uatExecutedCase() As Integer
        Get
            Return _uatExecutedCase
        End Get
        Set(ByVal value As Integer)
            _uatExecutedCase = value
        End Set
    End Property
End Class

Public Class DefectReOpen
    Private _reopenDefect As Integer
    Public Property reopenDefect() As Integer
        Get
            Return _reopenDefect
        End Get
        Set(ByVal value As Integer)
            _reopenDefect = value
        End Set
    End Property

    Private _defect As Defect
    Public Property defect() As Defect
        Get
            Return _defect
        End Get
        Set(ByVal value As Defect)
            _defect = value
        End Set
    End Property
End Class

Public Class CostOfPoorQuality
    Private _failureEffort As Decimal
    Public Property failureEffort() As Decimal
        Get
            Return _failureEffort
        End Get
        Set(ByVal value As Decimal)
            _failureEffort = value
        End Set
    End Property

    Private _actualEffort As Decimal
    Public Property actualEffort() As Decimal
        Get
            Return _actualEffort
        End Get
        Set(ByVal value As Decimal)
            _actualEffort = value
        End Set
    End Property

    Public Sub New()
    End Sub

    Public Sub New(ByVal failureEffortVal As Decimal, ByVal actualEffortVal As Decimal)
        _failureEffort = failureEffortVal
        _actualEffort = actualEffortVal
    End Sub
End Class


Public Class OnTimeIncident
    Private _onTime As Integer
    Public Property onTime() As Integer
        Get
            Return _onTime
        End Get
        Set(ByVal value As Integer)
            _onTime = value
        End Set
    End Property

    Private _receivedIncident As Integer
    Property receivedIncident() As Integer
        Get
            Return _receivedIncident
        End Get
        Set(ByVal value As Integer)
            _receivedIncident = value
        End Set
    End Property

    Public Sub New()
    End Sub

    Public Sub New(ByVal onTimeVal As Integer, ByVal receivedIncidentVal As Integer)
        _onTime = onTimeVal
        _receivedIncident = receivedIncidentVal
    End Sub
End Class


Public Class TaskOnSchedule
    Private _taskCompleteUnderControl As Integer
    Public Property taskCompletedUnderControl() As Integer
        Get
            Return _taskCompleteUnderControl
        End Get
        Set(ByVal value As Integer)
            _taskCompleteUnderControl = value
        End Set
    End Property

    Private _taskCompleted As Integer
    Public Property taskCompleted() As Integer
        Get
            Return _taskCompleted
        End Get
        Set(ByVal value As Integer)
            _taskCompleted = value
        End Set
    End Property
End Class


#End Region

#Region "Service"

Public Class MetricHelper

    '11 CSS
    Public Shared Function CSS(ByVal cssList As CSS()) As Decimal
        Dim decReturn As Decimal

        If cssList Is Nothing Then
            Return Nothing
        End If

        If cssList.Length = 0 Then
            Return Nothing
        End If


        Dim totCss As Decimal
        Dim totEffort As Decimal
        Dim totCssEffort As Decimal

        For i As Integer = 0 To cssList.Length - 1
            If IsNumeric(cssList(i).score) Then
                totCss = totCss + cssList(i).score
                totEffort = totEffort + cssList(i).actualEffort
                totCssEffort = totCssEffort + cssList(i).score * cssList(i).actualEffort
                'totEffort = totEffort + cssList(i).score * IIf(IsNumeric(cssList(i).actualEffort), cssList(i).actualEffort, 0)
                'totCssEffort = totCssEffort + cssList(i).score * (cssList(i).score * IIf(IsNumeric(cssList(i).actualEffort), cssList(i).actualEffort, 0))
            End If
        Next

        decReturn = IIf(totEffort = 0, 0, (totCssEffort / totEffort) * 0.5) + (totCss / cssList.Length) * 0.5

        CSS = decReturn
    End Function



    '21 & 22 S1 / S2 Incident
    Public Shared Function Incident(ByVal incidents As Integer()) As Integer
        Dim iReturn As Integer = 0

        If incidents Is Nothing Then
            Return iReturn
        End If

        If incidents.Length = 0 Then
            Return iReturn
        End If

        For i As Integer = 0 To incidents.Length - 1
            iReturn = iReturn + incidents(i)
        Next

        Incident = iReturn
    End Function

    '23 Bau Defect Rate
    Public Shared Function BauDefectRate(ByVal bauDefects As BauDefect()) As Decimal
        Dim decReturn As Decimal

        If bauDefects Is Nothing Then
            Return decReturn
        ElseIf bauDefects.Length = 0 Then
            Return decReturn
        End If

        Dim totCritical As Integer = 0
        Dim totMajor As Integer = 0
        Dim totMinor As Integer = 0
        Dim totTrivial As Integer = 0

        Dim totEffort As Decimal

        For i As Integer = 0 To bauDefects.Length - 1
            Dim uatDefect As Defect
            uatDefect = bauDefects(i).uatDefect

            totCritical = totCritical + IIf(IsNumeric(uatDefect.criticalDefect), uatDefect.criticalDefect, 0)
            totMajor = totMajor + IIf(IsNumeric(uatDefect.majorDefect), uatDefect.majorDefect, 0)
            totMinor = totMinor + IIf(IsNumeric(uatDefect.minorDefect), uatDefect.minorDefect, 0)
            totTrivial = totTrivial + IIf(IsNumeric(uatDefect.trivialDefect), uatDefect.trivialDefect, 0)

            totEffort = totEffort + IIf(IsNumeric(bauDefects(i).actualEffort), bauDefects(i).actualEffort, 0)

        Next

        If totEffort <> 0 Then
            decReturn = ((totCritical * 9 + totMajor * 3 + totMinor + totTrivial / 3) / totEffort) * 150
        End If

        BauDefectRate = decReturn
    End Function

    '24 Project Defect Rate
    Public Shared Function PrjDefectRate(ByVal prjDefects As PrjDefect()) As Decimal
        Dim decReturn As Decimal

        If prjDefects Is Nothing Then
            Return decReturn
        ElseIf prjDefects.Length = 0 Then
            Return decReturn
        End If

        Dim totCritical As Integer = 0
        Dim totMajor As Integer = 0
        Dim totMinor As Integer = 0
        Dim totTrivial As Integer = 0

        Dim totEffort As Decimal

        For i As Integer = 0 To prjDefects.Length - 1
            Dim uatDefect As Defect
            Dim prdDefect As Defect
            uatDefect = prjDefects(i).uatDefect
            prdDefect = prjDefects(i).prdDefect

            If Not uatDefect Is Nothing Then
                totCritical = totCritical + IIf(IsNumeric(uatDefect.criticalDefect), uatDefect.criticalDefect, 0)
                totMajor = totMajor + IIf(IsNumeric(uatDefect.majorDefect), uatDefect.majorDefect, 0)
                totMinor = totMinor + IIf(IsNumeric(uatDefect.minorDefect), uatDefect.minorDefect, 0)
                totTrivial = totTrivial + IIf(IsNumeric(uatDefect.trivialDefect), uatDefect.trivialDefect, 0)
            End If

            If Not prdDefect Is Nothing Then
                totCritical = totCritical + IIf(IsNumeric(prdDefect.criticalDefect), prdDefect.criticalDefect, 0)
                totMajor = totMajor + IIf(IsNumeric(prdDefect.majorDefect), prdDefect.majorDefect, 0)
                totMinor = totMinor + IIf(IsNumeric(prdDefect.minorDefect), prdDefect.minorDefect, 0)
                totTrivial = totTrivial + IIf(IsNumeric(prdDefect.trivialDefect), prdDefect.trivialDefect, 0)
            End If


            totEffort = totEffort + IIf(IsNumeric(prjDefects(i).actualEffort), prjDefects(i).actualEffort, 0)

        Next

        If totEffort <> 0 Then
            decReturn = ((totCritical * 9 + totMajor * 3 + totMinor + totTrivial / 3) / totEffort) * 150
        End If

        PrjDefectRate = decReturn
    End Function

    '25 UAT Defect Removal Rate
    Public Shared Function UatDefectRemovalRate(ByVal defectRemovals As DefectRemoval()) As Decimal
        Dim decReturn As Decimal = New Decimal(0)

        If defectRemovals Is Nothing Then
            Return Nothing
        ElseIf defectRemovals.Length = 0 Then
            Return Nothing
        End If


        Dim totSIT As Integer = 0
        Dim totUatCritical As Integer = 0
        Dim totUatMajor As Integer = 0
        Dim totUatMinor As Integer = 0
        Dim totUatTrivial As Integer = 0
        Dim totDefects As Integer = 0

        For i As Integer = 0 To defectRemovals.Length - 1
            totSIT = totSIT + IIf(IsNumeric(defectRemovals(i).sitDefect), defectRemovals(i).sitDefect, 0)

            If Not defectRemovals(i).uatDefect Is Nothing Then
                Dim uatDefect As Defect = New Defect
                uatDefect = defectRemovals(i).uatDefect
                If Not uatDefect Is Nothing Then
                    totUatCritical = totUatCritical + IIf(IsNumeric(uatDefect.criticalDefect), uatDefect.criticalDefect, 0)
                    totUatMajor = totUatMajor + IIf(IsNumeric(uatDefect.majorDefect), uatDefect.majorDefect, 0)
                    totUatMinor = totUatMinor + IIf(IsNumeric(uatDefect.minorDefect), uatDefect.minorDefect, 0)
                    totUatTrivial = totUatTrivial + IIf(IsNumeric(uatDefect.trivialDefect), uatDefect.trivialDefect, 0)
                End If
            End If
        Next

        totDefects = totSIT + totUatCritical + totUatMajor + totUatMinor + totUatTrivial


        If totDefects <> 0 Then
            decReturn = totSIT / totDefects
        End If

        UatDefectRemovalRate = decReturn
    End Function

    '26 UAT Initial Pass Ratio
    Public Shared Function UatInitPassRate(ByVal uatInitPassCases As UatInitPass()) As Decimal
        Dim decReturn As Decimal

        If uatInitPassCases Is Nothing Then
            Return Nothing
        ElseIf uatInitPassCases.Length = 0 Then
            Return Nothing
        End If

        Dim totUatInitPass As Integer = 0
        Dim totUatExecuted As Integer = 0

        For i As Integer = 0 To uatInitPassCases.Length - 1
            totUatInitPass = totUatInitPass + iif(IsNumeric(uatInitPassCases(i).uatInitPassCase), uatInitPassCases(i).uatInitPassCase, 0)
            totUatExecuted = totUatExecuted + IIf(IsNumeric(uatInitPassCases(i).uatExecutedCase), uatInitPassCases(i).uatExecutedCase, 0)
        Next


        If totUatExecuted <> 0 Then
            decReturn = totUatInitPass / totUatExecuted
        End If

        UatInitPassRate = decReturn
    End Function

    '27 UAT Defect Re-Open Rate
    Public Shared Function DefectReopenRate(ByVal defectReopens As DefectReOpen()) As Decimal
        Dim decReturn As Decimal

        If defectReopens Is Nothing Then
            Return decReturn
        ElseIf defectReopens.Length = 0 Then
            Return decReturn
        End If

        Dim totDefectReopn As Integer = 0
        Dim totUatDefects As Integer = 0

        For i As Integer = 0 To defectReopens.Length - 1
            totDefectReopn = totDefectReopn + IIf(IsNumeric(defectReopens(i).reopenDefect), defectReopens(i).reopenDefect, 0)

            If Not defectReopens(i).defect Is Nothing Then
                Dim uatDefect As Defect = defectReopens(i).defect
                totUatDefects = totUatDefects + IIf(uatDefect.criticalDefect, uatDefect.criticalDefect, 0)
                totUatDefects = totUatDefects + IIf(uatDefect.majorDefect, uatDefect.majorDefect, 0)
                totUatDefects = totUatDefects + IIf(uatDefect.minorDefect, uatDefect.minorDefect, 0)
                totUatDefects = totUatDefects + IIf(uatDefect.trivialDefect, uatDefect.trivialDefect, 0)
            End If
        Next

        If totUatDefects <> 0 Then
            decReturn = totDefectReopn / totUatDefects
        End If

        DefectReopenRate = decReturn
    End Function

    '28 Cost of Poor Quality
    Public Shared Function CostOfPoorQuality(ByVal cpqs As CostOfPoorQuality()) As Decimal
        Dim decReturn As Decimal

        If cpqs Is Nothing Then
            Return decReturn
        ElseIf cpqs.Length = 0 Then
            Return decReturn
        End If

        Dim totFailureEffort As Decimal
        Dim totActualEffort As Decimal


        For i As Integer = 0 To cpqs.Length - 1
            totFailureEffort = totFailureEffort + IIf(IsNumeric(cpqs(i).failureEffort), cpqs(i).failureEffort, 0)
            totActualEffort = totActualEffort + IIf(IsNumeric(cpqs(i).actualEffort), cpqs(i).actualEffort, 0)
        Next


        If totActualEffort <> 0 Then
            decReturn = totFailureEffort / totActualEffort
        End If

        CostOfPoorQuality = decReturn
    End Function



    '31 On-time Response Rate
    '32 On-teim Resolution Rate
    Public Shared Function OnTimeRate(ByVal onTimeIncidents As OnTimeIncident()) As Nullable(Of Decimal)
        Dim decReturn As Nullable(Of Decimal)

        If onTimeIncidents Is Nothing Then
            Return decReturn
        ElseIf onTimeIncidents.Length = 0 Then
            Return decReturn
        End If

        Dim totOnTimeIncidents As Integer = 0
        Dim totReceivedIncidents As Integer = 0

        For i As Integer = 0 To onTimeIncidents.Length - 1
            totOnTimeIncidents = totOnTimeIncidents + IIf(IsNumeric(onTimeIncidents(i).onTime), onTimeIncidents(i).onTime, 0)
            totReceivedIncidents = totReceivedIncidents + IIf(IsNumeric(onTimeIncidents(i).receivedIncident), onTimeIncidents(i).receivedIncident, 0)
        Next

        If totReceivedIncidents > 0 Then
            decReturn = totOnTimeIncidents / totReceivedIncidents
        End If

        OnTimeRate = decReturn
    End Function



    '41 Task On Schedule Rate
    Public Shared Function TaskOnSchedulRate(ByVal taskOnSchedules As TaskOnSchedule()) As Decimal
        Dim decReturn As Decimal

        If taskOnSchedules Is Nothing Then
            Return decReturn
        ElseIf taskOnSchedules.Length = 0 Then
            Return decReturn
        End If

        Dim totTaskOnSchedule As Integer = 0
        Dim totTaskCompleted As Integer = 0

        For i As Integer = 0 To taskOnSchedules.Count - 1
            totTaskOnSchedule = IIf(IsNumeric(taskOnSchedules(i).taskCompletedUnderControl), taskOnSchedules(i).taskCompletedUnderControl, 0)
            totTaskCompleted = IIf(IsNumeric(taskOnSchedules(i).taskCompleted), taskOnSchedules(i).taskCompleted, 0)
        Next

        If totTaskCompleted > 0 Then
            decReturn = totTaskOnSchedule / totTaskCompleted
        End If

        TaskOnSchedulRate = decReturn

    End Function

    '42 SPI
    Public Shared Function SPI(ByVal EV As Decimal, ByVal PV As Decimal) As Decimal
        Dim decReturn As Decimal = New Decimal

        If IsNumeric(PV) Then
            If PV = 0 Then
                Return decReturn
            Else
                decReturn = IIf(IsNumeric(EV), EV, 0) / PV
            End If
        End If


        SPI = decReturn
    End Function

    '43 CPI
    Public Shared Function CPI(ByVal EV As Decimal, ByVal AC As Decimal) As Decimal
        Dim decReturn As Decimal

        If IsNumeric(AC) Then
            If AC = 0 Then
                Return decReturn
            End If
        End If
        If AC.Equals(New Decimal(0)) Then
            Return decReturn
        Else
            decReturn = IIf(IsNumeric(EV), EV, 0) / AC
        End If

        CPI = decReturn
    End Function


End Class

#End Region