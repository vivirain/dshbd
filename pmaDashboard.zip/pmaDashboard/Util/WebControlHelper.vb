﻿Imports System.Data
Imports System.Web.UI.WebControls


Public Class WebControlHelper


    Private Shared emptyText As String = "No records."

    Private _sortDirection As String

    Public Property CurrentSortingDirection() As String
        Get
            Return _sortDirection
        End Get
        Set(value As String)
            _sortDirection = value
        End Set
    End Property


    Public Sub WebControlHelper()
    End Sub


    Public Shared Sub ResetGridView(ByVal gv As GridView, Optional showEmptyText As Boolean = True)
        Dim cell0Text As String = IIf(showEmptyText, emptyText, "")

        If (gv.Rows.Count = 1 And gv.Rows(0).Cells(0).Text = cell0Text) Then
            Dim colCount As Integer = gv.Columns.Count
            gv.Rows(0).Cells.Clear()

            gv.Rows(0).Cells.Add(New TableCell())
            gv.Rows(0).Cells(0).ColumnSpan = colCount
            gv.Rows(0).Cells(0).Text = cell0Text
            gv.Rows(0).Cells(0).Style.Add("text-align", "center")

        End If
    End Sub


    Public Shared Sub GridViewDataBind(ByVal gv As GridView, ByVal dt As DataTable, Optional showEmptyText As Boolean = True)
        If dt Is Nothing Then
            Return
        ElseIf dt.Rows.Count = 0 Then
            Dim dtEmpty As DataTable = New DataTable

            dtEmpty = dt.Clone

            Dim dr As DataRow = dtEmpty.NewRow

            For i As Integer = 0 To dtEmpty.Columns.Count - 1
                If Not dtEmpty.Columns(i).AllowDBNull Then
                    If dtEmpty.Columns(i).DataType.IsEquivalentTo(GetType(String)) Then
                        dr(i) = ""
                    ElseIf dtEmpty.Columns(i).DataType.IsEquivalentTo(GetType(Int32)) Then
                        dr(i) = 0
                    ElseIf dtEmpty.Columns(i).DataType.IsEquivalentTo(GetType(Date)) Then
                        dr(i) = Now
                    End If
                End If
            Next

            dtEmpty.Rows.Add(dr)

            gv.DataSource = dtEmpty
            gv.DataBind()


            Dim colCount As Integer = dtEmpty.Columns.Count
            Dim cell0Text As String = IIf(showEmptyText, emptyText, "")

            If Not gv Is Nothing Then
                If gv.Rows.Count > 0 Then
                    gv.Rows(0).Cells.Clear()
                    gv.Rows(0).Cells.Add(New TableCell())
                    gv.Rows(0).Cells(0).ColumnSpan = colCount
                    gv.Rows(0).Cells(0).Text = cell0Text
                    gv.Rows(0).Cells(0).Style.Add("text-align", "center")
                End If

            End If


        Else
            gv.DataSource = dt
            gv.DataBind()
        End If

        gv.UseAccessibleHeader = True
        'gv.HeaderRow.TableSection = TableRowSection.TableHeader

        gv.SelectedIndex = -1
    End Sub

    Public Shared Sub GridViewCellMerging(ByRef gv As GridView, ByRef e As System.Web.UI.WebControls.GridViewRowEventArgs, ByVal colIndex As Integer, ByRef gvMasterRow As Integer)
        Dim rowIndex As Integer = e.Row.RowIndex

        If rowIndex - 1 < 0 Then
            Return
        End If

        If e.Row.Cells(colIndex).Text = gv.Rows(rowIndex - 1).Cells(colIndex).Text Then
            If gv.Rows(gvMasterRow).Cells(colIndex).RowSpan = 0 Then
                gv.Rows(gvMasterRow).Cells(colIndex).RowSpan = gv.Rows(gvMasterRow).Cells(colIndex).RowSpan + 1
            End If
            gv.Rows(gvMasterRow).Cells(colIndex).RowSpan = gv.Rows(gvMasterRow).Cells(colIndex).RowSpan + 1
            e.Row.Cells(colIndex).Visible = False
        Else
            gvMasterRow = rowIndex
        End If
    End Sub

    Public Shared Sub GridViewRowCreated(ByRef gv As GridView, ByRef e As System.Web.UI.WebControls.GridViewRowEventArgs, ByRef currentSortExpression As String, ByRef currentSortDirection As String)
        If e.Row.RowType = DataControlRowType.Header And gv.AllowSorting = True Then

            For Each cell As TableCell In e.Row.Cells
                If cell.HasControls() Then
                    Dim lb As LinkButton = CType(cell.Controls(0), LinkButton)
                    If Not lb Is Nothing Then
                        Dim iSort As HtmlGenericControl = New HtmlGenericControl("i")
                        iSort.Attributes.Add("class", "fa fa-sort")

                        If lb.CommandArgument = currentSortExpression Then
                            If currentSortDirection.ToUpper = "ASC" Then
                                iSort.Attributes.Remove("class")
                                iSort.Attributes.Add("class", "fa fa-sort-up")
                            ElseIf currentSortDirection.ToUpper = "DESC" Then
                                iSort.Attributes.Remove("class")
                                iSort.Attributes.Add("class", "fa fa-sort-down")
                            End If

                        End If

                        cell.Controls.Add(iSort)

                    End If
                End If
            Next
        End If
    End Sub

    Public Shared Sub GridViewSorting(ByRef gv As GridView, ByRef e As System.Web.UI.WebControls.GridViewSortEventArgs, ByRef dt As DataTable)

        If dt Is Nothing OrElse gv.Rows.Count = 0 Then
            GridViewDataBind(gv, dt)
            Return
        End If

        Dim currentSortExpression As String = e.SortExpression.ToString
        Dim currentSortDirection As String = "ASC"


        If currentSortExpression = gv.Attributes("sortExpression") Then
            currentSortDirection = "ASC"

            If currentSortDirection = gv.Attributes("sortDirection") Then
                currentSortDirection = "DESC"
            End If
        End If

        gv.Attributes("sortExpression") = currentSortExpression
        gv.Attributes("sortDirection") = currentSortDirection

        dt.DefaultView.Sort = String.Format("{0} {1}", currentSortExpression, currentSortDirection)

        gv.DataSource = dt
        gv.DataBind()
    End Sub

    Public Shared Sub DropDownListDataBind(ByVal ddl As DropDownList, ByVal dt As DataTable, ByVal dataTextField As String, ByVal dataValueField As String, Optional ByVal showBlankValue As Boolean = True, Optional showBoth As Boolean = False)
        If Not dt Is Nothing Then
            ddl.Items.Clear()
            ddl.SelectedIndex = -1
            ddl.SelectedValue = Nothing
            ddl.ClearSelection()


            If showBlankValue Then
                ddl.Items.Add(New ListItem("", ""))
                ddl.AppendDataBoundItems = True
            End If

            ddl.DataSource = dt

            ddl.DataValueField = dataValueField
            ddl.DataTextField = dataTextField

            ddl.DataBind()
        End If
    End Sub

    Public Shared Sub ListBoxDataBind(ByVal lb As ListBox, ByVal dt As DataTable, ByVal dataTextField As String, ByVal dataValueField As String)
        lb.Items.Clear()
        If Not lb Is Nothing Then

            lb.DataSource = dt
            lb.DataValueField = dataValueField
            lb.DataTextField = dataTextField

            lb.DataBind()
        End If
    End Sub

    Public Shared Sub InitSortingIcon(ByRef gv As GridView)
        For Each headerCell As TableCell In gv.HeaderRow.Cells
            If headerCell.HasControls() Then
                Dim lb As LinkButton = CType(headerCell.Controls(0), LinkButton)
                If Not lb Is Nothing Then
                    Dim iSort As HtmlGenericControl = New HtmlGenericControl("i")
                    iSort.Attributes.Add("class", "fa fa-sort")

                    If lb.CommandArgument = gv.Attributes("sortExpression") Then
                        If gv.Attributes("sortDirection") = "ASC" Then
                            iSort.Attributes.Remove("class")
                            iSort.Attributes.Add("class", "fa fa-sort-up")
                        ElseIf gv.Attributes("sortDirection") = "DESC" Then
                            iSort.Attributes.Remove("class")
                            iSort.Attributes.Add("class", "fa fa-sort-down")
                        End If
                    End If
                    headerCell.Controls.Add(iSort)

                End If
            End If
        Next
    End Sub

End Class
