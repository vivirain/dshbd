﻿Imports System
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text


Public Class SecurityHelper

    Dim ivHex As String = "000102030405060708090A0B0C0D0E0F"

    Const key As String = "abcdeABCDE1234567890!@#$%&*^_+=-"

    Public Function AESRijndaelManaged_Encrypt(ByVal encryptSrc As String, ByVal encryptKey As String) As String

        Dim _key As String = ""

        If String.IsNullOrEmpty(encryptSrc.Trim) Then
            Return String.Empty
        End If

        If String.IsNullOrEmpty(encryptKey.Trim) Then
            _key = key
        ElseIf encryptKey.Trim.Length > 32 Then
            _key = Left(encryptKey.Trim, 32)
        ElseIf encryptKey.Trim.Length < 32 Then
            _key = encryptKey.PadRight(32, "0")
        End If

        Dim keyBytes As Byte() = UTF8Encoding.UTF8.GetBytes(_key)
        Dim encryptSrcBytes As Byte() = UTF8Encoding.UTF8.GetBytes(encryptSrc)


        Dim _rijndaelManaged As RijndaelManaged = New RijndaelManaged()
        _rijndaelManaged.Key = keyBytes
        _rijndaelManaged.Mode = CipherMode.ECB
        _rijndaelManaged.Padding = PaddingMode.PKCS7

        Dim _cryptoTransform As ICryptoTransform = _rijndaelManaged.CreateEncryptor()

        Dim _encryptedBytes As Byte() = _cryptoTransform.TransformFinalBlock(encryptSrcBytes, 0, encryptSrcBytes.Length)

        AESRijndaelManaged_Encrypt = Convert.ToBase64String(_encryptedBytes, 0, _encryptedBytes.Length)
    End Function

    Public Function AESRijndaelManaged_Decrypt(ByVal decryptSrc As String, ByVal decryptKey As String) As String
        Dim _key As String = ""

        If String.IsNullOrEmpty(decryptSrc.Trim) Then
            Return String.Empty
        End If

        If String.IsNullOrEmpty(decryptKey.Trim) Then
            _key = key
        ElseIf decryptKey.Trim.Length > 32 Then
            _key = Left(decryptKey.Trim, 32)
        ElseIf decryptKey.Trim.Length < 32 Then
            _key = decryptKey.PadRight(32, "0")
        End If

        Dim keyBytes As Byte() = UTF8Encoding.UTF8.GetBytes(_key)
        Dim decryptSrcBytes As Byte() = Convert.FromBase64String(decryptSrc)


        Dim _rijndaelManaged As RijndaelManaged = New RijndaelManaged()
        _rijndaelManaged.Key = keyBytes
        _rijndaelManaged.Mode = CipherMode.ECB
        _rijndaelManaged.Padding = PaddingMode.PKCS7

        Dim _cryptoTransform As ICryptoTransform = _rijndaelManaged.CreateDecryptor

        Dim _decryptedBytes As Byte() = _cryptoTransform.TransformFinalBlock(decryptSrcBytes, 0, decryptSrcBytes.Length)

        AESRijndaelManaged_Decrypt = UTF8Encoding.UTF8.GetString(_decryptedBytes, 0, _decryptedBytes.Length)
    End Function

    Public Function AESCryptServiceProvider_Encrypt(ByVal encryptSrc As String, encryptKey As String) As String
        Dim _encrypted As String = ""

        If String.IsNullOrEmpty(encryptSrc) Then
            Return String.Empty
        ElseIf String.IsNullOrEmpty(encryptKey) Then
            Return String.Empty
        End If

        Dim _aesCryptoServiceProvider As AesCryptoServiceProvider = New AesCryptoServiceProvider
        _aesCryptoServiceProvider.IV = Encoding.UTF8.GetBytes(ivHex)

        _aesCryptoServiceProvider.Key = GetAesKey(encryptKey)

        _aesCryptoServiceProvider.Mode = CipherMode.ECB
        _aesCryptoServiceProvider.Padding = PaddingMode.PKCS7

        Dim _cryptoTransform As ICryptoTransform = _aesCryptoServiceProvider.CreateEncryptor

        Try
            Dim _encryptSrcBytes As Byte() = Encoding.UTF8.GetBytes(encryptSrc)

            _encrypted = _cryptoTransform.TransformFinalBlock(_encryptSrcBytes, 0, _encryptSrcBytes.Length).ToString
        Catch ex As Exception

        End Try

        AESCryptServiceProvider_Encrypt = _encrypted


    End Function


    Public Function AESCryptServiceProvider_Decrypt(ByVal decryptSrc As String, decryptKey As String) As String
        Dim _decrypted As String = ""

        If String.IsNullOrEmpty(decryptSrc) Then
            Return String.Empty
        ElseIf String.IsNullOrEmpty(decryptSrc) Then
            Return String.Empty
        End If

        Dim _aesCryptoServiceProvider As AesCryptoServiceProvider = New AesCryptoServiceProvider
        _aesCryptoServiceProvider.GenerateIV()

        _aesCryptoServiceProvider.Key = GetAesKey(decryptKey)
        _aesCryptoServiceProvider.Mode = CipherMode.ECB
        _aesCryptoServiceProvider.Padding = PaddingMode.PKCS7

        Dim _cryptoTransform As ICryptoTransform = _aesCryptoServiceProvider.CreateDecryptor

        Try
            Dim _decryptSrcBytes As Byte() = Encoding.UTF8.GetBytes(decryptSrc)

            _decrypted = _cryptoTransform.TransformFinalBlock(_decryptSrcBytes, 0, _decryptSrcBytes.Length).ToString
        Catch ex As Exception

        End Try

        AESCryptServiceProvider_Decrypt = _decrypted


    End Function

    Private Function GetAesKey(ByVal encryptKey As String) As Byte()
        If String.IsNullOrEmpty(encryptKey) Then
            Return Nothing
        ElseIf encryptKey.Length < 32 Then
            encryptKey = encryptKey.PadRight(32, "0")
        ElseIf encryptKey.Length > 32 Then
            encryptKey = encryptKey.Substring(0, 32)
        End If

        Return Encoding.UTF8.GetBytes(encryptKey)
    End Function

End Class
