﻿Imports System.Net
Imports System.Net.Mail
Imports System.Net.NetworkCredential

Public Class ErrorHelper

    Dim lookupService As ILookupService = New LookupService

    Public Function SendEmail(ByVal emailTo As String(), ByVal emailSubject As String, ByVal emailBody As String) As Boolean

        Dim bSent As Boolean = False

        If emailTo Is Nothing Then
            Return bSent
        ElseIf emailTo.Length = 0 Then
            Return bSent
        End If

        'Email Server
        Dim smtpClient As SmtpClient = New SmtpClient
        smtpClient.Host = ""
        smtpClient.Port = ""


        'Email
        Dim mail As MailMessage = New MailMessage
        mail.From = New MailAddress("")
        For i As Integer = 0 To emailTo.Length - 1
            mail.To.Add(emailTo(i))
        Next
        mail.Subject = emailSubject
        mail.Body = emailBody

        Try
            smtpClient.Send(mail)
            bSent = True
        Catch ex As Exception

        End Try

        SendEmail = bSent

    End Function


    Public Shared Sub ShowErrors()
        Dim sError As String = ""

        Dim currentError As Exception = HttpContext.Current.Server.GetLastError

        sError = currentError.Message

    End Sub

    Public Shared Function IsSessionExpired() As Boolean
        If HttpContext.Current.Session Is Nothing Then
            If (HttpContext.Current.Session.IsNewSession) Then

                Dim cookieHeader As String = HttpContext.Current.Request.Headers("Cookie")

                If IsNothing(cookieHeader) And (cookieHeader.IndexOf("ASP.NET_SessionId") >= 0) Then
                    Return True
                End If
            End If
        End If

        Return False
    End Function



End Class
