﻿Imports Quartz
Imports Quartz.Impl
Imports System
Imports System.Net
Imports System.Net.Mail



Public Class ScheduleJob

    Public Shared _scheduler As IScheduler = Nothing

    Public Shared site As String = ""

    Public Shared Sub Start(ByVal siteUrl As String)

        Dim _schedulerFactory As ISchedulerFactory
        Dim scheduleJobService As IScheduleJobService = New ScheduleJobService
        Dim emailJobService As IEmailJobService = New EmailJobService

        site = siteUrl

        'Dim siteUrl As String = ""

        Try
            'siteUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & HttpRuntime.AppDomainAppVirtualPath

            'Schedule Job - Email Push
            Dim dtEmailJob As DataTable = scheduleJobService.GetEmailScheduleJob()
            If dtEmailJob Is Nothing OrElse dtEmailJob.Rows.Count = 0 Then
                LogHelper.WriteLog("No Email Reminder Jobs are schedule.")
            End If
            'Get a scheduler, start the schedular before triggers or anything else

            _schedulerFactory = New StdSchedulerFactory
            _scheduler = _schedulerFactory.GetScheduler()

            For Each drEmailJob As DataRow In dtEmailJob.Rows
                Dim _emailJobId As Integer = drEmailJob("job_id")
                Dim _emailJobName As String = drEmailJob("job_name").ToString
                Dim _emailJobCronExp As String = drEmailJob("cron_express").ToString
                Dim _emailSentBySbu As String = drEmailJob("send_by_sbu").ToString
                If String.IsNullOrEmpty(_emailSentBySbu) Then
                    _emailSentBySbu = "N"
                End If

                If drEmailJob("is_active").ToString.ToUpper = "Y" Then
                    'Create job
                    Dim _emailJob As IJobDetail
                    Dim _emailTrigger As ITrigger = TriggerBuilder.Create.WithCronSchedule(_emailJobCronExp).Build
                    Dim _emailJobKey As JobKey = New JobKey(_emailJobName)

                    Select Case _emailJobName
                        Case SCHEDULEJOBNAME.PROFILENEWSUBMITTED
                            _emailJob = JobBuilder.Create(Of ProfileNewSubmittedJob)().WithIdentity(_emailJobName).Build
                            _emailJob.JobDataMap("siteUrl") = siteUrl
                            _emailJob.JobDataMap("sendBySbu") = _emailSentBySbu
                            _emailJob.JobDataMap("jobId") = _emailJobId
                            _scheduler.ScheduleJob(_emailJob, _emailTrigger)

                        Case SCHEDULEJOBNAME.PROFILEUPDATE
                            _emailJob = JobBuilder.Create(Of ProfileUpdateReminderJob)().WithIdentity(_emailJobName).Build
                            _emailJob.JobDataMap("siteUrl") = siteUrl
                            _emailJob.JobDataMap("sendBySbu") = _emailSentBySbu
                            _emailJob.JobDataMap("jobId") = _emailJobId
                            _scheduler.ScheduleJob(_emailJob, _emailTrigger)

                        Case SCHEDULEJOBNAME.PROFILEOVERDUE
                            _emailJob = JobBuilder.Create(Of ProfileOverdueReminderJob)().WithIdentity(_emailJobName).Build
                            _emailJob.JobDataMap("siteUrl") = siteUrl
                            _emailJob.JobDataMap("sendToSbu") = _emailSentBySbu
                            _emailJob.JobDataMap("jobId") = _emailJobId
                            _scheduler.ScheduleJob(_emailJob, _emailTrigger)

                        Case SCHEDULEJOBNAME.UPDPROFILEDUEDATE
                            _emailJob = JobBuilder.Create(Of ReportDueDateUpddateJob)().WithIdentity(_emailJobName).Build
                            _scheduler.ScheduleJob(_emailJob, _emailTrigger)
                    End Select

                    LogHelper.WriteLog("Schedule Job " & _emailJobName & " is scheduled.")
                End If
            Next

            If Not _scheduler.IsStarted Then
                _scheduler.Start()
                LogHelper.WriteLog("Schedueler is started.")
            End If

        Catch ex As SchedulerException
            LogHelper.WriteLog("Failed to start scheduler. ", ex)
        End Try



    End Sub


    Public Shared Sub Shutdown()
        If Not _scheduler Is Nothing Then
            LogHelper.WriteLog("Scheduler is shutting down.")
            If _scheduler.IsStarted Then
                _scheduler.Shutdown(True)
                LogHelper.WriteLog("Scheduler is shutted down.")
            End If
        End If
    End Sub

    Public Shared Sub ReScheduleJob()
        Shutdown()
        Start(site)
    End Sub

End Class


Public Class ProfileNewSubmittedJob
    Implements IJob

    Public Sub Execute(context As Quartz.IJobExecutionContext) Implements Quartz.IJob.Execute
        LogHelper.WriteLog("ProfileNewSubmitted Job begins......")

        Dim siteUrl As String = context.JobDetail.JobDataMap("siteUrl")
        Dim sendBySbu As String = context.JobDetail.JobDataMap("sendBySbu")
        Dim emailJobService As IEmailJobService = New EmailJobService
        emailJobService.ExecuteProfileNewCreatedReminderJob(siteUrl, IIf(sendBySbu = "Y", True, False))

        LogHelper.WriteLog("ProfileNewSubmitted Job ends......")
    End Sub
End Class

Public Class ProfileUpdateReminderJob
    Implements IJob

    Public Sub Execute(context As Quartz.IJobExecutionContext) Implements Quartz.IJob.Execute
        LogHelper.WriteLog("ProfileUpdateReminderJob begins......")

        Dim siteUrl As String = context.JobDetail.JobDataMap("siteUrl")
        Dim sendToSbu As String = context.JobDetail.JobDataMap("sendToSbu")
        Dim jobId As Integer = context.JobDetail.JobDataMap("jobId")

        Dim emailJobService As IEmailJobService = New EmailJobService
        emailJobService.ExecuteProfileUpdateReminderJob(siteUrl, IIf(sendToSbu = "Y", True, False), jobId)

        LogHelper.WriteLog("ProfileUpdateReminderJob ends......")
    End Sub
End Class

Public Class ProfileOverdueReminderJob
    Implements IJob

    Public Sub Execute(context As Quartz.IJobExecutionContext) Implements Quartz.IJob.Execute
        LogHelper.WriteLog("ProfileOverdueReminderJob begins......")

        Dim siteUrl As String = context.JobDetail.JobDataMap("siteUrl")
        Dim sendToSbu As String = context.JobDetail.JobDataMap("sendToSbu")
        Dim jobId As Integer = context.JobDetail.JobDataMap("jobId")

        Dim emailJobService As IEmailJobService = New EmailJobService
        emailJobService.ExecuteProfileUpdateOverdueJob(siteUrl, IIf(sendToSbu = "Y", True, False), jobId)
        LogHelper.WriteLog("ProfileOverdueReminderJob ends......")
    End Sub
End Class

Public Class ReportDueDateUpddateJob
    Implements IJob

    Public Sub Execute(context As Quartz.IJobExecutionContext) Implements Quartz.IJob.Execute
        LogHelper.WriteLog("ReportDueDateUpddateJob begins......")

        Dim emailJobService As IEmailJobService = New EmailJobService
        emailJobService.ExecuteNextReportDateUpdJob()
        LogHelper.WriteLog("ReportDueDateUpddateJob ends......")
    End Sub
End Class

'Public Class EmailJob
'    Implements IJob

'    Public Sub Execute(context As Quartz.IJobExecutionContext) Implements Quartz.IJob.Execute
'        LogHelper.WriteLog("Email Job is running now")

'        LogHelper.WriteLog(context.JobDetail.JobDataMap("siteUrl"))



'        Dim emailScheduleJobService As IScheduleJobService = New ScheduleJobService
'        Dim dtEmailJob As DataTable = emailScheduleJobService.GetEmailScheduleJob()

'        Dim emailJobService As IEmailJobService = New EmailJobService

'        If Not dtEmailJob Is Nothing Then

'            For Each drEmailJob As DataRow In dtEmailJob.Rows
'                Dim _emailJobName As String = drEmailJob("job_name").ToString

'                Select Case _emailJobName
'                    Case EMAILJOBNAME.PROFILEUPDATE
'                        LogHelper.WriteLog("Begin to execute ExecuteProfileUpdateReminderJob.")
'                        emailJobService.ExecuteProfileUpdateReminderJob()
'                        LogHelper.WriteLog("End to execute ExecuteProfileUpdateReminderJob. ")

'                    Case EMAILJOBNAME.PROFILENEWSUBMITTED
'                        LogHelper.WriteLog("ProfileNewSubmitted Job begins......")
'                        emailJobService.ExecuteProfileNewCreatedReminderJob()
'                        LogHelper.WriteLog("ProfileNewSubmitted Job ends......")

'                    Case EMAILJOBNAME.PROFILERISK
'                        LogHelper.WriteLog("Begin to execute ExecuteProfileRiskUpdateReminderJob.")
'                        emailJobService.ExecuteProfileRiskIssueReminderJob()
'                        LogHelper.WriteLog("End to execute ExecuteProfileRiskUpdateReminderJob. ")
'                End Select
'            Next
'        End If

'    End Sub
'End Class