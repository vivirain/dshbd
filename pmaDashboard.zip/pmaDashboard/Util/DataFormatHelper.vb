﻿Public Class JsonText
    Private _key As String
    Property key() As String
        Get
            Return _key
        End Get
        Set(ByVal value As String)
            _key = value
        End Set
    End Property

    Private _value As String
    Property value() As String
        Get
            Return _value
        End Get
        Set(ByVal value As String)
            _value = value
        End Set
    End Property
End Class

Public Class DataFormatHelper


    Public Shared Function StringToInteger(ByVal sText As String) As Integer
        Dim iReturn As Integer = 0

        If Not String.IsNullOrEmpty(sText) Then
            Try
                iReturn = CInt(sText)
            Catch ex As Exception
                iReturn = 0
            End Try
        End If

        StringToInteger = iReturn
    End Function

    Public Shared Function StringToDecimal(ByVal sText As String) As Decimal
        Dim decReturn As Decimal = New Decimal(0)
        sText = StringTrim(sText)


        If String.IsNullOrEmpty(sText) Then
            decReturn = Convert.DBNull
        Else
            Try
                decReturn = Convert.ToDecimal(sText)
            Catch ex As Exception
                decReturn = New Decimal(0)
            End Try
        End If

        StringToDecimal = decReturn
    End Function


    Public Shared Function StringTrim(ByVal sText As String) As String

        If sText Is Nothing Then
            StringTrim = ""
        ElseIf String.IsNullOrEmpty(sText) Then
            StringTrim = ""
        Else
            StringTrim = sText.ToString.Trim
            StringTrim = StringTrim.Replace("&nbsp;", "")
        End If

    End Function


    Public Shared Function FormatStringToLower(ByVal sText As String) As String

        If sText Is Nothing Then
            FormatStringToLower = ""
        Else
            FormatStringToLower = StringTrim(sText).ToLower
        End If

    End Function


    Public Shared Function FormatStringToUpper(ByVal sText As String) As String

        If sText Is Nothing Then
            FormatStringToUpper = ""
        Else
            FormatStringToUpper = StringTrim(sText).ToUpper
        End If

    End Function

    Public Shared Function FormatString(ByVal sText As String, ByVal textFormatType As String, ByVal textFormatPrec As Integer)
        Dim sFormatString As String = ""

        sFormatString = StringTrim(sText)

        If Not String.IsNullOrEmpty(sFormatString) Then
            If FormatStringToUpper(textFormatType) = "P" Then
                sFormatString = FormatPercent(sFormatString, textFormatPrec)
            ElseIf FormatStringToUpper(textFormatType) = "N" Then
                sFormatString = FormatNumber(sFormatString, textFormatPrec)
            End If
        End If

        FormatString = sFormatString
    End Function


    Public Shared Function FormatDisplayYNValue(ByVal sText As String) As String
        Dim sReturn As String = ""

        If FormatStringToUpper(sText) = "Y" Then
            sReturn = "Yes"
        ElseIf FormatStringToUpper(sText) = "N" Then
            sReturn = "No"
        End If

        FormatDisplayYNValue = sReturn

    End Function

    Public Shared Function DecimalComparer(ByVal dec1 As Decimal, ByVal dec2 As Decimal) As Boolean
        Dim bEqual As Boolean = False

        If IsDBNull(dec1) And IsDBNull(dec2) Then
            bEqual = True
        ElseIf IsDBNull(dec1) And Not IsDBNull(dec2) Then
            bEqual = False
        ElseIf Not IsDBNull(dec1) And IsDBNull(dec2) Then
            bEqual = False
        Else
            bEqual = IIf(dec1 = dec2, True, False)
        End If

        DecimalComparer = bEqual
    End Function

    Public Shared Function GetRAGDesc(ByVal ragCode As String) As String
        If StringTrim(ragCode) = "" Then
            Return ""
        End If

        Dim lookupService As ILookupService = New LookupService
        GetRAGDesc = lookupService.GetLookUpName("B", "STATUS", ragCode)
        
    End Function
End Class
