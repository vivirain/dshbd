﻿Imports System.IO



#Region "Model"

#End Region


#Region "Services"
Public Class PropertyHelper

    Private _Properties As New Hashtable

    Public Sub New()

    End Sub

    Public Sub Load(ByRef sr As StreamReader)

        Dim line As String
        Dim _key As String
        Dim _value As String

        Do While sr.Peek <> -1
            line = sr.ReadLine
            If line = Nothing OrElse line.Length = 0 OrElse line.StartsWith("#") Then
                Continue Do
            End If

            Dim pos As Integer = line.IndexOf("=")
            _key = line.Substring(0, pos).Trim
            _value = line.Substring(pos + 1, line.Length - pos - 1).Trim



            SetProperty(_key, _value)
        Loop

    End Sub

    Private Sub SetProperty(ByVal key As String, ByVal value As String)
        _Properties.Add(key, value)
    End Sub

    Public Function GetProperty(ByVal key As String)

        Return _Properties.Item(key)

    End Function

    Public Function GetProperty(ByVal key As String, ByVal defValue As String) As String

        Dim _value As String = GetProperty(key)
        If _value = Nothing Then
            _value = defValue
        End If

        Return _value

    End Function
End Class
#End Region



