﻿Imports System.Web.Script.Serialization
Imports System.IO

Public Class JsonHelper

    Public Shared Function JsonSerializer(Of T)(obj As T) As String
        Dim ser As New JavaScriptSerializer()
        Dim jsonString As String = ser.Serialize(obj)
        Return jsonString
    End Function

    Public Shared Function JsonDeserialize(Of T)(jsonString As String) As Object
        Dim ser As New JavaScriptSerializer()
        Dim obj As T = ser.Deserialize(Of T)(jsonString)
        Return obj
    End Function


    Public Shared Function Datatable2Json(dt As DataTable) As String
        If dt Is Nothing Then
            Return "{}"
        End If

        Dim ser As New JavaScriptSerializer()

        Dim rowDataList As List(Of Dictionary(Of String, Object)) = New List(Of Dictionary(Of String, Object))
        Dim rowData As Dictionary(Of String, Object)
        For Each dr As DataRow In dt.Rows
            rowData = New Dictionary(Of String, Object)
            For Each col As DataColumn In dt.Columns
                rowData.Add(col.ColumnName, dr(col))
            Next
            rowDataList.Add(rowData)
        Next

        Return ser.Serialize(rowDataList)
    End Function

End Class
