﻿Imports log4net
Imports System.IO

#Region "Model"

Public Class RAG

    Public Shared ReadOnly Property RED
        Get
            Return "R"
        End Get
    End Property

    Public Shared ReadOnly Property AMBER
        Get
            Return "A"
        End Get
    End Property

    Public Shared ReadOnly Property GREEN
        Get
            Return "G"
        End Get
    End Property


End Class

#End Region

Public Class RAGHelper

    Public Shared Function RAGDesc(ByVal ragVal As String) As String
        Dim sRagDesc As String = ""

        If String.IsNullOrEmpty(ragVal) Then
            Return ""
        End If

        ragVal = Trim(ragVal).ToUpper
        Select Case ragVal
            Case "R"
                sRagDesc = "Critical"
            Case "A"
                sRagDesc = "At Risk"
            Case "G"
                sRagDesc = "On Track"
        End Select

        RAGDesc = sRagDesc
    End Function

    Public Shared Function RAGColor(ByVal ragVal As String) As String
        Dim sRagColor As String = ""

        If String.IsNullOrEmpty(ragVal) Then
            Return "#f0f0f0"
        End If

        ragVal = Trim(ragVal).ToUpper
        Select Case ragVal
            Case RAG.RED
                sRagColor = "Red"
            Case RAG.AMBER
                sRagColor = "#f0ad4e"
            Case RAG.GREEN
                sRagColor = "Green"
        End Select

        RAGColor = sRagColor
    End Function

End Class
