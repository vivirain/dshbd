use db_pma
go

delete from tpma_dshbd_prj_metric_raw_hist
delete from tpma_dshbd_prj_metric_raw
delete from tpma_dshbd_prj_metric_hist
delete from tpma_dshbd_prj_metric
delete from tpma_dshbd_profile_hist
delete from tpma_dshbd_profile
delete from tpma_dshbd_prj_issue
delete from tpma_dshbd_prj_schedule


select * from tpma_project where status = '00'

select * from tpma_team where is_func = 'Y'
update tpma_team set tl_id = 'ASNPHTZ' where team_code = 4

select * from tpma_dshbd_profile
select * from tpma_dshbd_profile_hist
select * from tpma_dshbd_prj_metric
select * from tpma_dshbd_prj_metric_raw 
select * from tpma_dshbd_prj_metric_raw_hist


select * from tpma_team

select * from tpma_business_unit 

SELECT [NAME] FROM [dbo].[tpma_tss_project] WHERE 1 =  1  AND [CODE] = '04'

select * from tpma_dshbd_lookup 

select * from tpma_dshbd_function 
update tpma_dshbd_function set function_url = '/Views/ProjectProfile/ProfileBasicTab.aspx' where function_id = 23


select len(is_dept) from tpma_team



SELECT * FROM [dbo].[tpma_dshbd_profile_hist] WHERE 1 = 1  AND [DATA_VERSION] <= '20181125'

select * from tpma_dshbd_prj_issue 


SELECT count(1) as actionNotFollowed FROM [dbo].[tpma_dshbd_prj_issue] a WHERE 1 = 1  AND PRF_ID = 119  AND isnull([ISSUE_STATUS], '') <> 'C'  AND isnull([ISSUE_TRACE_STATUS], '') <> 'G'  AND NOT EXISTS (SELECT 1 FROM [dbo].[tpma_dshbd_prj_issue] WHERE isnull([PARENT_ISSUE_NO], '') = a.[ISSUE_NO] AND [ISSUE_NO] <> a.[ISSUE_NO] AND [PRF_ID] = a.[PRF_ID])



SELECT count(1) as actionNotFollowed FROM [dbo].[tpma_dshbd_prj_issue] a WHERE 1 = 1  AND PRF_ID = 119 
 AND isnull([ISSUE_STATUS], '') <> 'C'  AND isnull([ISSUE_TRACE_STATUS], '') <> 'G'  
AND NOT EXISTS (SELECT 1 FROM [dbo].[tpma_dshbd_prj_issue] WHERE isnull([PARENT_ISSUE_NO], '') = a.[ISSUE_NO] AND [ISSUE_NO] <> a.[ISSUE_NO] AND [PRF_ID] = a.[PRF_ID])


select * from tpma_dshbd_function 
update tpma_dshbd_function set function_icon = 'book' where function_id = 2
update tpma_dshbd_function set function_icon = 'file-signature' where function_id = 22
update tpma_dshbd_function set function_icon = 'project-diagram' where function_id = 23

select system_bill_approach  from tpma_project 


select * from tpma_project a
where exists (select 1 from
		(select prj_code, max(chg_ctl_no) as chg_ctl_no from tpma_project group by prj_code ) b where b.prj_code = a.prj_code and b.chg_ctl_no = a.chg_ctl_no  )
and exists( select 1 from tpma_StaffBasic staff where staff.logon_id = a.prj_ld_id and staff.team_code 


SELECT [prj_code], [chg_ctl_no], [master_prj_code], [bill_approach], [system_bill_approach], [outsource_prj_code],   
       [prj_dictor], prj.[status], 
       [prj_desc], [desc_detail], [prj_desc_chn], [desc_detail_chn], 
       [est_strt_date], [est_cmpl_date], [atl_start], [atl_finish], 
       [est_tot_cost], [atl_cost], [atl_snp_cost], [atl_other_cost], [prj_tot_est_cost], 
       [est_tot_hour], [atl_hour], [prj_tot_est_hour],
	   prj.[bu_code], bu.bu_name, bu.bu_full_name, 
	   [prj_ld_id], [staff_name] as pm_name, staff.[status] as pm_status,
	   staff.[team_code], team.[team_name],
	   [tss_prj], tssprj.name as [tss_prj_name], 
	   [currency], currency.[currency_name]
FROM tpma_project prj
left join tpma_StaffBasic staff
on staff.logon_id = prj.prj_ld_id 
left join tpma_team team
on staff.team_code = team.team_code 
left join tpma_business_unit bu
on prj.bu_code = bu.bu_code 
left join tpma_tss_project tssprj
on prj.tss_prj = tssprj.code 
left join tpma_currency currency
on prj.currency = currency.currency_code 
where exists (select 1 from (select prj_code, max(chg_ctl_no) as chg_ctl_no from tpma_project group by prj_code) b where b.prj_code = prj.prj_code and b.chg_ctl_no = prj.chg_ctl_no )
and isnull(prj.[tss_prj],'') <> '' 

select * from tpma_StaffBasic 


select * from [dbo].[vpma_dshbd_project] a WHERE 1 = 1  AND EXISTS  (SELECT 1 FROM [tpma_staffbasic] staff WHERE staff.team_code = 2  AND staff.logon_id = a.prj_ld_id  ) 





SELECT * FROM [dbo].[tpma_team]  WHERE 1 = 1  AND [STATUS] = 'A' and team_code = 2 and subordinate = 13

depH: 7
funcH: 2

select * from tpma_StaffBasic where team_code = 19
select * from tpma_project

select * from tpma_dshbd_prj_issue 



SELECT * FROM [dbo].[tpma_dshbd_profile_hist] a  WHERE 1 = 1  AND [PRF_ID]=131  
AND EXISTS ( 
SELECT 1  FROM (
SELECT [prf_id], max(cast(data_version as int)) as data_version 
FROM [dbo].[tpma_dshbd_profile_hist] 
WHERE 1 =1 --cast(data_version as int) <= cast('20181126' as int)
GROUP BY [prf_id] ) b  WHERE b.prf_id = a.prf_id and b.data_version = a.data_version )


select * from tpma_dshbd_profile_hist


select * from tpma_dshbd_prj_metric_raw_hist
select * from tpma_dshbd_prj_metric_hist
select * from tpma_dshbd_profile_hist 

select * from tpma_dshbd_prj_metric_raw_hist
where exists (select 1 from
(select prj_code, metric_raw_code, max(data_version

select * from tpma_team where team_cod


update tpma_dshbd_prj_metric_raw_hist set data_version = '20181120'
update tpma_dshbd_prj_metric_hist set data_Version = '20181120'
update tpma_dshbd_profile_hist set data_version = '20181120'

update tpma_dshbd_prj_metric_raw set data_Version = '20181120'
update tpma_dshbd_prj_metric set data_version = '20181120'
update tpma_dshbd_profile set data_version = '20121120'


select * from tpma_dshbd_profile
3170197
3170198
3170202

select * from tpma_dshbd_prj_metric_raw where prj_code = '3170197' or prj_code = '3170198' or prj_code = '3170202'


select * from tpma_project where prj_code = '3170198'

select * from tpma_dshbd_profile

SELECT * FROM [dbo].[tpma_dshbd_prj_metric_raw_hist]  a  
WHERE 1 = 1  
AND (  [PRJ_CODE] = '3170197' OR  [PRJ_CODE] = '3170198' OR  [PRJ_CODE] = '3170200' OR  [PRJ_CODE] = '3170201' OR  [PRJ_CODE] = '3170202' OR  [PRJ_CODE] = '3180144')  
AND [DATA_VERSION] = (  SELECT MAX([DATA_VERSION]) FROM [dbo].[tpma_dshbd_prj_metric_raw_hist] WHERE [DATA_VERSION] <= '20181126'  
	AND (  [PRJ_CODE] = '3170197' OR  [PRJ_CODE] = '3170198' OR  [PRJ_CODE] = '3170200' OR  [PRJ_CODE] = '3170201' OR  [PRJ_CODE] = '3170202' OR  [PRJ_CODE] = '3180144') ) 




SELECT * FROM [dbo].[vpma_dshbd_profile_hist] a  WHERE 1 = 1 
 AND EXISTS ( SELECT 1  FROM (SELECT [prf_id], max(data_version) as data_version FROM [dbo].[vpma_dshbd_profile_hist] GROUP BY prf_id ) b  WHERE b.prf_id = a.prf_id and b.data_version = a.data_version ) 

    Select logon_id, staff_name, team_code from tpma_staffbasic staff 
            where exists (select 1 from tpma_dshbd_profile_hist where prj_ld_id = staff.logon_


			select * from tpma_team


			
			select func.team_code as func_code, func.team_name as func_name, func.tl_id as func_head, func.[status] as func_status,
				sbu.team_code as sbu_code, sbu.team_name as sbu_name, sbu.tl_id as sbu_head, sbu.[status] as sbu_status 
			from tpma_team func 
			left join tpma_team sbu
			on sbu.subordinate = func.team_code 
			where func.is_func = 'Y'
			and sbu.is_dept = 'Y'
			order by func.team_code, sbu.team_code 



			SELECT [prf_id], max(data_version) as data_version FROM vpma_dshbd_profile_hist where data_version <= '20181127' GROUP BY prf_id



SELECT isnull(SUM(act_hour),0) as failure_effort FROM [dbo].[tpma_task]
 WHERE 1 =  1  AND (  [STANDARD_CODE] = '9700'  OR [STANDARD_CODE] = '9710'  OR [STANDARD_CODE] = '9720'  ) 
 AND [STATUS] = 'C'  
 AND [ACT_COMPLETE] <= 11/27/2018 AND ([PRJ_CODE] = '2170336' )


 select * from tpma_dshbd_profile where prj_ld_id = 'os12tl1'

 select * from tpma_dshbd_function_auth where role_id = 6

 select * from tpma_dshbd_profile_hist 

 select * from tpma_StaffBasic 


 select *, rtrim(team_name + ' - ' + cast(team_code as varchar(10))) as display_name from tpma_team

 select * from tpma_team where is_dept = 'Y' order by subordinate 
 update tpma_team set dtl_id = 'disbu1' where team_code = 7


 select * from tpma_StaffBasic where logon_id = 'disbu1'

Select distinct prj_ld_id from [dbo].[vpma_dshbd_profile_hist] prfHistView 
where exists (select 1 from [dbo].[tpma_staffbasic] where logon_id = prfHistView.prj_ld_id and team_code = 7)  
AND EXISTS ( SELECT 1  FROM (SELECT [prf_id], max(data_version) as data_version FROM [dbo].[vpma_dshbd_profile_hist] GROUP BY prf_id ) b  WHERE b.prf_id = prfHistView.prf_id and b.data_version = prfHistView.data_version )  AND [DATA_VERSION] <= '20181127'



select * from tpma_StaffBasic where logon_id = 'di2pm02'
select * from tpma_team where team_code = 19

Select distinct prj_ld_id from [dbo].[vpma_dshbd_profile] a where exists (select 1 from [dbo].[tpma_staffbasic] where logon_id = prfHistView.prj_ld_id and team_code = @TEAMCODE)  AND EXISTS ( SELECT 1  FROM (SELECT [prf_id], max(data_version) as data_version FROM [dbo].[vpma_dshbd_profile_hist] GROUP BY prf_id ) b  WHERE b.prf_id = a.prf_id and b.data_version = a.data_version ) 
 AND [DATA_VERSION] <= '2018'



 Select distinct prj_ld_id from [dbo].[vpma_dshbd_profile_hist] a 
 where exists (select 1 from [dbo].[tpma_staffbasic] where logon_id = a.prj_ld_id and team_code = 45)  
 AND EXISTS ( SELECT 1  FROM (SELECT [prf_id], max(data_version) as data_version FROM [dbo].[vpma_dshbd_profile_hist] GROUP BY prf_id ) b  WHERE b.prf_id = a.prf_id and b.data_version = a.data_version )  
 AND [DATA_VERSION] <= @DATAVERSION



 select * from tpma_dshbd_profile 

 selec


 select * from tpma_dshbd_function_auth where role_id = 5

 select * from tpma_project where prj_ld_id = 'dihowad'

 select * from tpma_StaffBasic where team_code in( 14, 55, 56)

 select * from tpma_team where tl_id = 'dihowad' or dtl_id = 'dihowad'


select * from tpma_dshbd_profile prf
where exists (select 1 from tpma_StaffBasic staff, tpma_team team where logon_id = prf.prj_ld_id and staff.team_code = team.team_code and 
team.team_code in (2, 14,55,56, 57))
select * from tpma_StaffBasic where logon_id = 'innolab'


select * from tpma_dshbd_profile
update tpma_dshbd_profile set data_Version = '20181125' where prf_id = 155
update tpma_dshbd_profile_hist set data_version = '20181125' where prf_id = 155
update tpma_dshbd_prj_metric set data_version = '20181125' where prj_code in ('9000001','9000002')
update tpma_dshbd_prj_metric_hist set data_version = '20181125' where prj_code in ('9000001','9000002')
update tpma_dshbd_prj_metric_raw set data_version = '20181125' where prj_code in ('9000001','9000002')
update tpma_dshbd_prj_metric_raw_hist set data_version = '20181125' where prj_code in ('9000001','9000002')

select * from tpma_dshbd_profile_hist where data_version  = '20181125'
select * from tpma_dshbd_profile


SELECT a.*, b.lookup_name as schedule_trace_status_desc  FROM [dbo].[tpma_dshbd_prj_schedule] a  
LEFT JOIN [dbo].[tpma_dshbd_lookup] b  ON a.schedule_trace_status = b.lookup_code  AND b.lookup_type = 'B'  AND b.category = 'STATUS'  
WHERE 1 = 1  AND prf_id = 157



SELECT * FROM [dbo].[vpma_dshbd_project] a  
WHERE EXISTS ( SELECT 1 FROM [tpma_staffbasic] where [logon_id] = a.prj_ld_id and [team_code] in (1,4,6,7) and status = 'A'  )

select * from tpma_team where team_code = 7


select *, rtrim(team_name + ' - ' + cast(team_code as varchar(10))) as display_name from [dbo].[tpma_team] WHERE 1 = 1  AND STATUS = 'A'  
AND ( [TL_ID] = 'ASNPHTZ' OR [DTL_ID] = 'ASNPHTZ' OR [SUBORDINATE] = 1 ) 



select *, rtrim(team_name + ' - ' + cast(team_code as varchar(10))) as display_name from [dbo].[tpma_team] WHERE 1 = 1  AND STATUS = 'A'  AND ( [TL_ID] = 'ASNPHTZ' OR [DTL_ID] = 'ASNPHTZ' )


select *, rtrim(team_name + ' - ' + cast(team_code as varchar(10))) as display_name from [dbo].[tpma_team] WHERE 1 = 1  AND STATUS = 'A'  AND ( [SUBORDINATE] = 4 )
select *, rtrim(team_name + ' - ' + cast(team_code as varchar(10))) as display_name from [dbo].[tpma_team] WHERE 1 = 1  AND STATUS = 'A'  AND ( [SUBORDINATE] = 6 )
select *, rtrim(team_name + ' - ' + cast(team_code as varchar(10))) as display_name from [dbo].[tpma_team] WHERE 1 = 1  AND STATUS = 'A'  AND ( [SUBORDINATE] = 6 )


select prf_id from vpma_dshbd_profile_hist prfHist
where exists (
select 1 from tpma_project prj 
where prfHist.prj_codes like ('%' + prj.prj_code + '%')
and exists (select 1 from tpma_StaffBasic where logon_id = prj.prj_ld_id and team_code in (1,4, 6,7))
) 


select * from tpma_dshbd_profile 

SELECT * FROM [dbo].[vpma_dshbd_profile] prfHist WHERE 1 = 1 

 AND exists (      select 1 from tpma_project prj      where prfHist.prj_codes like ('%' + prj.prj_code + '%')      and exists (select 1 from [dbo].[tpma_StaffBasic] where logon_id = prj.prj_ld_id and team_code in (16,58,59,60,61,62,63))  )  
AND exists (      select 1 
					from (select prf_id, max(data_version) as data_version from [dbo].[vpma_dshbd_profile] group by prf_id)  b     
					where prf_id = prfHist.prf_id and data_version = prfHist.data_version  ) 



select * from vpma_dshbd_project 

select * from tpma_dshbd_profile 

update tpma_dshbd_profile set data_version = '20181128' where prf_id = 166 and data_version = '20181130'
update tpma_dshbd_profile_hist set data_version = '20181128' where prf_id = 166 and data_version = '20181130'
update tpma_dshbd_prj_metric set data_version = '20181128' where prj_code in ('IL00022','IL00024') and data_version = '20181130'
update tpma_dshbd_prj_metric_hist set data_version = '20181128' where prj_code in ('IL00022','IL00024') and data_version = '20181130'
update tpma_dshbd_prj_metric_raw set data_version = '20181128' where prj_code in ('IL00022','IL00024') and data_version = '20181130'
update tpma_dshbd_prj_metric_raw_hist set data_version = '20181128' where prj_code in ('IL00022','IL00024') and data_version = '20181130'


select * from tpma_dshbd_profile 

SELECT * FROM [dbo].[vpma_dshbd_profile] a  WHERE [prj_codes] like '%SS00002%'  
AND NOT EXISTS ( SELECT 1 FROM [dbo].[tpma_dshbd_profile_hist] WHERE PRF_ID = a.PRF_ID  )  AND STATUS = 'D'


select * from tpma_project 

SELECT * FROM [dbo].[vpma_dshbd_profile] a  WHERE 1 = 1  AND NOT EXISTS ( SELECT 1 FROM [dbo].[tpma_dshbd_profile_hist] WHERE PRF_ID = a.PRF_ID ) AND [status] = 'D'


select * from tpma_tss_prj
delete tpma_tss_prj where prj_code = ''
update tpma_project set master_prj_code = 'P180001' where prj_code = 'MOBIL12'

select * from tpma_project

SELECT [prj_code], [prj_name], [prj_desc], [prj_ld_id], [status] FROM [dbo].[tpma_tss_prj] a  WHERE 1 = 1  AND EXISTS ( SELECT 1 FROM [dbo].[tpma_staffbasic] staff WHERE logon_id = a.prj_ld_id and team_code in (1,6,22,23,24,25,26,7,27,28,29,30,31,32,4,16,58,59,60,61,62,63,17,64,65,103,66,18,67,68,69,70,71,72,73,74,83,89,90,91,84,92,93,94,95,96,97,85,98,99,100,101,102,86,87,88,19,75,76,77,20,78,79,80,81,82) )

SELECT [prj_code], [prj_name], [prj_desc], [prj_ld_id], [status] FROM [dbo].[tpma_tss_prj] a  WHERE 1 = 1  AND EXISTS ( SELEC 1 FROM [dbo].[tpma_staffbasic] staff WHERE logon_id = a.prj_ld_id and team_code in (1,6,22,23,24,25,26,7,27,28,29,30,31,32,4,16,58,59,60,61,62,63,17,64,65,103,66,18,67,68,69,70,71,72,73,74,83,89,90,91,84,92,93,94,95,96,97,85,98,99,100,101,102,86,87,88,19,75,76,77,20,78,79,80,81,82) ) 



SELECT * FROM [dbo].[vpma_dshbd_project] a  
WHERE NOT EXISTS ( SELECT 1 FROM [dbo].[tpma_dshbd_profile_hist] WHERE [prj_codes] like '%' + a.prj_code + '%'  AND [prf_id] <> 179 ) 
AND NOT EXISTS ( SELECT 1 FROM [dbo].[tpma_dshbd_profile] WHERE [prj_codes] like '%' + a.prj_code + '%' and [status] = 'D'  )


select * from tpma_dshbd_prj_issue 


SELECT ltrim(rtrim([STAFF_NAME])) + ' - ' + upper(logon_id) as display_name, * FROM [dbo].[tpma_staffbasic] WHERE [STATUS] = 'A' ORDER BY [display_name]

