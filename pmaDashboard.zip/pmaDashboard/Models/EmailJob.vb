﻿Imports System.Data
Imports System.Data.SqlClient


#Region "Model"
'Public Class EMAILJOBNAME

'    Public Shared ReadOnly Property PROFILEUPDATE As String
'        Get
'            Return "PROFILEUPDATE"
'        End Get
'    End Property

'    Public Shared ReadOnly Property PROFILEOVERDUE As String
'        Get
'            Return "PROFILEOVERDUE"
'        End Get
'    End Property

'    Public Shared ReadOnly Property PROFILENEWSUBMITTED As String
'        Get
'            Return "PROFILENEWSUBMITTED"
'        End Get
'    End Property

'    Public Shared ReadOnly Property PROFILERISK As String
'        Get
'            Return "PROFILERISK"
'        End Get
'    End Property

'End Class
#End Region

#Region "Service"

Public Interface IEmailJobService
    Sub ExecuteProfileUpdateReminderJob(ByVal siteUrl As String, ByVal sendBySbu As Boolean, ByVal jobId As Integer)
    Sub ExecuteProfileUpdateOverdueJob(ByVal siteUrl As String, ByVal sendBySbu As Boolean, ByVal jobId As Integer)
    Sub ExecuteProfileNewCreatedReminderJob(ByVal siteUrl As String, ByVal sendBySbu As Boolean)

    Sub ExecuteNextReportDateUpdJob()

End Interface

Class EmailJobService
    Implements IEmailJobService

    Dim prfService As IProfileService = New ProfileService
    Dim emailHelper As EmailHelper = New EmailHelper
    Dim pmaEmailTemplateService As IPmaEmailTemplateService = New PmaEmailTemplateService
    Dim lookupService As ILookupService = New LookupService
    Dim userRoleService As IUserRoleService = New UserRoleService
    Dim pmaUserService As IPmaUserService = New PmaUserService
    Dim emailUnsubscriptionService As IEmailUnsubscriptionService = New EmailUnsubscriptionService

    Sub ExecuteProfileUpdateReminderJob(ByVal siteUrl As String, ByVal sendBySbu As Boolean, ByVal jobId As Integer) Implements IEmailJobService.ExecuteProfileUpdateReminderJob
        Try
            ProfileUpdateReminderJob(siteUrl, "Profile_Update", sendBySbu, jobId)
        Catch ex As Exception
            LogHelper.WriteLog("Failed to execute ExecuteProfileUpdate2ndReminder.", ex)
        End Try
    End Sub

    Sub ExecuteProfileUpdateOverdueJob(ByVal siteUrl As String, ByVal sendBySbu As Boolean, ByVal jobId As Integer) Implements IEmailJobService.ExecuteProfileUpdateOverdueJob

        Try
            ProfileUpdateReminderJob(siteUrl, "Profile_Overdue", sendBySbu, jobId)
        Catch ex As Exception
            LogHelper.WriteLog("Failed to execute ExecuteProfileUpdate2ndReminder.", ex)
        End Try

    End Sub

    Sub ProfileUpdateReminderJob(ByVal siteUrl As String, ByVal emailTemplate As String, ByVal sendBySbu As Boolean, ByVal jobId As Integer)
        Try
            Dim dtPrfUpdReminder As DataTable = prfService.GetProfileProgressUpdateReminder(jobId)

            If dtPrfUpdReminder Is Nothing OrElse dtPrfUpdReminder.Rows.Count = 0 Then
                LogHelper.WriteLog("No Profiles found for this reminder job.")
                Return
            End If

            Dim dtEmailTemplate As DataTable = pmaEmailTemplateService.getEmailTemplate(emailTemplate)
            If dtEmailTemplate Is Nothing OrElse dtEmailTemplate.Rows.Count = 0 Then
                If dtEmailTemplate Is Nothing Then
                    LogHelper.WriteLog("Email Template" & emailTemplate & " is not found.")
                    Return
                End If
            End If


            Dim _emailSubject As String = dtEmailTemplate.Rows(0).Item("email_subject").ToString
            Dim _emailBody As String = dtEmailTemplate.Rows(0).Item("email_content").ToString
            Dim _emailToTmp As String = dtEmailTemplate.Rows(0).Item("email_to").ToString
            Dim _emailCcTmp As String = dtEmailTemplate.Rows(0).Item("email_cc").ToString
            _emailBody = _emailBody.Replace("{2}", siteUrl)
            _emailBody = _emailBody.Replace("{4}", GetEmailCommonSuffix)

            Dim _sbuEmailSubject As String = ""
            Dim _sbuEmailBody As String = ""
            Dim _sbuEmailTo As String = ""
            Dim _sbuEmailCc As String = ""

            Dim _emailBodyRows As StringBuilder = New StringBuilder("")
            Dim _emailBodyRow As String = ""
            Dim _emailBodyRowTemplate As String = "<tr class='tdBgColor'><td><strong>{1}</strong></td><td>{2}</td><td>{3}</td><td>{4}</td></tr>"

            Dim _prfDraftRows As StringBuilder = New StringBuilder("")
            Dim _prfNotUpdRows As StringBuilder = New StringBuilder("")
            Dim _prfIssueRows As StringBuilder = New StringBuilder("")

            Dim prfTeamCode As String = ""
            Dim prfTeamName As String = ""
            Dim prfSbuCode As String = ""
            Dim prfSbuName As String = ""

            Dim lookupService As ILookupService = New LookupService
            Dim nxtRptDateStr As String = lookupService.GetLookUpName("S", "MISC", "NEXT_REPORT_DATE")
            Dim nxtRptDate As Date
            If IsDate(nxtRptDateStr) Then
                nxtRptDate = nxtRptDateStr
            End If

            For Each drPrfUpd As DataRow In dtPrfUpdReminder.Rows

                Dim pushType As String = drPrfUpd("push_type").ToString.Trim
                Dim prfDesc As String = DataFormatHelper.StringTrim(drPrfUpd("prf_desc").ToString)
                Dim prjCodes As String = DataFormatHelper.StringTrim(drPrfUpd("prj_codes").ToString)
                If prjCodes.Length > 15 Then
                    prjCodes = prjCodes.Substring(0, 15) & "..."
                End If
                Dim cellPrfRow As String = "<strong>" & prfDesc & "</strong>, [" & prjCodes & "]<br/>"

                'Send email if loaded all required data for specific BU & reset related variables
                If sendBySbu AndAlso Not String.IsNullOrEmpty(prfSbuCode) AndAlso drPrfUpd("sbu_code").ToString.Trim <> prfSbuCode Then
                    PrepareProfileUpdateRowData(_prfDraftRows, _prfIssueRows, _prfNotUpdRows, _emailBodyRowTemplate, _emailBodyRows, prfTeamName)

                    If Not String.IsNullOrEmpty(_sbuEmailTo) Or Not String.IsNullOrEmpty(_sbuEmailCc) Then
                        _sbuEmailSubject = _emailSubject.Replace("{0}", prfSbuName)
                        _sbuEmailSubject = _sbuEmailSubject.Replace("{1}", Format(nxtRptDate, GetEmailDateFormat))
                        _sbuEmailBody = _emailBody.Replace("{3}", _emailBodyRows.ToString)

                        emailHelper.SendInstantEmail(_sbuEmailSubject, _sbuEmailBody.ToString, _sbuEmailTo.Split(","), IIf(String.IsNullOrEmpty(_sbuEmailCc), Nothing, _sbuEmailCc.Split(",")))
                    End If

                    _sbuEmailSubject = ""
                    _sbuEmailBody = ""
                    _sbuEmailTo = ""
                    _sbuEmailCc = ""

                    prfTeamCode = ""
                    prfTeamName = ""

                    _emailBodyRows = New StringBuilder("")
                End If

                'Push row data for specific team under specific SBU.
                If Not String.IsNullOrEmpty(prfTeamCode) AndAlso drPrfUpd("team_code").ToString.Trim <> prfTeamCode Then
                    PrepareProfileUpdateRowData(_prfDraftRows, _prfIssueRows, _prfNotUpdRows, _emailBodyRowTemplate, _emailBodyRows, prfTeamName)
                End If

                Select Case pushType
                    Case "D" 'Draft
                        _prfDraftRows.Append(cellPrfRow)

                    Case "S" 'Not Update
                        _prfNotUpdRows.Append(cellPrfRow)

                    Case "I" 'Risk/Issue
                        _prfIssueRows.Append(cellPrfRow)
                End Select

                prfTeamCode = drPrfUpd("team_code").ToString.Trim
                prfTeamName = drPrfUpd("team_name").ToString.Trim
                prfSbuCode = drPrfUpd("sbu_code").ToString.Trim
                prfSbuName = drPrfUpd("sbu_name").ToString.Trim

                'Construct To Email
                If Not String.IsNullOrEmpty(_emailToTmp) Then
                    PrepareEmailSendToRole(_sbuEmailTo, _emailToTmp, drPrfUpd, emailTemplate)
                End If

                'Construct Cc Email
                If Not String.IsNullOrEmpty(_emailCcTmp) Then
                    PrepareEmailSendToRole(_sbuEmailCc, _emailCcTmp, drPrfUpd, emailTemplate)
                End If
            Next


            If Not String.IsNullOrEmpty(_sbuEmailTo) Or Not String.IsNullOrEmpty(_sbuEmailCc) Then

                PrepareProfileUpdateRowData(_prfDraftRows, _prfIssueRows, _prfNotUpdRows, _emailBodyRowTemplate, _emailBodyRows, prfTeamName)

                _sbuEmailSubject = _emailSubject.Replace("{0}", prfSbuName)
                _sbuEmailSubject = _sbuEmailSubject.Replace("{1}", Format(nxtRptDate, GetEmailDateFormat))
                _sbuEmailBody = _emailBody.Replace("{3}", _emailBodyRows.ToString)

                emailHelper.SendInstantEmail(_sbuEmailSubject, _sbuEmailBody.ToString, _sbuEmailTo.Split(","), IIf(String.IsNullOrEmpty(_sbuEmailCc), Nothing, _sbuEmailCc.Split(",")))
            End If

        Catch ex As Exception
            LogHelper.WriteLog("Failed to execute ProfileUpdateReminderEmailJob.", ex)
        End Try

    End Sub

    Sub PrepareEmailSendToRole(ByRef emailTo As String, ByRef _TmpEmailTo As String, ByRef drPrf As DataRow, ByVal _emailTmp As String)
        Dim _emailToRoleList As String() = _TmpEmailTo.Split(",")

        For Each _emailToRole As String In _emailToRoleList
            Dim dtEmailToRole As DataTable = userRoleService.GetUserRoleList(_emailToRole)

            Select Case _emailToRole
                Case DASHBORADROLES.PM
                    Dim prfPmEmail As String = DataFormatHelper.StringTrim(drPrf("prj_ld_email").ToString)
                    PrepareEmailSendTo(_emailTmp, emailTo, prfPmEmail)
                    
                Case DASHBORADROLES.TL
                    Dim prfTlEmail As String = DataFormatHelper.StringTrim(drPrf("tl_email").ToString)
                    Dim prfDtlEmail As String = DataFormatHelper.StringTrim(drPrf("dtl_email").ToString)
                    PrepareEmailSendTo(_emailTmp, emailTo, prfTlEmail)
                    PrepareEmailSendTo(_emailTmp, emailTo, prfDtlEmail)
                    
                Case DASHBORADROLES.SBUH
                    Dim sbuHeadEmail As String = DataFormatHelper.StringTrim(drPrf("sbuh_email").ToString)
                    Dim dSbuHeadEmail As String = DataFormatHelper.StringTrim(drPrf("dsbuh_email").ToString)
                    PrepareEmailSendTo(_emailTmp, emailTo, sbuHeadEmail)
                    PrepareEmailSendTo(_emailTmp, emailTo, dSbuHeadEmail)

                Case DASHBORADROLES.FH
                    Dim funcHeadEmail As String = DataFormatHelper.StringTrim(drPrf("funch_email").ToString)
                    Dim dFuncHeadEmail As String = DataFormatHelper.StringTrim(drPrf("dfunch_email").ToString)
                    PrepareEmailSendTo(_emailTmp, emailTo, funcHeadEmail)
                    PrepareEmailSendTo(_emailTmp, emailTo, dFuncHeadEmail)

                Case DASHBORADROLES.EXCO
                    PrepareEmailSendToRoleUsers(emailTo, dtEmailToRole, _emailTmp)
                Case DASHBORADROLES.GM
                    PrepareEmailSendToRoleUsers(emailTo, dtEmailToRole, _emailTmp)
                Case DASHBORADROLES.AM
                    PrepareEmailSendToRoleUsers(emailTo, dtEmailToRole, _emailTmp)
                Case DASHBORADROLES.QAG
                    PrepareEmailSendToRoleUsers(emailTo, dtEmailToRole, _emailTmp)
                Case DASHBORADROLES.ADM
                    PrepareEmailSendToRoleUsers(emailTo, dtEmailToRole, _emailTmp)
            End Select

        Next
    End Sub

    Sub PrepareEmailSendToRoleUsers(ByRef emailTo As String, ByRef dtEmailRole As DataTable, ByVal emailTmp As String)
        If Not dtEmailRole Is Nothing AndAlso dtEmailRole.Rows.Count > 0 Then
            For Each drEmailRole As DataRow In dtEmailRole.Rows
                Dim dtPma As DataTable = pmaUserService.GetActiveUserByLogonId(drEmailRole("pma_logon_id"))

                If Not dtPma Is Nothing AndAlso dtPma.Rows.Count > 0 Then
                    Dim pmaEmail As String = dtPma.Rows(0).Item("email").ToString.Trim
                    PrepareEmailSendTo(emailTmp, emailTo, pmaEmail)
                End If
            Next
        End If
    End Sub

    Sub PrepareEmailSendTo(ByVal emailTmp As String, ByRef emailTo As String, ByVal email As String)
        If Not String.IsNullOrEmpty(email) AndAlso Not emailTo.Contains(email) _
                      AndAlso Not emailUnsubscriptionService.IsEmailUnsubscribed(emailTmp, email) Then
            emailTo = emailTo & IIf(String.IsNullOrEmpty(emailTo), "", ",") & email
        End If
    End Sub

    Sub PrepareProfileUpdateRowData(ByRef _prfDraftRows As StringBuilder, ByRef _prfIssueRows As StringBuilder, ByRef _prfNotUpdRows As StringBuilder, ByVal _emailBodyRowTemp As String, ByRef _emailbodyrows As StringBuilder, ByVal prfTeamName As String)
        Dim _emailBodyRow As String = _emailBodyRowTemp
        _emailBodyRow = _emailBodyRow.Replace("{1}", prfTeamName)
        _emailBodyRow = _emailBodyRow.Replace("{2}", _prfDraftRows.ToString)
        _emailBodyRow = _emailBodyRow.Replace("{3}", _prfIssueRows.ToString)
        _emailBodyRow = _emailBodyRow.Replace("{4}", _prfNotUpdRows.ToString)

        _emailbodyrows.Append(_emailBodyRow)

        _prfDraftRows = New StringBuilder("")
        _prfNotUpdRows = New StringBuilder("")
        _prfIssueRows = New StringBuilder("")
    End Sub

    Sub ExecuteProfileNewCreatedReminderJob(ByVal siteUrl As String, ByVal sendBySbu As Boolean) Implements IEmailJobService.ExecuteProfileNewCreatedReminderJob
        Try
            Dim dtPrfNewSubmmited As DataTable = prfService.GetProfileNewSubmitted
            If dtPrfNewSubmmited Is Nothing OrElse dtPrfNewSubmmited.Rows.Count = 0 Then
                Return
            End If

            Dim emailTmplate As String = "Profile_New_Submitted"
            Dim dtEmailTemplate As DataTable = pmaEmailTemplateService.getEmailTemplate(emailTmplate)
            If dtEmailTemplate Is Nothing OrElse dtEmailTemplate.Rows.Count = 0 Then
                If dtEmailTemplate Is Nothing Then
                    LogHelper.WriteLog("Email Template [Profile_New_Submitted] is not found.")
                    Return
                End If
            End If

            'Dim _emailSendTo As String = ""
            'Dim _emailCcTo As String = ""
            Dim _emailSubject As String = dtEmailTemplate.Rows(0).Item("email_subject").ToString.Trim
            Dim _emailBody As String = dtEmailTemplate.Rows(0).Item("email_content").ToString.Trim
            Dim _emailToTmp As String = dtEmailTemplate.Rows(0).Item("email_to").ToString.Trim
            Dim _emailCcTmp As String = dtEmailTemplate.Rows(0).Item("email_cc").ToString.Trim

            _emailBody = _emailBody.Replace("{2}", siteUrl)
            _emailBody = _emailBody.Replace("{4}", GetEmailCommonSuffix)

            Dim _prfRow As String = "<tr class='trBgColor'>"
            _prfRow = _prfRow & "<td><strong>{0}</strong></td>"
            '_prfRow = _prfRow & "<td style='width:40%'>{1}<span style='height:15px; width:15px; background-color:{2}; border-radius:50%; display:inline-block; text-align:right'/></td>"
            _prfRow = _prfRow & "<td class='prfBgColor'><table style='width:100%'><tr><td style='width:95%'>{1}</td><td style='background-color:{2}'></td></tr></table></td>"
            _prfRow = _prfRow & "<td style='text-align:center; border-bottom:2px solid {3}'>{QUALITY}</td>"
            _prfRow = _prfRow & "<td style='text-align:center; border-bottom:2px solid {4}'>{SCHEDULE}</td>"
            _prfRow = _prfRow & "<td style='text-align:center; border-bottom:2px solid {5}'>{COST}</td>"
            _prfRow = _prfRow & "<td style='text-align:center; border-bottom:2px solid {6}'>{RESOURCE}</td>"
            _prfRow = _prfRow & "<td style='text-align:center; border-bottom:2px solid {7}'>{SCOPE}</td>"
            _prfRow = _prfRow & "<td style='text-align:center; border-bottom:2px solid {8}'>{CSS}</td>"
            _prfRow = _prfRow & "</tr>"

            Dim _newPrfRows As StringBuilder = New StringBuilder("")

            Dim _sbuCode As String = ""
            Dim _sbuName As String = ""
            Dim _sbuEmailSubject As String = ""
            Dim _sbuEmailBody As String = ""
            Dim _sbuEmailTo As String = ""
            Dim _sbuEmailCc As String = ""

            Dim today As Date = Date.Today
            'Dim dayDiff As Integer = today.DayOfWeek - DayOfWeek.Monday
            Dim dayDiff As Integer = 1
            Dim monday As Date = today.AddDays(-dayDiff)

            For Each drPrfNewSubmitted As DataRow In dtPrfNewSubmmited.Rows
                'send email by each SBU
                If sendBySbu AndAlso drPrfNewSubmitted("sbu_code").ToString <> _sbuCode AndAlso Not String.IsNullOrEmpty(_sbuCode) Then
                    If Not String.IsNullOrEmpty(_sbuEmailTo) Then
                        _sbuEmailSubject = _emailSubject.Replace("{0}", _sbuName)
                        _sbuEmailSubject = _sbuEmailSubject.Replace("{1}", Format(monday, GetEmailDateFormat))
                        _sbuEmailBody = _emailBody.Replace("{3}", _newPrfRows.ToString)

                        emailHelper.SendInstantEmail(_sbuEmailSubject, _sbuEmailBody, _sbuEmailTo.Split(","), IIf(String.IsNullOrEmpty(_sbuEmailCc), Nothing, _sbuEmailCc.Split(",")))

                    End If

                    _sbuEmailSubject = ""
                    _sbuEmailBody = ""
                    _sbuEmailTo = ""
                    _sbuEmailCc = ""
                    _newPrfRows = New StringBuilder("")
                End If

                _sbuCode = drPrfNewSubmitted("sbu_code").ToString.Trim
                _sbuName = drPrfNewSubmitted("sbu_name").ToString.Trim

                Dim _newPrfRow As String = _prfRow
                _newPrfRow = _newPrfRow.Replace("{0}", DataFormatHelper.StringTrim(drPrfNewSubmitted("team_name").ToString))
                _newPrfRow = _newPrfRow.Replace("{1}", DataFormatHelper.StringTrim(drPrfNewSubmitted("prf_desc").ToString))
                _newPrfRow = _newPrfRow.Replace("{2}", Lookup.RAGColor(drPrfNewSubmitted("prf_health_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{3}", Lookup.RAGColor(drPrfNewSubmitted("prf_quality_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{4}", Lookup.RAGColor(drPrfNewSubmitted("prf_schedule_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{5}", Lookup.RAGColor(drPrfNewSubmitted("prf_cost_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{6}", Lookup.RAGColor(drPrfNewSubmitted("prf_resource_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{7}", Lookup.RAGColor(drPrfNewSubmitted("prf_scope_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{8}", Lookup.RAGColor(drPrfNewSubmitted("prf_css_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{QUALITY}", RAGHelper.RAGDesc(drPrfNewSubmitted("prf_quality_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{SCHEDULE}", RAGHelper.RAGDesc(drPrfNewSubmitted("prf_schedule_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{COST}", RAGHelper.RAGDesc(drPrfNewSubmitted("prf_cost_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{RESOURCE}", RAGHelper.RAGDesc(drPrfNewSubmitted("prf_resource_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{SCOPE}", RAGHelper.RAGDesc(drPrfNewSubmitted("prf_scope_sta").ToString))
                _newPrfRow = _newPrfRow.Replace("{CSS}", RAGHelper.RAGDesc(drPrfNewSubmitted("prf_css_sta").ToString))

                _newPrfRows.Append(_newPrfRow)

                'Construct email to
                If Not String.IsNullOrEmpty(_emailToTmp) Then
                    PrepareEmailSendToRole(_sbuEmailTo, _emailToTmp, drPrfNewSubmitted, emailTmplate)
                End If

                'Construct email cc
                If Not String.IsNullOrEmpty(_emailCcTmp) Then
                    PrepareEmailSendToRole(_sbuEmailCc, _emailCcTmp, drPrfNewSubmitted, emailTmplate)
                End If
            Next


            If Not String.IsNullOrEmpty(_sbuEmailTo) Then
                _sbuEmailSubject = _emailSubject.Replace("{0}", _sbuName)
                _sbuEmailSubject = _sbuEmailSubject.Replace("{1}", Format(monday, GetEmailDateFormat))
                _sbuEmailBody = _emailBody.Replace("{3}", _newPrfRows.ToString)

                emailHelper.SendInstantEmail(_sbuEmailSubject, _sbuEmailBody, _sbuEmailTo.Split(","), IIf(String.IsNullOrEmpty(_sbuEmailCc), Nothing, _sbuEmailCc.Split(",")))
            End If

        Catch ex As Exception
            LogHelper.WriteLog("Failed to execute ProfileNewCreatedReminderJob.", ex)
        End Try
    End Sub

    Function GetEmailCommonSuffix() As String
        Return pmaEmailTemplateService.getEmailTemplateContent(EMAILTEMPLATEID.COMMON)
    End Function

    Function GetEmailDateFormat() As String
        Dim emailDateFormat As String = lookupService.GetLookUpName("S", "EMAIL", "EMAIL_DATE_FORMAT")

        If String.IsNullOrEmpty(emailDateFormat) Then
            emailDateFormat = "ddMMyyyy"
        End If

        GetEmailDateFormat = emailDateFormat
    End Function

    Sub ExecuteNextReportDateUpdJob() Implements IEmailJobService.ExecuteNextReportDateUpdJob
        Dim dtNxtRptDt As DataTable = lookupService.GetLookUp("S", "MISC", "NEXT_REPORT_DATE")
        Dim strInterval As String = lookupService.GetLookUpName("S", "MISC", "REPORT_FREQUENCY")
        Dim dateFormat As String = lookupService.GetLookUpName("S", "MISC", "DATE_FORMAT")
        If String.IsNullOrEmpty(dateFormat) Then
            dateFormat = "MM/dd/yyyy"
        End If

        Dim nxtRptDateStr As String = ""

        Try
            If dtNxtRptDt Is Nothing OrElse dtNxtRptDt.Rows.Count = 0 Then
                LogHelper.WriteLog("[NEXT_REPORT_DATE] is not yet set.")
                nxtRptDateStr = Format(Today, dateFormat)
            Else
                nxtRptDateStr = dtNxtRptDt.Rows(0).Item("lookup_name").ToString.Trim
            End If

            Dim nxtRptDate As Date
            If Not IsDate(nxtRptDateStr) Then
                nxtRptDateStr = Format(Today, dateFormat)
                LogHelper.WriteLog("[NEXT_REPORT_DATE] is not a valid date value.")
            End If

            nxtRptDate = nxtRptDateStr

                Select Case strInterval.ToUpper.Trim
                    Case "DAILY"
                        nxtRptDate = DateAdd(DateInterval.Day, 1, nxtRptDate)
                    Case "WEEKLY"
                    nxtRptDate = DateAdd(DateInterval.Day, 7, nxtRptDate)
                    Case "BIWEEKLY"
                        nxtRptDate = DateAdd(DateInterval.Day, 14, nxtRptDate)
                    Case "MONTHLY"
                        nxtRptDate = DateAdd(DateInterval.Month, 1, nxtRptDate)
                    Case Else
                        nxtRptDate = DateAdd(DateInterval.Day, 7, nxtRptDate)
                End Select

                
                dtNxtRptDt.Rows(0).Item("lookup_name") = Format(nxtRptDate, dateFormat)

                lookupService.SaveLookup(dtNxtRptDt)
        Catch ex As Exception
            LogHelper.WriteLog("Failed to execute NextReportDateUpdJob", ex)
        End Try
    End Sub
End Class

#End Region


