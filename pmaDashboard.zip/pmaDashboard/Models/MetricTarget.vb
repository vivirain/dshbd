﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

'Public Class MetricTarget
'    Property metricTargetId As Integer
'    Property metricYear As String
'    Property tssPrj As String
'    Property metricId As String
'    Property metricValType As String
'    Property metricVal As String
'    Property metricValMin As String
'    Property metricValMax As String

'    Property isActive As String

'    Property lastUpdatedBy As String
'    Property lastUpdatedDate As DateTime

'    Public Sub New()

'    End Sub
'End Class


Public Enum METRICVALCOMPARESIGN As Integer
    EQUALTO = 1
    NOTEQUALTO = 2
    GREATERTHANOREQUALTO = 3
    GREATERTHAN = 4
    LESSTHANOREQUALTO = 5
    LESSTHAN = 6
End Enum
#End Region

#Region "Service"

Public Interface IMetricTargetService

    Function GetBlankMetricTarget() As DataTable

    Function GetMetricTargetList(Optional year As String = "", Optional ByVal tssPrj As String = "") As DataTable

    Function GetMetricTarget(ByVal year As String, ByVal tssPrj As String, ByVal metricCode As String) As DataTable

    Function GetMetricTarget(ByVal metricTargetId As Integer) As DataTable


    Function GetLatestMetricTargetList(Optional tssPrj As String = "", Optional metricCode As String = "") As DataTable

    Function GetLatestMetricTargetYear(Optional tssPrj As String = "", Optional ByVal metricCode As String = "") As String

    Function GetMetricTargetViewByYear(ByVal year As String) As DataTable

    Function GetMetricTargetViewList(Optional ByVal year As String = "", Optional ByVal tssPrj As String = "") As DataTable


    Function HaveMetricTarget(ByVal year As String) As Boolean


    Function SaveMetricTargetList(ByVal dtEdit As DataTable) As Boolean


End Interface

Class MetricTargetService
    Implements IMetricTargetService

    Const sTable = "[dbo].[tpma_dshbd_metric_target]"
    Const sMetricTable = "[dbo].[tpma_dshbd_metric]"
    Const sView = "[dbo].[vpma_dshbd_metric_target]"

    Dim sSQLSel As String = String.Format("SELECT * FROM {0} ", sTable)
    Dim sSQLWhere As String = " WHERE [IS_ACTIVE] = 'Y' "
    Dim sSQLOrderBy As String = "ORDER BY [METRIC_YEAR] DESC, [TSS_PRJ], [METRIC_CODE] "
    Dim sSQLSelActiveOrder As String = sSQLSel & sSQLWhere & sSQLOrderBy
    Dim sSQLSelActiveOrderN As String = sSQLSel & sSQLWhere

    Private sqlHelper As SqlHelper = New SqlHelper()

    Function GetBlankMetricTarget() As DataTable Implements IMetricTargetService.GetBlankMetricTarget
        Dim sSQL As String = sSQLSel & " WHERE 1 = 0 "

        GetBlankMetricTarget = sqlHelper.ExecuteReaderQuery(sSQL)

    End Function


    Function GetMetricTargetList(Optional ByVal year As String = "", Optional ByVal tssPrj As String = "") As DataTable Implements IMetricTargetService.GetMetricTargetList
        Dim sb As StringBuilder = New StringBuilder(sSQLSelActiveOrderN)

        Dim sqlParams As SqlParameter() = {}
        Dim iParamsUpperBound As Integer = 0

        If Not String.IsNullOrEmpty(year) Then
            sb.Append(" AND [METRIC_YEAR] = @METRICYEAR ")

            If sqlParams.Length > 0 Then
                iParamsUpperBound = sqlParams.Length
            Else
                iParamsUpperBound = 0
            End If
            ReDim Preserve sqlParams(iParamsUpperBound)
            sqlParams(iParamsUpperBound) = New SqlParameter("@METRICYEAR", year)
        End If

        If Not String.IsNullOrEmpty(tssPrj) Then
            sb.Append(" AND [TSS_PRJ] = @TSSSERVICECATEGORY ")

            If sqlParams.Length > 0 Then
                iParamsUpperBound = sqlParams.Length
            Else
                iParamsUpperBound = 0
            End If

            ReDim Preserve sqlParams(iParamsUpperBound)
            sqlParams(iParamsUpperBound) = New SqlParameter("@TSSSERVICECATEGORY", tssPrj)
        End If

        sb.Append(sSQLOrderBy)


        If sqlParams Is Nothing Then
            GetMetricTargetList = sqlHelper.ExecuteReaderQuery(sb.ToString)
        ElseIf sqlParams.Length > 0 Then
            GetMetricTargetList = sqlHelper.ExecuteReaderQuery(sb.ToString, sqlParams)
        Else
            GetMetricTargetList = sqlHelper.ExecuteReaderQuery(sb.ToString)
        End If

    End Function


    Function GetMetricTarget(ByVal year As String, ByVal tssPrj As String, ByVal metricCode As String) As DataTable Implements IMetricTargetService.GetMetricTarget

        Dim sSQL As String = sSQLSelActiveOrderN & " And [METRIC_YEAR] = @METRICYEAR AND [TSS_PRJ] = @TSSSERVICECATEGORY AND [METRIC_CODE] = @METRICCODE"

        Dim sqlParams As SqlParameter() = {New SqlParameter("@METRICYEAR", year), _
                                           New SqlParameter("@TSSSERVICECATEGORY", tssPrj), _
                                           New SqlParameter("@METRICCODE", metricCode)}

        GetMetricTarget = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)
    End Function

    Function GetMetricTarget(ByVal metricTargetId As Integer) As DataTable Implements IMetricTargetService.GetMetricTarget
        Dim sSQL As String = sSQLSelActiveOrderN & " And [METRIC_TARGET_ID] = @METRICTARGETID"

        Dim sqlParams As SqlParameter() = {New SqlParameter("@METRICTARGETID", metricTargetId)}

        GetMetricTarget = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)
    End Function

    Function GetMetricTargetViewByYear(ByVal year As String) As DataTable Implements IMetricTargetService.GetMetricTargetViewByYear
        Dim sSQL As StringBuilder = New StringBuilder("")
        sSQL.Append("SELECT metricTarget.*, metric.metric_category, metric.metric_category_desc, metric.metric_name ")
        sSQL.Append(" FROM " & sTable & " metricTarget, " & sMetricTable & " metric")
        sSQL.Append(" WHERE metricTarget.metric_code = metric.metric_code AND metricTarget.is_active = 'Y' AND metricTarget.metric_year = @METRICYEAR")

        Dim sParams As SqlParameter() = {New SqlParameter("@METRICYEAR", year)}

        GetMetricTargetViewByYear = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sParams)

    End Function


    Function GetLatestMetricTargetList(Optional tssPrj As String = "", Optional metricCode As String = "") As DataTable Implements IMetricTargetService.GetLatestMetricTargetList
        Dim sLatestYear As String = ""
        sLatestYear = GetLatestMetricTargetYear(tssPrj, metricCode)

        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0

        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND [IS_ACTIVE] = 'Y' "
        If Not String.IsNullOrEmpty(sLatestYear) Then
            sSQL = sSQL & " AND [METRIC_YEAR] = @METRICYEAR "

            iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@METRICYEAR", sLatestYear)
        End If

        If Not String.IsNullOrEmpty(tssPrj) Then
            sSQL = sSQL & " AND [TSS_PRJ] = @TSSPRJ "

            iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@TSSPRJ", tssPrj)
        End If

        If Not String.IsNullOrEmpty(metricCode) Then
            sSQL = sSQL & " AND [METRIC_CODE] = @METRICCODE "

            iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@METRICCODE", metricCode)
        End If

        sSQL = sSQL & " ORDER BY [METRIC_YEAR] DESC, [TSS_PRJ], [METRIC_CODE] "

        If sqlParams Is Nothing Then
            GetLatestMetricTargetList = sqlHelper.ExecuteReaderQuery(sSQL)
        ElseIf sqlParams.Length = 0 Then
            GetLatestMetricTargetList = sqlHelper.ExecuteReaderQuery(sSQL)
        Else
            GetLatestMetricTargetList = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)
        End If

    End Function

    Function GetLatestMetricTargetYear(Optional tssPrj As String = "", Optional ByVal metricCode As String = "") As String Implements IMetricTargetService.GetLatestMetricTargetYear
        Dim sYear As String = ""
        Dim dt As DataTable = New DataTable

        Dim sSQL As String = "SELECT max(metric_year) AS metric_year FROM " & sTable & sSQLWhere

        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0

        If Not String.IsNullOrEmpty(tssPrj) Then
            sSQL = sSQL & " AND [TSS_PRJ] = @TSSPRJ "

            iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@TSSPRJ", tssPrj)
        End If

        If Not String.IsNullOrEmpty(metricCode) Then
            sSQL = sSQL & " AND [METRIC_CODE] = @METRICCODE "

            iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@METRICCODE", metricCode)
        End If


        If String.IsNullOrEmpty(tssPrj) And String.IsNullOrEmpty(metricCode) Then
            dt = sqlHelper.ExecuteReaderQuery(sSQL)
        Else
            dt = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)
        End If

        If Not dt Is Nothing Then
            If dt.Rows.Count > 0 Then
                If Not String.IsNullOrEmpty(dt.Rows(0).Item("metric_year").ToString) Then
                    sYear = dt.Rows(0).Item("metric_year").ToString
                End If
                dt.Dispose()
            End If
        End If

        GetLatestMetricTargetYear = sYear
    End Function



    Function GetMetricTargetViewList(Optional ByVal year As String = "", Optional ByVal tssPrj As String = "") As DataTable Implements IMetricTargetService.GetMetricTargetViewList
        Dim sb As StringBuilder = New StringBuilder("SELECT * FROM " & sView & "WHERE [IS_ACTIVE] = 'Y' ")

        Dim sqlParams As SqlParameter() = {}
        Dim iParamsUpperBound As Integer = 0

        If Not String.IsNullOrEmpty(year) Then
            sb.Append(" AND [METRIC_YEAR] = @METRICYEAR ")

            If sqlParams.Length > 0 Then
                iParamsUpperBound = sqlParams.Length
            Else
                iParamsUpperBound = 0
            End If
            ReDim Preserve sqlParams(iParamsUpperBound)
            sqlParams(iParamsUpperBound) = New SqlParameter("@METRICYEAR", year)
        End If

        If Not String.IsNullOrEmpty(tssPrj) Then
            sb.Append(" AND [TSS_PRJ] = @TSSSERVICECATEGORY ")

            If sqlParams.Length > 0 Then
                iParamsUpperBound = sqlParams.Length
            Else
                iParamsUpperBound = 0
            End If
            sqlParams(iParamsUpperBound) = New SqlParameter("@TSSSERVICECATEGORY", tssPrj)
        End If

        sb.Append(sSQLOrderBy)


        If sqlParams Is Nothing Then
            GetMetricTargetViewList = sqlHelper.ExecuteReaderQuery(sb.ToString)
        ElseIf sqlParams.Length = 0 Then
            GetMetricTargetViewList = sqlHelper.ExecuteReaderQuery(sb.ToString)
        Else
            GetMetricTargetViewList = sqlHelper.ExecuteReaderQuery(sb.ToString, sqlParams)
        End If

    End Function

    Function HaveMetricTarget(ByVal year As String) As Boolean Implements IMetricTargetService.HaveMetricTarget
        Dim iResult As Integer = 0

        Dim sSQL As String = "Select 1 FROM " & sTable & " WHERE [metric_year] = @METRICYEAR"
        Dim sParams As SqlParameter() = {New SqlParameter("@METRICYEAR", year)}

        iResult = sqlHelper.ExecuteReaderScalar(sSQL, sParams)

        HaveMetricTarget = IIf(iResult > 0, True, False)
    End Function


    Function SaveMetricTargetList(ByVal dtEdit As DataTable) As Boolean Implements IMetricTargetService.SaveMetricTargetList
        Dim bReturn As Boolean = False

        Dim sSQL = "SELECT * FROM " & sTable & " WHERE 1 = 0"

        Try
            Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQL, dtEdit)}
            bReturn = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
        Catch ex As Exception
            Console.Write(ex.ToString)
        End Try

        SaveMetricTargetList = bReturn
    End Function


End Class


Public Class MetricStatus
    Const GREEN = "G"
    Const AMBER = "A"
    Const RED = "R"

    Public Shared Function CalculateMetricStatus(ByVal dtMetricTarget As DataTable, ByVal compareVal As Decimal) As String
        Dim metricSta As String = ""

        If dtMetricTarget Is Nothing Then
            Return metricSta
        ElseIf dtMetricTarget.Rows.Count = 0 Then
            Return metricSta
        ElseIf IsDBNull(dtMetricTarget.Rows(0).Item("metric_val_sign")) Then
            Return metricSta
        ElseIf String.IsNullOrEmpty(dtMetricTarget.Rows(0).Item("metric_val_sign").ToString) Then
            Return metricSta
        ElseIf Not IsNumeric(dtMetricTarget.Rows(0).Item("metric_val_sign")) Then
            Return metricSta
        End If

        Dim drMetricTarget As DataRow = dtMetricTarget.Rows(0)
        Dim metricValSign As String = DataFormatHelper.StringTrim(drMetricTarget("metric_val_sign").ToString)
        Dim metricValG As String = DataFormatHelper.StringTrim(drMetricTarget("metric_val_green").ToString)
        Dim metricValA As String = DataFormatHelper.StringTrim(drMetricTarget("metric_val_amber").ToString)
        Dim metricValR As String = DataFormatHelper.StringTrim(drMetricTarget("metric_val_red").ToString)

        metricValG = IIf(IsNumeric(metricValG), metricValG, 0)
        metricValA = IIf(IsNumeric(metricValA), metricValA, 0)
        metricValR = IIf(IsNumeric(metricValR), metricValR, 0)

        'metricSta = RED

        Select Case CInt(metricValSign)
            Case METRICVALCOMPARESIGN.EQUALTO '=
                If Not String.IsNullOrEmpty(metricValG) And compareVal = metricValG Then
                    metricSta = GREEN
                ElseIf Not String.IsNullOrEmpty(metricValA) And compareVal = metricValA Then
                    metricSta = AMBER
                ElseIf Not String.IsNullOrEmpty(metricValR) And compareVal = metricValR Then
                    metricSta = RED
                End If

            Case METRICVALCOMPARESIGN.NOTEQUALTO  '<>
                If Not String.IsNullOrEmpty(metricValG) And compareVal <> metricValG Then
                    metricSta = GREEN
                ElseIf Not String.IsNullOrEmpty(metricValA) And compareVal <> metricValA Then
                    metricSta = AMBER
                ElseIf Not String.IsNullOrEmpty(metricValR) And compareVal <> metricValR Then
                    metricSta = RED
                End If


            Case METRICVALCOMPARESIGN.GREATERTHANOREQUALTO  '>=
                If Not String.IsNullOrEmpty(metricValG) And compareVal >= metricValG Then
                    metricSta = GREEN
                ElseIf Not String.IsNullOrEmpty(metricValA) And compareVal >= metricValA Then
                    metricSta = AMBER
                ElseIf Not String.IsNullOrEmpty(compareVal) Then
                    metricSta = RED
                End If

            Case METRICVALCOMPARESIGN.GREATERTHAN  '>
                If Not String.IsNullOrEmpty(metricValG) And compareVal > metricValG Then
                    metricSta = GREEN
                ElseIf Not String.IsNullOrEmpty(metricValA) And compareVal > metricValA Then
                    metricSta = AMBER
                ElseIf Not String.IsNullOrEmpty(compareVal) Then
                    metricSta = RED
                End If

            Case METRICVALCOMPARESIGN.LESSTHANOREQUALTO  '<=
                If Not String.IsNullOrEmpty(metricValG) And compareVal <= metricValG Then
                    metricSta = GREEN
                ElseIf Not String.IsNullOrEmpty(metricValA) And compareVal <= metricValA Then
                    metricSta = AMBER
                ElseIf Not String.IsNullOrEmpty(compareVal) Then
                    metricSta = RED
                End If

            Case METRICVALCOMPARESIGN.LESSTHAN  '<
                If Not String.IsNullOrEmpty(metricValG) And compareVal < metricValG Then
                    metricSta = GREEN
                ElseIf Not String.IsNullOrEmpty(metricValA) And compareVal < metricValA Then
                    metricSta = AMBER
                ElseIf Not String.IsNullOrEmpty(compareVal) Then
                    metricSta = RED
                End If
        End Select

        CalculateMetricStatus = metricSta
    End Function

End Class


#End Region