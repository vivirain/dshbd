﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

#End Region


#Region "Service"

Public Interface IUserBuService

    Function GetUserBuList(Optional ByVal buCode As String = "", Optional ByVal logonId As Integer = 0) As DataTable

    Function SaveUserBuList(ByVal dtSave As DataTable) As Boolean

End Interface

Class UserBuService
    Implements IUserBuService

    Const sTable As String = "[dbo].[tpma_dshbd_user_bu]"
    Dim sSQLSel As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND IS_ACTIVE = 'Y'"

    Private sqlHelper As SqlHelper = New SqlHelper()


    Function GetUserBuList(Optional ByVal buCode As String = "", Optional ByVal logonId As Integer = 0) As DataTable Implements IUserBuService.GetUserBuList
        Dim sSQL As StringBuilder = New StringBuilder(sSQLSel)


        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0

        If Not String.IsNullOrEmpty(buCode) Then
            sSQL.Append(" AND [bu_code] = @BUCODE")

            iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@BUCODE", buCode)
        End If

        If logonId > 0 Then
            sSQL.Append(" AND [pma_logon_id] = @LOGONID")

            iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@LOGONID", logonId)
        End If


        If String.IsNullOrEmpty(buCode) And logonId <= 0 Then
            GetUserBuList = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        Else
            GetUserBuList = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
        End If

    End Function


    Function SaveUserBuList(ByVal dtSave As DataTable) As Boolean Implements IUserBuService.SaveUserBuList
        Dim bSave As Boolean = False

        If dtSave Is Nothing Then
            Return bSave
        End If

        Dim sSQL As StringBuilder = New StringBuilder(" SELECT * FROM " & sTable & " WHERE 1 = 0 ")

        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQL.ToString, dtSave)}
        bSave = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)

        SaveUserBuList = bSave
    End Function


End Class

#End Region

