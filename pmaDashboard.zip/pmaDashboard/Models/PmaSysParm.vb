﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"


#End Region


#Region "Service"

Public Interface IPmaSysParmService

    Function getSystemParam() As DataTable

    Function getSystemParam(ByVal paramCd As String) As DataTable

    Function getSystemParamValue(ByVal paramCd As String) As String

End Interface

Class PmaSysParmService
    Implements IPmaSysParmService

    Const sTable = "[dbo].[tpma_sysparm]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 "
    Private sqlHelper As SqlHelper = New SqlHelper()

    Function getSystemParam() As DataTable Implements IPmaSysParmService.getSystemParam

        getSystemParam = sqlHelper.ExecuteReaderQuery(sSQLTable)

    End Function

    Function getSystemParam(ByVal paramCd As String) As DataTable Implements IPmaSysParmService.getSystemParam
        Dim sSQL As String = sSQLTable & " AND [sys_param_cd] = @SYSPARAMCD "

        Dim sqlParams As SqlParameter() = {New SqlParameter("@SYSPARAMCD", paramCd)}

        getSystemParam = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

    End Function

    Function getSystemParamValue(ByVal paramCd As String) As String Implements IPmaSysParmService.getSystemParamValue
        Dim sReturnVal As String = ""
        Dim dtSysParams As DataTable
        Dim sSQL As String = sSQLTable & " AND [sys_param_cd] = @SYSPARAMCD "

        Dim sqlParams As SqlParameter() = {New SqlParameter("@SYSPARAMCD", paramCd)}

        dtSysParams = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

        If Not dtSysParams Is Nothing AndAlso dtSysParams.Rows.Count > 0 Then
            sReturnVal = dtSysParams.Rows(0).Item("sys_param_value").ToString.Trim
            dtSysParams.Dispose()
        End If

        getSystemParamValue = sReturnVal

    End Function

End Class

#End Region

