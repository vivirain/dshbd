﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

Public Enum EMAILTEMPLATEID
    NEWPRFSUBMITTED = 21
    PRFUPD = 22
    PRFUPDOVERDUE = 23
    COMMON = 99
End Enum

#End Region


#Region "Service"

Public Interface IPmaEmailTemplateService

    Function getEmailTemplate(ByVal templateName As String) As DataTable

    Function getEmailTemplate(ByVal templateId As Integer) As DataTable

    Function getEmailTemplateContent(ByVal templateId As Integer) As String

End Interface

Class PmaEmailTemplateService
    Implements IPmaEmailTemplateService

    Const sTable = "[dbo].[tpma_email_template]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 "
    Private sqlHelper As SqlHelper = New SqlHelper()

    Function getEmailTemplate(ByVal templateName As String) As DataTable Implements IPmaEmailTemplateService.getEmailTemplate
        Dim sSQL As String = sSQLTable & " AND [tmp_name] = @TMPNAME "
        Dim sqlParams As SqlParameter() = {New SqlParameter("@TMPNAME", templateName)}

        getEmailTemplate = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

    End Function

    Function getEmailTemplate(ByVal templateId As Integer) As DataTable Implements IPmaEmailTemplateService.getEmailTemplate
        Dim sSQL As String = sSQLTable & " AND [tmp_id] = @TMPID "
        Dim sqlParams As SqlParameter() = {New SqlParameter("@TMPID", templateId)}

        getEmailTemplate = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)
    End Function

    Function getEmailTemplateContent(ByVal templateId As Integer) As String Implements IPmaEmailTemplateService.getEmailTemplateContent
        Dim sSQL As String = sSQLTable & " AND [tmp_id] = @TMPID "
        Dim sqlParams As SqlParameter() = {New SqlParameter("@TMPID", templateId)}

        Dim dtEmailTmpl As DataTable = New DataTable
        Dim sEmailContent As String = ""

        dtEmailTmpl = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

        If Not dtEmailTmpl Is Nothing AndAlso dtEmailTmpl.Rows.Count > 0 Then
            sEmailContent = dtEmailTmpl.Rows(0).Item("email_content").ToString.Trim

            dtEmailTmpl.Dispose()
        End If

        getEmailTemplateContent = sEmailContent
    End Function
End Class

#End Region

