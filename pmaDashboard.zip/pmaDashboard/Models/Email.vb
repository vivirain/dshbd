﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"
#End Region


#Region "Service"

Public Interface IEmailService

End Interface

Class EmailService
    Implements IEmailService
   
End Class

#End Region

