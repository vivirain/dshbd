﻿Imports System.Data
Imports System.Data.SqlClient
Imports pmaDashboard.SqlHelper


#Region "Model"

Public Class SCHEDULE_STAUS

    Public Shared ReadOnly Property OPEN() As String
        Get
            Return "O"
        End Get
    End Property

    Public Shared ReadOnly Property INPROGRESS() As String
        Get
            Return "P"
        End Get
    End Property

    Public Shared ReadOnly Property CLOSE() As String
        Get
            Return "C"
        End Get
    End Property
End Class


#End Region

#Region "Service"

Public Interface IProfileScheduleService

    Function GetProfileScheduleList(Optional ByVal emptyData As Boolean = False) As DataTable
    Function GetScheduleList(ByVal scheduleStatus As String) As DataTable
    Function GetProfileScheduleList(ByVal prfId As Integer) As DataTable
    Function GetProfileScheduleActionList(Optional ByVal emptyData As Boolean = False) As DataTable

    Function GetProfileScheduleListView(ByVal prfId As Integer, Optional ByVal scheduleStatus As String = "") As DataTable



    Function GetProfileSchedule(ByVal scheduleNo As String) As DataTable

    Function GetNewScheduleNo() As Nullable(Of Integer)

    Function SaveProfileSchedule(ByVal dtScheduleSave As DataTable) As Boolean
    'Function CreateProfileSchedule(ByVal dtSchedule As DataTable, ByVal dtScheduleAction As DataTable) As Boolean

End Interface

Class ProfileScheduleService
    Implements IProfileScheduleService


    Const sTable As String = "[dbo].[tpma_dshbd_prj_schedule]"
    Const sChildTable As String = "[dbo].[tpma_dshbd_prj_schedule_comment]"
    Const sLookupTable As String = "[dbo].[tpma_dshbd_lookup]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " "
    Dim sSQLBuilder As StringBuilder

    Private sqlHelper As SqlHelper = New SqlHelper()


    Function GetProfileScheduleList(Optional ByVal emptyData As Boolean = False) As DataTable Implements IProfileScheduleService.GetProfileScheduleList
        sSQLBuilder = New StringBuilder(sSQLTable)

        If emptyData Then
            sSQLBuilder.Append(" WHERE 1 = 0 ")
        End If

        GetProfileScheduleList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

    End Function

    Function GetScheduleList(ByVal scheduleStatus As String) As DataTable Implements IProfileScheduleService.GetScheduleList
        Dim sqlParams As SqlParameter() = {}

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")



        If Not String.IsNullOrEmpty(scheduleStatus) Then
            sSQLBuilder.Append(" AND schedule_status = @SCHEDULESTATUS")
            If sqlParams.Length <= 0 Then
                ReDim Preserve sqlParams(0)
                sqlParams(0) = New SqlParameter("@SCHEDULESTA", scheduleStatus)
            Else
                ReDim Preserve sqlParams(sqlParams.Length)
                sqlParams(sqlParams.Length) = New SqlParameter("@SCHEDULESTA", scheduleStatus)
            End If
        End If

        If sqlParams Is Nothing Then
            GetScheduleList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
        ElseIf sqlParams.Length = 0 Then
            GetScheduleList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
        Else
            GetScheduleList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
        End If

    End Function

    Function GetProfileScheduleList(ByVal prfId As Integer) As DataTable Implements IProfileScheduleService.GetProfileScheduleList
        sSQLBuilder = New StringBuilder(sSQLTable & "WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND prf_id = @PRFID ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId)}

        GetProfileScheduleList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function
    Function GetProfileScheduleListView(ByVal prfId As Integer, Optional ByVal scheduleStatus As String = "") As DataTable Implements IProfileScheduleService.GetProfileScheduleListView
        sSQLBuilder = New StringBuilder("SELECT a.*, b.lookup_name as schedule_trace_status_desc ")
        sSQLBuilder.Append(" FROM " & sTable & " a ")
        sSQLBuilder.Append(" LEFT JOIN " & sLookupTable & " b ")
        sSQLBuilder.Append(" ON a.schedule_trace_status = b.lookup_code ")
        sSQLBuilder.Append(" AND b.lookup_type = 'B' ")
        sSQLBuilder.Append(" AND b.category = 'STATUS' ")

        sSQLBuilder.Append(" WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND prf_id = @PROFILEID")
        Dim sqlParams As SqlParameter() = {New SqlParameter("PROFILEID", prfId)}

        If Not String.IsNullOrEmpty(scheduleStatus) Then
            sSQLBuilder.Append(" AND schedule_status = @SCHEDULESTA ")

            ReDim Preserve sqlParams(1)
            sqlParams(1) = New SqlParameter("@SCHEDULESTA", scheduleStatus)
        End If


        GetProfileScheduleListView = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

    End Function


    Function GetProfileSchedule(ByVal scheduleNo As String) As DataTable Implements IProfileScheduleService.GetProfileSchedule
        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [SCHEDULE_NO] = @SCHEDULENO")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@SCHEDULENO", scheduleNo)}

        GetProfileSchedule = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

    End Function

    Function GetNewScheduleNo() As Nullable(Of Integer) Implements IProfileScheduleService.GetNewScheduleNo
        Dim scheduleNo As String = ""


        Dim lookupService As ILookupService = New LookupService
        Dim dtLookup As DataTable = New DataTable
        dtLookup = lookupService.GetLookUp("S", "MISC", "Schedule_No")
        If dtLookup Is Nothing Then
            Return vbNull
        ElseIf dtLookup.Rows.Count = 0 Then
            Return vbNull
        Else
            scheduleNo = dtLookup.Rows(0).Item("lookup_name").ToString
        End If

        If IsNumeric(scheduleNo) Then
            scheduleNo = scheduleNo + 1

            dtLookup.Rows(0).Item("lookup_name") = scheduleNo

            lookupService.SaveLookup(dtLookup)

            Return CInt(scheduleNo)
        Else
            Return vbNull
        End If

    End Function




    Function SaveProfileSchedule(ByVal dtScheduleSave As DataTable) As Boolean Implements IProfileScheduleService.SaveProfileSchedule
        If dtScheduleSave Is Nothing Then
            Return False
        End If

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 0 ")

        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQLBuilder.ToString, dtScheduleSave)}
        SaveProfileSchedule = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
    End Function

    Function GetProfileScheduleActionList(Optional ByVal emptyData As Boolean = False) As DataTable Implements IProfileScheduleService.GetProfileScheduleActionList
        sSQLBuilder = New StringBuilder("SELECT * FROM " & sChildTable & " ")

        If emptyData Then
            sSQLBuilder.Append(" WHERE 1 = 0 ")
        End If

        GetProfileScheduleActionList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
    End Function


    'Function CreateProfileSchedule(ByVal dtSchedule As DataTable, ByVal dtScheduleAction As DataTable) As Boolean Implements IProfileScheduleService.CreateProfileSchedule

    '    'Dim sSQLSchedule As String = "SELECT * FROM " & sTable & " WHERE 1 = 0 "
    '    'Dim sSQLScheduleAction As String = "SELECT * FROM " & sChildTable & " WHERE 1 = 0 "

    '    'sSQLBuilder = New StringBuilder(sSQLTable)
    '    'sSQLBuilder.Append(" WHERE 1 = 0 ")

    '    'Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQLSchedule, dtSchedule), _
    '    '                                           New SqlAdapterUpdate(sSQLScheduleAction, dtScheduleAction)
    '    '                                           }
    '    'Dim scheduleId As Integer
    '    'CreateProfileSchedule = sqlHelper.ExecuteAdapterInsert(sqlAdapterUpd, scheduleId, "schedule_id")
    'End Function


End Class

#End Region

