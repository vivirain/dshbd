﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization



#Region "Model"

'Public Class ProjectMetric
'    Property id As Integer

'    Property prjCode As String
'    Property metricCode As String

'    Property metricVal As String
'    Property metricRawValJson As String
'    Property metricStatus As String

'    Property data_version As String

'    Property isActive As String

'    Property createdBy As String
'    Property createdDate As DateTime
'    Property lastUpdatedBy As String
'    Property lastUpdatedDate As DateTime
'End Class

Public Class ProjectMetricRawJson
    Private _code As String
    Property code() As String
        Get
            Return _code
        End Get
        Set(ByVal value As String)
            _code = value
        End Set
    End Property

    Private _value As String
    Property value() As String
        Get
            Return _value
        End Get
        Set(ByVal value As String)
            _value = value
        End Set
    End Property

    Public Shared Function DeserializeJsonToList(ByVal jsonText As String) As List(Of ProjectMetricRawJson)

        Dim JsonList As List(Of ProjectMetricRawJson) = Nothing
        If Not String.IsNullOrEmpty(jsonText) Then
            Dim ser As JavaScriptSerializer = New JavaScriptSerializer()
            JsonList = ser.Deserialize(Of List(Of ProjectMetricRawJson))(jsonText)
        End If

        Return JsonList
    End Function
End Class


Public Enum METRICVERSION
    CURRENT = 0
    LAST = -1
End Enum

#End Region

#Region "Service"

Public Interface IProjectMetricService

    Function GetBlankProjectMetric() As DataTable

    Function GetProjectMetric(ByVal prjCodes As String()) As DataTable

    Function GetProjectMetric(ByVal prjCode As String, ByVal metricCode As String) As DataTable

    Function GetProjectMetricId(ByVal prjCode As String, ByVal metricCode As String) As Integer

    Function UploadProjectMetric(ByVal PrjCode As String, ByVal dtMetricRaw As DataTable) As Boolean

    Function CalculateMetricValue(ByVal metricCode As String, ByVal dtPrjMetricRaw As DataTable) As Decimal

    Function CalculateMetricValue(ByVal metricCode As String, ByVal hash As Hashtable) As Nullable(Of Decimal)

    Function CalculateMetricStatus(ByVal metricTargetYear As String, ByVal tssPrj As String, ByVal metricCode As String, ByVal metricVal As Decimal) As String


    Function GetProjectMetricHistList(ByVal prjCodes As String(), ByVal dataVersion As String) As DataTable
    Function GetProjectMetricHistList(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataversion As String) As DataTable

    Function GetProjectMetricHist(ByVal prjCodes As String(), ByVal dataVersion As String) As DataTable
    Function GetProjectMetricHist(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataversion As String) As DataTable

    Function GetProjectMetricHist(ByVal prjCode As String, ByVal dataVersion As String) As Hashtable

    Function HasProjectMetrics(ByVal prjCodes As String()) As Boolean

End Interface

Class ProjectMetricService
    Implements IProjectMetricService

    Const sTable = "[dbo].[tpma_dshbd_prj_metric]"
    Const sHistTable = "[dbo].[tpma_dshbd_prj_metric_hist]"

    Enum EDITMODE As Integer
        ADD = DataRowState.Added
        UPDATE = DataRowState.Modified
        DELETE = DataRowState.Deleted
    End Enum

    Dim mode As Integer = EDITMODE.ADD
    Private sqlHelper As SqlHelper = New SqlHelper()

    Dim pmaPrjService As IPmaProjectService = New PmaProjectService

    Function GetBlankProjectMetric() As DataTable Implements IProjectMetricService.GetBlankProjectMetric
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE 1 = 0"

        GetBlankProjectMetric = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Function GetProjectMetric(ByVal prjCodes As String()) As DataTable Implements IProjectMetricService.GetProjectMetric
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND [IS_ACTIVE] = 'Y' "

        If prjCodes Is Nothing Then
            Return sqlHelper.ExecuteReaderQuery(sSQL)
        ElseIf prjCodes.Length = 0 Then
            Return sqlHelper.ExecuteReaderQuery(sSQL)
        End If

        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQL = sSQL & "AND ( "
                Else
                    sSQL = sSQL & " OR "
                End If

                iParam = iParam + 1
                sSQL = sSQL & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next

        If iParam > 0 Then
            sSQL = sSQL & ") "
        End If

        If iParam = 0 Then
            GetProjectMetric = sqlHelper.ExecuteReaderQuery(sSQL)
        Else
            GetProjectMetric = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)
        End If

    End Function


    Function GetProjectMetric(ByVal prjCode As String, ByVal metricCode As String) As DataTable Implements IProjectMetricService.GetProjectMetric

        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND [IS_ACTIVE] = 'Y' AND [PrJ_CODE] = @PRJCODE AND [METRIC_CODE] = @METRICCODE"

        Dim sqlParams() As SqlParameter = {New SqlParameter("@PRJCODE", prjCode), _
                                           New SqlParameter("@METRICCODE", metricCode)}

        GetProjectMetric = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)
    End Function


    Function GetProjectMetricId(ByVal prjCode As String, ByVal metricCode As String) As Integer Implements IProjectMetricService.GetProjectMetricId

        Dim sSQL As String = "SELECT [id] FROM " & sTable & " WHERE 1 = 1 AND [IS_ACTIVE] = 'Y' AND [PrJ_CODE] = @PRJCODE AND [METRIC_CODE] = @METRICCODE "
        sSQL = sSQL & " AND [TSS_PRJ] = @TSSPRJ "
        sSQL = sSQL & " AND [METRIC_CATEGORY] = @METRICCATE "
        sSQL = sSQL & " AND [METRIC_CODE] = @METRICCODE "

        Dim sqlParams() As SqlParameter = {New SqlParameter("@PRJCODE", prjCode), _
                                           New SqlParameter("@METRICCODE", metricCode)}

        GetProjectMetricId = sqlHelper.ExecuteReaderScalar(sSQL, sqlParams)
    End Function


    Function IsExistedProjectMetric(ByVal prjCode As String, ByVal metricCode As String) As Boolean

        If GetProjectMetricId(prjCode, metricCode) > 0 Then
            Return True
        Else
            Return False
        End If

    End Function


    Function UploadProjectMetric(ByVal prjCode As String, ByVal dtPrjMetricRaw As DataTable) As Boolean Implements IProjectMetricService.UploadProjectMetric
        Dim bUpdate As Boolean = False

        If dtPrjMetricRaw Is Nothing Then
            Return False
        End If

        If dtPrjMetricRaw.Rows.Count = 0 Then
            Return False
        End If

        'Get existing project project metric data
        Dim dtPrjMetric As DataTable = New DataTable("prjMetric")
        Dim prjCodeArray As String() = {prjCode}
        dtPrjMetric = GetProjectMetric(prjCodeArray)

        'Get TSS Service Category

        Dim dtProject As DataTable = pmaPrjService.GetProjectView(prjCode)
        Dim tssPrj As String
        If Not dtProject Is Nothing Then
            If dtProject.Rows.Count > 0 Then
                tssPrj = dtProject.Rows(0).Item("tss_prj").ToString
            Else
                Return False
            End If
        Else
            Return False
        End If

        'Get project metric list
        Dim metricService As IMetricService = New MetricService
        Dim dtMetric As DataTable = New DataTable("metric")
        'dtMetric = metricService.GetMetricList(tssPrj)
        If Not dtMetric Is Nothing Then
            If dtMetric.Rows.Count = 0 Then
                Return False
            End If
        Else
            Return False
        End If


        Dim dtPrjMetricEdit As DataTable = dtPrjMetric.Clone
        Dim dataVersion As String = Format(Now, "yyyyMMdd")
        For Each drMetric As DataRow In dtMetric.Rows
            Dim metricCate As String = drMetric("metric_category").ToString
            Dim metricCode As String = drMetric("metric_code").ToString
            Dim metricVal As Decimal = New Decimal(0)

            Dim prjMetricId As Integer = GetProjectMetricId(prjCode, metricCode)
            Dim drPrjMetricEdit As DataRow = dtPrjMetricEdit.NewRow
            Dim drPrjMetric As DataRow

            If prjMetricId = 0 Then
                mode = EDITMODE.ADD

                drPrjMetricEdit("prj_code") = prjCode
                drPrjMetricEdit("tss_prj") = tssPrj
                drPrjMetricEdit("metric_category") = metricCate
                drPrjMetricEdit("metric_code") = metricCode

                drPrjMetricEdit("created_dt") = Now
                drPrjMetricEdit("last_updated_dt") = Now
                drPrjMetricEdit("is_active") = "Y"

            Else
                mode = EDITMODE.UPDATE
                drPrjMetricEdit.SetModified()

                drPrjMetric = dtPrjMetric.Rows.Find(prjMetricId)
                drPrjMetricEdit.ItemArray = drPrjMetric.ItemArray
                drPrjMetricEdit("last_updated_dt") = Now
            End If

            'Calculate Metric Value
            drPrjMetricEdit("metric_val") = Decimal.Round(CalculateUploadMetricValue(metricCode, dtPrjMetricRaw), 2)

            'Data Version
            drPrjMetricEdit("data_version") = dataVersion
            dtPrjMetricEdit.Rows.Add(drPrjMetricEdit)

        Next

        Dim sSQL As String = "SELECT * FROM " & sTable

        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQL, dtPrjMetricEdit)}
        UploadProjectMetric = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)


    End Function

    Function CalculateUploadMetricValue(ByVal metricCode As String, ByVal dtPrjMetricRaw As DataTable) As Decimal
        Dim metricVal As Decimal = New Decimal(0)

        Dim rawRec As Integer = 0

        If dtPrjMetricRaw Is Nothing Then
            Return metricVal
        ElseIf dtPrjMetricRaw.Rows.Count = 0 Then
            Return metricVal
        Else
            rawRec = dtPrjMetricRaw.Rows.Count
        End If



        Select Case metricCode
            Case "11" 'CSS
                Dim cssList(rawRec - 1) As CSS

                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)
                    Dim cssScore As Decimal
                    Dim actlEffort As Decimal
                    If Not IsDBNull(drPrjMetricRaw("css_score")) Then
                        cssScore = drPrjMetricRaw("css_score")
                    End If
                    If Not IsDBNull(drPrjMetricRaw("actual_effort")) Then
                        actlEffort = drPrjMetricRaw("actual_effort")
                    End If
                    cssList(i) = New CSS(cssScore, actlEffort)
                Next
                metricVal = MetricHelper.CSS(cssList)


            Case "21" 'S1
                Dim s1List(rawRec - 1) As Integer
                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)
                    Dim s1 As Integer = DataFormatHelper.StringToInteger(drPrjMetricRaw("s1").ToString())
                    s1List(i) = s1
                Next
                metricVal = MetricHelper.Incident(s1List)

            Case "22" 'S2
                Dim s2List(rawRec - 1) As Integer
                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)
                    Dim s2 As Integer = DataFormatHelper.StringToInteger(drPrjMetricRaw("s2").ToString())
                    s2List(i) = s2
                Next
                metricVal = MetricHelper.Incident(s2List)

            Case "23"
                Dim bauDefectList(rawRec - 1) As BauDefect

                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim uatDefect As Defect = New Defect
                    uatDefect.criticalDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_critical_defect").ToString())
                    uatDefect.majorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_major_defect").ToString())
                    uatDefect.minorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_minor_defect").ToString())
                    uatDefect.trivialDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_trivial_defect").ToString())

                    bauDefectList(i).uatDefect = uatDefect
                    bauDefectList(i).actualEffort = DataFormatHelper.StringToDecimal(drPrjMetricRaw("actual_effort").ToString())
                Next

                metricVal = MetricHelper.BauDefectRate(bauDefectList)

            Case "24"
                Dim prjDefectList(rawRec - 1) As PrjDefect

                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim uatDefect As Defect = New Defect
                    uatDefect.criticalDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_critical_defect").ToString())
                    uatDefect.majorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_major_defect").ToString())
                    uatDefect.minorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_minor_defect").ToString())
                    uatDefect.trivialDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_trivial_defect").ToString())

                    Dim prdDefect As Defect = New Defect
                    prdDefect.criticalDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("prod_critical_defect").ToString())
                    prdDefect.majorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("prod_major_defect").ToString())
                    prdDefect.minorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("prod_minor_defect").ToString())
                    prdDefect.trivialDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("prod_trivial_defect").ToString())

                    prjDefectList(i).uatDefect = uatDefect
                    prjDefectList(i).prdDefect = prdDefect
                    prjDefectList(i).actualEffort = DataFormatHelper.StringToDecimal(drPrjMetricRaw("actual_effort").ToString())
                Next

                metricVal = MetricHelper.PrjDefectRate(prjDefectList)

            Case "25"

                Dim defectRemovalList(rawRec - 1) As DefectRemoval

                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim defectRemoval As DefectRemoval = New DefectRemoval
                    defectRemoval.sitDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("sit_defect").ToString())

                    Dim uatDefect As Defect = New Defect

                    uatDefect.criticalDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_critical_defect").ToString())
                    uatDefect.majorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_major_defect").ToString())
                    uatDefect.minorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_minor_defect").ToString())
                    uatDefect.trivialDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_trivial_defect").ToString())

                    defectRemoval.uatDefect = uatDefect

                    defectRemovalList(i) = defectRemoval
                Next

                metricVal = MetricHelper.UatDefectRemovalRate(defectRemovalList)

            Case "26"

                Dim uatInitPassList(rawRec - 1) As UatInitPass
                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim uatInitPass As UatInitPass = New UatInitPass
                    uatInitPass.uatInitPassCase = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_test_cases_1st_time_passed").ToString())
                    uatInitPass.uatExecutedCase = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_test_cases_executed").ToString())

                    uatInitPassList(i) = uatInitPass
                Next
                metricVal = MetricHelper.UatInitPassRate(uatInitPassList)



            Case "27" 'UAT ReOpen


                Dim uatReopenList(rawRec - 1) As DefectReOpen

                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim uatReopen As DefectReOpen = New DefectReOpen
                    uatReopen.reopenDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("reopen_uat_defect").ToString())

                    Dim uatDefect As Defect = New Defect

                    uatDefect.criticalDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_critical_defect").ToString())
                    uatDefect.majorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_major_defect").ToString())
                    uatDefect.minorDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_minor_defect").ToString())
                    uatDefect.trivialDefect = DataFormatHelper.StringToInteger(drPrjMetricRaw("uat_trivial_defect").ToString())

                    uatReopen.defect = uatDefect

                    uatReopenList(i) = uatReopen
                Next
                metricVal = MetricHelper.DefectReopenRate(uatReopenList)


            Case "28" 'Cost of Poor Quality
                Dim cpqList(rawRec - 1) As CostOfPoorQuality

                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim cpq As CostOfPoorQuality = New CostOfPoorQuality
                    cpq.failureEffort = DataFormatHelper.StringToDecimal(drPrjMetricRaw("failure_effort").ToString)
                    cpq.actualEffort = DataFormatHelper.StringToDecimal(drPrjMetricRaw("actual_effort").ToString)

                    cpqList(i) = cpq

                Next

                metricVal = MetricHelper.CostOfPoorQuality(cpqList)



            Case "31"

                Dim responseOnTimeList(rawRec - 1) As OnTimeIncident

                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim responseOnTime As OnTimeIncident = New OnTimeIncident
                    responseOnTime.onTime = DataFormatHelper.StringToInteger(drPrjMetricRaw("response_on_time").ToString)
                    responseOnTime.receivedIncident = DataFormatHelper.StringToInteger(drPrjMetricRaw("resolution_on_time").ToString)

                    responseOnTimeList(i) = responseOnTime

                Next

                metricVal = MetricHelper.OnTimeRate(responseOnTimeList)


            Case "32" 'Resolution OnTime Rate
                Dim resolutionOnTimeList(rawRec - 1) As OnTimeIncident

                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim resolutionOnTime As OnTimeIncident = New OnTimeIncident
                    resolutionOnTime.onTime = DataFormatHelper.StringToInteger(drPrjMetricRaw("resolution_on_time").ToString)
                    resolutionOnTime.receivedIncident = DataFormatHelper.StringToInteger(drPrjMetricRaw("resolution_on_time").ToString)

                    resolutionOnTimeList(i) = resolutionOnTime

                Next

                metricVal = MetricHelper.OnTimeRate(resolutionOnTimeList)



            Case "41" 'Task On Schedule Rate
                Dim taskOnScheduleList(rawRec - 1) As TaskOnSchedule

                For i As Integer = 0 To rawRec - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim taskOnSchedule As TaskOnSchedule = New TaskOnSchedule
                    taskOnSchedule.taskCompletedUnderControl = DataFormatHelper.StringToInteger(drPrjMetricRaw("comp_task_und_ctrl").ToString)
                    taskOnSchedule.taskCompleted = DataFormatHelper.StringToInteger(drPrjMetricRaw("comp_task").ToString)

                    taskOnScheduleList(i) = taskOnSchedule

                Next

                metricVal = MetricHelper.TaskOnSchedulRate(taskOnScheduleList)

            Case "42" 'SPI

                'metricVal = MetricHelper.SPI(drMetricRaw(""), drMetricRaw(""))

            Case "43"
                'metricVal = MetricHelper.SPI(drMetricRaw(""), drMetricRaw(""))

        End Select

        CalculateUploadMetricValue = metricVal
    End Function

    Function CalculateMetricValue(ByVal metricCode As String, ByVal dtPrjMetricRaw As DataTable) As Decimal Implements IProjectMetricService.CalculateMetricValue
        Dim metricVal As Decimal = Nothing

        Dim rawRec As Integer = 0

        If dtPrjMetricRaw Is Nothing Then
            Return metricVal
        ElseIf dtPrjMetricRaw.Rows.Count = 0 Then
            Return metricVal
        End If

        Dim drCal As DataRow()
        'drCal = dtPrjMetricRaw.Select("metric_code = '" & metricCode & "'", "prj_code, metric_raw_code")
        drCal = dtPrjMetricRaw.Select(" 1 = 1 ", "prj_code, metric_raw_code")
        If drCal Is Nothing Then
            Return metricVal
        ElseIf drCal.Length = 0 Then
            Return metricVal
        End If



        Select Case metricCode
            Case "11" 'CSS
                'Dim cssList(rawRec - 1) As CSS

                Dim cssList As CSS() = {}
                Dim iUpperBound As Integer = 0

                Dim css As CSS = Nothing

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If


                    Dim sMetricRawCode As String = ""
                    If Not IsDBNull(drPrjMetricRaw("metric_raw_code")) Then
                        sMetricRawCode = DataFormatHelper.StringTrim(drPrjMetricRaw("metric_raw_code"))
                    End If

                    Dim decMetricRawVal As Nullable(Of Decimal)
                    If Not IsDBNull(drPrjMetricRaw("metric_raw_val")) Then
                        decMetricRawVal = drPrjMetricRaw("metric_raw_val")
                    End If

                    If sMetricRawCode = "css_score" Or sMetricRawCode = "actual_effort" Then
                        If css Is Nothing Then
                            css = New CSS
                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            css = New CSS
                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then

                            If css.score > 0 And css.actualEffort > 0 Then
                                iUpperBound = IIf(cssList.Length <= 0, 0, cssList.Length)
                                ReDim Preserve cssList(iUpperBound)
                                cssList(iUpperBound) = css
                            End If
                            
                            css = New CSS
                        End If

                        If sMetricRawCode = "css_score" Then
                            css.score = IIf(decMetricRawVal.HasValue, decMetricRawVal, 0)
                        Else
                            css.actualEffort = IIf(decMetricRawVal.HasValue, decMetricRawVal, 0)
                        End If
                    End If
                Next

                'Handle last css item
                If Not css Is Nothing And css.score > 0 And css.actualEffort > 0 Then
                    iUpperBound = IIf(cssList.Length <= 0, 0, cssList.Length)
                    ReDim Preserve cssList(iUpperBound)
                    cssList(iUpperBound) = css
                End If

                If cssList.Length > 0 Then
                    metricVal = MetricHelper.CSS(cssList)
                End If



            Case "21" 'S1
                'Dim s1List(rawRec - 1) As Integer
                Dim s1List As Integer() = {}
                Dim iUpperBound As Integer = 0

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)
                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")

                    If sMetricRawCode = "s1" Then
                        iUpperBound = IIf(s1List.Length <= 0, 0, s1List.Length)
                        ReDim s1List(iUpperBound)
                        s1List(iUpperBound) = drPrjMetricRaw("metrci_raw_val")
                    End If
                Next
                If s1List.Length > 0 Then
                    metricVal = MetricHelper.Incident(s1List)
                End If


            Case "22" 'S2
                'Dim s1List(rawRec - 1) As Integer
                Dim s2List As Integer() = {}
                Dim iUpperBound As Integer = 0

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)
                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")

                    If sMetricRawCode = "s2" Then
                        iUpperBound = IIf(s2List.Length <= 0, 0, s2List.Length)
                        ReDim s2List(iUpperBound)
                        s2List(iUpperBound) = drPrjMetricRaw("metrci_raw_val")
                    End If
                Next
                If s2List.Length > 0 Then
                    metricVal = MetricHelper.Incident(s2List)
                End If

            Case "23"
                Dim bauDefectList As BauDefect() = {}
                Dim iUpperBound As Integer = 0

                Dim bauDefect As BauDefect = Nothing
                Dim uatDefect As Defect = Nothing

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If

                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")
                    Dim decMetricRawVal As Decimal = drPrjMetricRaw("metric_raw_val")

                    If sMetricRawCode = "uat_critical_defect" Or sMetricRawCode = "uat_major_defect" _
                        Or sMetricRawCode = "uat_minor_defect" Or sMetricRawCode = "uat_trivial_defect" _
                        Or sMetricRawCode = "actual_effort" Then
                        If bauDefect Is Nothing Then
                            bauDefect = New BauDefect
                            uatDefect = New Defect
                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            bauDefect = New BauDefect
                            uatDefect = New Defect
                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then
                            iUpperBound = IIf(bauDefectList.Length <= 0, 0, bauDefectList.Length)
                            ReDim Preserve bauDefectList(iUpperBound)
                            bauDefect.uatDefect = uatDefect
                            bauDefectList(iUpperBound) = bauDefect

                            bauDefect = New BauDefect
                            uatDefect = New Defect
                        End If

                        If sMetricRawCode = "actual_effort" Then
                            bauDefect.actualEffort = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_critical_defect" Then
                            uatDefect.criticalDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_major_defect" Then
                            uatDefect.majorDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_minor_defect" Then
                            uatDefect.minorDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_trivial_defect" Then
                            uatDefect.trivialDefect = decMetricRawVal
                        End If
                    End If
                Next

                'Handle last css item
                If Not bauDefect Is Nothing And Not uatDefect Is Nothing Then
                    bauDefect.uatDefect = uatDefect
                    iUpperBound = IIf(bauDefectList.Length <= 0, 0, bauDefectList.Length)
                    ReDim Preserve bauDefectList(iUpperBound)
                    bauDefectList(iUpperBound) = bauDefect
                End If

                If bauDefectList.Length > 0 Then
                    metricVal = MetricHelper.BauDefectRate(bauDefectList)
                End If

            Case "24"
                Dim prjDefectList As PrjDefect() = {}
                Dim iUpperBound As Integer = 0

                Dim prjDefect As PrjDefect = Nothing
                Dim uatDefect As Defect = Nothing
                Dim prdDefect As Defect = Nothing

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If

                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")
                    Dim decMetricRawVal As Decimal = drPrjMetricRaw("metric_raw_val")

                    If sMetricRawCode = "uat_critical_defect" Or sMetricRawCode = "uat_major_defect" _
                        Or sMetricRawCode = "uat_minor_defect" Or sMetricRawCode = "uat_trivial_defect" _
                        Or sMetricRawCode = "prd_critical_defect" Or sMetricRawCode = "prd_major_defect" _
                        Or sMetricRawCode = "prd_minor_defect" Or sMetricRawCode = "prd_trivial_defect" _
                        Or sMetricRawCode = "actual_effort" Then

                        If prjDefect Is Nothing Then
                            prjDefect = New PrjDefect
                            uatDefect = New Defect
                            prdDefect = New Defect
                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            prjDefect = New PrjDefect
                            uatDefect = New Defect
                            prdDefect = New Defect
                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then
                            iUpperBound = IIf(prjDefectList.Length <= 0, 0, prjDefectList.Length)
                            ReDim Preserve prjDefectList(iUpperBound)
                            prjDefect.uatDefect = uatDefect
                            prjDefect.prdDefect = prdDefect
                            prjDefectList(iUpperBound) = prjDefect

                            prjDefect = New PrjDefect
                            uatDefect = New Defect
                            prdDefect = New Defect
                        End If

                        Select Case sMetricRawCode
                            Case "actual_effort"
                                prjDefect.actualEffort = decMetricRawVal
                            Case "uat_critical_defect"
                                uatDefect.criticalDefect = decMetricRawVal
                            Case "uat_major_defect"
                                uatDefect.majorDefect = decMetricRawVal
                            Case "uat_minor_defect"
                                uatDefect.minorDefect = decMetricRawVal
                            Case "uat_trivial_defect"
                                uatDefect.trivialDefect = decMetricRawVal
                            Case "prd_critical_defect"
                                prdDefect.criticalDefect = decMetricRawVal
                            Case "prd_major_defect"
                                prdDefect.majorDefect = decMetricRawVal
                            Case "prd_minor_defect"
                                prdDefect.minorDefect = decMetricRawVal
                            Case "prd_trivial_defect"
                                prdDefect.trivialDefect = decMetricRawVal
                        End Select
                        
                    End If
                Next

                'Handle last css item
                If Not prjDefect Is Nothing Then
                    prjDefect.uatDefect = uatDefect
                    prjDefect.prdDefect = prdDefect
                    iUpperBound = IIf(prjDefectList.Length <= 0, 0, prjDefectList.Length)
                    ReDim Preserve prjDefectList(iUpperBound)
                    prjDefectList(iUpperBound) = prjDefect
                End If

                If prjDefectList.Length > 0 Then
                    metricVal = MetricHelper.PrjDefectRate(prjDefectList)
                End If

            Case "25" 'Defect Removal
                Dim defectRemovalList As DefectRemoval() = {}
                Dim iUpperBound As Integer = 0

                Dim defectRemoval As DefectRemoval = Nothing
                Dim uatDefect As Defect = Nothing

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If

                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")
                    Dim decMetricRawVal As Decimal = drPrjMetricRaw("metric_raw_val")

                    If sMetricRawCode = "uat_critical_defect" Or sMetricRawCode = "uat_major_defect" _
                        Or sMetricRawCode = "uat_minor_defect" Or sMetricRawCode = "uat_trivial_defect" _
                        Or sMetricRawCode = "sit_defect" Then

                        If defectRemoval Is Nothing Then
                            defectRemoval = New DefectRemoval
                            uatDefect = New Defect
                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            defectRemoval = New DefectRemoval
                            uatDefect = New Defect
                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then
                            iUpperBound = IIf(defectRemovalList.Length <= 0, 0, defectRemovalList.Length)
                            ReDim Preserve defectRemovalList(iUpperBound)
                            defectRemoval.uatDefect = uatDefect
                            defectRemovalList(iUpperBound) = defectRemoval

                            defectRemoval = New DefectRemoval
                            uatDefect = New Defect
                        End If

                        If sMetricRawCode = "sit_defect" Then
                            defectRemoval.sitDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_critical_defect" Then
                            uatDefect.criticalDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_major_defect" Then
                            uatDefect.majorDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_minor_defect" Then
                            uatDefect.minorDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_trivial_defect" Then
                            uatDefect.trivialDefect = decMetricRawVal
                        End If
                    End If
                Next

                'Handle last item
                If Not defectRemoval Is Nothing And Not uatDefect Is Nothing Then
                    defectRemoval.uatDefect = uatDefect
                    iUpperBound = IIf(defectRemovalList.Length <= 0, 0, defectRemovalList.Length)
                    ReDim Preserve defectRemovalList(iUpperBound)
                    defectRemovalList(iUpperBound) = defectRemoval
                End If

                If defectRemovalList.Length > 0 Then
                    metricVal = MetricHelper.UatDefectRemovalRate(defectRemovalList)
                End If


            Case "26"
                Dim uatInitPassList As UatInitPass() = {}
                Dim iUpperBound As Integer = 0
                Dim uatInitPass As UatInitPass = Nothing


                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If

                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")
                    Dim decMetricRawVal As Decimal = drPrjMetricRaw("metric_raw_val")

                    If sMetricRawCode = "uat_test_cases_1st_time_passed" Or sMetricRawCode = "uat_test_cases_executed" Then

                        If uatInitPass Is Nothing Then
                            uatInitPass = New UatInitPass

                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            uatInitPass = New UatInitPass

                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then
                            iUpperBound = IIf(uatInitPassList.Length <= 0, 0, uatInitPassList.Length)
                            ReDim Preserve uatInitPassList(iUpperBound)

                            uatInitPassList(iUpperBound) = uatInitPass

                            uatInitPass = New UatInitPass

                        End If

                        If sMetricRawCode = "uat_test_cases_1st_time_passed" Then
                            uatInitPass.uatInitPassCase = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_test_cases_executed" Then
                            uatInitPass.uatExecutedCase = decMetricRawVal
                        
                        End If
                    End If
                Next

                'Handle last item
                If Not uatInitPass Is Nothing Then

                    iUpperBound = IIf(uatInitPassList.Length <= 0, 0, uatInitPassList.Length)
                    ReDim Preserve uatInitPassList(iUpperBound)
                    uatInitPassList(iUpperBound) = uatInitPass
                End If

                If uatInitPassList.Length > 0 Then
                    metricVal = MetricHelper.UatInitPassRate(uatInitPassList)
                End If


            Case "27" 'UAT ReOpen
                Dim defectReOpenList As DefectReOpen() = {}
                Dim iUpperBound As Integer = 0
                Dim defectReOpen As DefectReOpen = Nothing
                Dim uatDefect As Defect = Nothing

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If

                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")
                    Dim decMetricRawVal As Decimal = drPrjMetricRaw("metric_raw_val")

                    If sMetricRawCode = "uat_critical_defect" Or sMetricRawCode = "uat_major_defect" _
                        Or sMetricRawCode = "uat_minor_defect" Or sMetricRawCode = "uat_trivial_defect" _
                        Or sMetricRawCode = "reopen_uat_defect" Then

                        If DefectReOpen Is Nothing Then
                            defectReOpen = New DefectReOpen
                            uatDefect = New Defect
                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            defectReOpen = New DefectReOpen
                            uatDefect = New Defect
                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then
                            defectReOpen.defect = uatDefect
                            iUpperBound = IIf(defectReOpenList.Length <= 0, 0, defectReOpenList.Length)
                            ReDim Preserve defectReOpenList(iUpperBound)
                            defectReOpen.defect = uatDefect
                            defectReOpenList(iUpperBound) = defectReOpen

                            defectReOpen = New DefectReOpen
                            uatDefect = New Defect
                        End If

                        If sMetricRawCode = "reopen_uat_defect" Then
                            defectReOpen.reopenDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_critical_defect" Then
                            uatDefect.criticalDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_major_defect" Then
                            uatDefect.majorDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_minor_defect" Then
                            uatDefect.minorDefect = decMetricRawVal
                        ElseIf sMetricRawCode = "uat_trivial_defect" Then
                            uatDefect.trivialDefect = decMetricRawVal
                        End If
                    End If
                Next

                If Not defectReOpen Is Nothing And Not uatDefect Is Nothing Then
                    defectReOpen.defect = uatDefect
                    iUpperBound = IIf(defectReOpenList.Length <= 0, 0, defectReOpenList.Length)
                    ReDim Preserve defectReOpenList(iUpperBound)
                    defectReOpen.defect = uatDefect
                    defectReOpenList(iUpperBound) = defectReOpen
                End If

                If defectReOpenList.Length > 0 Then
                    metricVal = MetricHelper.DefectReopenRate(defectReOpenList)
                End If



            Case "28" 'Cost of Poor Quality
                Dim copqList As CostOfPoorQuality() = {}
                Dim iUpperBound As Integer = 0
                Dim copq As CostOfPoorQuality = Nothing


                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If

                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")
                    Dim decMetricRawVal As Decimal = drPrjMetricRaw("metric_raw_val")

                    If sMetricRawCode = "failure_effort" Or sMetricRawCode = "actual_effort" Then

                        If copq Is Nothing Then
                            copq = New CostOfPoorQuality

                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            copq = New CostOfPoorQuality

                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then
                            iUpperBound = IIf(copqList.Length <= 0, 0, copqList.Length)
                            ReDim Preserve copqList(iUpperBound)
                            copqList(iUpperBound) = copq

                            copq = New CostOfPoorQuality

                        End If

                        If sMetricRawCode = "failure_effort" Then
                            copq.failureEffort = decMetricRawVal
                        ElseIf sMetricRawCode = "actual_effort" Then
                            copq.actualEffort = decMetricRawVal

                        End If
                    End If
                Next

                'Handle last item
                If Not copq Is Nothing Then
                    iUpperBound = IIf(copqList.Length <= 0, 0, copqList.Length)
                    ReDim Preserve copqList(iUpperBound)
                    copqList(iUpperBound) = copq

                End If

                If copqList.Length > 0 Then
                    metricVal = MetricHelper.CostOfPoorQuality(copqList)
                End If

            Case "31"
                Dim responseOnTimeList As OnTimeIncident() = {}
                Dim iUpperBound As Integer = 0
                Dim responseOntime As OnTimeIncident = Nothing

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If

                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")
                    Dim decMetricRawVal As Decimal = drPrjMetricRaw("metric_raw_val")

                    If sMetricRawCode = "response_on_time" Or sMetricRawCode = "received_incident" Then

                        If responseOntime Is Nothing Then
                            responseOntime = New OnTimeIncident

                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            responseOntime = New OnTimeIncident

                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then
                            iUpperBound = IIf(responseOnTimeList.Length <= 0, 0, responseOnTimeList.Length)
                            ReDim Preserve responseOnTimeList(iUpperBound)
                            responseOnTimeList(iUpperBound) = responseOntime

                            responseOntime = New OnTimeIncident

                        End If

                        If sMetricRawCode = "response_on_time" Then
                            responseOntime.onTime = decMetricRawVal
                        ElseIf sMetricRawCode = "received_incident" Then
                            responseOntime.receivedIncident = decMetricRawVal

                        End If
                    End If
                Next

                'Handle last item
                If Not responseOntime Is Nothing Then
                    iUpperBound = IIf(responseOnTimeList.Length <= 0, 0, responseOnTimeList.Length)
                    ReDim Preserve responseOnTimeList(iUpperBound)
                    responseOnTimeList(iUpperBound) = responseOntime

                End If

                If responseOnTimeList.Length > 0 Then
                    metricVal = MetricHelper.OnTimeRate(responseOnTimeList)
                End If


            Case "32" 'Resolution OnTime Rate
                Dim resolutionOnTimeList As OnTimeIncident() = {}
                Dim iUpperBound As Integer = 0
                Dim resolutionOntime As OnTimeIncident = Nothing

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If

                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")
                    Dim decMetricRawVal As Decimal = drPrjMetricRaw("metric_raw_val")

                    If sMetricRawCode = "resolution_on_time" Or sMetricRawCode = "received_incident" Then

                        If resolutionOntime Is Nothing Then
                            resolutionOntime = New OnTimeIncident

                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            resolutionOntime = New OnTimeIncident

                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then
                            iUpperBound = IIf(resolutionOnTimeList.Length <= 0, 0, resolutionOnTimeList.Length)
                            ReDim Preserve resolutionOnTimeList(iUpperBound)
                            resolutionOnTimeList(iUpperBound) = resolutionOntime

                            resolutionOntime = New OnTimeIncident

                        End If

                        If sMetricRawCode = "resolution_on_time" Then
                            resolutionOntime.onTime = decMetricRawVal
                        ElseIf sMetricRawCode = "received_incident" Then
                            resolutionOntime.receivedIncident = decMetricRawVal

                        End If
                    End If
                Next

                'Handle last item
                If Not resolutionOntime Is Nothing Then
                    iUpperBound = IIf(resolutionOnTimeList.Length <= 0, 0, resolutionOnTimeList.Length)
                    ReDim Preserve resolutionOnTimeList(iUpperBound)
                    resolutionOnTimeList(iUpperBound) = resolutionOntime

                End If

                If resolutionOnTimeList.Length > 0 Then
                    metricVal = MetricHelper.OnTimeRate(resolutionOnTimeList)
                End If

            Case "41" 'Task On Schedule Rate
                Dim taskOnScheduleList As TaskOnSchedule() = {}
                Dim iUpperBound As Integer = 0
                Dim taskOnSchedule As TaskOnSchedule = Nothing

                For i As Integer = 0 To dtPrjMetricRaw.Rows.Count - 1
                    Dim drPrjMetricRaw As DataRow = dtPrjMetricRaw.Rows(i)

                    Dim prjCode As String = drPrjMetricRaw("prj_code")
                    Dim lastPrjCode As String = ""
                    If i > 0 Then
                        lastPrjCode = dtPrjMetricRaw.Rows(i - 1)("prj_code").ToString
                    End If

                    Dim sMetricRawCode As String = drPrjMetricRaw("metric_raw_code")
                    Dim decMetricRawVal As Decimal = drPrjMetricRaw("metric_raw_val")

                    If sMetricRawCode = "comp_task_und_ctrl" Or sMetricRawCode = "comp_task" Then

                        If taskOnSchedule Is Nothing Then
                            taskOnSchedule = New TaskOnSchedule

                        ElseIf prjCode <> lastPrjCode And String.IsNullOrEmpty(lastPrjCode) Then
                            taskOnSchedule = New TaskOnSchedule

                        ElseIf prjCode <> lastPrjCode And Not String.IsNullOrEmpty(lastPrjCode) Then
                            iUpperBound = IIf(taskOnScheduleList.Length <= 0, 0, taskOnScheduleList.Length)
                            ReDim Preserve taskOnScheduleList(iUpperBound)
                            taskOnScheduleList(iUpperBound) = taskOnSchedule

                            taskOnSchedule = New TaskOnSchedule

                        End If

                        If sMetricRawCode = "comp_task_und_ctrl" Then
                            taskOnSchedule.taskCompletedUnderControl = decMetricRawVal
                        ElseIf sMetricRawCode = "comp_task" Then
                            taskOnSchedule.taskCompleted = decMetricRawVal
                        End If
                    End If
                Next

                'Handle last item
                If Not taskOnSchedule Is Nothing Then
                    iUpperBound = IIf(taskOnScheduleList.Length <= 0, 0, taskOnScheduleList.Length)
                    ReDim Preserve taskOnScheduleList(iUpperBound)
                    taskOnScheduleList(iUpperBound) = taskOnSchedule

                End If

                If taskOnScheduleList.Length > 0 Then
                    metricVal = MetricHelper.TaskOnSchedulRate(taskOnScheduleList)
                End If



            Case "42" 'SPI

                'metricVal = MetricHelper.SPI(drMetricRaw(""), drMetricRaw(""))

            Case "43"
                'metricVal = MetricHelper.SPI(drMetricRaw(""), drMetricRaw(""))

        End Select

        CalculateMetricValue = metricVal
    End Function

    Function CalculateMetricValue(ByVal metricCode As String, ByVal hash As Hashtable) As Nullable(Of Decimal) Implements IProjectMetricService.CalculateMetricValue
        Dim metricVal As Nullable(Of Decimal) = Nothing

        Dim rawRec As Integer = 0

        If hash Is Nothing Then
            Return metricVal
        ElseIf hash.Count = 0 Then
            Return metricVal
        End If



        Select Case metricCode
            Case "11" 'CSS

                If Not (hash.ContainsKey("css_score") Or hash.ContainsKey("actual_effort")) Then
                    Return metricVal
                ElseIf String.IsNullOrEmpty(hash("css_score")) Or String.IsNullOrEmpty("actual_effort") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("actual_effort")) Then
                    Return metricVal
                ElseIf hash("actual_effort") = 0 Then
                    Return metricVal
                End If

                Dim css As CSS = New CSS
                css.score = hash("css_score")
                css.actualEffort = hash("actual_effort")

                Dim cssArray As CSS() = {css}
                metricVal = MetricHelper.CSS(cssArray)


            Case "21" 'S1
                If hash.ContainsKey("s1") Then
                    If IsNumeric(hash("s1")) Then
                        Dim s1 As Integer = hash("s1")
                        Dim s1Array As Integer() = {s1}
                        metricVal = MetricHelper.Incident(s1Array)
                    End If
                End If


            Case "22" 'S2
                If hash.ContainsKey("s2") Then
                    If IsNumeric(hash("s2")) Then
                        Dim s2 As Integer = hash("s2")
                        Dim s2Array As Integer() = {s2}
                        metricVal = MetricHelper.Incident(s2Array)
                    End If
                End If


            Case "23"
                Dim bauDefect As BauDefect = New BauDefect

                If Not hash.ContainsKey("actual_effort") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("actual_effort")) Then
                    Return metricVal
                ElseIf Not hash.ContainsKey("uat_critical_defect") And Not hash.ContainsKey("uat_major_defect") And Not hash.ContainsKey("uat_minor_defect") _
                    And Not hash.ContainsKey("uat_trivial_defect") Then
                    Return metricVal
                Else
                    bauDefect.actualEffort = hash("actual_effort")
                End If

                Dim uatDefect As Defect = New Defect
                If hash.ContainsKey("uat_critical_defect") Then
                    uatDefect.criticalDefect = hash("uat_critical_defect")
                End If
                If hash.ContainsKey("uat_major_defect") Then
                    uatDefect.majorDefect = hash("uat_major_defect")
                End If
                If hash.ContainsKey("uat_minor_defect") Then
                    uatDefect.minorDefect = hash("uat_minor_defect")
                End If
                If hash.ContainsKey("uat_trivial_defect") Then
                    uatDefect.trivialDefect = hash("uat_trivial_defect")
                End If
                bauDefect.uatDefect = uatDefect

                Dim bauDefectArray As BauDefect() = {bauDefect}
                metricVal = MetricHelper.BauDefectRate(bauDefectArray)

            Case "24"
                Dim prjDefect As PrjDefect = New PrjDefect

                If Not hash.ContainsKey("actual_effort") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("actual_effort")) Then
                    Return metricVal
                ElseIf Not hash.ContainsKey("uat_critical_defect") And Not hash.ContainsKey("uat_major_defect") And _
                    Not hash.ContainsKey("uat_minor_defect") And Not hash.ContainsKey("uat_trivial_defect") And _
                    Not hash.ContainsKey("prd_critical_defect") And Not hash.ContainsKey("prd_major_defect") And _
                    Not hash.ContainsKey("prd_minor_defect") And Not hash.ContainsKey("prd_trivial_defect") Then
                    Return metricVal
                End If

                prjDefect.actualEffort = hash("actual_effort")

                Dim uatDefect As Defect = New Defect
                If hash.ContainsKey("uat_critical_defect") Then
                    uatDefect.criticalDefect = hash("uat_critical_defect")
                End If
                If hash.ContainsKey("uat_major_defect") Then
                    uatDefect.majorDefect = hash("uat_major_defect")
                End If
                If hash.ContainsKey("uat_minor_defect") Then
                    uatDefect.minorDefect = hash("uat_minor_defect")
                End If
                If hash.ContainsKey("uat_trivial_defect") Then
                    uatDefect.trivialDefect = hash("uat_trivial_defect")
                End If
                prjDefect.uatDefect = uatDefect

                Dim prdDefect As Defect = New Defect
                If hash.ContainsKey("prd_critical_defect") Then
                    prdDefect.criticalDefect = hash("prd_critical_defect")
                End If
                If hash.ContainsKey("prd_major_defect") Then
                    prdDefect.majorDefect = hash("prd_major_defect")
                End If
                If hash.ContainsKey("prd_minor_defect") Then
                    prdDefect.minorDefect = hash("prd_minor_defect")
                End If
                If hash.ContainsKey("prd_trivial_defect") Then
                    prdDefect.trivialDefect = hash("prd_trivial_defect")
                End If
                prjDefect.prdDefect = prdDefect

                Dim prjDefectArray As PrjDefect() = {prjDefect}
                metricVal = MetricHelper.PrjDefectRate(prjDefectArray)

            Case "25"

                Dim defectRemoval As DefectRemoval = New DefectRemoval

                If Not hash.ContainsKey("sit_defect") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("sit_defect")) Then
                    Return metricVal
                Else
                    defectRemoval.sitDefect = hash("sit_defect")
                End If

                Dim uatDefect As Defect = New Defect
                If hash.ContainsKey("uat_critical_defect") Then
                    uatDefect.criticalDefect = hash("uat_critical_defect")
                End If
                If hash.ContainsKey("uat_major_defect") Then
                    uatDefect.majorDefect = hash("uat_major_defect")
                End If
                If hash.ContainsKey("uat_minor_defect") Then
                    uatDefect.minorDefect = hash("uat_minor_defect")
                End If
                If hash.ContainsKey("uat_trivial_defect") Then
                    uatDefect.trivialDefect = hash("uat_trivial_defect")
                End If
                defectRemoval.uatDefect = uatDefect

                Dim defectRemovalArray As DefectRemoval() = {defectRemoval}
                metricVal = MetricHelper.UatDefectRemovalRate(defectRemovalArray)

            Case "26"

                If Not hash.ContainsKey("uat_test_cases_1st_time_passed") And Not hash.ContainsKey("uat_test_cases_executed") Then
                    Return metricVal
                End If

                Dim uatInitPass As UatInitPass = New UatInitPass

                If hash.ContainsKey("1st_time_passed_uat_test_cases") Then
                    uatInitPass.uatInitPassCase = hash("1st_time_passed_uat_test_cases")
                End If

                If hash.ContainsKey("uat_test_cases_executed") Then
                    uatInitPass.uatExecutedCase = hash("uat_test_cases_executed")
                End If

                Dim uatInitPassArray As UatInitPass() = {uatInitPass}
                metricVal = MetricHelper.UatInitPassRate(uatInitPassArray)



            Case "27" 'UAT ReOpen

                Dim uatReopen As DefectReOpen = New DefectReOpen


                If Not hash.ContainsKey("reopen_uat_defects") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("reopen_uat_defects")) Then
                    Return metricVal
                Else
                    uatReopen.reopenDefect = hash("reopen_uat_defects")
                End If

                Dim uatDefect As Defect = New Defect
                If hash.ContainsKey("uat_critical_defect") Then
                    uatDefect.criticalDefect = hash("uat_critical_defect")
                End If
                If hash.ContainsKey("uat_major_defect") Then
                    uatDefect.majorDefect = hash("uat_major_defect")
                End If
                If hash.ContainsKey("uat_minor_defect") Then
                    uatDefect.minorDefect = hash("uat_minor_defect")
                End If
                If hash.ContainsKey("uat_trivial_defect") Then
                    uatDefect.trivialDefect = hash("uat_trivial_defect")
                End If
                uatReopen.defect = uatDefect

                Dim uatReopens As DefectReOpen() = {uatReopen}
                metricVal = MetricHelper.DefectReopenRate(uatReopens)


            Case "28" 'Cost of Poor Quality
                Dim copq As CostOfPoorQuality = New CostOfPoorQuality


                If Not hash.ContainsKey("actual_effort") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("actual_effort")) Then
                    Return metricVal
                Else
                    copq.actualEffort = hash("actual_effort")
                End If

                If Not hash.ContainsKey("failure_effort") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("failure_effort")) Then
                    Return metricVal
                Else
                    copq.failureEffort = hash("failure_effort")
                End If

                Dim copqs As CostOfPoorQuality() = {copq}
                metricVal = MetricHelper.CostOfPoorQuality(copqs)



            Case "31"

                Dim responseOnTime As OnTimeIncident = New OnTimeIncident

                If Not hash.ContainsKey("response_on_time") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("response_on_time")) Then
                    Return metricVal
                ElseIf hash("response_on_time") = 0 Then
                    Return metricVal
                Else
                    responseOnTime.onTime = hash("response_on_time")
                End If

                If Not hash.ContainsKey("received_incident") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("received_incident")) Then
                    Return metricVal
                Else
                    responseOnTime.receivedIncident = hash("received_incident")
                End If

                Dim responseOnTimes As OnTimeIncident() = {responseOnTime}
                metricVal = MetricHelper.OnTimeRate(responseOnTimes)


            Case "32" 'Resolution OnTime Rate
                Dim resolutionOnTime As OnTimeIncident = New OnTimeIncident

                If Not hash.ContainsKey("resolution_on_time") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("resolution_on_time")) Then
                    Return metricVal
                ElseIf hash("resolution_on_time") = 0 Then
                    Return metricVal
                Else
                    resolutionOnTime.onTime = hash("resolution_on_time")
                End If

                If Not hash.ContainsKey("received_incident") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("received_incident")) Then
                    Return metricVal
                Else
                    resolutionOnTime.receivedIncident = hash("received_incident")
                End If

                Dim resolutionOnTimes As OnTimeIncident() = {resolutionOnTime}
                metricVal = MetricHelper.OnTimeRate(resolutionOnTimes)



            Case "41" 'Task On Schedule Rate
                Dim taskOnSchedule As TaskOnSchedule = New TaskOnSchedule

                If Not hash.ContainsKey("comp_task") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("comp_task")) Then
                    Return metricVal
                ElseIf hash("comp_task") = 0 Then
                    Return metricVal
                Else
                    taskOnSchedule.taskCompleted = hash("comp_task")
                End If

                If Not hash.ContainsKey("comp_task_und_ctrl") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("comp_task_und_ctrl")) Then
                    Return metricVal
                Else
                    taskOnSchedule.taskCompletedUnderControl = hash("comp_task_und_ctrl")
                End If

                Dim taskOnSchedules As TaskOnSchedule() = {taskOnSchedule}
                metricVal = MetricHelper.TaskOnSchedulRate(taskOnSchedules)

            Case "42" 'SPI

                If Not hash.ContainsKey("pv") Or Not hash.ContainsKey("ev") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("pv")) Or Not IsNumeric(hash("ev")) Then
                    Return metricVal
                ElseIf hash("pv") = 0 Or hash("ev") = 0 Then
                    Return metricVal

                Else
                    Dim decEV As Decimal = hash("ev")
                    Dim decPV As Decimal = hash("pv")
                    metricVal = decEV / decPV
                End If

            Case "43"
                If Not hash.ContainsKey("ac") Or Not hash.ContainsKey("ev") Then
                    Return metricVal
                ElseIf Not IsNumeric(hash("ac")) Or Not IsNumeric(hash("ev")) Then
                    Return metricVal
                ElseIf hash("ac") = 0 Or hash("ev") = 0 Then
                    Return metricVal

                Else
                    Dim decEV As Decimal = hash("ev")
                    Dim decAC As Decimal = hash("ac")
                    metricVal = decEV / decAC
                End If

        End Select

        CalculateMetricValue = metricVal
    End Function

    Function CalculateMetricStatus(ByVal metricTargetYear As String, ByVal tssPrj As String, ByVal metricCode As String, ByVal metricVal As Decimal) As String Implements IProjectMetricService.CalculateMetricStatus
        Dim sMetricSta As String = ""
        Dim dt As DataTable = New DataTable

        Dim metricTargetService As IMetricTargetService = New MetricTargetService

        dt = metricTargetService.GetMetricTarget(metricTargetYear, tssPrj, metricCode)

        If Not dt Is Nothing Then
            sMetricSta = MetricStatus.CalculateMetricStatus(dt, metricVal)
        End If

        CalculateMetricStatus = sMetricSta
        dt.Dispose()
    End Function


    Function GetProjectMetricHistList(ByVal prjCodes As String(), ByVal dataVersion As String) As DataTable Implements IProjectMetricService.GetProjectMetricHistList
        Dim sSQLPrjCodes As String = ""
        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)
        sSQLBuilder.Append(" AND [DATA_VERSION] = ( ")
        sSQLBuilder.Append(" SELECT MAX([DATA_VERSION]) as data_version FROM " & sHistTable & " WHERE [DATA_VERSION] < @DATAVERSION " & sSQLPrjCodes & ") ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataVersion)


        GetProjectMetricHistList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProjectMetricHistList(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataversion As String) As DataTable Implements IProjectMetricService.GetProjectMetricHistList

        Dim sSQLPrjCodes As String = ""
        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)

        sSQLBuilder.Append(" AND [metric_code] = @METRICCODE ")
        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@METRICCODE", metricCode)

        sSQLBuilder.Append(" AND [DATA_VERSION] = ( ")
        sSQLBuilder.Append(" SELECT MAX([DATA_VERSION]) FROM " & sHistTable & " WHERE [DATA_VERSION] <= @DATAVERSION " & sSQLPrjCodes & ") ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataversion)


        GetProjectMetricHistList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProjectMetricHist(ByVal prjCodes As String(), ByVal dataVersion As String) As DataTable Implements IProjectMetricService.GetProjectMetricHist
        Dim sSQLPrjCodes As String = ""
        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)
        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataVersion)


        GetProjectMetricHist = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function
    Function GetProjectMetricHist(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataversion As String) As DataTable Implements IProjectMetricService.GetProjectMetricHist
        Dim sSQLPrjCodes As String = ""
        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)

        sSQLBuilder.Append(" AND [metric_code] = @METRICCODE ")
        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@METRICCODE", metricCode)

        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataversion)


        GetProjectMetricHist = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function


    Function GetProjectMetricHist(ByVal prjCode As String, ByVal dataVersion As String) As Hashtable Implements IProjectMetricService.GetProjectMetricHist

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [PRJ_CODE] = @PRJCODE ")
        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION ")


        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRJCODE", prjCode), _
                                            New SqlParameter("@DATAVERSION", dataVersion)}


        Dim dt As DataTable = New DataTable
        dt = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

        If dt Is Nothing Then
            Return Nothing
        ElseIf dt.Rows.Count = 0 Then
            Return Nothing
        End If

        Dim hsReturn As Hashtable = New Hashtable
        For Each dr As DataRow In dt.Rows
            hsReturn.Add(dr("metric_code"), dr("metric_val"))
        Next

        GetProjectMetricHist = hsReturn
        dt.Dispose()
    End Function
    Function HasProjectMetrics(ByVal prjCodes As String()) As Boolean Implements IProjectMetricService.HasProjectMetrics
        Dim dt As DataTable = GetProjectMetric(prjCodes)

        If dt Is Nothing Then
            Return False
        ElseIf dt.Rows.Count = 0 Then
            dt.Dispose()
            Return False
        Else
            dt.Dispose()
            Return True
        End If
    End Function
End Class

#End Region