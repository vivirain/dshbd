﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

Public Class LogModel

End Class

Public Enum TRANTYPE
    LOGIN = 1
End Enum

#End Region


#Region "Service"

Public Interface ILogService
    Sub WriteTranLog(ByVal tranType As String, ByVal tranBy As String, ByVal tranLog As String, Optional tranErr As String = "")
End Interface

Class LogService
    Implements ILogService

    Const sTable = "[dbo].[tpma_dshbd_tran_log]"
    Private sqlHelper As SqlHelper = New SqlHelper()

    Sub WriteTranLog(ByVal tranType As String, ByVal tranBy As String, ByVal tranLog As String, Optional tranErr As String = "") Implements ILogService.WriteTranLog
        Dim sSQLBuilder As StringBuilder = New StringBuilder("INSERT INTO " & sTable)

        sSQLBuilder.Append(" VALUES (")
        sSQLBuilder.Append(" @TRANTYPE, @TRANLOG, @TRANERR, @TRANBY, @TRANDATE, @TRANBY, @TRANDATE")
        sSQLBuilder.Append(" )")


        Dim sqlParams As SqlParameter() = {New SqlParameter("@TRANTYPE", tranType), _
                                           New SqlParameter("@TRANLOG", tranLog), _
                                           New SqlParameter("@TRANERR", tranErr), _
                                           New SqlParameter("@TRANBY", HttpContext.Current.Session.Item("logon_id")), _
                                           New SqlParameter("@TRANDATE", Now)
                                           }

        sqlHelper.ExecuteNonQuery(sSQLBuilder.ToString, sqlParams)

    End Sub
End Class

#End Region

