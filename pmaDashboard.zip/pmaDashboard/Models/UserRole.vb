﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

Public Class UserRole
    Private _userRoleId As Integer
    Public ReadOnly Property userRoleId() As Integer
        Get
            Return _userRoleId
        End Get
    End Property

    Private _roleId As Integer
    Public Property roleId() As Integer
        Get
            Return _roleId
        End Get
        Set(ByVal value As Integer)
            _roleId = value
        End Set
    End Property

    Private _roleName As String
    Public Property roleName() As String
        Get
            Return _roleName
        End Get
        Set(ByVal value As String)
            _roleName = value
        End Set
    End Property

    Private _logonId As String
    Public Property logonId() As String
        Get
            Return _logonId
        End Get
        Set(ByVal value As String)
            _logonId = value
        End Set
    End Property

    Private _staffName As String
    Public Property staffName() As String
        Get
            Return _staffName
        End Get
        Set(ByVal value As String)
            _staffName = value
        End Set
    End Property

    Private _isActive As String
    Public Property isActive() As String
        Get
            Return _isActive
        End Get
        Set(ByVal value As String)
            If String.IsNullOrEmpty(value) Then
                _isActive = "Y"
            Else
                _isActive = value
            End If
        End Set
    End Property

    Public Sub New()

    End Sub
End Class

#End Region


#Region "Service"

Public Interface IUserRoleService

    'Used in House Keeping 
    Function GetUserRoleList(Optional ByVal roleId As Integer = 0, Optional ByVal logonId As Integer = 0) As DataTable
    Function EditUserRoleList(ByVal dtEdit As DataTable, Optional ByVal roleId As Integer = 0, Optional ByVal logonId As Integer = 0) As Boolean

    'Function GetUserDashboardRole(ByVal pmaLogonId As String) As Nullable(Of Integer)

End Interface

Class UserRoleService
    Implements IUserRoleService

    Const sTable = "[dbo].[tpma_dshbd_user_role]"
    Dim sSQLSel As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND IS_ACTIVE = 'Y'"

    Private sqlHelper As SqlHelper = New SqlHelper()


    Function GetUserRoleList(Optional ByVal roleId As Integer = 0, Optional ByVal logonId As Integer = 0) As DataTable Implements IUserRoleService.GetUserRoleList
        Dim sSQL As StringBuilder = New StringBuilder("")
        sSQL.Append("SELECT *, (rtrim([pma_logon_id]) + '-' + rtrim([pma_logon_id_card])) as pma_logon ")
        sSQL.Append(" FROM " & sTable)
        sSQL.Append(" WHERE 1 = 1 AND IS_ACTIVE = 'Y' ")

        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0

        If roleId > 0 Then
            sSQL.Append(" AND [ROLE_ID] = @ROLEID")
            iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@ROLEID", roleId)
        End If

        If logonId > 0 Then
            sSQL.Append(" AND [USER_ID] = @LOGONID")

            iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@LOGONID", logonId)
        End If

        If sqlParams Is Nothing Then
            GetUserRoleList = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        ElseIf sqlParams.Length = 0 Then
            GetUserRoleList = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        Else
            GetUserRoleList = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
        End If

    End Function



    Function EditUserRoleList(ByVal dtEdit As DataTable, Optional ByVal roleId As Integer = 0, Optional ByVal logonId As Integer = 0) As Boolean Implements IUserRoleService.EditUserRoleList
        Dim bEdit As Boolean = False

        Dim sSQL As StringBuilder = New StringBuilder(sSQLSel)

        If roleId > 0 And logonId > 0 Then
            sSQL.Append(" AND [ROLE_ID] = " & roleId)
            sSQL.Append(" AND [USER_ID] = " & logonId)
        ElseIf roleId > 0 Then
            sSQL.Append(" AND [ROLE_ID] = " & roleId)
        ElseIf logonId > 0 Then
            sSQL.Append(" AND [USER_ID] = " & logonId)
        End If

        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQL.ToString, dtEdit)}
        bEdit = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)

        EditUserRoleList = bEdit
    End Function


    'Function GetUserDashboardRole(ByVal pmaLogonId As String) As Nullable(Of Integer) Implements IUserRoleService.GetUserDashboardRole
    '    Dim iDshbdRole As Nullable(Of Integer)

    '    'If already
    '    iDshbdRole = GetDashboardRole(pmaLogonId)
    '    If iDshbdRole.HasValue Then
    '        Return iDshbdRole.Value
    '    End If

    '    'Step 2: Check PMA
    '    Dim pmaUserservice As IPmaUserService = New PmaUserService
    '    Dim dtPmaUser As DataTable = pmaUserservice.GetActiveUserByLogonId(pmaLogonId)
    '    If dtPmaUser Is Nothing Then
    '        Return Nothing
    '    ElseIf dtPmaUser.Rows.Count = 0 Then
    '        Return Nothing
    '    End If

    '    Dim iTeamCode As Integer = dtPmaUser.Rows(0).Item("team_code")
    '    iDshbdRole = GetPMATeamRole(pmaLogonId, iTeamCode)
    '    If iDshbdRole.HasValue Then
    '        Return iDshbdRole.Value
    '    End If

    '    '
    '    Dim pmaProjectService As IPmaProjectService = New PmaProjectService
    '    If pmaProjectService.IsProjectManager(pmaLogonId) Then
    '        Return DASHBORADROLES.PM
    '    End If

    '    Return Nothing

    'End Function


    Function GetDashboardRole(ByVal pmaLogonId As String) As Nullable(Of Integer)

        Dim sUserRoleString As String = GetUserRolesString(pmaLogonId)
        If String.IsNullOrEmpty(sUserRoleString) Then
            Return Nothing
        End If

        If sUserRoleString.Contains(DASHBORADROLES.GM) Then
            Return DASHBORADROLES.GM
        End If

        If sUserRoleString.Contains(DASHBORADROLES.ADM) Then
            Return DASHBORADROLES.ADM
        End If

        If sUserRoleString.Contains(DASHBORADROLES.QAG) Then
            Return DASHBORADROLES.QAG
        End If

        If sUserRoleString.Contains(DASHBORADROLES.AM) Then
            Return DASHBORADROLES.AM
        End If

        If sUserRoleString.Contains(DASHBORADROLES.EXCO) Then
            Return DASHBORADROLES.EXCO
        End If

        If sUserRoleString.Contains(DASHBORADROLES.FH) Then
            Return DASHBORADROLES.FH
        End If

        If sUserRoleString.Contains(DASHBORADROLES.SBUH) Then
            Return DASHBORADROLES.SBUH
        End If

        If sUserRoleString.Contains(DASHBORADROLES.TL) Then
            Return DASHBORADROLES.TL
        End If

        If sUserRoleString.Contains(DASHBORADROLES.PM) Then
            Return DASHBORADROLES.PM
        End If
    End Function

    Function GetPMATeamRole(ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String, ByVal teamCode As Integer) As Nullable(Of Integer)
        Dim pmaTeamService As IPmaTeamService = New PmaTeamService
        Dim dtMyTeams As DataTable = pmaTeamService.GetMyLeadTeams(pmaLogonId, pmaLogonIdCard, teamCode)

        If dtMyTeams Is Nothing Then
            Return Nothing
        ElseIf dtMyTeams.Rows.Count = 0 Then
            Return Nothing
        End If

        For Each drMyTeam As DataRow In dtMyTeams.Rows
            If drMyTeam("team_code") = pmaTeamService.GetTopTeamCode() Then
                Return DASHBORADROLES.GM
            End If

            If drMyTeam("is_func") = "Y" Then
                Return DASHBORADROLES.FH
            End If

            If drMyTeam("is_dept") = "Y" Then
                Return DASHBORADROLES.SBUH
            End If
        Next

        Return DASHBORADROLES.TL
    End Function

    Public Function GetUserRolesString(ByVal pmaLogonId As String) As String
        Dim dtUserRole As DataTable = GetUserRoles(pmaLogonId)
        Dim sUserRole As String = ""

        If Not dtUserRole Is Nothing Then
            For dr As Integer = 0 To dtUserRole.Rows.Count - 1
                sUserRole = sUserRole & IIf(dr = 0, "", ",") & dtUserRole.Rows(dr).Item("role_id").ToString
            Next
        End If

        dtUserRole.Dispose()
        GetUserRolesString = sUserRole
    End Function

    Public Function GetUserRoles(ByVal pmaLogonId As String) As DataTable

        Dim sSQL = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND [IS_ACTIVE] = 'Y'  AND [PMA_LOGON_ID] = @PMALOGONID"
        Dim sqlParams() As SqlParameter = {New SqlParameter("@PMALOGONID", pmaLogonId)}

        GetUserRoles = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

    End Function
End Class

#End Region

