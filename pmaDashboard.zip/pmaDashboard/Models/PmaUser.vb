﻿Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlClient


#Region "Model"

'Public Class PmaUserModel
'    Property pmaUserNo As String
'    Property logonId As String
'    Property stafCode As String
'    Property staffName As String
'    Property teamCode As String
'    Property status As String

'    Property email As String
'    Property joinDate As Date
'    Property term_date As Date

'    Property idCard As String
'    Property titleId As Integer
'End Class


#End Region

#Region "Service"

Public Interface IPmaUserService
    Function GetActiveUserByCode(ByVal pmaUserNo As String) As DataTable
    Function GetActiveUserByLogonId(ByVal logonId As String) As DataTable
    Function GetActiveUserByStaffCode(ByVal staffCode As String) As DataTable
    Function GetActiveUserListByTeamCode(ByVal teamCode As String) As DataTable
    Function GetActiveUserList() As DataTable

    Function GetActiveUserHash() As DataTable
    Function GetActiveUserHashByMyTeams(ByVal teamCodes As String) As DataTable

    Function GetActiveUserNameByLogonId(ByVal logonId As String) As String



    Function GetUserName(ByVal logonId As String, ByVal idCard As String) As String

    Function GetUserRolesString(ByVal logonId As String) As String
    Function GetActiveUserIdCardByLogonId(ByVal logonId As String) As String


End Interface

Class PmaUserService
    Implements IPmaUserService

    Const sTable = "[dbo].[tpma_staffbasic]"
    Private sqlHelper As SqlHelper = New SqlHelper
    Private dtPmaStaff As DataTable = New DataTable

    Function GetActiveUserByCode(ByVal pmaUserNo As String) As DataTable Implements IPmaUserService.GetActiveUserByCode
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE [STATUS] = 'A' AND [USER_NO] = @PMAUSERCODE"
        Dim sParams() As SqlParameter = {New SqlParameter("@PMAUSERCODE", pmaUserNo)}

        GetActiveUserByCode = sqlHelper.ExecuteReaderQuery(sSQL, sParams)
    End Function

    Public Function GetActivUserByLogonId(ByVal logonId As String) As DataTable Implements IPmaUserService.GetActiveUserByLogonId
        If logonId Is Nothing Then
            Return dtPmaStaff
        ElseIf logonId = "" Then
            Return dtPmaStaff
        Else
            logonId = logonId.Trim.ToUpper
            Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE [STATUS] = 'A' AND upper(rtrim(ltrim([LOGON_ID]))) = @LOGONID"
            Dim sParams() As SqlParameter = {New SqlParameter("@LOGONID", logonId)}

            GetActivUserByLogonId = sqlHelper.ExecuteReaderQuery(sSQL, sParams)
        End If

    End Function

    Public Function GetActiveUserByStaffCode(ByVal staffCode As String) As DataTable Implements IPmaUserService.GetActiveUserByStaffCode
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE [STATUS] = 'A' AND [STAFF_CODE] = @STAFFCODE"
        Dim sParams() As SqlParameter = {New SqlParameter("@STAFFCODE", staffCode)}

        GetActiveUserByStaffCode = sqlHelper.ExecuteReaderQuery(sSQL, sParams)
    End Function


    Public Function GetActiveUserListByTeamCode(ByVal teamCode As String) As DataTable Implements IPmaUserService.GetActiveUserListByTeamCode

        If String.IsNullOrEmpty(teamCode) Or teamCode = "" Then
            GetActiveUserListByTeamCode = GetActiveUserList()
        End If

        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE [STATUS] = 'A' AND [TEAM_CODE] = @TEAMCODE"
        Dim sParams() As SqlParameter = {New SqlParameter("@TEAMCODE", teamCode)}
        GetActiveUserListByTeamCode = sqlHelper.ExecuteReaderQuery(sSQL, sParams)

    End Function

    Function GetActiveUserHashByMyTeams(ByVal teamCodes As String) As DataTable Implements IPmaUserService.GetActiveUserHashByMyTeams

        Dim sSQL As String = "SELECT distinct rtrim(ltrim([STAFF_NAME])) + ' - ' + upper([LOGON_ID]) as display_name, upper([logon_id]) + '-' + upper(ltrim(rtrim([id_card]))) as pmaId FROM " & sTable & " WHERE [STATUS] = 'A' "

        If Not String.IsNullOrEmpty(teamCodes) Then
            sSQL = sSQL & " AND [TEAM_CODE] in (" & teamCodes & ")"
        End If

        sSQL = sSQL & " ORDER BY [DISPLAY_NAME] DESC "

        GetActiveUserHashByMyTeams = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Public Function GetActiveUserList() As DataTable Implements IPmaUserService.GetActiveUserList
        Dim sSQL As String = "SELECT rtrim(ltrim([STAFF_NAME])) + ' - ' + upper([LOGON_ID]) as display_name, upper([LOGON_ID]) + '-' + rtrim(ltrim([ID_CARD]))as active_logon, * FROM " & sTable & " WHERE [STATUS] = 'A' ORDER BY [DISPLAY_NAME]"
        GetActiveUserList = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Function GetActiveUserHash() As DataTable Implements IPmaUserService.GetActiveUserHash
        Dim sSQL As String = "SELECT rtrim(ltrim([STAFF_NAME])) + ' - ' + upper([LOGON_ID]) as display_name, upper([LOGON_ID]) + '-' + upper(rtrim(ltrim([ID_CARD])))  as pmaId FROM " & sTable & " WHERE [STATUS] = 'A' ORDER BY [DISPLAY_NAME]"
        GetActiveUserHash = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Function GetActiveUserNameByLogonId(ByVal logonId As String) As String Implements IPmaUserService.GetActiveUserNameByLogonId
        Dim dt As DataTable = New DataTable
        Dim userName As String = ""

        If logonId Is Nothing Then
            Return ""
        ElseIf logonId = "" Then
            Return ""
        End If

        logonId = logonId.Trim.ToUpper
        Dim sSQL As String = "SELECT STAFF_NAME FROM " & sTable & " WHERE upper([LOGON_ID]) = @LOGONID AND [STATUS] = 'A' "
        Dim sParams() As SqlParameter = {New SqlParameter("@LOGONID", logonId)}

        Try
            dt = sqlHelper.ExecuteReaderQuery(sSQL, sParams)

            If Not dt Is Nothing Then
                If dt.Rows.Count > 0 Then
                    userName = dt.Rows(0).Item("STAFF_NAME")
                End If

                dt.Dispose()
            End If

        Catch ex As Exception
            LogHelper.WriteLog("GetActiveUserNameByLogonId: Failed to execute SQL " & sSQL, ex)
            Throw ex
            dt.Dispose()
        End Try

        GetActiveUserNameByLogonId = userName
    End Function

    Function GetUserName(ByVal logonId As String, ByVal idCard As String) As String Implements IPmaUserService.GetUserName
        Dim dt As DataTable = New DataTable
        Dim userName As String = ""

        If String.IsNullOrEmpty(logonId) Then
            Return ""
        ElseIf String.IsNullOrEmpty(idCard) Then
            Return ""
        End If

        logonId = logonId.Trim.ToUpper
        idCard = idCard.Trim.ToUpper

        Dim sSQL As String = "SELECT STAFF_NAME FROM " & sTable & " WHERE upper([LOGON_ID]) = @LOGONID AND rtrim(ltrim([ID_CARD])) = @IDCARD "
        Dim sParams() As SqlParameter = {New SqlParameter("@LOGONID", logonId), _
                                         New SqlParameter("@IDCARD", idCard)}

        Try
            dt = sqlHelper.ExecuteReaderQuery(sSQL, sParams)

            If Not dt Is Nothing Then
                If dt.Rows.Count > 0 Then
                    userName = dt.Rows(0).Item("STAFF_NAME")
                End If

                dt.Dispose()
            End If

        Catch ex As Exception
            LogHelper.WriteLog("GetUserName: Failed to execute SQL " & sSQL, ex)
            Throw ex
            dt.Dispose()
        End Try

        GetUserName = userName
    End Function

    Function GetUserRolesString(ByVal logonId As String) As String Implements IPmaUserService.GetUserRolesString
        Dim dtPmaUser As DataTable = GetActivUserByLogonId(logonId)
        Dim sUserRoleString = ""
        Dim slogonIdCard As String = ""
        Dim iTeamCode As Integer
        Dim dtTeam As DataTable = Nothing
        Dim pmaTeamService As IPmaTeamService = New PmaTeamService
        Dim pmaPrjService As IPmaProjectService = New PmaProjectService


        If dtPmaUser Is Nothing OrElse dtPmaUser.Rows.Count = 0 Then
            Return sUserRoleString
        End If

        slogonIdCard = dtPmaUser.Rows(0).Item("id_card").ToString.Trim
        iTeamCode = dtPmaUser.Rows(0).Item("team_code")


        dtTeam = pmaTeamService.GetMyLeadTeams(logonId, slogonIdCard, iTeamCode)
        If Not dtTeam Is Nothing Then
            For Each drTeam As DataRow In dtTeam.Rows
                If drTeam("team_code") = pmaTeamService.GetTopTeamCode() Then
                    sUserRoleString = sUserRoleString & IIf(String.IsNullOrEmpty(sUserRoleString), "", ",") & DASHBORADROLES.GM
                    Continue For
                End If

                If IIf(IsDBNull(drTeam("is_func")), "", drTeam("is_func")).ToString.ToUpper = "Y" Then
                    sUserRoleString = sUserRoleString & IIf(String.IsNullOrEmpty(sUserRoleString), "", ",") & DASHBORADROLES.FH
                    Continue For
                End If

                If IIf(IsDBNull(drTeam("is_dept")), "", drTeam("is_dept")).ToString.ToUpper = "Y" Then
                    sUserRoleString = sUserRoleString & IIf(String.IsNullOrEmpty(sUserRoleString), "", ",") & DASHBORADROLES.SBUH
                    Continue For
                End If

                If ((IIf(IsDBNull(drTeam("tl_id")), "", drTeam("tl_id")).ToString.ToUpper = logonId.ToUpper) Or _
                                        (IIf(IsDBNull(drTeam("dtl_id")), "", drTeam("dtl_id")).ToString.ToUpper = logonId.ToUpper)) Then
                    sUserRoleString = sUserRoleString & IIf(String.IsNullOrEmpty(sUserRoleString), "", ",") & DASHBORADROLES.TL
                    Continue For
                End If
            Next
        End If

        If pmaPrjService.IsProjectManager(logonId, slogonIdCard) Then
            sUserRoleString = sUserRoleString & IIf(String.IsNullOrEmpty(sUserRoleString), "", ",") & DASHBORADROLES.PM
        End If

        GetUserRolesString = sUserRoleString
        If Not dtTeam Is Nothing Then
            dtTeam = Nothing
        End If
    End Function

    Function GetActiveUserIdCardByLogonId(ByVal logonId As String) As String Implements IPmaUserService.GetActiveUserIdCardByLogonId
        Dim dt As DataTable = New DataTable
        Dim idCard As String = ""

        If logonId Is Nothing Then
            Return ""
        ElseIf logonId = "" Then
            Return ""
        End If

        logonId = logonId.Trim.ToUpper
        Dim sSQL As String = "SELECT ID_CARD FROM " & sTable & " WHERE upper([LOGON_ID]) = @LOGONID AND [STATUS] = 'A' "
        Dim sParams() As SqlParameter = {New SqlParameter("@LOGONID", logonId)}

        Try
            dt = sqlHelper.ExecuteReaderQuery(sSQL, sParams)

            If Not dt Is Nothing Then
                If dt.Rows.Count > 0 Then
                    idCard = dt.Rows(0).Item("ID_CARD")
                End If

                dt.Dispose()
            End If

        Catch ex As Exception
            LogHelper.WriteLog("GetActiveUserIdCardByLogonId: Failed to execute SQL " & sSQL, ex)
            Throw ex
            dt.Dispose()
        End Try

        GetActiveUserIdCardByLogonId = idCard
    End Function
End Class
#End Region


#Region "Validation"

#End Region
