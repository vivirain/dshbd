﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

'Public Class PmaCurrency
'    Property currencyCode As Integer
'    Property currencyName As String
'    Property isActive As String

'End Class

#End Region


#Region "Service"

Public Interface IPmaCurrencyService

    Function getCurrencyList() As DataTable
    Function getCurrency(ByVal currencyCode As String) As DataTable
    Function getCurrencyName(ByVal currencyCode As String) As String

End Interface

Class PmaCurrencyService
    Implements IPmaCurrencyService

    Const sTable = "[dbo].[tpma_currency]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND [ACTIVE] = 'Y'"
    Private sqlHelper As SqlHelper = New SqlHelper()

    Public Function getCurrencyList() As System.Data.DataTable Implements IPmaCurrencyService.getCurrencyList
        getCurrencyList = sqlHelper.ExecuteReaderQuery(sSQLTable)
    End Function

    Function getCurrency(ByVal currencyCode As String) As DataTable Implements IPmaCurrencyService.getCurrency
        Dim sSQL As String = sSQLTable & " AND [CURRENCY_CODE] = @CURRENCYCODE"
        Dim sqlParams As SqlParameter() = {New SqlParameter("@CURRENCYCODE", currencyCode)}

        getCurrency = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

    End Function

    Function getCurrencyName(ByVal currencyCode As String) As String Implements IPmaCurrencyService.getCurrencyName
        Dim sCurrencyName As String = ""
        Dim dt As DataTable = getCurrency(currencyCode)

        If Not dt Is Nothing Then
            If dt.Rows.Count > 0 Then
                sCurrencyName = dt.Rows(0).Item("currency_name").ToString
            End If

        End If

        getCurrencyName = sCurrencyName
    End Function
End Class

#End Region

