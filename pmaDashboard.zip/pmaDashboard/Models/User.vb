﻿Imports System.ComponentModel
Imports System.Globalization
Imports System.Data.SqlClient


#Region "Model"

Public Class UserModel
    Private _userRoleId As Integer
    Public ReadOnly Property userRoleId() As Integer
        Get
            Return _userRoleId
        End Get
    End Property

    Private _pmaLogonId As String
    Public Property pmaLogonId() As String
        Get
            Return _pmaLogonId
        End Get
        Set(ByVal value As String)
            _pmaLogonId = value
        End Set
    End Property

    Private _roleId As Integer
    Public Property roleId() As Integer
        Get
            Return _roleId
        End Get
        Set(ByVal value As Integer)
            _roleId = value
        End Set
    End Property

    Private _pmaStaffName As String
    Public Property pmaStaffName() As String
        Get
            Return _pmaStaffName
        End Get
        Set(ByVal value As String)
            _pmaStaffName = value
        End Set
    End Property


    Private _pmaEmail As String
    Property pmaEmail() As String
        Get
            Return _pmaEmail
        End Get
        Set(ByVal value As String)
            _pmaEmail = value
        End Set
    End Property

    Private _isActive As String
    Property isActive() As String
        Get
            Return _isActive
        End Get
        Set(ByVal value As String)
            _isActive = IIf(String.IsNullOrEmpty(value), "Y", value)
        End Set
    End Property

    Private _userRoles As String
    Property userRoles() As String
        Get
            Return _userRoles
        End Get
        Set(ByVal value As String)
            _userRoles = value
        End Set
    End Property

    Private _userMenus As String
    Property userMenus() As String
        Get
            Return _userMenus
        End Get
        Set(ByVal value As String)
            _userMenus = value
        End Set
    End Property

    Public Sub New()
    End Sub
End Class

#End Region



#Region "Services"
Public Interface IUserService

    Function IsValidDashboardUser(ByVal pmaLogonId As String) As Boolean

    Function GetUserRoles(ByVal pmaLogonId As String) As DataTable

    Function GetUserRoleString(ByVal pmaLogonId As String) As String


End Interface

Class UserService
    Implements IUserService

    Const sTable As String = "[dbo].[tpma_dshbd_user_role]"
    Private sqlHelper As SqlHelper = New SqlHelper()
    Private user As UserModel = Nothing

    Function IsValidDashboardUser(ByVal pmaLogonId As String) As Boolean Implements IUserService.IsValidDashboardUser
        Dim isValid As Boolean = False

        Dim sSQL As String = "Select 1 from " + sTable + " Where is_Active = 'Y' And pma_logon_id = @PMALOGONID"
        Dim sqlParams() As SqlParameter = {New SqlParameter("@PMALOGONID", pmaLogonId)}

        Dim dt As DataTable = New DataTable()

        dt = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

        If dt Is Nothing Then
            isValid = False
        ElseIf dt.Rows.Count = 0 Then
            isValid = False
        ElseIf dt.Rows.Count > 0 Then
            isValid = True
        End If

        sqlParams = Nothing
        dt.Dispose()

        IsValidDashboardUser = isValid
    End Function


    Public Function GetUserRoles(ByVal pmaLogonId As String) As DataTable Implements IUserService.GetUserRoles

        Dim sSQL = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND [IS_ACTIVE] = 'Y'  AND [PMA_LOGON_ID] = @PMALOGONID"
        Dim sqlParams() As SqlParameter = {New SqlParameter("@PMALOGONID", pmaLogonId)}

        GetUserRoles = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

    End Function

    Public Function GetUserRolesString(ByVal pmaLogonId As String) As String Implements IUserService.GetUserRoleString
        Dim dtUserRole As DataTable = GetUserRoles(pmaLogonId)
        Dim sUserRole As String = ""

        If Not dtUserRole Is Nothing Then
            For dr As Integer = 0 To dtUserRole.Rows.Count - 1
                sUserRole = sUserRole & IIf(dr = 0, "", ",") & dtUserRole.Rows(dr).Item(1).ToString
            Next
        End If

        dtUserRole.Dispose()
        GetUserRolesString = sUserRole
    End Function

    Function GetUserAuthMenus(ByVal roleIds As String, ByVal userId As Integer) As String
        Dim menuAuthService As IMenuAuthService = New MenuAuthService

        GetUserAuthMenus = menuAuthService.GetMenuIdsByUserRoles(roleIds, userId)

    End Function



End Class

#End Region



#Region "Validation"

#End Region

