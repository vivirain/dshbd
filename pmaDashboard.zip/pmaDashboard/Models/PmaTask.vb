﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"


#End Region


#Region "Service"

Public Interface IPmaTaskService

    Function getTaskList() As DataTable
    Function getTaskList(ByVal prjCode As String) As DataTable

    Function getPoorQualityTaskList(ByVal prjCodes As String()) As DataTable
    'Function getPoorQualityTaskList(ByVal prjCodes As String(), ByVal dataVersion As String) As DataTable

    Function getFailureEffort(ByVal prjCodes As String, ByVal dataVersion As String) As Decimal

End Interface

Class PmaTaskService
    Implements IPmaTaskService

    Const sTable = "[dbo].[tpma_task]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 "
    Private sqlHelper As SqlHelper = New SqlHelper()

    Public Function getTaskList() As System.Data.DataTable Implements IPmaTaskService.getTaskList
        getTaskList = sqlHelper.ExecuteReaderQuery(sSQLTable)
    End Function

    Function getTaskList(ByVal prjCode As String) As DataTable Implements IPmaTaskService.getTaskList
        Dim sSQL As String = sSQLTable & " AND [PRJ_CODE] = @PRJCODE"
        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRJCODE", prjCode)}

        getTaskList = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

    End Function


    Function getPoorQualityTaskList(ByVal prjCodes As String()) As DataTable Implements IPmaTaskService.getPoorQualityTaskList
        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLTable)
        If Not prjCodes Is Nothing Then
            For i As Integer = 0 To prjCodes.Length - 1
                If i = 0 Then
                    sSQLBuilder.Append(" AND ( ")
                Else
                    sSQLBuilder.Append(" OR ")
                End If
                sSQLBuilder.Append(" PRJ_CODE = '" & prjCodes(i) & "' ")
            Next
            If prjCodes.Length > 0 Then
                sSQLBuilder.Append(" )")
            End If
        End If

        sSQLBuilder.Append(" AND ( ")
        sSQLBuilder.Append(" [STANDARD_CODE] = '9700' ")
        sSQLBuilder.Append(" OR [STANDARD_CODE] = '9710' ")
        sSQLBuilder.Append(" OR [STANDARD_CODE] = '9720' ")
        sSQLBuilder.Append(" )")


        getPoorQualityTaskList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
    End Function

    Function getFailureEffort(ByVal prjCodes As String, ByVal dataVersion As String) As Decimal Implements IPmaTaskService.getFailureEffort

        If String.IsNullOrEmpty(prjCodes) Then
            Return 0
        End If

        'Dim prjCodeListString As StringBuilder = New StringBuilder("")
        'Dim prjCodeList As String() = prjCodes.Split(",")
        'For Each prjCode In prjCodeList
        '    If Not String.IsNullOrEmpty(prjCodeListString.ToString) Then
        '        prjCodeListString.Append(",")
        '    End If
        '    prjCodeListString.Append("'" & prjCode & "'")
        'Next

        Dim decFailureEffort As Decimal = 0
        'Dim dFromData As Date
        Dim dToDate As Date

        If Not String.IsNullOrEmpty(dataVersion) Then
            dataVersion = Format(Now, "yyyyMMdd")
        ElseIf Not String.IsNullOrEmpty(Trim(dataVersion)) Then
            dataVersion = Format(Now, "yyyyMMdd")
        End If

        dToDate = New Date(CInt(Left(dataVersion, 4)), CInt(dataVersion.Substring(4, 2)), CInt(Right(dataVersion, 2)))

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRJ_CODES", prjCodes), _
                                           New SqlParameter("FROM_DATE", DBNull.Value), _
                                           New SqlParameter("TO_DATE", dToDate)}

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery("[dbo].[usp_dshbd_get_failue_effort]", sqlParams, CommandType.StoredProcedure)

        If dt Is Nothing Then
            getFailureEffort = 0
        ElseIf dt.Rows.Count = 0 Then
            getFailureEffort = 0
        ElseIf IsNumeric(dt.Rows(0).Item(0)) Then
            getFailureEffort = dt.Rows(0).Item(0)
        Else
            getFailureEffort = 0
        End If

        dt = Nothing

    End Function
End Class

#End Region

