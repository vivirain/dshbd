﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

'Public Class MenuAuthModel
'    Property funcAuthId As Integer
'    Property funcId As Integer
'    Property roleId As Integer
'    Property pmaLogonId As String
'    Property isReadable As String
'    Property isEditable As String
'    Property isActive As String
'End Class

#End Region


#Region "Service"

Public Interface IMenuAuthService
    Function GetMenuAuthsByRoleUser(Optional ByVal roleId As Integer = 0, Optional ByVal pmaLogonId As String = "") As DataTable

    Function GetMenuAuthsByUserRoles(Optional ByVal roleIds As String = "", Optional ByVal pmaLogonId As String = "") As DataTable

    Function GetMenuIdsByUserRoles(Optional ByVal roleIds As String = "", Optional ByVal pmaLogonId As String = "") As String
End Interface

Class MenuAuthService
    Implements IMenuAuthService

    Const sTable = "[dbo].[tpma_dshbd_function_auth]"

    Private sqlHelper As SqlHelper = New SqlHelper()

    Function GetMenuAuthsByRoleUser(Optional ByVal roleId As Integer = 0, Optional ByVal pmaLogonId As String = "") As DataTable Implements IMenuAuthService.GetMenuAuthsByRoleUser
        Dim dt As DataTable = New DataTable
        Dim sSQL = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND IS_ACTIVE = 'Y' "
        Dim sqlParams() As SqlParameter = Nothing

        If roleId > 0 And pmaLogonId <> "" Then
            ReDim sqlParams(1)
        ElseIf (roleId > 0 And pmaLogonId = "") Or (roleId = 0 And pmaLogonId <> "") Then
            ReDim sqlParams(0)
        End If

        If roleId > 0 And pmaLogonId <> "" Then
            sSQL = sSQL & " AND role_id = @ROLEID AND pma_logon_id = @PMALOGONID"
            sqlParams(0) = New SqlParameter("ROLEID", roleId)
            sqlParams(1) = New SqlParameter("PMALOGONID", pmaLogonId)
        ElseIf roleId > 0 And pmaLogonId = "" Then
            sSQL = sSQL & " AND role_id = @ROLEID AND pma_logon_id = @PMALOGONID"
            sqlParams(0) = New SqlParameter("ROLEID", roleId)
        ElseIf roleId = 0 And pmaLogonId <> "" Then
            sSQL = sSQL & " AND pma_logon_id = @PMALOGONID"
            sqlParams(0) = New SqlParameter("PMALOGONID", pmaLogonId)
        End If

        If sqlParams Is Nothing Or sqlParams.Length <= 0 Then
            dt = sqlHelper.ExecuteReaderQuery(sSQL)
        Else
            dt = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)
        End If

        GetMenuAuthsByRoleUser = dt
    End Function


    Function GetMenuAuthsByUserRoles(Optional ByVal roleIds As String = "", Optional ByVal pmaLogonId As String = "") As DataTable Implements IMenuAuthService.GetMenuAuthsByUserRoles
        Dim dt As DataTable = New DataTable
        Dim sSQL = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND IS_ACTIVE = 'Y' "
        Dim sSqlRole As String = ""
        Dim sSqlUser As String = ""
        Dim hasOrFilter As Boolean = False

        If Not String.IsNullOrEmpty(pmaLogonId) Then
            sSqlUser = " OR [PMA_LOGON_ID] = '" & pmaLogonId & "' "
            hasOrFilter = True
        End If


        If Not String.IsNullOrEmpty(roleIds) Then
            Dim roleList As String() = roleIds.Split(",")

            If Not roleList Is Nothing Then


                If roleList.Length > 0 Then
                    sSqlRole = " OR ( "
                    hasOrFilter = True
                End If

                For i As Integer = 0 To roleList.Length - 1
                    If i > 0 Then
                        sSqlRole = sSqlRole & " OR "
                    End If

                    sSqlRole = sSqlRole & " [ROLE_ID] = " & roleList(i)
                Next

                If roleList.Length > 0 Then
                    sSqlRole = sSqlRole & " ) "
                End If
            End If
        End If

        If hasOrFilter Then
            sSQL = sSQL & " AND ( "
            sSQL = sSQL & Right(sSqlRole & sSqlUser, (sSqlRole & sSqlUser).Length - 3)
            sSQL = sSQL & " ) "
        End If

        GetMenuAuthsByUserRoles = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Function GetMenuIdsByUserRoles(Optional ByVal roleIds As String = "", Optional ByVal pmaLogonId As String = "") As String Implements IMenuAuthService.GetMenuIdsByUserRoles
        Dim dt As DataTable = New DataTable

        Dim sSQL = "SELECT [function_id] FROM " & sTable & " WHERE 1 = 1 AND IS_ACTIVE = 'Y' "
        Dim sSqlRole As String = ""
        Dim sSqlUser As String = ""

        Dim hasOrFilter As Boolean = False

        If Not String.IsNullOrEmpty(pmaLogonId) Then
            sSqlUser = " OR [PMA_LOGON_ID] = '" & pmaLogonId & "' "
            hasOrFilter = True
        End If


        If Not String.IsNullOrEmpty(roleIds) Then
            Dim roleList As String() = roleIds.Split(",")

            If Not roleList Is Nothing Then


                If roleList.Length > 0 Then
                    sSqlRole = " OR ( "
                    hasOrFilter = True
                End If

                For i As Integer = 0 To roleList.Length - 1
                    If i > 0 Then
                        sSqlRole = sSqlRole & " OR "
                    End If

                    sSqlRole = sSqlRole & " [ROLE_ID] = " & roleList(i)
                Next

                If roleList.Length > 0 Then
                    sSqlRole = sSqlRole & " ) "
                End If
            End If
        End If

        If hasOrFilter Then
            sSQL = sSQL & " AND ( "
            sSQL = sSQL & Right(sSqlRole & sSqlUser, (sSqlRole & sSqlUser).Length - 3)
            sSQL = sSQL & " ) "
        End If

        dt = sqlHelper.ExecuteReaderQuery(sSQL)

        Dim strIds As String = ""
        If Not dt Is Nothing Then
            If dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    strIds = strIds & IIf(i = 0, "", ",") & dt.Rows(i).Item(0).ToString
                Next
            End If
        End If


        GetMenuIdsByUserRoles = strIds
    End Function

End Class

#End Region
