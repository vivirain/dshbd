﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

'Public Class PmaTssProjectModel
'    Property code As Integer
'    Property name As String
'    Property isActive As String
'End Class

Public Enum ServiceCategoryGroup
    BAU = 1
    PRJ = 2
End Enum

Public Class TSSSERVICECATEGORY
    Public Shared ReadOnly Property BAUM
        Get
            BAUM = "01"
        End Get
    End Property

    Public Shared ReadOnly Property BAUE
        Get
            BAUE = "02"
        End Get
    End Property

    Public Shared ReadOnly Property PRJDEVLOPMENT
        Get
            PRJDEVLOPMENT = "03"
        End Get
    End Property

    Public Shared ReadOnly Property PRJDEPLOY
        Get
            PRJDEPLOY = "04"
        End Get
    End Property

End Class

#End Region


#Region "Service"

Public Interface IPmaTssProjectService

    Function GetTssProjectFilterList() As DataTable
    Function GetTssProjectByCode(ByVal code As String) As DataTable
    Function GetTssProjectNameByCode(ByVal code As String) As String

End Interface

Class PmaTssProjectService
    Implements IPmaTssProjectService

    Const sTable As String = "[dbo].[tpma_tss_project]"
    Dim sSQLSel As String = " SELECT [CODE], [NAME] FROM " & sTable & " WHERE 1 =  1 "
    Private sqlHelper As SqlHelper = New SqlHelper()

    Public Function GetTssProjectFilterList() As System.Data.DataTable Implements IPmaTssProjectService.GetTssProjectFilterList
        Dim sSQLBuilder As StringBuilder = New StringBuilder(" SELECT [CODE], [NAME], (NAME + ' - ' + CODE) AS DISPLAY_NAME FROM " & sTable & " WHERE 1 =  1 AND [ACTIVE] = 'Y' ")

        GetTssProjectFilterList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

    End Function

    Function GetTssProjectByCode(ByVal code As String) As DataTable Implements IPmaTssProjectService.GetTssProjectByCode
        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLSel)

        sSQLBuilder.Append(" AND [CODE] = @CODE ")
        Dim sqlParams() As SqlParameter = {New SqlParameter("@CODE", code)}

        GetTssProjectByCode = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

    End Function

    Function GetTssProjectNameByCode(ByVal code As String) As String Implements IPmaTssProjectService.GetTssProjectNameByCode

        Dim sSQLBuilder As StringBuilder = New StringBuilder(" SELECT [NAME] FROM " & sTable & " WHERE 1 =  1 ")

        sSQLBuilder.Append(" AND [CODE] = @CODE ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@CODE", code)}

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
        If Not dt Is Nothing Then
            If dt.Rows.Count > 0 Then
                GetTssProjectNameByCode = dt.Rows(0).Item(0).ToString
            Else
                GetTssProjectNameByCode = ""
            End If
        Else
            GetTssProjectNameByCode = ""
        End If


    End Function
End Class

Public Class PmaTSSProject
    Public Shared Function GetServiceCategoryGroup(ByVal tssPrj As String) As Integer
        Dim iReturn = 0

        Select Case tssPrj
            Case "01"
                iReturn = ServiceCategoryGroup.BAU
            Case "02"
                iReturn = ServiceCategoryGroup.BAU
            Case "03"
                iReturn = ServiceCategoryGroup.PRJ
            Case "04"
                iReturn = ServiceCategoryGroup.PRJ
        End Select

        GetServiceCategoryGroup = iReturn
    End Function
End Class
#End Region

