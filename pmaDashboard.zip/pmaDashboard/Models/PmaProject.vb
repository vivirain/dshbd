﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

'Public Class PmaProjectModel
'    Property projectCode As String
'    Property projectChangeControlNo As String
'    Property projectDesc As String
'    Property projectDescDetail As String
'    Property projectChineseDesc As String
'    Property projectChineseDescDetail As String
'    Property projectType As String
'    Property application As String
'    Property projectNature As String
'    Property projectSource As String

'    Property regionCode As String
'    Property companyNo As String
'    Property buCode As String
'    Property bizFunctionCode As String

'    Property requester As String
'    Property requesterEmail As String
'    Property projectLeaderId As String
'    Property projectDirector As String
'    Property projectDirectorEmail As String

'    Property planDate As Date
'    Property desiredCompleteDate As Date
'    Property estimatedStartDate As Date
'    Property estimatedCompleteDate As Date
'    Property actualStartDate As Date
'    Property actualFinishDate As Date

'    Property estimatedSystemHours As Decimal
'    Property estimatedSystemCost As Decimal
'    Property estimatedProgramHours As Decimal
'    Property estimatedProgramCost As Decimal
'    Property estimatedTotalHours As Decimal
'    Property estimatedTotalCost As Decimal
'    Property estimatedProjectTotalHours As Decimal
'    Property estimatedProjectTotalCost As Decimal
'    Property actualHours As Decimal
'    Property actualCost As Decimal
'    Property actualSnpCost As Decimal
'    Property actualOtherCost As Decimal
'    'Property ActualProjectTotalCost As Decimal
'    Property allowOverCost As String
'    Property allowOverSchedule As String
'    Property estimatedProjectTotalCostUSD As Decimal

'    Property status As String


'    Public Sub New()

'    End Sub
'End Class

#End Region


#Region "Service"

Public Interface IPmaProjectService


    Function GetOutsourcedProjectViewList(ByVal prjCode As String) As DataTable
    Function GetProjectViewListByMasterCode(ByVal masterPrjCode As String) As DataTable


    Function GetAllNoneProfiledProjectViewList(Optional ByVal prfId As Integer = 0) As DataTable
    Function GetTeamNoneProfiledProjectViewList(ByVal pmaLogonId As String, ByVal pmaIdCard As String, ByVal teamCodeString As String, Optional ByVal prfId As Integer = 0) As DataTable
    Function GetPmNoneProfiledProjectViewList(ByVal pmaLogonId As String, ByVal pmaIdCard As String, Optional ByVal prfId As Integer = 0) As DataTable


    Function GetProjectViewList(ByVal prjCodes As String) As DataTable

    Function GetProjectView(ByVal prjCode As String) As DataTable
    Function GetProject(ByVal prjCode As String, ByVal prjChgCtlNo As String) As DataTable

    Function GetProjectKpi(ByVal prjCode As String, ByVal dataVersion As String) As DataTable

    Function IsProjectManager(ByVal logonId As String, ByVal logonIdCard As String) As Boolean



End Interface

Class PmaProjectService
    Implements IPmaProjectService

    Const sTable As String = "[dbo].[tpma_project]"
    Const sView As String = "[dbo].[vpma_dshbd_project]"
    Dim sSQLTable As String = "SELECT [prj_code], [chg_ctl_no], [master_prj_code], [bill_approach], [system_bill_approach], [outsource_prj_code], [currency], [tss_prj], " & _
                                " [prj_dictor], [prj_ld_id], [prj_ld_id_card], [bu_code], [status], " & _
                                " [prj_desc], [desc_detail], [prj_desc_chn], [desc_detail_chn], " & _
                                " [est_strt_date], [est_cmpl_date], [atl_start], [atl_finish], " & _
                                " [est_tot_cost], [atl_cost], [atl_snp_cost], [atl_other_cost], [prj_tot_est_cost], " & _
                                " [est_tot_hour], [atl_hour], [prj_tot_est_hour] " & _
                               "FROM " & sTable
    Dim sSQLView As String = "SELECT * FROM " & sView & " WHERE 1 = 1 "
    Dim sSQLBuilder As StringBuilder

    Private sqlHelper As SqlHelper = New SqlHelper()
    Private logHelper As LogHelper = New LogHelper()



    Function GetOutsourcedProjectViewList(ByVal prjCode As String) As DataTable Implements IPmaProjectService.GetOutsourcedProjectViewList
        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLView)

        sSQLBuilder.Append(" AND [OUTSOURCE_PRJ_CODE] = @OUTSOURCEPRJCODE ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@OUTSOURCEPRJCODE", prjCode)}

        sSQLBuilder.Append(" ORDER BY [BU_CODE], [TSS_PRJ], [PRJ_CODE] ")



        GetOutsourcedProjectViewList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Public Function GetProjectViewList(ByVal prjCodes As String) As DataTable Implements IPmaProjectService.GetProjectViewList
        'Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLTable & " a ")
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sView & " a ")

        sSQLBuilder.Append(" WHERE 1 = 1 ")
        'sSQLBuilder.Append(" WHERE EXISTS ")
        'sSQLBuilder.Append("    (SELECT 1 FROM ")
        'sSQLBuilder.Append("        (SELECT [PRJ_CODE], MAX([CHG_CTL_NO]) AS [CHG_CTL_NO] FROM " & sTable & " GROUP BY [PRJ_CODE]) b ")
        'sSQLBuilder.Append("     WHERE b.[PRJ_CODE] = a.[PRJ_CODE] AND b.[CHG_CTL_NO] = a.[CHG_CTL_NO] ) ")
        'sSQLBuilder.Append(" AND ISNULL([TSS_PRJ], '') <> '' ")

        'Handle multiple project codes
        If Not String.IsNullOrEmpty(prjCodes) Then
            Dim prjCodeList As String() = prjCodes.Split(",")

            If Not prjCodeList Is Nothing Then
                For i As Integer = 0 To prjCodeList.Length - 1
                    sSQLBuilder.Append(IIf(i = 0, " AND (a.[PRJ_CODE] = ", " OR a.[PRJ_CODE] = "))
                    sSQLBuilder.Append("'" & prjCodeList(i) & "' ")
                Next
                sSQLBuilder.Append(IIf(prjCodeList.Length = 0, "", ")"))
            End If
        End If

        sSQLBuilder.Append(" ORDER BY a.[PRJ_CODE], a.[CHG_CTL_NO] ")

        GetProjectViewList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

    End Function


    Function GetProjectViewListByMasterCode(ByVal masterPrjCode As String) As DataTable Implements IPmaProjectService.GetProjectViewListByMasterCode
        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLView)

        sSQLBuilder.Append(" AND [MASTER_PRJ_CODE] = @MASTERPRJCODE ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@MASTERPRJCODE", masterPrjCode)}

        sSQLBuilder.Append(" ORDER BY [BU_CODE], [TSS_PRJ], [PRJ_CODE] ")

        GetProjectViewListByMasterCode = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function


    Function GetProjectView(ByVal prjCode As String) As DataTable Implements IPmaProjectService.GetProjectView
        'Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLTable)
        'sSQLBuilder.Append(" a ")
        'sSQLBuilder.Append(" WHERE 1 = 1 ")
        'sSQLBuilder.Append(" AND EXISTS ")
        'sSQLBuilder.Append("    (SELECT 1 FROM ")
        'sSQLBuilder.Append("        (SELECT [PRJ_CODE], MAX([CHG_CTL_NO]) AS [CHG_CTL_NO] FROM " & sTable & " GROUP BY [PRJ_CODE]) b ")
        'sSQLBuilder.Append("     WHERE b.[PRJ_CODE] = a.[PRJ_CODE] AND b.[CHG_CTL_NO] = a.[CHG_CTL_NO] ) ")
        'sSQLBuilder.Append(" AND ISNULL([TSS_PRJ], '') <> '' ")

        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLView)
        sSQLBuilder.Append(" AND [PRJ_CODE] = @PRJCODE ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRJCODE", prjCode)}

        GetProjectView = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Public Function GetProject(ByVal prjCode As String, ByVal prjChgCtlNo As String) As DataTable Implements IPmaProjectService.GetProject
        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [PRJ_CODE] = @PRJCODE ")
        sSQLBuilder.Append(" AND [CHG_CTL_NO] = @CHGCTLNO")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRJCODE", prjCode), _
                                           New SqlParameter("@CHGCTLNO", prjChgCtlNo)}

        GetProject = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function





    

    Function GetProjectKpi(ByVal prjCode As String, ByVal dataVersion As String) As DataTable Implements IPmaProjectService.GetProjectKpi
        Dim dToDate As Date

        If Not String.IsNullOrEmpty(dataVersion) Then
            dataVersion = Format(Now, "yyyyMMdd")
        ElseIf Not String.IsNullOrEmpty(Trim(dataVersion)) Then
            dataVersion = Format(Now, "yyyyMMdd")
        End If

        dToDate = New Date(CInt(Left(dataVersion, 4)), CInt(dataVersion.Substring(4, 2)), CInt(Right(dataVersion, 2)))

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRJ_CODE", prjCode), _
                                           New SqlParameter("TO_DATE", dToDate)}

        GetProjectKpi = sqlHelper.ExecuteReaderQuery("usp_dshbd_prj_kpi", sqlParams, CommandType.StoredProcedure)
    End Function

    Function IsProjectManager(ByVal logonId As String, ByVal logonIdCard As String) As Boolean Implements IPmaProjectService.IsProjectManager
        Dim bReturn As Boolean = False

        If String.IsNullOrEmpty(logonId) Then
            Return False
        ElseIf String.IsNullOrEmpty(logonIdCard) Then
            Return False
        End If

        logonId = logonId.Trim.ToUpper
        logonIdCard = logonIdCard.Trim.ToUpper

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT 1 as iReturn FROM " & sView)
        sSQLBuilder.Append(" WHERE upper(prj_ld_id) = @LOGONID")
        sSQLBuilder.Append(" AND upper(ltrim(rtrim(prj_ld_id_card_no))) = @LOGONIDCARD")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@LOGONID", logonId), _
                                           New SqlParameter("@LOGONIDCARD", logonIdCard)}

        Try
            If (sqlHelper.ExecuteReaderScalar(sSQLBuilder.ToString, sqlParams)) > 0 Then
                bReturn = True
            End If

        Catch ex As Exception
            logHelper.WriteLog("IsProjectManager: Failed to execute SQL: " & sSQLBuilder.ToString, ex)
            Throw ex
            bReturn = False
        End Try

        Return bReturn
    End Function

    Function GetAllNoneProfiledProjectViewList(Optional ByVal prfId As Integer = 0) As DataTable Implements IPmaProjectService.GetAllNoneProfiledProjectViewList
        Dim sPrfTable As String = "[dbo].[tpma_dshbd_profile]"
        Dim sPrfHistTable As String = "[dbo].[tpma_dshbd_profile_hist]"

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sView & " a ")

        sSQLBuilder.Append(" WHERE NOT EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM " & sPrfHistTable & " WHERE [prj_codes] like '%' + a.prj_code + '%' ")
        If prfId > 0 Then
            sSQLBuilder.Append(" AND [prf_id] <> " & prfId)
        End If
        sSQLBuilder.Append(" )")

        sSQLBuilder.Append(" AND NOT EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM " & sPrfTable & " WHERE [prj_codes] like '%' + a.prj_code + '%' and [status] = 'D' ")
        If prfId > 0 Then
            sSQLBuilder.Append(" AND [prf_id] <> " & prfId)
        End If
        sSQLBuilder.Append(" )")


        GetAllNoneProfiledProjectViewList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
    End Function

    Function GetTeamNoneProfiledProjectViewList(ByVal pmaLogonId As String, ByVal pmaIdCard As String, ByVal teamCodeString As String, Optional ByVal prfId As Integer = 0) As DataTable Implements IPmaProjectService.GetTeamNoneProfiledProjectViewList

        Dim sPrfTable As String = "[dbo].[tpma_dshbd_profile]"
        Dim sPrfHistTable As String = "[dbo].[tpma_dshbd_profile_hist]"
        Dim sStaffTable As String = "[dbo].[tpma_staffbasic]"

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sView & " a ")

        sSQLBuilder.Append(" WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND NOT EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM " & sPrfHistTable & " WHERE [prj_codes] like '%' + a.prj_code + '%' ")
        If prfId > 0 Then
            sSQLBuilder.Append(" AND [prf_id] <> " & prfId)
        End If
        sSQLBuilder.Append(" )")

        sSQLBuilder.Append(" AND NOT EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM " & sPrfTable & " WHERE [prj_codes] like '%' + a.prj_code + '%' and [status] = 'D' ")
        If prfId > 0 Then
            sSQLBuilder.Append(" AND [prf_id] <> " & prfId)
        End If
        sSQLBuilder.Append(" )")

        sSQLBuilder.Append(" AND (")

        sSQLBuilder.Append(" ( prj_ld_id = '" & pmaLogonId & "' ")
        sSQLBuilder.Append("   AND prj_ld_id_card_no = '" & pmaIdCard & "' ) ")

        sSQLBuilder.Append(" OR EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM " & sStaffTable & " where [logon_id] = a.prj_ld_id and [id_card] = a.prj_ld_id_card_no and [team_code] in (" & teamCodeString & ") and status = 'A' ")
        sSQLBuilder.Append(" )")

        sSQLBuilder.Append(" ) ")

        Try
            GetTeamNoneProfiledProjectViewList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
        Catch ex As Exception
            logHelper.WriteLog("GetTeamNoneProfiledProjectViewList: Failed to run SQL " & sSQLBuilder.ToString, ex)
            Throw ex
        End Try

    End Function

    Function GetPmNoneProfiledProjectViewList(ByVal pmaLogonId As String, ByVal pmaIdCard As String, Optional ByVal prfId As Integer = 0) As DataTable Implements IPmaProjectService.GetPmNoneProfiledProjectViewList

        Dim sPrfTable As String = "[dbo].[tpma_dshbd_profile]"
        Dim sPrfHistTable As String = "[dbo].[tpma_dshbd_profile_hist]"
        Dim sStaffTable As String = "[dbo].[tpma_staffbasic]"

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sView & " a ")

        sSQLBuilder.Append(" WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND NOT EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM " & sPrfHistTable & " WHERE [prj_codes] like '%' + a.prj_code + '%' ")
        If prfId > 0 Then
            sSQLBuilder.Append(" AND [prf_id] <> " & prfId)
        End If
        sSQLBuilder.Append(" )")

        sSQLBuilder.Append(" AND NOT EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM " & sPrfTable & " WHERE [prj_codes] like '%' + a.prj_code + '%' and [status] = 'D' ")
        If prfId > 0 Then
            sSQLBuilder.Append(" AND [prf_id] <> " & prfId)
        End If
        sSQLBuilder.Append(" )")

        sSQLBuilder.Append(" AND (")

        sSQLBuilder.Append(" ( prj_ld_id = '" & pmaLogonId & "' ")
        sSQLBuilder.Append(" AND prj_ld_id_card_no = '" & pmaIdCard & "' ) ")

        sSQLBuilder.Append(" ) ")

        Try
            GetPmNoneProfiledProjectViewList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
        Catch ex As Exception
            logHelper.WriteLog("GetPmNoneProfiledProjectViewList: Failed to execute SQL " & sSQLBuilder.ToString, ex)
            Throw ex
        End Try

    End Function
End Class

#End Region

