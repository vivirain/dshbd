﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

'Public Class PmaDebitNoteDetailModel
'    Property dnNo As String
'    Property dnYearMonth As String
'    Property prjCode As String
'    Property snpCost As Decimal
'    Property otherCost As Decimal

'    Public Sub New()

'    End Sub
'End Class

#End Region


#Region "Service"

Public Interface IPmaDebitNoteDetailService

    Function GetActualCost(ByVal prjCodes As String, ByVal dnYearMonth As String) As Decimal

End Interface

Class PmaDebitNoteDetailService
    Implements IPmaDebitNoteDetailService

    Const sTable = "[dbo].[tpma_debit_note_detail]"

    Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sTable)
    Private sqlHelper As SqlHelper = New SqlHelper()

    Function GetActualCost(ByVal prjCodes As String, ByVal dnYearMonth As String) As Decimal Implements IPmaDebitNoteDetailService.GetActualCost
        Dim decActlCost As Decimal = New Decimal(0)

        sSQLBuilder = New StringBuilder(" SELECT ISNULL(SUM( SNP_COST + OTHER_COST ),0) AS Actual_Cost ")
        sSQLBuilder.Append(" FROM " & sTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")

        Dim prjCodeList As String() = prjCodes.Split(",")

        If Not prjCodeList Is Nothing Then
            If prjCodeList.Length > 0 Then
                sSQLBuilder.Append("AND ( ")
                For i As Integer = 0 To prjCodeList.Length - 1
                    If i > 0 Then
                        sSQLBuilder.Append(" OR ")
                    End If
                    'sSQLBuilder.Append(" AND " & IIf(i = 0, " ( ", ""))
                    sSQLBuilder.Append(" [PRJ_CODE] = '" & prjCodeList(i) & "' ")
                Next
                sSQLBuilder.Append(") ")

            End If
        End If

        If Not String.IsNullOrEmpty(dnYearMonth) Then
            sSQLBuilder.Append(" AND [DN_YEARMONTH] <= '" & dnYearMonth & "'")
        End If

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

        If Not dt Is Nothing Then
            If dt.Rows.Count > 0 Then
                If IsNumeric(dt.Rows(0).Item("Actual_Cost")) Then
                    decActlCost = Convert.ToDecimal(dt.Rows(0).Item("Actual_Cost").ToString)
                End If
            End If
        End If

        GetActualCost = decActlCost
    End Function

End Class

#End Region

