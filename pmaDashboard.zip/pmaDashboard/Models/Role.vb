﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

Public Class RoleModel
    Private _roleId As Integer
    Public ReadOnly Property roleId() As Integer
        Get
            Return _roleId
        End Get
    End Property

    Private _roleCode As String
    Public Property roleCode() As String
        Get
            Return _roleCode
        End Get
        Set(ByVal value As String)
            _roleCode = value
        End Set
    End Property

    Private _roleName As String
    Property roleName() As String
        Get
            Return _roleName
        End Get
        Set(ByVal value As String)
            _roleName = value
        End Set
    End Property

    Private _pmaTeam As Integer
    Property pmaTeam() As Integer
        Get
            Return _pmaTeam
        End Get
        Set(ByVal value As Integer)
            _pmaTeam = value
        End Set
    End Property

    Private _isActive As String
    Public Property isActive() As String
        Get
            Return _isActive
        End Get
        Set(ByVal value As String)
            _isActive = IIf(String.IsNullOrEmpty(value), "Y", value)
        End Set
    End Property

    Public Sub New()

    End Sub
End Class

Public Enum DASHBORADROLES
    ADM = 1
    PM = 2
    TL = 3
    SBUH = 4
    FH = 5
    GM = 6
    EXCO = 7
    QAG = 8
    AM = 9
End Enum
#End Region


#Region "Service"

Public Interface IRoleService

    Function GetRoleList() As DataTable
    Function GetRoleById(ByVal roleId) As DataTable
End Interface

Class RoleService
    Implements IRoleService

    Const sTable = "[dbo].[tpma_dshbd_role]"
    Private sqlHelper As SqlHelper = New SqlHelper()

    Public Function GetRoleList() As System.Data.DataTable Implements IRoleService.GetRoleList
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND IS_ACTIVE = 'Y'"

        GetRoleList = sqlHelper.ExecuteReaderQuery(sSQL)

    End Function

    Function GetRoleById(ByVal roleId) As DataTable Implements IRoleService.GetRoleById
        Dim dt As DataTable = New DataTable

        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND IS_ACTIVE = 'Y' AND ROLE_ID = @ROLEID"
        Dim sqlParams() As SqlParameter = {New SqlParameter("@ROLEID", roleId)}

        dt = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

        GetRoleById = dt
    End Function
End Class

#End Region

