﻿Imports System.Data
Imports System.Data.SqlClient
Imports pmaDashboard.SqlHelper


#Region "Model"

Public Class ISSUE_STAUS

    Public Shared ReadOnly Property OPEN() As String
        Get
            Return "O"
        End Get
    End Property

    Public Shared ReadOnly Property INPROGRESS() As String
        Get
            Return "P"
        End Get
    End Property

    Public Shared ReadOnly Property CLOSED() As String
        Get
            Return "C"
        End Get
    End Property

    Public Shared ReadOnly Property CANCELLED() As String
        Get
            Return "N"
        End Get
    End Property
End Class

Public Enum ISSUE_DATE_TYPE
    TARGET_START_DATE = 1
    TARGET_END_DATE = 2
    ACTUAL_START_DATE = 3
    ACTUAL_END_DATE = 4
End Enum
#End Region

#Region "Service"

Public Interface IProfileIssueService

    Function GetProfileIssueList(Optional ByVal loadData As Boolean = True) As DataTable
    Function GetProfileIssueListAll(ByVal issueCate As String, Optional issueStatus As String = "") As DataTable
    Function GetProfileIssueList(ByVal prfId As Integer, ByVal issueCate As String, Optional issueStatus As String = "") As DataTable
    Function GetProfileIssueList(ByVal prfId As Integer) As DataTable

    Function GetProfileIssueListView(ByVal prfId As Integer, Optional ByVal issueStatus As String = "") As DataTable

    'Used in dashboard
    Function GetOpenIssueList(Optional ByVal issueCate As String = "") As DataTable
    'Used in profile tracking
    Function GetOpenProfileIssueList(ByVal prfId As Integer, Optional ByVal issueCate As String = "") As DataTable

    Function GetProfileIssue(ByVal issueNo As String) As DataTable
    Function GetNewIssueNo(ByVal issueCate As String) As Nullable(Of Integer)
    Function SaveProfileIssue(ByVal dtIssueSave As DataTable) As Boolean

    Function SaveProfileIssueAndAction(ByVal dtIssueSave As DataTable, ByVal dtIssueActionSave As DataTable) As Boolean


    Function GetProfileIssueAction(ByVal issueNo As String, ByVal openActionOnly As Boolean) As DataTable
    Function GetProfileIssueActionView(ByVal issueNo As String, ByVal openActionOnly As Boolean) As DataTable
    'Function GetOpenProfileIssueAction(ByVal issueNo As String) As DataTable
    Function CountProfileIssueAction(ByVal issueNo As String) As Integer
    Function CountOpenProfileIssueAction(ByVal issueNo As String) As Integer

    Function IsAllActionsFollowed(ByVal prfId As Integer) As Boolean
    Function IsIssueCreated(ByVal prfId As Integer, ByVal issueCate As String, ByVal issueDesc As String, ByVal issueTag As String) As Boolean
    Function IsNotApprovedSRIssueCreated(ByVal prfId As Integer, ByVal issueCate As String, ByVal issueDescSys As String, ByVal issueTag As String) As Boolean
    Function IsTagIssueCreated(ByVal prfId As Integer, ByVal issueTag As String) As Boolean

    Function GetProfileIssueCommentList(Optional ByVal emptyData As Boolean = False) As DataTable

    Function CreateProfileIssue(ByVal dtIssue As DataTable, ByVal dtIssueAction As DataTable, ByVal dtIssueComment As DataTable) As Boolean

    Function CountOpenProfileIssue(ByVal prfId As Integer) As Integer

    Function CalculateProfileIssueDate(ByVal prfId As Integer, ByVal issueNo As String, ByVal issueDateType As Integer) As Nullable(Of Date)
    Function CalculateProfileIssueDate(ByVal prfId As Integer, ByVal issueNo As String, ByVal issueActionNo As String, ByVal issueDateType As Integer) As Nullable(Of Date)

End Interface

Class ProfileIssueService
    Implements IProfileIssueService


    Const sTable = "[dbo].[tpma_dshbd_prj_issue]"
    Const sView As String = "[dbo].[vpma_dshbd_prj_issue]"
    Const sChildTable = "[dbo].[tpma_dshbd_prj_issue_comment]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " "
    Dim sSQLView As String = "SELECT * FROM " & sView & " "

    Dim sSQLBuilder As StringBuilder

    Const ISSUE = "ISSUE"
    Const RISK = "RISK"


    Shared issueCate As String = ""

    Private sqlHelper As SqlHelper = New SqlHelper()


    Function GetProfileIssueList(Optional ByVal loadData As Boolean = True) As DataTable Implements IProfileIssueService.GetProfileIssueList
        sSQLBuilder = New StringBuilder(sSQLTable)

        If Not loadData Then
            sSQLBuilder.Append(" WHERE 1 = 0 ")
        End If

        GetProfileIssueList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)


    End Function

    Function GetProfileIssueList(ByVal prfId As Integer) As DataTable Implements IProfileIssueService.GetProfileIssueList
        sSQLBuilder = New StringBuilder(sSQLTable & " WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND prf_id = @PRFID ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId)}

        GetProfileIssueList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProfileIssueListView(ByVal prfId As Integer, Optional ByVal issueStatus As String = "") As DataTable Implements IProfileIssueService.GetProfileIssueListView
        sSQLBuilder = New StringBuilder(sSQLView)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND isnull([parent_issue_no],'') = '' ")

        sSQLBuilder.Append(" AND prf_id = @PROFILEID")
        Dim sqlParams As SqlParameter() = {New SqlParameter("PROFILEID", prfId)}

        If Not String.IsNullOrEmpty(issueStatus) Then
            sSQLBuilder.Append(" AND issue_status = @ISSUESTA ")

            ReDim Preserve sqlParams(1)
            sqlParams(1) = New SqlParameter("@ISSUESTA", issueStatus)
        End If

        GetProfileIssueListView = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetOpenIssueList(Optional ByVal issueCate As String = "") As DataTable Implements IProfileIssueService.GetOpenIssueList

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")


        sSQLBuilder.Append(" AND issue_status <> @ISSUESTACLOSED ")
        sSQLBuilder.Append(" AND issue_status <> @ISSUESTACANCELLED ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@ISSUESTACLOSED", ISSUE_STAUS.CLOSED), _
                                           New SqlParameter("@ISSUESTACANCELLED", ISSUE_STAUS.CANCELLED)}

        If Not String.IsNullOrEmpty(issueCate) Then
            sSQLBuilder.Append(" AND [ISSUE_CATEGORY] = @ISSUECATE ")

            ReDim Preserve sqlParams(2)
            sqlParams(2) = New SqlParameter("@ISSUECATE", issueCate)
        End If

        GetOpenIssueList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function


    Function GetOpenProfileIssueList(ByVal prfId As Integer, Optional ByVal issueCate As String = "") As DataTable Implements IProfileIssueService.GetOpenProfileIssueList
        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND issue_status <> @ISSUESTACLOSED ")
        sSQLBuilder.Append(" AND issue_status <> @ISSUESTACANCELLED ")
        sSQLBuilder.Append(" AND [PRF_ID] = @PRFID ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@ISSUESTACLOSED", ISSUE_STAUS.CLOSED), _
                                           New SqlParameter("@ISSUESTACANCELLED", ISSUE_STAUS.CANCELLED), _
                                           New SqlParameter("@PRFID", prfId)}


        If Not String.IsNullOrEmpty(issueCate) Then
            sSQLBuilder.Append(" AND [ISSUE_CATEGORY] = @ISSUECATE ")

            ReDim Preserve sqlParams(3)
            sqlParams(3) = New SqlParameter("@ISSUECATE", issueCate)
        End If


        GetOpenProfileIssueList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function


    Function GetProfileIssueCommentList(Optional ByVal emptyData As Boolean = False) As DataTable Implements IProfileIssueService.GetProfileIssueCommentList
        sSQLBuilder = New StringBuilder("SELECT * FROM " & sChildTable & " ")

        If emptyData Then
            sSQLBuilder.Append(" WHERE 1 = 0 ")
        End If

        GetProfileIssueCommentList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
    End Function

    Function GetProfileIssueListAll(ByVal issueCate As String, Optional issueStatus As String = "") As DataTable Implements IProfileIssueService.GetProfileIssueListAll
        Dim sqlParams As SqlParameter() = {}

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND charindex('_', issue_no) <= 0 ")

        If Not String.IsNullOrEmpty(issueCate) Then
            sSQLBuilder.Append(" AND [ISSUE_CATEGORY] = @ISSUECATE ")

            ReDim Preserve sqlParams(0)
            sqlParams(0) = New SqlParameter("@ISSUECATE", issueCate)
        End If

        If Not String.IsNullOrEmpty(issueStatus) Then
            sSQLBuilder.Append(" AND issue_status = @ISSUESTATUS")
            If sqlParams.Length <= 0 Then
                ReDim Preserve sqlParams(0)
                sqlParams(0) = New SqlParameter("@ISSUESTA", issueStatus)
            Else
                ReDim Preserve sqlParams(sqlParams.Length)
                sqlParams(sqlParams.Length) = New SqlParameter("@ISSUESTA", issueStatus)
            End If
        End If

        If sqlParams Is Nothing Then
            GetProfileIssueListAll = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
        ElseIf sqlParams.Length = 0 Then
            GetProfileIssueListAll = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
        Else
            GetProfileIssueListAll = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
        End If

    End Function
    

    Function GetProfileIssueList(ByVal prfId As Integer, ByVal issueCate As String, Optional issueStatus As String = "") As DataTable Implements IProfileIssueService.GetProfileIssueList

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND [PRF_ID] = @PRFID ")
        sSQLBuilder.Append(" AND [ISSUE_CATEGORY] = @ISSUECATE ")
        sSQLBuilder.Append(" AND charindex('_', issue_no) <= 0 ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId), _
                                           New SqlParameter("@ISSUECATE", issueCate)}

        If Not String.IsNullOrEmpty(issueStatus) Then
            sSQLBuilder.Append(" AND issue_status = @ISSUESTATUS")

            ReDim Preserve sqlParams(sqlParams.Length)
            sqlParams(sqlParams.Length) = New SqlParameter("@ISSUESTA", issueStatus)
        End If

        GetProfileIssueList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function
    

    Function GetProfileIssue(ByVal issueNo As String) As DataTable Implements IProfileIssueService.GetProfileIssue
        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [ISSUE_NO] = @ISSUENO")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@ISSUENO", issueNo)}

        GetProfileIssue = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

    End Function


    Function GetProfileIssueAction(ByVal issueNo As String, ByVal openActionOnly As Boolean) As DataTable Implements IProfileIssueService.GetProfileIssueAction
        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [parent_issue_no] = @PARENT_ISSUE_NO ")

        If openActionOnly Then
            sSQLBuilder.Append(" AND issue_status <> 'C' ")
            sSQLBuilder.Append(" AND issue_status <> 'N' ")
        End If

        sSQLBuilder.Append(" ORDER BY issue_no ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PARENT_ISSUE_NO", issueNo)}

        GetProfileIssueAction = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProfileIssueActionView(ByVal issueNo As String, ByVal openActionOnly As Boolean) As DataTable Implements IProfileIssueService.GetProfileIssueActionView
        sSQLBuilder = New StringBuilder(sSQLView)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [parent_issue_no] = @PARENT_ISSUE_NO ")

        If openActionOnly Then
            sSQLBuilder.Append(" AND issue_status <> 'C' ")
            sSQLBuilder.Append(" AND issue_status <> 'N' ")
        End If

        sSQLBuilder.Append(" ORDER BY issue_no ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PARENT_ISSUE_NO", issueNo)}

        GetProfileIssueActionView = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function
    'Function GetOpenProfileIssueAction(ByVal issueNo As String) As DataTable Implements IProfileIssueService.GetOpenProfileIssueAction
    '    sSQLBuilder = New StringBuilder(sSQLTable)
    '    sSQLBuilder.Append(" WHERE 1 = 1 ")
    '    sSQLBuilder.Append(" AND [parent_issue_no] = @PARENT_ISSUE_NO ")
    '    sSQLBuilder.Append(" AND issue_status <> 'C' ")
    '    sSQLBuilder.Append(" ORDER BY issue_no ")

    '    Dim sqlParams As SqlParameter() = {New SqlParameter("@PARENT_ISSUE_NO", issueNo)}

    '    GetOpenProfileIssueAction = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    'End Function



    Function GetNewIssueNo(ByVal issueCate As String) As Nullable(Of Integer) Implements IProfileIssueService.GetNewIssueNo
        Dim issueNo As String = ""


        Dim lookupService As ILookupService = New LookupService
        Dim dtLookup As DataTable = New DataTable
        dtLookup = lookupService.GetLookUp("S", "MISC", IIf(issueCate = RISK, "Risk_No", "Issue_No"))
        If dtLookup Is Nothing Then
            Return vbNull
        ElseIf dtLookup.Rows.Count = 0 Then
            Return vbNull
        Else
            issueNo = dtLookup.Rows(0).Item("lookup_name").ToString
        End If

        If IsNumeric(issueNo) Then
            issueNo = issueNo + 1

            dtLookup.Rows(0).Item("lookup_name") = issueNo

            lookupService.SaveLookup(dtLookup)

            Return CInt(issueNo)
        Else
            Return vbNull
        End If

    End Function


    Function SaveProfileIssue(ByVal dtIssueSave As DataTable) As Boolean Implements IProfileIssueService.SaveProfileIssue
        If dtIssueSave Is Nothing Then
            Return False
        ElseIf dtIssueSave.Rows.Count = 0 Then
            Return False

        End If

        If IsDBNull(dtIssueSave.Rows(0).Item("issue_no")) Then
            Dim issue_cate As String = dtIssueSave.Rows(0).Item("issue_category")

            Dim lookupService As ILookupService = New LookupService
            Dim issueNo As String = ""
            If issue_cate = "RISK" Then
                issueNo = lookupService.GetLookUpName("B", "ISSUECATE", "Risk_No")
            ElseIf issue_cate = "ISSUE" Then
                issueNo = lookupService.GetLookUpName("B", "ISSUECATE", "Issue_No")
            End If
            dtIssueSave.Rows(0).Item("issue_no") = issueNo
        End If



        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 0 ")



        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQLBuilder.ToString, dtIssueSave)}
        SaveProfileIssue = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
    End Function

    Function SaveProfileIssueAndAction(ByVal dtIssueSave As DataTable, ByVal dtIssueActionSave As DataTable) As Boolean Implements IProfileIssueService.SaveProfileIssueAndAction
        If dtIssueSave Is Nothing Then
            Return False
        ElseIf dtIssueSave.Rows.Count = 0 Then
            Return False
        End If

        If dtIssueActionSave Is Nothing Then
            Return False
        ElseIf dtIssueActionSave.Rows.Count = 0 Then
            Return False
        End If

        If IsDBNull(dtIssueSave.Rows(0).Item("issue_no")) Then
            Dim issue_cate As String = dtIssueSave.Rows(0).Item("issue_category")

            Dim lookupService As ILookupService = New LookupService
            Dim issueNo As String = ""
            If issue_cate = "RISK" Then
                issueNo = lookupService.GetLookUpName("B", "ISSUECATE", "Risk_No")
            ElseIf issue_cate = "ISSUE" Then
                issueNo = lookupService.GetLookUpName("B", "ISSUECATE", "Issue_No")
            End If
            dtIssueSave.Rows(0).Item("issue_no") = issueNo
        End If



        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 0 ")



        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQLBuilder.ToString, dtIssueActionSave), _
                                                   New SqlAdapterUpdate(sSQLBuilder.ToString, dtIssueSave)}

        SaveProfileIssueAndAction = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
    End Function


    Function CreateProfileIssue(ByVal dtIssue As DataTable, ByVal dtIssueAction As DataTable, ByVal dtIssueComment As DataTable) As Boolean Implements IProfileIssueService.CreateProfileIssue

        Dim sSQLIssue As String = "SELECT * FROM " & sTable & " WHERE 1 = 0 "
        Dim sSQLIssueAction As String = "SELECT * FROM " & sTable & " WHERE 1 = 0 "
        Dim sSQLIssueComment As String = "SELECT * FROM " & sChildTable & " WHERE 1 = 0 "


        Dim sqlAdapterIns As SqlAdapterInsert() = {New SqlAdapterInsert(sSQLIssue, dtIssue, False), _
                                                   New SqlAdapterInsert(sSQLIssueAction, dtIssueAction, True), _
                                                    New SqlAdapterInsert(sSQLIssueComment, dtIssueComment, False)
                                                   }
        Dim issueId As Integer
        CreateProfileIssue = sqlHelper.ExecuteAdapterInsert(sqlAdapterIns, issueId, "issue_id")
    End Function


    Function CountProfileIssueAction(ByVal issueNo As String) As Integer Implements IProfileIssueService.CountProfileIssueAction
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT count(1) FROM " & sTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [parent_issue_no] = @ISSUENO ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@ISSUENO", issueNo)}

        CountProfileIssueAction = sqlHelper.ExecuteReaderScalar(sSQLBuilder.ToString, sqlParams)
    End Function

    Function CountOpenProfileIssueAction(ByVal issueNo As String) As Integer Implements IProfileIssueService.CountOpenProfileIssueAction
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT count(1) FROM " & sTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [parent_issue_no] = @ISSUENO ")

        sSQLBuilder.Append(" AND [issue_status] <> @ISSUESTACLOSED ")
        sSQLBuilder.Append(" AND [issue_status] <> @ISSUESTACANCELLED ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@ISSUENO", issueNo), _
                                            New SqlParameter("@ISSUESTACLOSED", ISSUE_STAUS.CLOSED), _
                                           New SqlParameter("@ISSUESTACANCELLED", ISSUE_STAUS.CANCELLED)}

        CountOpenProfileIssueAction = sqlHelper.ExecuteReaderScalar(sSQLBuilder.ToString, sqlParams)
    End Function


    Function IsAllActionsFollowed(ByVal prfId As Integer) As Boolean Implements IProfileIssueService.IsAllActionsFollowed
        Dim iActionNotFollowed As Integer = 0

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT count(1) as actionNotFollowed FROM " & sTable & " a WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND PRF_ID = @PRFID ")
        sSQLBuilder.Append(" AND isnull([ISSUE_STATUS], '') <> 'C' ")
        sSQLBuilder.Append(" AND isnull([ISSUE_STATUS], '') <> 'N' ")
        sSQLBuilder.Append(" AND isnull([ISSUE_TRACE_STATUS], '') <> 'G' ")
        sSQLBuilder.Append(" AND isnull([PARNET_ISSUE_NO], '') = '' ")
        sSQLBuilder.Append(" AND NOT EXISTS (SELECT 1 FROM " & sTable & " WHERE isnull([PARENT_ISSUE_NO], '') = a.[ISSUE_NO] AND [ISSUE_NO] <> a.[ISSUE_NO] AND [PRF_ID] = a.[PRF_ID]) ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId)}
        iActionNotFollowed = sqlHelper.ExecuteReaderScalar(sSQLBuilder.ToString, sqlParams)

        If iActionNotFollowed = 0 Then
            IsAllActionsFollowed = True
        Else
            IsAllActionsFollowed = False
        End If

    End Function

    Function IsIssueCreated(ByVal prfId As Integer, ByVal issueCate As String, ByVal issueDesc As String, ByVal issueTag As String) As Boolean Implements IProfileIssueService.IsIssueCreated

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT COUNT(1) FROM " & sTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND PRF_ID = @PRFID ")
        sSQLBuilder.Append(" AND [ISSUE_CATEGORY] = @ISSUECATE ")
        sSQLBuilder.Append(" AND [ISSUE_DESC_SHORT] = @ISSUEDESC ")
        sSQLBuilder.Append(" AND [ISSUE_TAG] = @ISSUETAG ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId), _
                                           New SqlParameter("@ISSUECATE", issueCate), _
                                           New SqlParameter("@ISSUEDESC", issueDesc), _
                                           New SqlParameter("@ISSUETAG", issueTag)}

        Dim iActionFollowed = sqlHelper.ExecuteReaderScalar(sSQLBuilder.ToString, sqlParams)


        If iActionFollowed > 0 Then
            IsIssueCreated = True
        Else
            IsIssueCreated = False
        End If
    End Function


    Function IsNotApprovedSRIssueCreated(ByVal prfId As Integer, ByVal issueCate As String, ByVal issueDescSys As String, ByVal issueTag As String) As Boolean Implements IProfileIssueService.IsNotApprovedSRIssueCreated
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT COUNT(1) FROM " & sTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND PRF_ID = @PRFID ")
        sSQLBuilder.Append(" AND [ISSUE_CATEGORY] = @ISSUECATE ")
        sSQLBuilder.Append(" AND [ISSUE_DESC_SYS] = @ISSUEDESCSYS ")
        sSQLBuilder.Append(" AND [ISSUE_TAG] = @ISSUETAG ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId), _
                                           New SqlParameter("@ISSUECATE", issueCate), _
                                           New SqlParameter("@ISSUEDESCSYS", issueDescSys), _
                                           New SqlParameter("@ISSUETAG", issueTag)}

        Dim iActionFollowed = sqlHelper.ExecuteReaderScalar(sSQLBuilder.ToString, sqlParams)


        If iActionFollowed > 0 Then
            IsNotApprovedSRIssueCreated = True
        Else
            IsNotApprovedSRIssueCreated = False
        End If
    End Function
    Function IsTagIssueCreated(ByVal prfId As Integer, ByVal issueTag As String) As Boolean Implements IProfileIssueService.IsTagIssueCreated
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT COUNT(1) as issueTagCnt FROM " & sTable & " WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND PRF_ID = @PRFID ")

        sSQLBuilder.Append(" AND [ISSUE_TAG] = @ISSUETAG ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId), _
                                           New SqlParameter("@ISSUETAG", issueTag)}

        Dim iActionFollowed = sqlHelper.ExecuteReaderScalar(sSQLBuilder.ToString, sqlParams)


        If iActionFollowed > 0 Then
            IsTagIssueCreated = True
        Else
            IsTagIssueCreated = False
        End If
    End Function
    Function CountOpenProfileIssue(ByVal prfId As Integer) As Integer Implements IProfileIssueService.CountOpenProfileIssue
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT count(1) FROM " & sTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND isnull([parent_issue_no],'') = '' ")
        sSQLBuilder.Append(" AND [issue_status] <> 'C' ")
        sSQLBuilder.Append(" AND [issue_status] <> 'N' ")
        sSQLBuilder.Append(" AND prf_id = @PRFID ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId)}

        CountOpenProfileIssue = sqlHelper.ExecuteReaderScalar(sSQLBuilder.ToString, sqlParams)
    End Function

    Function CalculateProfileIssueDate(ByVal prfId As Integer, ByVal issueNo As String, ByVal issueDateType As Integer) As Nullable(Of Date) Implements IProfileIssueService.CalculateProfileIssueDate
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT ")

        Select Case issueDateType
            Case ISSUE_DATE_TYPE.TARGET_START_DATE
                sSQLBuilder.Append("MIN(ISSUE_EST_START_DATE) as issueDate ")
            Case ISSUE_DATE_TYPE.TARGET_END_DATE
                sSQLBuilder.Append("MIN(ISSUE_EST_END_DATE) as issueDate ")
            Case ISSUE_DATE_TYPE.ACTUAL_START_DATE
                sSQLBuilder.Append("MIN(ISSUE_ACTL_START_DATE) as issueDate ")
            Case ISSUE_DATE_TYPE.ACTUAL_END_DATE
                sSQLBuilder.Append("MIN(ISSUE_ACTL_END_DATE) as issueDate ")
        End Select

        sSQLBuilder.Append(" FROM " & sTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND isnull([parent_issue_no],'') = @ISSUENO ")
        sSQLBuilder.Append(" AND prf_id = @PRFID ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId), _
                                           New SqlParameter("@ISSUENO", issueNo)}

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
        If dt Is Nothing Then
            CalculateProfileIssueDate = Nothing
        ElseIf dt.Rows.Count = 0 Then
            CalculateProfileIssueDate = Nothing
        Else
            CalculateProfileIssueDate = dt.Rows(0).Item(0)
        End If

        dt.Dispose()
    End Function

    Function CalculateProfileIssueDate(ByVal prfId As Integer, ByVal issueNo As String, ByVal issueActionNo As String, ByVal issueDateType As Integer) As Nullable(Of Date) Implements IProfileIssueService.CalculateProfileIssueDate
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT ")

        Select Case issueDateType
            Case ISSUE_DATE_TYPE.TARGET_START_DATE
                sSQLBuilder.Append("MIN(ISSUE_EST_START_DT) as issueDate ")
            Case ISSUE_DATE_TYPE.TARGET_END_DATE
                sSQLBuilder.Append("MIN(ISSUE_EST_END_DT) as issueDate ")
            Case ISSUE_DATE_TYPE.ACTUAL_START_DATE
                sSQLBuilder.Append("MIN(ISSUE_ACTL_START_DT) as issueDate ")
            Case ISSUE_DATE_TYPE.ACTUAL_END_DATE
                sSQLBuilder.Append("MIN(ISSUE_ACTL_END_DT) as issueDate ")
        End Select

        sSQLBuilder.Append(" FROM " & sTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND isnull([parent_issue_no],'') = @ISSUENO ")
        sSQLBuilder.Append(" AND isnull([issue_no],'') <> @ISSUEACTIONNO ")
        sSQLBuilder.Append(" AND prf_id = @PRFID ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId), _
                                           New SqlParameter("@ISSUENO", issueNo), _
                                           New SqlParameter("@ISSUEACTIONNO", issueActionNo)}

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
        If dt Is Nothing Then
            CalculateProfileIssueDate = Nothing
        ElseIf dt.Rows.Count = 0 Then
            CalculateProfileIssueDate = Nothing
        ElseIf IsDBNull(dt.Rows(0).Item(0)) Then
            CalculateProfileIssueDate = Nothing
        Else
            CalculateProfileIssueDate = dt.Rows(0).Item(0)
        End If

        dt.Dispose()
    End Function
End Class

#End Region

