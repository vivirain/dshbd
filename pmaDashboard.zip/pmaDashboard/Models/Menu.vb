﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

'Public Class MenuModel
'    Property funcId As Integer
'    Property funcName As String
'    Property funcSeq As Integer
'    Property funcTopId As Integer
'    Property funcUrl As String
'    Property isActive As String

'End Class

#End Region


#Region "Service"

Public Interface IMenuService
    Function GetMenuItems() As DataTable
    Function GetUserMenuItems(ByVal funcIds As String) As DataTable
End Interface

Class MenuService
    Implements IMenuService

    Const sTable = "[dbo].[tpma_dshbd_function]"

    Private sqlHelper As SqlHelper = New SqlHelper()

    Function GetMenuItems() As DataTable Implements IMenuService.GetMenuItems
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE [IS_ACTIVE] = 'Y' "

        GetMenuItems = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Function GetUserMenuItems(ByVal funcIds As String) As DataTable Implements IMenuService.GetUserMenuItems
        Dim dt As DataTable = New DataTable

        If String.IsNullOrEmpty(funcIds) Or funcIds = "" Then
            dt = GetMenuItems()
        Else
            Dim sSQL = "SELECT * FROM " & sTable & " WHERE [IS_ACTIVE] = 'Y' AND [FUNCTION_ID] IN (" & funcIds & ")"
            'Dim sParams() As SqlParameter = {New SqlParameter("@FUNCIDS", funcIds)}
            dt = sqlHelper.ExecuteReaderQuery(sSQL)
        End If

        GetUserMenuItems = dt
    End Function

End Class

#End Region
