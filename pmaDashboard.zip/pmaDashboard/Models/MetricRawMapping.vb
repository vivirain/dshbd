﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization



#Region "Model"



'Public Class MetricRawMapping
'    Property metricCode As String
'    Property metricRawCode As String

'    Property effectBeginDate As DateTime
'    Property effectEndDate As DateTime
'    Property isActive As String

'    Property createdBy As String
'    Property createdDate As DateTime
'    Property lastUpdatedBy As String
'    Property lastUpdatedDate As DateTime

'End Class

#End Region

#Region "Service"

Public Interface IMetricRawMappingService


    Function GetMappingList(Optional ByVal isActive As String = "") As DataTable
    Function GetMappingListByMetric(ByVal metricCode As String, Optional ByVal isActive As String = "Y") As DataTable

    Function GetMappingListViewByMetric(ByVal metricCode As String, Optional ByVal isActive As String = "Y") As DataTable

    Function GetMapping(ByVal mappingId As Integer, Optional ByVal isActive As String = "Y") As DataTable
    Function GetMapping(ByVal metricCode As String, ByVal metricRawCode As String, Optional ByVal isActive As String = "Y") As DataTable

    Function IsMappingFound(ByVal metricCode As String, ByVal metricRawCode As String, Optional ByVal isActive As String = "Y") As Boolean

    'Function SaveMetricRaw(ByVal dtSave As DataTable) As Boolean

    'Function IsExistedQualityMetricRaw(ByVal metricRaw As MetricRaw) As Boolean

End Interface

Class MetricRawMappingService
    Implements IMetricRawMappingService

    Const sTable = "[dbo].[tpma_dshbd_metric_raw_mapping]"
    Const sView = "[dbo].[vpma_dshbd_metric_raw_mapping]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " "
    Dim sSQLView As String = "SELECT * FROM " & sView & " "
    Dim sSQL As StringBuilder = New StringBuilder("")

    Private sqlHelper As SqlHelper = New SqlHelper()


    Function GetMappingList(Optional ByVal isActive As String = "") As DataTable Implements IMetricRawMappingService.GetMappingList
        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")

        If String.IsNullOrEmpty(isActive) Then
            GetMappingList = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        Else
            sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")
            Dim sqlParams As SqlParameter() = {New SqlParameter("@ISACTIVE", isActive)}
            GetMappingList = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
        End If

    End Function


    Function GetMappingListByMetric(ByVal metricCode As String, Optional ByVal isActive As String = "Y") As DataTable Implements IMetricRawMappingService.GetMappingListByMetric
        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [METRIC_CODE] = @METRICCODE")
        sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@METRICCODE", metricCode), _
                                           New SqlParameter("@ISACTIVE", isActive)}

        GetMappingListByMetric = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function


    Function GetMappingListViewByMetric(ByVal metricCode As String, Optional ByVal isActive As String = "Y") As DataTable Implements IMetricRawMappingService.GetMappingListViewByMetric
        sSQL = New StringBuilder(sSQLView)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [METRIC_CODE] = @METRICCODE")
        'sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@METRICCODE", metricCode)}

        GetMappingListViewByMetric = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function

    Function GetMapping(ByVal mappingId As Integer, Optional ByVal isActive As String = "Y") As DataTable Implements IMetricRawMappingService.GetMapping
        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [MAPPING_ID] = @ID")
        sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@ID", mappingId), _
                                           New SqlParameter("@ISACTIVE", isActive)}

        GetMapping = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function

    Function GetMapping(ByVal metricCode As String, ByVal metricRawCode As String, Optional ByVal isActive As String = "Y") As DataTable Implements IMetricRawMappingService.GetMapping
        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [METRIC_CODE] = @METRICCODE")
        sSQL.Append(" AND [METRIC_RAW_CODE] = @METRICRAWCODE")
        sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@METRICCODE", metricCode), _
                                           New SqlParameter("@METRICRAWCODE", metricRawCode), _
                                           New SqlParameter("@ISACTIVE", isActive)}

        GetMapping = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function

    Function IsMappingFound(ByVal metricCode As String, ByVal metricRawCode As String, Optional ByVal isActive As String = "Y") As Boolean Implements IMetricRawMappingService.IsMappingFound

        Dim dtMapping As DataTable = New DataTable
        dtMapping = GetMapping(metricCode, metricRawCode)


        If dtMapping Is Nothing Then
            Return False
        ElseIf dtMapping.Rows.Count = 0 Then
            dtMapping.Dispose()
            Return False
        Else
            dtMapping.Dispose()
            Return True
        End If

    End Function

End Class


#End Region