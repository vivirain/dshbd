﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization



#Region "Model"



'Public Class MetricRaw
'    Property code As String
'    Property desc As String
'    Property tips As String
'    Property dataType As String
'    Property dataPrecision As Integer
'    Property dataSource As String

'    Property effectBeginDate As DateTime
'    Property effectEndDate As DateTime
'    Property isActive As String

'    Property createdBy As String
'    Property createdDate As DateTime
'    Property lastUpdatedBy As String
'    Property lastUpdatedDate As DateTime

'    Public Sub New()

'    End Sub
'End Class

Public Class MetricRawJson
    Private _code As String
    Property code() As String
        Get
            Return _code
        End Get
        Set(ByVal value As String)
            _code = value
        End Set
    End Property

    Public Shared Function DeserializeJsonToList(ByVal jsonText As String) As List(Of MetricRawJson)

        Dim JsonList As List(Of MetricRawJson) = Nothing
        If Not String.IsNullOrEmpty(jsonText) Then
            Dim ser As JavaScriptSerializer = New JavaScriptSerializer()
            JsonList = ser.Deserialize(Of List(Of MetricRawJson))(jsonText)
        End If

        Return JsonList
    End Function
End Class

#End Region

#Region "Service"

Public Interface IMetricRawService


    Function GetMetricRawList(Optional ByVal isActive As String = "") As DataTable
    Function GetMetricRawListBySrc(ByVal dataSrc As String) As DataTable

    Function GetMetricRaw(ByVal id As Integer, Optional ByVal isActive As String = "Y") As DataTable
    Function GetMetricRaw(ByVal code As String, Optional ByVal isActive As String = "Y") As DataTable


    'Function SaveMetricRaw(ByVal dtSave As DataTable) As Boolean

    'Function IsExistedQualityMetricRaw(ByVal metricRaw As MetricRaw) As Boolean

End Interface

Class MetricRawService
    Implements IMetricRawService

    Const sTable = "[dbo].[tpma_dshbd_metric_raw]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " "
    Dim sSQL As StringBuilder = New StringBuilder("")

    Private sqlHelper As SqlHelper = New SqlHelper()


    Function GetMetricRawList(Optional ByVal isActive As String = "") As DataTable Implements IMetricRawService.GetMetricRawList
        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")

        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0

        If Not String.IsNullOrEmpty(isActive) Then
            sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")

            If sqlParams.Length > 0 Then
                iUpperBound = sqlParams.Length
            End If
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@ISACTIVE", isActive)
        End If

        If sqlParams Is Nothing Then
            GetMetricRawList = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        ElseIf sqlParams.Length = 0 Then
            GetMetricRawList = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        Else
            GetMetricRawList = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
        End If
    End Function

    Function GetMetricRawListBySrc(ByVal dataSrc As String) As DataTable Implements IMetricRawService.GetMetricRawListBySrc
        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [IS_ACTIVE] = 'Y' ")
        sSQL.Append(" AND [DATA_SOURCE] = @DATASRC")


        Dim sqlParams As SqlParameter() = {New SqlParameter("@DATASRC", dataSrc)}


        GetMetricRawListBySrc = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function

    Function GetMetricRaw(ByVal id As Integer, Optional ByVal isActive As String = "Y") As DataTable Implements IMetricRawService.GetMetricRaw

        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")
        sSQL.Append(" AND [ID] = @ID")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@ID", id), _
                                           New SqlParameter("@ISACTIVE", isActive)}


        GetMetricRaw = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)

    End Function


    Function GetMetricRaw(ByVal code As String, Optional ByVal isActive As String = "Y") As DataTable Implements IMetricRawService.GetMetricRaw
        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")
        sSQL.Append(" AND [CODE] = @CODE")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@CODE", code), _
                                           New SqlParameter("@ISACTIVE", isActive)}


        GetMetricRaw = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function

End Class


#End Region