﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

Public Class ProjectMetricRaw
    Private _id As Integer
    Public ReadOnly Property id() As Integer
        Get
            Return _id
        End Get
    End Property

    'Property prjCode As String


    Private _metricCode As String
    Public Property metricCode() As String
        Get
            Return _metricCode
        End Get
        Set(ByVal value As String)
            _metricCode = value
        End Set
    End Property

    Private _metricRawCode As String
    Public Property metricRawCode() As String
        Get
            Return _metricRawCode
        End Get
        Set(ByVal value As String)
            _metricRawCode = value
        End Set
    End Property

    Private _metricRawVal As String
    Public Property metricRawVal() As String
        Get
            Return _metricRawVal
        End Get
        Set(ByVal value As String)
            _metricRawVal = value
        End Set
    End Property

    Private _dataVersion As String
    Public Property dataVersion() As String
        Get
            Return _dataVersion
        End Get
        Set(ByVal value As String)
            _dataVersion = value
        End Set
    End Property

    Private _isActive As String
    Public Property isActive() As String
        Get
            Return _isActive
        End Get
        Set(ByVal value As String)
            _isActive = IIf(String.IsNullOrEmpty(value), "Y", value)
        End Set
    End Property

    Private _lastUpdatedBy As String
    Public Property lastUpdatedBy() As String
        Get
            Return _lastUpdatedBy
        End Get
        Set(ByVal value As String)
            _lastUpdatedBy = value
        End Set
    End Property

    Private _lastUpdatedDate As Date
    Public Property lastUpdatedDate() As Date
        Get
            Return _lastUpdatedDate
        End Get
        Set(ByVal value As Date)
            _lastUpdatedDate = value
        End Set
    End Property
End Class

#End Region

#Region "Service"

Public Interface IProjectMetricRawService

    Function GetBlankProjectMetricRaw() As DataTable

    Function GetProjectMetricRawList() As DataTable
    Function GetProjectMetricRawList(ByVal prjCodes As String()) As DataTable
    Function GetProjectMetricRawList(ByVal prjCode As String, ByVal metricCode As String) As DataTable

    Function GetProjectMetricRaw(ByVal id As Integer) As DataTable
    Function GetProjectMetricRaw(ByVal prjCode As String, ByVal metricCode As String, ByVal metricRawCode As String) As DataTable


    Function SaveProjectQualytMetricRaw(ByVal dtSave As DataTable) As Boolean


    Function GetProjectMetricRawHistList(ByVal prjCodes As String(), ByVal dataVersion As String, ByVal includeDataVersion As Boolean) As DataTable
    Function GetProjectMetricRawHistListByMetric(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataVersion As String, ByVal includeDataVersion As Boolean) As DataTable
    Function GetProjectMetricRawHistList(ByVal prjCodes As String(), ByVal metricRawCode As String, ByVal dataVersion As String, ByVal includeDataVersion As Boolean) As DataTable

    Function GetProjectMetricRawHist(ByVal prjCodes As String(), ByVal dataVersion As String) As DataTable
    Function GetProjectMetricRawHist(ByVal prjCodes As String(), ByVal metricRawCode As String, ByVal dataVersion As String) As DataTable

    Function GetProjectMetricRawHist(ByVal prjCode As String, ByVal dataVersion As String) As Hashtable

End Interface

Class ProjectMetricRawService
    Implements IProjectMetricRawService

    Const sTable = "[dbo].[tpma_dshbd_prj_metric_raw]"
    Const sHistTable = "[dbo].[tpma_dshbd_prj_metric_raw_hist]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " "
    Dim sSQLHistTable As String = "SELECT * FROM " & sHistTable & " "

    Private sqlHelper As SqlHelper = New SqlHelper()


    Function GetBlankProjectMetricRaw() As DataTable Implements IProjectMetricRawService.GetBlankProjectMetricRaw

        Dim sSQL As String = sSQLTable & " WHERE 1 = 0"

        GetBlankProjectMetricRaw = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Function GetProjectMetricRawList() As DataTable Implements IProjectMetricRawService.GetProjectMetricRawList
        Dim sSQL As StringBuilder = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")

        GetProjectMetricRawList = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
    End Function

    Function GetProjectMetricRawList(ByVal prjCodes As String()) As DataTable Implements IProjectMetricRawService.GetProjectMetricRawList
        Dim sSQL As StringBuilder = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")

        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQL.Append(" AND ( ")
                Else
                    sSQL.Append(" OR ")
                End If

                iParam = iParam + 1
                sSQL.Append(" [PRJ_CODE] = @P" & iParam)

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next

        If iParam > 0 Then
            sSQL.Append(") ")
        End If

        If iParam = 0 Then
            GetProjectMetricRawList = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        Else
            GetProjectMetricRawList = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
        End If

    End Function

    Function GetProjectMetricRawList(ByVal prjCode As String, ByVal metricCode As String) As DataTable Implements IProjectMetricRawService.GetProjectMetricRawList
        Dim sSQL As StringBuilder = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [PRJ_CODE] = @PRJCODE")
        sSQL.Append(" AND [METRIC_CODE] = @METRICCODE")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRJCODE", prjCode), _
                                           New SqlParameter("@METRICCODE", metricCode)}

        GetProjectMetricRawList = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function



    Function GetProjectMetricRaw(ByVal id As Integer) As DataTable Implements IProjectMetricRawService.GetProjectMetricRaw
        Dim sSQL As StringBuilder = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [ID] = @ID")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@ID", id)}

        GetProjectMetricRaw = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function

    Function GetProjectMetricRaw(ByVal prjCode As String, ByVal metricCode As String, ByVal metricRawCode As String) As DataTable Implements IProjectMetricRawService.GetProjectMetricRaw
        Dim sSQL As StringBuilder = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [PRJ_CODE] = @PRJCODE")
        sSQL.Append(" AND [METRIC_CODE] = @METRICCODE")
        sSQL.Append(" AND [METRIC_RAW_CODE] = @METRICRAWCODE")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRJCODE", prjCode), _
                                           New SqlParameter("@METRICCODE", metricCode), _
                                           New SqlParameter("@METRICRAWCODE", metricRawCode)}

        GetProjectMetricRaw = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function



    Function SaveProjectQualytMetricRaw(ByVal dtSave As DataTable) As Boolean Implements IProjectMetricRawService.SaveProjectQualytMetricRaw
        Dim sSQL As StringBuilder = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 0 ")

        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQL.ToString, dtSave)}
        SaveProjectQualytMetricRaw = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
    End Function


    Function GetProjectMetricRawHistList(ByVal prjCodes As String(), ByVal dataVersion As String, ByVal includeDataVersion As Boolean) As DataTable Implements IProjectMetricRawService.GetProjectMetricRawHistList
        Dim sSQLPrjCodes As String = ""

        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                Dim prjCodeList As String() = prjCodes(i).Split(",")

                For Each prjCode In prjCodeList
                    If iParam = 0 Then
                        sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                    Else
                        sSQLPrjCodes = sSQLPrjCodes & " OR "
                    End If

                    iParam = iParam + 1
                    sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                    iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                    ReDim Preserve sqlParams(iUpperBound)
                    sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCode)
                Next

            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & " ) "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLHistTable & " a ")
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)
        sSQLBuilder.Append(" AND [DATA_VERSION] = ( ")
        sSQLBuilder.Append(" SELECT MAX([DATA_VERSION]) FROM " & sHistTable & " WHERE [DATA_VERSION] " & IIf(includeDataVersion, "<=", "<") & " @DATAVERSION " & sSQLPrjCodes & ") ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataVersion)

        GetProjectMetricRawHistList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProjectMetricRawHistListByMetric(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataVersion As String, ByVal includeDataVersion As Boolean) As DataTable Implements IProjectMetricRawService.GetProjectMetricRawHistListByMetric
        Dim sSQLPrjCodes As String = ""

        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLHistTable & " a ")
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)

        'sSQLBuilder.Append(" AND [METRIC_RAW_CODE] = @METRICRAWCODE ")
        sSQLBuilder.Append(" AND EXISTS( SELECT 1 FROM [dbo].[tpma_dshbd_metric_raw_mapping] WHERE metric_code = @METRICCODE and metric_raw_code = a.metric_raw_code )")
        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@METRICCODE", metricCode)


        sSQLBuilder.Append(" AND [DATA_VERSION] = ( SELECT DATA_VERSION FROM ")
        sSQLBuilder.Append(" (SELECT PRJ_CODE, MAX([DATA_VERSION]) as DATA_VERSION FROM " & sHistTable & " WHERE [DATA_VERSION] " & IIf(includeDataVersion, "<=", "<") & " @DATAVERSION " & " GROUP BY PRJ_CODE) b ")
        sSQLBuilder.Append(" WHERE PRJ_CODE = a.PRJ_CODE ) ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataVersion)

        GetProjectMetricRawHistListByMetric = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function
    Function GetProjectMetricRawHistList(ByVal prjCodes As String(), ByVal metricRawCode As String, ByVal dataVersion As String, ByVal includeDataVersion As Boolean) As DataTable Implements IProjectMetricRawService.GetProjectMetricRawHistList
        Dim sSQLPrjCodes As String = ""

        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLHistTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)

        sSQLBuilder.Append(" AND [METRIC_RAW_CODE] = @METRICRAWCODE ")
        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@METRICRAWCODE", metricRawCode)


        sSQLBuilder.Append(" AND [DATA_VERSION] = ( ")
        sSQLBuilder.Append(" SELECT MAX([DATA_VERSION]) FROM " & sHistTable & " WHERE [DATA_VERSION] " & IIf(includeDataVersion, "<=", "<") & " @DATAVERSION " & sSQLPrjCodes & ") ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataVersion)

        GetProjectMetricRawHistList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProjectMetricRawHist(ByVal prjCodes As String(), ByVal dataVersion As String) As DataTable Implements IProjectMetricRawService.GetProjectMetricRawHist
        Dim sSQLPrjCodes As String = ""

        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLHistTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)
        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataVersion)

        GetProjectMetricRawHist = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProjectMetricRawHist(ByVal prjCodes As String(), ByVal metricRawCode As String, ByVal dataVersion As String) As DataTable Implements IProjectMetricRawService.GetProjectMetricRawHist
        Dim sSQLPrjCodes As String = ""

        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLHistTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)

        sSQLBuilder.Append(" AND [METRIC_RAW_CODE] = @METRICRAWCODE ")
        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@METRICRAWCODE", metricRawCode)


        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataVersion)

        GetProjectMetricRawHist = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProjectMetricRawHist(ByVal prjCode As String, ByVal dataVersion As String) As Hashtable Implements IProjectMetricRawService.GetProjectMetricRawHist

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [PRJ_CODE] = @PRJCODE ")
        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION ")


        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRJCODE", prjCode), _
                                            New SqlParameter("@DATAVERSION", dataVersion)}


        Dim dt As DataTable = New DataTable
        dt = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

        If dt Is Nothing Then
            Return Nothing
        ElseIf dt.Rows.Count = 0 Then
            Return Nothing
        End If

        Dim hsReturn As Hashtable = New Hashtable
        For Each dr As DataRow In dt.Rows
            hsReturn.Add(dr("metric_raw_code"), dr("metric_raw_val"))
        Next

        GetProjectMetricRawHist = hsReturn
        dt.Dispose()
    End Function
End Class

#End Region