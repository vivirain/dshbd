﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"
Public Class SCHEDULEJOBNAME

    Public Shared ReadOnly Property PROFILEUPDATE As String
        Get
            Return "PROFILEUPDATE"
        End Get
    End Property

    Public Shared ReadOnly Property PROFILEOVERDUE As String
        Get
            Return "PROFILEOVERDUE"
        End Get
    End Property

    Public Shared ReadOnly Property PROFILENEWSUBMITTED As String
        Get
            Return "PROFILENEWSUBMITTED"
        End Get
    End Property

    Public Shared ReadOnly Property PROFILERISK As String
        Get
            Return "PROFILERISK"
        End Get
    End Property

    Public Shared ReadOnly Property UPDPROFILEDUEDATE As String
        Get
            Return "UPDPROFILEDUEDATE"
        End Get
    End Property

End Class
#End Region


#Region "Service"

Public Interface IScheduleJobService
    Function GetEmailScheduleJob() As DataTable
    Function GetScheduleJob(ByVal jobId As Integer) As DataTable

    Function SaveScheduleJob(ByVal dtJob As DataTable) As Boolean
End Interface

Class ScheduleJobService
    Implements IScheduleJobService

    Const sTable = "[dbo].[tpma_dshbd_schedule_job]"
    Private sqlHelper As SqlHelper = New SqlHelper()

    Function GetEmailScheduleJob() As DataTable Implements IScheduleJobService.GetEmailScheduleJob
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE [IS_ACTIVE] = 'Y' AND [JOB_CATE] = 'EMAIL' "

        GetEmailScheduleJob = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Function GetScheduleJob(ByVal jobId As Integer) As DataTable Implements IScheduleJobService.GetScheduleJob
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE [IS_ACTIVE] = 'Y' AND [JOB_ID] = " & jobid

        GetScheduleJob = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function


    Function SaveScheduleJob(ByVal dtJob As DataTable) As Boolean Implements IScheduleJobService.SaveScheduleJob
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE 1 = 0"

        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQL, dtJob)}
        SaveScheduleJob = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
    End Function
End Class

#End Region
