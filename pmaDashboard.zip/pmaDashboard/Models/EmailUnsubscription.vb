﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"



#End Region


#Region "Service"

Public Interface IEmailUnsubscriptionService

    Function IsEmailUnsubscribed(ByVal emailTmp As String, ByVal email As String) As Boolean

End Interface

Class EmailUnsubscriptionService
    Implements IEmailUnsubscriptionService

    Const sTable = "[dbo].[tpma_dshbd_email_unsubscription]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 "
    Private sqlHelper As SqlHelper = New SqlHelper()

    Function getEmailUnscriped(ByVal emailTmp As String, ByVal email As String) As DataTable
        Dim sSQL As String = sSQLTable & " AND [email_tmp_name] = @TMPNAME AND [pma_email] = @EMAIL "
        Dim sqlParams As SqlParameter() = {New SqlParameter("@TMPNAME", emailTmp), New SqlParameter("@EMAIL", email)}

        getEmailUnscriped = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

    End Function


    Function IsEmailUnsubscribed(ByVal emailTmp As String, ByVal email As String) As Boolean Implements IEmailUnsubscriptionService.IsEmailUnsubscribed
        Dim bUnscribed As Boolean = False
        Dim dt As DataTable = getEmailUnscriped(emailTmp, email)
        If Not dt Is Nothing AndAlso dt.Rows.Count > 0 Then
            Dim sUnscribed As String = dt.Rows(0).Item("email_unsubscribed").ToString.ToUpper.Trim

            If Not String.IsNullOrEmpty(sUnscribed) AndAlso sUnscribed = "Y" Then
                bUnscribed = True
            End If

            dt.Dispose()
        End If

        IsEmailUnsubscribed = bUnscribed
    End Function
   
End Class

#End Region

