﻿Imports System.Data
Imports System.Data.SqlClient


#Region "Model"

Public Class ProfileModel
    Property prfId As Integer
    Property prfMainCode As String
    Property prfDesc As String
    Property prfDescDetail As String
    Property prfDescChinese As String

    Property prjCodes As String
    Property prjMasterCode As String

    Property fixedPricePrj As String
    Property tssPrj As String
    Property buCode As String

    Property prfLeaderId As String
    Property prfLeaderIdCardNo As String

    Property prfCurrency As String

    Property estimatedStartDate As Date
    Property estimatedEndDate As Date
    Property actualStartDate As Date
    Property actualEndDate As Date

    Property estimatedTotalHours As Decimal
    Property actualTotalHours As Decimal
    Property estimatedPrjTotalHours As Decimal
    Property actualPrjTotalHours As Decimal

    Property estimatedTotalCost As Decimal
    Property actualTotalCost As Decimal
    Property actualTotalCostBilled As Decimal

    Property status As String
    Property healthStatus As ProfileHealthStatusModel
    'Property healthStatus As String
    'Property qualityStatus As String
    'Property scheduleStatus As String
    'Property scopeStatus As String
    'Property resourceStatus As String
    'Property costStatus As String
    'Property cssStatus As String

    Property prjStage As String
    Property prjStatusRemark As String

    Property dataVersion As String

    Property createdBy As String
    Property createdDate As Date

    Property lastUpdatedBy As String
    Property lastUpdatedDt As Date

    Public Sub New()

    End Sub
End Class

Public Class ProfileHealthStatusModel
    Property healthStatus As String
    Property scopeStatus As String
    Property scheduleStatus As String
    Property resourceStatus As String
    Property qualityStatus As String
    Property costStatus As String
    Property cssStatus As String

    Public Sub New()
    End Sub
End Class

Public Enum PROFILEMODE
    READ = 0
    EDIT = -1
    ADD = 1
End Enum


Public Class PROFILESTATUS

    Public Shared ReadOnly Property DRAFT As String
        Get
            Return "D"
        End Get
    End Property

    Public Shared ReadOnly Property SUBMITTED As String
        Get
            Return "S"
        End Get
    End Property

    Public Shared ReadOnly Property CLOSED As String
        Get
            Return "C"
        End Get
    End Property

    Public Shared ReadOnly Property VOID As String
        Get
            Return "V"
        End Get
    End Property

    Public Shared ReadOnly Property OBSOLETED As String
        Get
            Return "O"
        End Get
    End Property

    Public Shared ReadOnly Property TEMP As String
        Get
            Return "T"
        End Get
    End Property
End Class
#End Region




#Region "Service"

Public Interface IProfileService

    Function GetProfileList(Optional emptyData As Boolean = False) As DataTable
    Function GetProfile(ByVal prfId As Integer) As DataTable
    Function GetProfileLatestSubmit(ByVal prfId As Integer) As DataTable
    Function CreateProfile(ByVal dtPrfSave As DataTable, ByRef prfId As Integer) As Boolean
    Sub GetMyTeamProfiles(ByRef sPrfList As StringBuilder, ByVal steamCodes As String, ByVal dataVersion As String)
    Function GetNeverSubmittedProfileList(ByVal sFilter As String) As DataTable

    Function GetDraftProfiles() As DataTable

    Function GetProfileView(ByVal prfId As Integer) As DataTable
    Function GetDraftProfileViewWithPrjCode(ByVal prjCode As String) As DataTable
    Function GetProfileViewList(ByVal viewMode As String, Optional ByVal sFilter As String = "") As DataTable

    Function GetProfileHistList(ByVal dataVersion As String, Optional ByVal beforeDataVersion As Boolean = False) As DataTable
    Function GetProfileHist(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable
    Function GetProfileHistLatest(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable
    Function GetProfileHistLast(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable
    Sub GetMyTeamProfilesHist(ByRef sPrfList As StringBuilder, ByVal steamCodes As String, ByVal dataVersion As String)

    Function GetProfileHistView(ByVal prjCode As String, ByVal prfStatus As String) As DataTable
    Function GetProfileHistView(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable
    Function GetProfileHistViewList(ByVal viewMode As String, ByVal sFilter As String) As DataTable
    Function GetProfileHistViewLatest(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable


    'Common
    Sub GetMyProfilePMs(ByRef sPMList As StringBuilder, ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String, ByVal teamCode As Integer, ByVal dataVersion As String, ByVal viewMode As String)
    Function SaveProfile(ByVal viewMode As String, ByVal dtPrfSave As DataTable) As Boolean
    Function SubmitProfile(ByVal dtPrfSubmit As DataTable, ByVal dtPrjMetrics As DataTable, ByVal dtPrjMetricRaws As DataTable) As Boolean
    Function DeleteProfileHist(ByVal dtPrfHistDel As DataTable, ByVal dtPrfDel As DataTable) As Boolean

    Function SaveProjectMetric(ByVal dtPrjMetricRaw As DataTable, ByVal dtPrjMetric As DataTable, Optional ByVal dtPrfSave As DataTable = Nothing) As Boolean
    Function SaveProjectMetricRaw(ByVal dtPrjMetricRaw As DataTable) As Boolean

    Function ExportProfile(ByVal prfIds As String, ByVal gvProfile As GridView) As Boolean
    Function ObsoleteProfileHist(ByVal dtPrfDel As DataTable, Optional ByVal dtPrjMetricDel As DataTable = Nothing, Optional ByVal dtPrjMetricRawDel As DataTable = Nothing) As Boolean

    Function HasNewDraftVersion(ByVal prfId As Integer, ByVal dataVersion As String) As Boolean
    Function HasNewerVersion(ByVal prfId As Integer, ByVal dataVersion As String) As Boolean
    Function HasHealthStatus(ByVal prfId As Integer) As Boolean
    Function GetProfileLastSubmittedDate(ByVal profielId As Integer) As String
    Function GetProfileProgressUpdateReminder(ByVal jobId As Integer) As DataTable
    Function GetProfileNewSubmitted() As DataTable

    Sub CopyHistDataToDraft(ByRef drPrfHist As DataRow, ByRef drPrf As DataRow)


End Interface


Class ProfileService
    Implements IProfileService

#Region "Variables"
    Const sTable As String = "[dbo].[tpma_dshbd_profile]"
    Const sHistTable As String = "[dbo].[tpma_dshbd_profile_hist]"
    Const sView As String = "[dbo].[vpma_dshbd_profile]"
    Const sHistView As String = "[dbo].[vpma_dshbd_profile_hist]"

    Const sMetricRawTable As String = "[dbo].[tpma_dshbd_prj_metric_raw]"
    Const sMetricTable As String = "[dbo].[tpma_dshbd_prj_metric]"
    Const sMetricRawHistTable As String = "[dbo].[tpma_dshbd_prj_metric_raw_hist]"
    Const sMetricHistTable As String = "[dbo].[tpma_dshbd_prj_metric_hist]"

    Dim sSQLTable As String = "SELECT * FROM " & sTable
    Dim sSQLView As String = "SELECT * FROM " & sView
    Dim sSQLHistTable As String = "SELECT * FROM " & sHistTable
    Dim sSQLHistView As String = "SELECT * FROM " & sHistView

    Private sqlHelper As SqlHelper = New SqlHelper()
    Dim sSQLBuilder As StringBuilder
#End Region


    Public Function GetProfileList(Optional emptyData As Boolean = False) As System.Data.DataTable Implements IProfileService.GetProfileList
        sSQLBuilder = New StringBuilder(sSQLTable)
        If emptyData Then
            sSQLBuilder.Append(" WHERE 1 = 0")
        End If

        GetProfileList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

    End Function

    Function GetProfile(ByVal prfId As Integer) As DataTable Implements IProfileService.GetProfile
        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE [PRF_ID]=@PRFID")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId)}

        GetProfile = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProfileLatestSubmit(ByVal prfId As Integer) As DataTable Implements IProfileService.GetProfileLatestSubmit
        sSQLBuilder = New StringBuilder("SELECT TOP 1 * FROM " & sHistTable)
        sSQLBuilder.Append(" WHERE [PRF_ID]=@PRFID ")
        sSQLBuilder.Append(" ORDER BY [DATA_VERSION] desc ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId)}

        GetProfileLatestSubmit = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function CreateProfile(ByVal dtPrfInsert As DataTable, ByRef prfId As Integer) As Boolean Implements IProfileService.CreateProfile
        Dim bCreate As Boolean = False

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 0 ")

        If Not dtPrfInsert Is Nothing Then
            bCreate = sqlHelper.ExecuteAdapterInsert(sSQLBuilder.ToString, dtPrfInsert, prfId)
        End If

        CreateProfile = bCreate
    End Function

    Function SubmitProfile(ByVal dtPrfSubmit As DataTable, ByVal dtPrjMetrics As DataTable, ByVal dtPrjMetricRaws As DataTable) As Boolean Implements IProfileService.SubmitProfile
        Dim bSave As Boolean = False
        Dim sqlAdaUpd As SqlAdapterUpdate() = {}
        Dim iUpperBound As Integer = 0

        Dim sSQLMetricRaw As String = "SELECT * FROM " & sMetricRawTable & " WHERE 1 = 0 "
        Dim sSQLMetric As String = "SELECT * FROM " & sMetricTable & " WHERE 1 = 0 "
        Dim sSQLPrf As String = "SELECT * FROM " & sTable & " WHERE 1 = 0 "
        Dim sSQLMetricRawHist As String = "SELECT * FROM " & sMetricRawHistTable & " WHERE 1 = 0 "
        Dim sSQLMetricHist As String = "SELECT * FROM " & sMetricHistTable & " WHERE 1 = 0 "
        Dim sSQLPrfHist As String = "SELECT * FROM " & sHistTable & " WHERE 1 = 0 "

        Dim profileId As Integer = 0
        Dim dataVersion As String = ""
        Dim prfMasterCode As String = ""
        Dim prjCodes As String = ""
        Dim bNewSubmittedPrf As Boolean = False

        Try
            'Profile
            If Not dtPrfSubmit Is Nothing Then
                If dtPrfSubmit.Rows.Count > 0 Then
                    profileId = dtPrfSubmit.Rows(0).Item("prf_id")
                    dataVersion = dtPrfSubmit.Rows(0).Item("data_version")
                    prfMasterCode = dtPrfSubmit.Rows(0).Item("prf_main_code")
                    prjCodes = dtPrfSubmit.Rows(0).Item("prj_codes")

                    iUpperBound = IIf(sqlAdaUpd.Length <= 0, 0, sqlAdaUpd.Length)
                    ReDim Preserve sqlAdaUpd(iUpperBound)
                    sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLPrf, dtPrfSubmit)
                End If
            End If

            'Profile Hist
            If String.IsNullOrEmpty(GetProfileLastSubmittedDate(profileId)) Then
                bNewSubmittedPrf = True
            End If

            Dim dtPrfHist As DataTable = GetProfileHist(profileId, dataVersion)
            If Not dtPrfHist Is Nothing Then
                Dim drPrfHist As DataRow = dtPrfHist.NewRow
                If dtPrfHist.Rows.Count = 0 Then

                    drPrfHist.ItemArray = dtPrfSubmit.Rows(0).ItemArray
                    dtPrfHist.Rows.Add(drPrfHist)
                Else
                    drPrfHist = dtPrfHist.Rows(0)
                    drPrfHist.ItemArray = dtPrfSubmit.Rows(0).ItemArray
                End If

                iUpperBound = IIf(sqlAdaUpd.Length <= 0, 0, sqlAdaUpd.Length)
                ReDim Preserve sqlAdaUpd(iUpperBound)
                sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLPrfHist, dtPrfHist)
            End If

            'Profile Metric
            If Not dtPrjMetrics Is Nothing Then
                iUpperBound = IIf(sqlAdaUpd.Length <= 0, 0, sqlAdaUpd.Length)
                ReDim Preserve sqlAdaUpd(iUpperBound)
                sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLMetric, dtPrjMetrics)
            End If

            'Profile Metric Hist
            Dim prjMetricService As IProjectMetricService = New ProjectMetricService
            Dim dtPrjMetricsHist As DataTable = prjMetricService.GetProjectMetricHist(prjCodes.Split(","), dataVersion)
            Dim dtPrjMetricHistPk As DataColumn() = {dtPrjMetricsHist.Columns("id"), dtPrjMetricsHist.Columns("data_version")}
            dtPrjMetricsHist.PrimaryKey = dtPrjMetricHistPk

            For Each drPrjMetric As DataRow In dtPrjMetrics.Rows
                Dim dtPrjMetricHist As DataTable = prjMetricService.GetProjectMetricHist({drPrjMetric("prj_code")}, drPrjMetric("metric_code"), dataVersion)
                If Not dtPrjMetricHist Is Nothing Then
                    Dim drPrjMetricHist As DataRow
                    If dtPrjMetricHist.Rows.Count = 0 Then 'Not exist, add it
                        drPrjMetricHist = dtPrjMetricsHist.NewRow()
                        drPrjMetricHist.ItemArray = drPrjMetric.ItemArray
                        dtPrjMetricsHist.Rows.Add(drPrjMetricHist)
                    Else
                        Dim prjMetricHistId As Integer = dtPrjMetricHist.Rows(0).Item("id")
                        drPrjMetricHist = dtPrjMetricsHist.Rows.Find({prjMetricHistId, dataVersion})
                        drPrjMetricHist.ItemArray = drPrjMetric.ItemArray
                    End If
                End If
            Next

            If Not dtPrjMetricsHist Is Nothing Then
                iUpperBound = IIf(sqlAdaUpd.Length <= 0, 0, sqlAdaUpd.Length)
                ReDim Preserve sqlAdaUpd(iUpperBound)
                sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLMetricHist, dtPrjMetricsHist)
            End If

            'Profile Metric Raw
            If Not dtPrjMetricRaws Is Nothing Then
                iUpperBound = IIf(sqlAdaUpd.Length <= 0, 0, sqlAdaUpd.Length)
                ReDim Preserve sqlAdaUpd(iUpperBound)
                sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLMetricRaw, dtPrjMetricRaws)
            End If

            'Profile Metric Raw Hist
            Dim prjMetricRawService As IProjectMetricRawService = New ProjectMetricRawService
            Dim dtPrjMetricRawsHist As DataTable = prjMetricRawService.GetProjectMetricRawHist(prjCodes.Split(","), dataVersion)
            Dim dtPrjMetricRawHistPk As DataColumn() = {dtPrjMetricRawsHist.Columns("id"), dtPrjMetricRawsHist.Columns("data_version")}
            dtPrjMetricRawsHist.PrimaryKey = dtPrjMetricRawHistPk

            For Each drPrjMetricRaw As DataRow In dtPrjMetricRaws.Rows
                Dim dtPrjMetricRawHist As DataTable = prjMetricRawService.GetProjectMetricRawHist({drPrjMetricRaw("prj_code")}, drPrjMetricRaw("metric_raw_code"), dataVersion)

                If Not dtPrjMetricRawHist Is Nothing Then
                    Dim drPrjMetricRawHist As DataRow

                    If dtPrjMetricRawHist.Rows.Count = 0 Then 'add it
                        drPrjMetricRawHist = dtPrjMetricRawsHist.NewRow
                        drPrjMetricRawHist.ItemArray = drPrjMetricRaw.ItemArray
                        dtPrjMetricRawsHist.Rows.Add(drPrjMetricRawHist)
                    Else
                        Dim prjMetricRawHistId As Integer = dtPrjMetricRawHist.Rows(0).Item("id")
                        drPrjMetricRawHist = dtPrjMetricRawsHist.Rows.Find({prjMetricRawHistId, dataVersion})
                        drPrjMetricRawHist.ItemArray = drPrjMetricRaw.ItemArray
                    End If
                End If
            Next

            If Not dtPrjMetricRawsHist Is Nothing Then
                iUpperBound = IIf(sqlAdaUpd.Length <= 0, 0, sqlAdaUpd.Length)
                ReDim Preserve sqlAdaUpd(iUpperBound)
                sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLMetricRawHist, dtPrjMetricRawsHist)
            End If


            If Not sqlAdaUpd Is Nothing Then
                bSave = sqlHelper.ExecuteAdapterUpdate(sqlAdaUpd)
            End If

            If bSave Then
                LogHelper.WriteLog("Successfully to submit profile " & profileId)

            Else
                LogHelper.WriteLog("Failed to submit profile " & profileId)
            End If

        Catch ex As Exception
            LogHelper.WriteLog("Failed to submit profile " & profileId, ex)
        End Try

        SubmitProfile = bSave
    End Function

    Function GetDraftProfiles() As DataTable Implements IProfileService.GetDraftProfiles
        sSQLBuilder = New StringBuilder(sSQLView)

        sSQLBuilder.Append(" WHERE [STATUS]=@PRFSTA ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFSTA", PROFILESTATUS.DRAFT)}

        sSQLBuilder.Append(" ORDER BY [FUNC_CODE], [SBU_CODE], [TEAM_CODE] ")

        GetDraftProfiles = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProfileHistList(ByVal dataVersion As String, Optional ByVal beforeDataVersion As Boolean = False) As DataTable Implements IProfileService.GetProfileHistList
        sSQLBuilder = New StringBuilder(sSQLHistTable & " WHERE 1 = 1 ")

        If beforeDataVersion Then
            sSQLBuilder.Append(" AND [DATA_VERSION] <= @DATAVERSION")
        Else
            sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION")
        End If

        Dim sqlParams As SqlParameter() = {New SqlParameter("@DATAVERSION", dataVersion)}

        GetProfileHistList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProfileHist(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable Implements IProfileService.GetProfileHist
        sSQLBuilder = New StringBuilder(sSQLHistTable)
        sSQLBuilder.Append(" WHERE [PRF_ID]=@PRFID ")
        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId), _
                                           New SqlParameter("@DATAVERSION", dataVersion)}

        GetProfileHist = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProfileHistLatest(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable Implements IProfileService.GetProfileHistLatest

        sSQLBuilder = New StringBuilder(sSQLHistTable & " a ")
        sSQLBuilder.Append(" WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND [PRF_ID]=@PRFID ")
        sSQLBuilder.Append(" AND [STATUS] = @PRFSTA")

        sSQLBuilder.Append(" AND EXISTS ( SELECT 1 ")
        sSQLBuilder.Append(" FROM (SELECT [prf_id], max(data_version) as data_version FROM " & sHistTable & " WHERE data_version <= @DATAVERSION GROUP BY prf_id ) b ")
        sSQLBuilder.Append(" WHERE b.prf_id = a.prf_id and b.data_version = a.data_version ) ")

        Dim sqlParams As SqlParameter() = Nothing

        Try
            sqlParams = {New SqlParameter("@PRFID", prfId), _
                         New SqlParameter("@PRFSTA", PROFILESTATUS.SUBMITTED), _
                         New SqlParameter("@DATAVERSION", dataVersion)}

            GetProfileHistLatest = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
        Catch ex As Exception
            'LogHelper.logError("Failed to execute query.", ex)
            Throw ex
        End Try

    End Function



    Function GetProfileHistLast(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable Implements IProfileService.GetProfileHistLast

        sSQLBuilder = New StringBuilder(sSQLHistTable)

        sSQLBuilder.Append(" WHERE [PRF_ID]=@PRFID ")
        sSQLBuilder.Append(" AND [STATUS]=@PRFSTA ")

        sSQLBuilder.Append(" AND [DATA_VERSION] = (")
        sSQLBuilder.Append(" SELECT MAX([DATA_VERSION]) FROM " & sHistTable & " WHERE [DATA_VERSION] < @DATAVERSION AND [PRF_ID] = @PRFID ")
        sSQLBuilder.Append(" )")


        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId), _
                                           New SqlParameter("@PRFSTA", PROFILESTATUS.SUBMITTED), _
                                           New SqlParameter("@DATAVERSION", dataVersion)}

        GetProfileHistLast = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

    End Function

    Function DeleteProfileHist(ByVal dtPrfHistDel As DataTable, ByVal dtPrfDel As DataTable) As Boolean Implements IProfileService.DeleteProfileHist
        Dim bDelete As Boolean = False

        If dtPrfHistDel Is Nothing And dtPrfDel Is Nothing Then
            Return False
        End If

        Dim sSQLBuilderHist As StringBuilder = New StringBuilder(sSQLHistTable & " WHERE 1 = 0 ")
        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLTable & "WHERE 1 = 0 ")


        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQLBuilderHist.ToString, dtPrfHistDel), _
                                                   New SqlAdapterUpdate(sSQLBuilder.ToString, dtPrfDel)}
        bDelete = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)

        DeleteProfileHist = bDelete
    End Function

    Function DeleteProfile(ByVal dtPrfDel As DataTable) As Boolean
        Dim bDelete As Boolean = False
        Dim dtPrjMetricRawDel As DataTable = Nothing
        Dim dtPrjMetricDel As DataTable = Nothing
        Dim dtPrjIssueDel As DataTable = Nothing
        Dim dtPrjScheduleDel As DataTable = Nothing

        If dtPrfDel Is Nothing Then
            Return bDelete
        End If

        For Each drPrfDel As DataRow In dtPrfDel.Rows
            '
            If drPrfDel.RowState = DataRowState.Deleted And String.IsNullOrEmpty(drPrfDel("data_version").ToString.Trim) Then
                Dim prfIdDel As Integer = drPrfDel("prf_id")
                Dim prfMainCodeDel As String = drPrfDel("prf_main_code")
                Dim prfPrjCodesDel As String = drPrfDel("prj_codes")

                'Delete Issue
                Dim prfIssueService As IProfileIssueService = New ProfileIssueService
                Dim dtPrjIssue As DataTable = prfIssueService.GetProfileIssueList(prfIdDel)

                'Delete Schedule
                Dim prfScheduleService As IProfileScheduleService = New ProfileScheduleService
                dtPrjScheduleDel = prfScheduleService.GetProfileScheduleList(prfIdDel)

                'Delete Metric
                Dim prjMetricService As IProjectMetricService = New ProjectMetricService
                dtPrjMetricDel = prjMetricService.GetProjectMetric(prfPrjCodesDel.Split(","))

                'Delete Metric Raw
                Dim prjMetricRawService As IProjectMetricRawService = New ProjectMetricRawService
                dtPrjMetricRawDel = prjMetricRawService.GetProjectMetricRawList(prfPrjCodesDel.Split(","))

            End If
        Next

        'Dim 
        Dim sSQLBuilderPrfHist As StringBuilder = New StringBuilder(sSQLHistTable & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrf As StringBuilder = New StringBuilder(sSQLTable & "WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetricRawHist As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_metric_raw_hist]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetricRaw As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_metric_raw]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetricHist As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_metric_hist]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetric As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_metric]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjIssue As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_issue]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjSchedule As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_schedule]" & " WHERE 1 = 0 ")



        Return bDelete
    End Function

    Function DeleteProfileHist(ByVal prfIds As String) As Boolean
        Dim bDelete As Boolean = False

        If String.IsNullOrEmpty(prfIds) Then
            Return bDelete
        End If

        'Dim 
        Dim sSQLBuilderPrfHist As StringBuilder = New StringBuilder(sSQLHistTable & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrf As StringBuilder = New StringBuilder(sSQLTable & "WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetricRawHist As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_metric_raw_hist]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetricRaw As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_metric_raw]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetricHist As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_metric_hist]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetric As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_metric]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjIssue As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_issue]" & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjSchedule As StringBuilder = New StringBuilder("SELECT 1 FROM [dbo].[tpma_dshbd_prj_schedule]" & " WHERE 1 = 0 ")


        Dim prfIdList As String() = prfIds.Split(",")
        If prfIdList Is Nothing Then
            Return bDelete
        ElseIf prfIdList.Length > 0 Then
            Return bDelete
        End If

        Dim dtProfileDel As DataTable = GetProfileList()
        Dim dtProfileDelPk As DataColumn() = {dtProfileDel.Columns("prf_id")}
        dtProfileDel.PrimaryKey = dtProfileDelPk


        For Each prfId As String In prfIdList
            Dim drPrfDel As DataRow = dtProfileDel.Rows.Find(prfId)
            If drPrfDel Is Nothing Then
                Continue For
            End If
            drPrfDel.Delete()

        Next
        Return bDelete
    End Function


    Function SaveProfile(ByVal viewMode As String, ByVal dtPrfSave As DataTable) As Boolean Implements IProfileService.SaveProfile
        Dim bSave As Boolean = False


        If viewMode = PROFILESTATUS.DRAFT Then
            sSQLBuilder = New StringBuilder(sSQLTable)
        ElseIf viewMode = PROFILESTATUS.SUBMITTED Then
            sSQLBuilder = New StringBuilder(sSQLHistTable)
        End If

        sSQLBuilder.Append(" WHERE 1 = 0 ")

        If Not dtPrfSave Is Nothing Then
            Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQLBuilder.ToString, dtPrfSave)}
            bSave = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
        End If

        SaveProfile = bSave
    End Function

    Function GetProfileView(ByVal prfId As Integer) As DataTable Implements IProfileService.GetProfileView
        sSQLBuilder = New StringBuilder(sSQLView)
        sSQLBuilder.Append(" WHERE [PRF_ID]=@PRFID ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId)}

        GetProfileView = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProfileViewList(ByVal viewMode As String, Optional ByVal sFilter As String = "") As DataTable Implements IProfileService.GetProfileViewList
        If String.IsNullOrEmpty(viewMode) Then
            sSQLBuilder = New StringBuilder(sSQLView & " a ")
        ElseIf viewMode = PROFILESTATUS.SUBMITTED Then
            sSQLBuilder = New StringBuilder(sSQLHistView & " a ")
        ElseIf viewMode = PROFILESTATUS.DRAFT Then
            sSQLBuilder = New StringBuilder(sSQLView & " a ")
        End If

        sSQLBuilder.Append(" WHERE 1 = 1 ")

        If viewMode = PROFILESTATUS.SUBMITTED Then
            sSQLBuilder.Append(" AND EXISTS ( SELECT 1 ")
            sSQLBuilder.Append(" FROM (SELECT [prf_id], max(data_version) as data_version FROM " & sHistView & " GROUP BY prf_id ) b ")
            sSQLBuilder.Append(" WHERE b.prf_id = a.prf_id and b.data_version = a.data_version ) ")
        End If

        If Not String.IsNullOrEmpty(sFilter) Then
            sSQLBuilder.Append(sFilter)
        End If

        GetProfileViewList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
    End Function

    Function GetDraftProfileViewWithPrjCode(ByVal prjCode As String) As DataTable Implements IProfileService.GetDraftProfileViewWithPrjCode
        sSQLBuilder = New StringBuilder(sSQLView & " a ")
        sSQLBuilder.Append(" WHERE [prj_codes] like '%" & prjCode & "%' ")
        sSQLBuilder.Append(" AND NOT EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM " & sHistTable & " WHERE PRF_ID = a.PRF_ID ")
        sSQLBuilder.Append(" ) ")
        sSQLBuilder.Append(" AND STATUS = 'D' ")

        GetDraftProfileViewWithPrjCode = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
    End Function

    Function GetProfileHistViewLatest(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable Implements IProfileService.GetProfileHistViewLatest

        sSQLBuilder = New StringBuilder(sSQLHistView & " a ")
        sSQLBuilder.Append(" WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND [PRF_ID]=@PRFID ")
        sSQLBuilder.Append(" AND [STATUS] = @PRFSTA")

        sSQLBuilder.Append(" AND EXISTS ( SELECT 1 ")
        sSQLBuilder.Append(" FROM (SELECT [prf_id], max(data_version) as data_version FROM " & sHistTable & " WHERE data_version <= @DATAVERSION GROUP BY prf_id ) b ")
        sSQLBuilder.Append(" WHERE b.prf_id = a.prf_id and b.data_version = a.data_version ) ")

        Dim sqlParams As SqlParameter() = Nothing

        Try
            sqlParams = {New SqlParameter("@PRFID", prfId), _
                         New SqlParameter("@PRFSTA", PROFILESTATUS.SUBMITTED), _
                         New SqlParameter("@DATAVERSION", dataVersion)}

            GetProfileHistViewLatest = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
        Catch ex As Exception
            Throw ex
        End Try

    End Function


    Function GetProfileHistViewList(ByVal dataVersion As String, ByVal sFilter As String) As DataTable Implements IProfileService.GetProfileHistViewList

        sSQLBuilder = New StringBuilder(sSQLHistView & " a ")

        sSQLBuilder.Append(" WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND EXISTS ( SELECT 1 ")
        sSQLBuilder.Append(" FROM (SELECT [prf_id], max(data_version) as data_version FROM " & sHistView)
        If dataVersion <> Format(Now, "yyyyMMdd") Then
            sSQLBuilder.Append("  WHERE data_version <= '" & dataVersion & "' ")
        End If
        sSQLBuilder.Append(" GROUP BY prf_id ) b ")
        sSQLBuilder.Append(" WHERE b.prf_id = a.prf_id and b.data_version = a.data_version ) ")

        If Not String.IsNullOrEmpty(sFilter) Then
            sSQLBuilder.Append(sFilter)
        End If

        GetProfileHistViewList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
    End Function

    Function GetProfileHistView(ByVal prfId As Integer, ByVal dataVersion As String) As DataTable Implements IProfileService.GetProfileHistView
        sSQLBuilder = New StringBuilder(sSQLHistView)
        sSQLBuilder.Append(" WHERE [PRF_ID]=@PRFID ")
        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId), _
                                           New SqlParameter("@DATAVERSION", dataVersion)}

        GetProfileHistView = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProfileHistView(ByVal prjCode As String, ByVal prfStatus As String) As DataTable Implements IProfileService.GetProfileHistView
        sSQLBuilder = New StringBuilder(sSQLHistView & " a ")
        sSQLBuilder.Append(" WHERE [prj_codes] like '%" & prjCode & "%'")
        sSQLBuilder.Append(" AND [status] = '" & prfStatus & "' ")

        GetProfileHistView = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

    End Function


    Function SaveProjectMetric(ByVal dtPrjMetricRaw As DataTable, ByVal dtPrjMetric As DataTable, Optional ByVal dtPrfSave As DataTable = Nothing) As Boolean Implements IProfileService.SaveProjectMetric
        Dim bSave As Boolean = False
        Dim sqlAdaUpd As SqlAdapterUpdate() = {}
        Dim iUpperBound As Integer = 0

        Dim sSQLMetricRaw As String = "SELECT * FROM " & sMetricRawTable & " WHERE 1 = 0 "
        Dim sSQLMetric As String = "SELECT * FROM " & sMetricTable & " WHERE 1 = 0 "
        Dim sSQLPrf As String = "SELECT * FROM " & sTable & " WHERE 1 = 0 "

        If Not dtPrjMetricRaw Is Nothing Then
            ReDim Preserve sqlAdaUpd(iUpperBound)
            sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLMetricRaw, dtPrjMetricRaw)
        End If

        If Not dtPrjMetric Is Nothing Then
            iUpperBound = IIf(sqlAdaUpd.Length <= 0, 0, sqlAdaUpd.Length)
            ReDim Preserve sqlAdaUpd(iUpperBound)
            sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLMetric, dtPrjMetric)
        End If

        If Not dtPrfSave Is Nothing Then
            iUpperBound = IIf(sqlAdaUpd.Length <= 0, 0, sqlAdaUpd.Length)
            ReDim Preserve sqlAdaUpd(iUpperBound)
            sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLPrf, dtPrfSave)
        End If

        If Not sqlAdaUpd Is Nothing Then
            If sqlAdaUpd.Length > 0 Then
                bSave = sqlHelper.ExecuteAdapterUpdate(sqlAdaUpd)
            End If
        End If

        SaveProjectMetric = bSave
    End Function

    Function SaveProjectMetricRaw(ByVal dtPrjMetricRaw As DataTable) As Boolean Implements IProfileService.SaveProjectMetricRaw
        Dim bSave As Boolean = False
        Dim sqlAdaUpd As SqlAdapterUpdate() = {}
        Dim iUpperBound As Integer = 0

        Dim sSQLMetricRaw As String = "SELECT * FROM " & sMetricRawTable & " WHERE 1 = 0 "

        If Not dtPrjMetricRaw Is Nothing Then
            ReDim Preserve sqlAdaUpd(iUpperBound)
            sqlAdaUpd(iUpperBound) = New SqlAdapterUpdate(sSQLMetricRaw, dtPrjMetricRaw)
        End If

        If Not sqlAdaUpd Is Nothing Then
            If sqlAdaUpd.Length > 0 Then
                bSave = sqlHelper.ExecuteAdapterUpdate(sqlAdaUpd)
            End If
        End If

        SaveProjectMetricRaw = bSave
    End Function


    Private Sub sendEmail(ByVal emailTemplate As String, ByVal prfId As Integer)
        Dim emailHelper As EmailHelper = New EmailHelper
        Dim emailTo As String() = Nothing
        Dim emailSubject As String = ""
        Dim emailBody As String = ""

        Dim pmaEmailTemplateService As IPmaEmailTemplateService = New PmaEmailTemplateService
        Dim dtEmailTemplate As DataTable = pmaEmailTemplateService.getEmailTemplate(emailTemplate)

        If dtEmailTemplate Is Nothing Then
            LogHelper.WriteLog("Email Template [" & emailTemplate & "] is not found.")
            Return
        ElseIf dtEmailTemplate.Rows.Count = 0 Then
            LogHelper.WriteLog("Email Template [" & emailTemplate & "] is not found.")
            Return
        End If

        If IsDBNull(dtEmailTemplate.Rows(0).Item("email_to")) Then
            LogHelper.WriteLog("Email to list is not set for [" & emailTemplate & "].")
            Return
        Else
            emailTo = dtEmailTemplate.Rows(0).Item("email_to").ToString.Split(",")
        End If

        If Not IsDBNull(dtEmailTemplate.Rows(0).Item("email_content")) Then
            emailBody = dtEmailTemplate.Rows(0).Item("email_content").ToString.Trim
            UpdateEmailBody(emailBody, prfId)
        End If

        If Not IsDBNull(dtEmailTemplate.Rows(0).Item("email_subject")) Then
            emailSubject = dtEmailTemplate.Rows(0).Item("email_subject").ToString.Trim
        End If

        If Not emailTo Is Nothing Then
            emailHelper.SendInstantEmail(emailSubject, emailBody, emailTo, Nothing)
        End If

    End Sub

    Sub UpdateEmailBody(ByRef emailBody As String, ByVal prfId As Integer)
        Dim dtPrf As DataTable = GetProfile(prfId)

        If Not dtPrf Is Nothing Then
            If dtPrf.Rows.Count > 0 Then
                Dim url As String = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & HttpContext.Current.Request.ApplicationPath
                emailBody = emailBody.Replace("{0}", url)
                emailBody = emailBody.Replace("{1}", DataFormatHelper.StringTrim(dtPrf.Rows(0).Item("prf_desc").ToString))
                emailBody = emailBody.Replace("{2}", Lookup.RAGColor(dtPrf.Rows(0).Item("health_status").ToString))
                emailBody = emailBody.Replace("{3}", Lookup.RAGColor(dtPrf.Rows(0).Item("quality_status").ToString))
                emailBody = emailBody.Replace("{4}", Lookup.RAGColor(dtPrf.Rows(0).Item("scope_status").ToString))
                emailBody = emailBody.Replace("{5}", Lookup.RAGColor(dtPrf.Rows(0).Item("cost_status").ToString))
                emailBody = emailBody.Replace("{6}", Lookup.RAGColor(dtPrf.Rows(0).Item("schedule_status").ToString))
                emailBody = emailBody.Replace("{7}", Lookup.RAGColor(dtPrf.Rows(0).Item("resource_status").ToString))
                emailBody = emailBody.Replace("{8}", Lookup.RAGColor(dtPrf.Rows(0).Item("css_status").ToString))

            End If

        End If
    End Sub

    Function ExportProfile(ByVal prfIds As String, ByVal gvProfile As GridView) As Boolean Implements IProfileService.ExportProfile
        Dim bReturn As Boolean = False

        If prfIds.Length > 0 Then
        Else
            'Export All to excel
        End If

        ExportProfile = bReturn
    End Function


    Function ObsoleteProfileHist(ByVal dtPrfDel As DataTable, Optional ByVal dtPrjMetricDel As DataTable = Nothing, Optional ByVal dtPrjMetricRawDel As DataTable = Nothing) As Boolean Implements IProfileService.ObsoleteProfileHist
        Dim bSave As Boolean = False

        Dim sSQLBuilderPrf = New StringBuilder(sSQLHistTable & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetric = New StringBuilder("SELECT * FROM " & sMetricHistTable & " WHERE 1 = 0 ")
        Dim sSQLBuilderPrjMetricRaw = New StringBuilder("SELECT * FROM " & sMetricRawHistTable & " WHERE 1 = 0 ")

        Dim sqlAdapterUpd As SqlAdapterUpdate() = {}
        Dim iUpperBound As Integer = 0

        If Not dtPrfDel Is Nothing Then
            iUpperBound = IIf(sqlAdapterUpd.Length <= 0, 0, sqlAdapterUpd.Length)
            ReDim Preserve sqlAdapterUpd(iUpperBound)
            sqlAdapterUpd(iUpperBound) = New SqlAdapterUpdate(sSQLBuilder.ToString, dtPrfDel)
        End If

        If Not dtPrjMetricDel Is Nothing Then
            iUpperBound = IIf(sqlAdapterUpd.Length <= 0, 0, sqlAdapterUpd.Length)
            ReDim Preserve sqlAdapterUpd(iUpperBound)
            sqlAdapterUpd(iUpperBound) = New SqlAdapterUpdate(sSQLBuilderPrjMetric.ToString, dtPrjMetricDel)
        End If

        If Not dtPrjMetricRawDel Is Nothing Then
            iUpperBound = IIf(sqlAdapterUpd.Length <= 0, 0, sqlAdapterUpd.Length)
            ReDim Preserve sqlAdapterUpd(iUpperBound)
            sqlAdapterUpd(iUpperBound) = New SqlAdapterUpdate(sSQLBuilderPrjMetricRaw.ToString, dtPrjMetricRawDel)
        End If

        If Not dtPrfDel Is Nothing Or Not dtPrjMetricDel Is Nothing Or Not dtPrjMetricRawDel Is Nothing Then
            bSave = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
        End If

        ObsoleteProfileHist = bSave
    End Function


    Function HasNewDraftVersion(ByVal prfId As Integer, ByVal dataVersion As String) As Boolean Implements IProfileService.HasNewDraftVersion
        Dim dt As DataTable = GetProfile(prfId)

        If dt Is Nothing Then
            Return False
        ElseIf dt.Rows.Count = 0 Then
            Return False
        ElseIf IsDBNull(dt.Rows(0).Item("data_version")) Then
            Return True
        ElseIf DataFormatHelper.StringTrim(dt.Rows(0).Item("data_version")) = "" Then
            Return True
            'ElseIf dt.Rows(0).Item("data_version") > dataVersion AndAlso dt.Rows(0).Item("status") = PROFILESTATUS.DRAFT Then
        ElseIf dt.Rows(0).Item("data_version") > dataVersion Then
            Return True
        Else
            Return False
        End If

        If Not dt Is Nothing Then
            dt.Dispose()
        End If

    End Function


    Function HasNewerVersion(ByVal prfId As Integer, ByVal dataVersion As String) As Boolean Implements IProfileService.HasNewerVersion
        Dim bHasNewerVersion As Boolean = False
        Dim dt As DataTable = GetProfileHist(prfId)

        If dt Is Nothing Then
            Return False
        ElseIf dt.Rows.Count = 0 Then
            Return False
        End If

        For Each dr In dt.Rows
            Dim drDataVersion = dr("data_version").ToString.Trim
            If Not String.IsNullOrEmpty(drDataVersion) AndAlso drDataVersion > dataVersion Then
                bHasNewerVersion = True
                Exit For
            End If
        Next

        If Not dt Is Nothing Then
            dt.Dispose()
        End If

        HasNewerVersion = bHasNewerVersion

    End Function

    Function GetProfileHist(ByVal prfId As Integer) As DataTable
        sSQLBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " prf WHERE 1 = 1 AND prf_id = @PRFID")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", prfId)}

        Return sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Sub GetMyProfilePMs(ByRef sPMList As StringBuilder, ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String, ByVal teamCode As Integer, ByVal dataVersion As String, ByVal viewMode As String) Implements IProfileService.GetMyProfilePMs


        Dim pmaTeamService As IPmaTeamService = New PmaTeamService
        Dim dtMyTeams As DataTable = pmaTeamService.GetMyLeadTeams(pmaLogonId, pmaLogonIdCard, teamCode)

        If dtMyTeams Is Nothing Then
            Return
        ElseIf dtMyTeams.Rows.Count = 0 Then
            Return
        End If

        For Each drMyTeam As DataRow In dtMyTeams.Rows
            If viewMode = PROFILESTATUS.SUBMITTED Then
                GetMyProfileHistPMsByTeam(sPMList, drMyTeam("team_code"), dataVersion)
            Else
                GetMyProfilePMsByTeam(sPMList, drMyTeam("team_code"), dataVersion)
            End If
        Next

    End Sub

    Sub GetMyProfileHistPMsByTeam(ByRef sPMList As StringBuilder, ByVal teamCode As Integer, ByVal dataVersion As String)
        Dim sStaffTable As String = "[dbo].[tpma_staffbasic]"

        Dim sSQLBuilder As StringBuilder = New StringBuilder("Select distinct prj_ld_id from " & sHistView & " a ")
        sSQLBuilder.Append("where exists (select 1 from " & sStaffTable & " where logon_id = a.prj_ld_id and team_code = @TEAMCODE) ")

        sSQLBuilder.Append(" AND EXISTS ( SELECT 1 ")
        sSQLBuilder.Append(" FROM (SELECT [prf_id], max(data_version) as data_version FROM " & sHistView & " GROUP BY prf_id ) b ")
        sSQLBuilder.Append(" WHERE b.prf_id = a.prf_id and b.data_version = a.data_version ) ")

        sSQLBuilder.Append(" AND [DATA_VERSION] <= @DATAVERSION ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@TEAMCODE", teamCode), _
                                           New SqlParameter("@DATAVERSION", dataVersion)}

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

        If Not dt Is Nothing Then
            For Each dr In dt.Rows
                If sPMList.Length = 0 Then
                    sPMList.Append("'" & dr("prj_ld_id") & "'")
                ElseIf Not sPMList.ToString.Contains(dr("prj_ld_id")) Then
                    sPMList.Append(", ")
                    sPMList.Append("'" & dr("prj_ld_id") & "'")
                End If
            Next
        End If

        Dim pmaTeamService As IPmaTeamService = New PmaTeamService
        Dim dtSubTeams As DataTable = pmaTeamService.GetSubTeamList(teamCode)
        If dtSubTeams Is Nothing Then
            Return
        ElseIf dtSubTeams.Rows.Count = 0 Then
            Return
        Else
            For Each drSubTeam In dtSubTeams.Rows
                GetMyProfileHistPMsByTeam(sPMList, drSubTeam("team_code"), dataVersion)
            Next
        End If

    End Sub

    Sub GetMyProfilePMsByTeam(ByRef sPMList As StringBuilder, ByVal teamCode As Integer, ByVal dataVersion As String)
        Dim sStaffTable As String = "[dbo].[tpma_staffbasic]"

        Dim sSQLBuilder As StringBuilder = New StringBuilder("Select distinct prj_ld_id from " & sView & " a ")
        sSQLBuilder.Append("where exists (select 1 from " & sStaffTable & " where logon_id = a.prj_ld_id and team_code = @TEAMCODE) ")

        'sSQLBuilder.Append(" AND EXISTS ( SELECT 1 ")
        'sSQLBuilder.Append(" FROM (SELECT [prf_id], max(data_version) as data_version FROM " & sHistView & " GROUP BY prf_id ) b ")
        'sSQLBuilder.Append(" WHERE b.prf_id = a.prf_id and b.data_version = a.data_version ) ")

        'sSQLBuilder.Append(" AND [DATA_VERSION] <= @DATAVERSION ")

        'Dim sqlParams As SqlParameter() = {New SqlParameter("@TEAMCODE", teamCode), _
        '                                   New SqlParameter("@DATAVERSION", dataVersion)}

        Dim sqlParams As SqlParameter() = {New SqlParameter("@TEAMCODE", teamCode)}

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

        If Not dt Is Nothing Then
            For Each dr In dt.Rows
                If sPMList.Length = 0 Then
                    sPMList.Append("'" & dr("prj_ld_id") & "'")
                ElseIf Not sPMList.ToString.Contains(dr("prj_ld_id")) Then
                    sPMList.Append(", ")
                    sPMList.Append("'" & dr("prj_ld_id") & "'")
                End If
            Next
        End If

        Dim pmaTeamService As IPmaTeamService = New PmaTeamService
        Dim dtSubTeams As DataTable = pmaTeamService.GetSubTeamList(teamCode)
        If dtSubTeams Is Nothing Then
            Return
        ElseIf dtSubTeams.Rows.Count = 0 Then
            Return
        Else
            For Each drSubTeam In dtSubTeams.Rows
                GetMyProfilePMsByTeam(sPMList, drSubTeam("team_code"), dataVersion)
            Next
        End If

    End Sub


    Sub GetMyTeamProfilesHist(ByRef sPrfList As StringBuilder, ByVal steamCodes As String, ByVal dataVersion As String) Implements IProfileService.GetMyTeamProfilesHist
        sSQLBuilder = New StringBuilder("SELECT * FROM " & sHistView & " prfHist WHERE 1 = 1 ")


        sSQLBuilder.Append(" AND exists ( ")
        sSQLBuilder.Append("     select 1 from tpma_project prj ")
        sSQLBuilder.Append("     where prfHist.prj_codes like ('%' + prj.prj_code + '%') ")
        sSQLBuilder.Append("     and exists (select 1 from [dbo].[tpma_StaffBasic] where logon_id = prj.prj_ld_id and team_code in (" & steamCodes & ")) ")
        sSQLBuilder.Append(" ) ")

        sSQLBuilder.Append(" AND exists ( ")
        sSQLBuilder.Append("     select 1 from (select prf_id, max(data_version) as data_version from " & sHistView)
        If dataVersion <> Format(Now, "yyyyMMdd") Then
            sSQLBuilder.Append("  WHERE data_version <= '" & dataVersion & "' ")
        End If
        sSQLBuilder.Append(" group by prf_id) b ")
        sSQLBuilder.Append("     where prf_id = prfHist.prf_id and data_version = prfHist.data_version ")
        sSQLBuilder.Append(" ) ")

        'sSQLBuilder.Append(" AND EXISTS( ")
        ''Select 1 from (select prf_id, max(data_version) as data_version from shistview where group by prf_id) where prf_id = prfHist.prf_id and data_version = prfHist.data_version 
        'sSQLBuilder.Append(" ) ")


        'Dim sqlParams As SqlParameter() = {New SqlParameter("@DATAVERSION", dataVersion)}

        Dim dt As DataTable = New DataTable
        dt = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

        If dt Is Nothing Then
            Return
        ElseIf dt.Rows.Count = 0 Then
            Return
        End If

        For Each dr As DataRow In dt.Rows
            If String.IsNullOrEmpty(sPrfList.ToString) Then
                sPrfList.Append(dr("prf_id"))
            ElseIf Not sPrfList.ToString.Contains(dr("prf_id")) Then
                sPrfList.Append(",")
                sPrfList.Append(dr("prf_id"))
            End If
        Next

    End Sub

    Sub GetMyTeamProfiles(ByRef sPrfList As StringBuilder, ByVal steamCodes As String, ByVal dataVersion As String) Implements IProfileService.GetMyTeamProfiles
        sSQLBuilder = New StringBuilder("SELECT * FROM " & sView & " prf WHERE 1 = 1 ")


        sSQLBuilder.Append(" AND exists ( ")
        sSQLBuilder.Append("     select 1 from tpma_project prj ")
        sSQLBuilder.Append("     where prf.prj_codes like ('%' + prj.prj_code + '%') ")
        sSQLBuilder.Append("     and exists (select 1 from [dbo].[tpma_StaffBasic] where logon_id = prj.prj_ld_id and team_code in (" & steamCodes & ")) ")
        sSQLBuilder.Append(" ) ")

        'sSQLBuilder.Append(" AND exists ( ")
        'sSQLBuilder.Append("     select 1 from (select prf_id, max(data_version) as data_version from " & sView & " group by prf_id) b ")
        'sSQLBuilder.Append("     where prf_id = prf.prf_id and data_version = prf.data_version ")
        'sSQLBuilder.Append(" ) ")

        'sSQLBuilder.Append(" AND EXISTS( ")
        ''Select 1 from (select prf_id, max(data_version) as data_version from shistview where group by prf_id) where prf_id = prfHist.prf_id and data_version = prfHist.data_version 
        'sSQLBuilder.Append(" ) ")


        'Dim sqlParams As SqlParameter() = {New SqlParameter("@DATAVERSION", dataVersion)}

        Dim dt As DataTable = New DataTable
        dt = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

        If dt Is Nothing Then
            Return
        ElseIf dt.Rows.Count = 0 Then
            Return
        End If

        For Each dr As DataRow In dt.Rows
            If String.IsNullOrEmpty(sPrfList.ToString) Then
                sPrfList.Append(dr("prf_id"))
            ElseIf Not sPrfList.ToString.Contains(dr("prf_id")) Then
                sPrfList.Append(",")
                sPrfList.Append(dr("prf_id"))
            End If
        Next

    End Sub

    Function GetNeverSubmittedProfileList(ByVal sFilter As String) As DataTable Implements IProfileService.GetNeverSubmittedProfileList

        sSQLBuilder = New StringBuilder(sSQLView & " a ")

        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND NOT EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM " & sHistTable & " WHERE PRF_ID = a.PRF_ID ")
        sSQLBuilder.Append(")")
        sSQLBuilder.Append(" AND STATUS = 'D' ")

        If Not String.IsNullOrEmpty(sFilter) Then
            sSQLBuilder.Append(sFilter)
        End If

        GetNeverSubmittedProfileList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
    End Function


    Function HasHealthStatus(ByVal prfId As Integer) As Boolean Implements IProfileService.HasHealthStatus
        Dim bHasHealthSta As Boolean = False
        Dim dt As DataTable = GetProfile(prfId)

        If Not dt Is Nothing Then
            If dt.Rows.Count > 0 Then
                If Not IsDBNull(dt.Rows(0).Item("health_status")) Then
                    bHasHealthSta = True
                End If
            End If

        End If

        If Not dt Is Nothing Then
            dt.Dispose()
        End If

        HasHealthStatus = bHasHealthSta
    End Function

    Function GetProfileLastSubmittedDate(ByVal profielId As Integer) As String Implements IProfileService.GetProfileLastSubmittedDate
        sSQLBuilder = New StringBuilder("SELECT MAX(data_version) as data_version FROM " & sHistTable)
        sSQLBuilder.Append(" WHERE 1 =  1 ")
        sSQLBuilder.Append(" AND [PRF_ID] = @PRFID ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@PRFID", profielId)}

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

        If dt Is Nothing Then
            Return ""
        ElseIf dt.Rows.Count = 0 Then
            Return ""
        Else
            Return dt.Rows(0).Item(0).ToString
        End If
    End Function

    Function GetProfileProgressUpdateReminder(ByVal jobId As Integer) As DataTable Implements IProfileService.GetProfileProgressUpdateReminder
        Dim sqlParams As SqlParameter() = {New SqlParameter("@JOB_ID", jobId)}

        Return sqlHelper.ExecuteReaderQuery("usp_dshbd_job_profile_upd_push", sqlParams, CommandType.StoredProcedure)
    End Function

    Function GetProfileNewSubmitted() As DataTable Implements IProfileService.GetProfileNewSubmitted
        Return sqlHelper.ExecuteReaderQuery("usp_dshbd_job_profile_new_submitted", Nothing, CommandType.StoredProcedure)
    End Function

    Sub CopyHistDataToDraft(ByRef drPrfHist As DataRow, ByRef drPrf As DataRow) Implements IProfileService.CopyHistDataToDraft
        If drPrfHist Is Nothing Or drPrf Is Nothing Then
            Return
        End If

        Dim i As Integer = 0
        For i = 0 To drPrf.Table.Columns.Count - 1
            If Not drPrf.Table.Columns(i).ReadOnly Then
                drPrf(i) = drPrfHist(i)
            End If
        Next
    End Sub

End Class


Public Class ProfileHealthStatus

    Public Shared Function CalculateProfileHealthStatus(ByVal prfHealthSta As ProfileHealthStatusModel) As String
        Dim sPrfHealthSta As String = ""

        Dim scopeSta As String = DataFormatHelper.StringTrim(prfHealthSta.scopeStatus)
        Dim scheduleSta As String = DataFormatHelper.StringTrim(prfHealthSta.scheduleStatus)
        Dim resourceSta As String = DataFormatHelper.StringTrim(prfHealthSta.resourceStatus)

        Dim qualitySta As String = DataFormatHelper.StringTrim(prfHealthSta.qualityStatus)
        Dim costSta As String = DataFormatHelper.StringTrim(prfHealthSta.costStatus)
        Dim cssSta As String = DataFormatHelper.StringTrim(prfHealthSta.cssStatus)

        If (scopeSta = RAG.RED Or scheduleSta = RAG.RED Or resourceSta = RAG.RED Or qualitySta = RAG.RED Or costSta = RAG.RED Or cssSta = RAG.RED) Then
            sPrfHealthSta = RAG.RED

        ElseIf (scopeSta = RAG.AMBER Or scheduleSta = RAG.AMBER Or resourceSta = RAG.AMBER Or qualitySta = RAG.AMBER Or costSta = RAG.AMBER Or cssSta = RAG.AMBER) Then
            sPrfHealthSta = RAG.AMBER

        ElseIf (scopeSta = RAG.GREEN Or scheduleSta = RAG.GREEN Or resourceSta = RAG.GREEN Or qualitySta = RAG.GREEN Or costSta = RAG.GREEN Or cssSta = RAG.GREEN) Then
            sPrfHealthSta = RAG.GREEN
        End If

        CalculateProfileHealthStatus = sPrfHealthSta
    End Function

    Public Shared Function GetProfileQualityStatus(ByVal dtPrjMetric As DataTable) As String
        Dim sQtySta As String = ""

        If dtPrjMetric Is Nothing Then
            Return sQtySta
        ElseIf dtPrjMetric.Rows.Count = 0 Then
            Return sQtySta
        End If

        Dim metricService As IMetricService = New MetricService

        Dim sQtyMetricList As String = metricService.GetQualityMetricList()
        If String.IsNullOrEmpty(sQtyMetricList) Then
            Return sQtySta
        End If

        Dim iStaCntR As Integer = 0
        Dim iStaCntA As Integer = 0
        Dim iStaCntG As Integer = 0
        Dim iNoStaCnt As Integer = 0

        For Each drPrjMetric As DataRow In dtPrjMetric.Rows
            If sQtyMetricList.Contains(drPrjMetric("metric_code")) Then

                If IsDBNull(drPrjMetric("metric_status")) Then
                    Continue For
                End If

                Select Case drPrjMetric("metric_status").ToString.Trim.ToUpper
                    Case RAG.RED
                        iStaCntR = iStaCntR + 1
                    Case RAG.AMBER
                        iStaCntA = iStaCntA + 1
                    Case RAG.GREEN
                        iStaCntG = iStaCntG + 1
                End Select

            End If
        Next


        If iStaCntR + iStaCntA >= 2 Then
            sQtySta = RAG.RED

        ElseIf iStaCntR + iStaCntA >= 1 Then
            sQtySta = RAG.AMBER

        ElseIf iStaCntG > 0 Then
            sQtySta = RAG.GREEN
        End If

        GetProfileQualityStatus = sQtySta
    End Function

    Public Shared Function GetProfileScheduleStatus(ByVal dtPrjMetric As DataTable, ByVal sTssPrj As String) As String
        Dim sScheduleSta As String = ""

        If dtPrjMetric Is Nothing Then
            Return sScheduleSta
        ElseIf dtPrjMetric.Rows.Count = 0 Then
            Return sScheduleSta
        End If

        Dim decTotMetricVal As Decimal
        Dim iTotCntMetric As Integer = 0

        For Each dr As DataRow In dtPrjMetric.Rows
            If dr("metric_code").ToString = METRICCODE.ONSCHEDULE Then

            End If
            If dr("metric_code").ToString = METRICCODE.SPI.ToString Then
                If IsDBNull(dr("metric_value")) Then
                ElseIf IsNumeric(dr("metric_value")) Then
                    decTotMetricVal = decTotMetricVal + dr("metric_value")
                    iTotCntMetric = iTotCntMetric + 1
                End If
            End If
        Next

        If iTotCntMetric > 0 Then
            Dim metricTargetService As IMetricTargetService = New MetricTargetService
            Dim dtTarget As DataTable = New DataTable
            Dim sMetricCode As String = ""
            If sTssPrj = TSSSERVICECATEGORY.BAUE.ToString Then
                sMetricCode = METRICCODE.ONSCHEDULE
            ElseIf sTssPrj = TSSSERVICECATEGORY.PRJDEVLOPMENT.ToString Or sTssPrj = TSSSERVICECATEGORY.PRJDEPLOY.ToString Then
                sMetricCode = METRICCODE.SPI
            End If

            dtTarget = metricTargetService.GetLatestMetricTargetList(sTssPrj, sMetricCode)

            If Not dtTarget Is Nothing Then
                If dtTarget.Rows.Count > 0 Then
                    sScheduleSta = MetricStatus.CalculateMetricStatus(dtTarget, decTotMetricVal / iTotCntMetric)
                End If
            End If
        End If

        GetProfileScheduleStatus = sScheduleSta
    End Function

    Public Shared Function GetProfileCostStatus(ByVal dtPrjMetric As DataTable, ByVal sTssPrj As String) As String
        Dim sCostSta As String = ""

        If dtPrjMetric Is Nothing Then
            Return sCostSta
        ElseIf dtPrjMetric.Rows.Count = 0 Then
            Return sCostSta
        End If

        Dim decTotCPI As Decimal
        Dim iTotCntCPI As Integer = 0

        For Each dr As DataRow In dtPrjMetric.Rows
            If dr("metric_code").ToString = METRICCODE.CPI.ToString Then
                If IsDBNull(dr("metric_val")) Then
                ElseIf IsNumeric(dr("metric_val")) Then
                    decTotCPI = decTotCPI + dr("metric_val")
                    iTotCntCPI = iTotCntCPI + 1
                End If
            End If
        Next

        If iTotCntCPI > 0 Then
            Dim metricTargetService As IMetricTargetService = New MetricTargetService
            Dim dtTarget As DataTable = New DataTable


            dtTarget = metricTargetService.GetMetricTarget(METRICCODE.SPI.ToString)
            If Not dtTarget Is Nothing Then
                If dtTarget.Rows.Count > 0 Then
                    sCostSta = MetricStatus.CalculateMetricStatus(dtTarget, decTotCPI / iTotCntCPI)
                End If
            End If
        End If

        GetProfileCostStatus = sCostSta
    End Function

End Class
#End Region

