﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

Public Class LookupModel

    Private _lookupId As Integer
    Public ReadOnly Property lookupId() As Integer
        Get
            Return _lookupId
        End Get
    End Property


    Private _lookupType As String
    Public Property lookupType() As String
        Get
            Return _lookupType
        End Get
        Set(ByVal value As String)
            _lookupType = value
        End Set
    End Property



    Private _category As String
    Public Property category() As String
        Get
            Return _category
        End Get
        Set(ByVal value As String)
            _category = value
        End Set
    End Property


    Private _categoryDesc As String
    Public Property categoryDesc() As String
        Get
            Return _categoryDesc
        End Get
        Set(ByVal value As String)
            _categoryDesc = value
        End Set
    End Property

    Private _subCategory As String
    Public Property subCategory() As String
        Get
            Return _subCategory
        End Get
        Set(ByVal value As String)
            _subCategory = value
        End Set
    End Property

    Private _subCategoryDesc As String
    Public Property subCategoryDesc() As String
        Get
            Return _subCategoryDesc
        End Get
        Set(ByVal value As String)
            _subCategoryDesc = value
        End Set
    End Property

    Private _lookupCode As String
    Public Property lookupCode() As String
        Get
            Return _lookupCode
        End Get
        Set(ByVal value As String)
            _lookupCode = value
        End Set
    End Property

    Private _lookupName As String
    Property lookupName() As String
        Get
            Return _lookupName
        End Get
        Set(ByVal value As String)
            _lookupName = value
        End Set
    End Property

    Private _isActive As String
    Property isActive() As String
        Get
            Return _isActive
        End Get
        Set(ByVal value As String)
            _isActive = IIf(String.IsNullOrEmpty(value), "Y", value)
        End Set
    End Property

    Private _createdBy As String
    Property createdBy() As String
        Get
            Return _createdBy
        End Get
        Set(ByVal value As String)
            _createdBy = value
        End Set
    End Property

    Private _createdDate As Date
    Property createdDate() As Date
        Get
            Return _createdDate
        End Get
        Set(ByVal value As Date)
            _createdDate = value
        End Set
    End Property

    Private _lastUpdatedBy As String
    Property lastUpdatedBy() As String
        Get
            Return _lastUpdatedBy
        End Get
        Set(ByVal value As String)
            _lastUpdatedBy = value
        End Set
    End Property

    Private _lastUpdatedDate As Date
    Property lastUpdatedDate() As Date
        Get
            Return _lastUpdatedDate
        End Get
        Set(ByVal value As Date)
            _lastUpdatedDate = value
        End Set
    End Property



    Public Sub New()

    End Sub


End Class


#End Region


#Region "Service"

Public Interface ILookupService



    Function GetLookUpList(ByVal lookupType As String, Optional ByVal lookupCate As String = "", Optional ByVal lookupCode As String = "") As DataTable

    Function GetBlankLookUp() As DataTable
    Function GetLookUp(ByVal lookupType As String, ByVal lookupCate As String, ByVal lookupCode As String) As DataTable

    Function GetLookUpName(ByVal lookupType As String, ByVal lookupCate As String, ByVal lookupCode As String) As String


    Function SaveLookup(ByVal dtLookupSave As DataTable) As Boolean

    Function IsExistedLookup(ByVal dtLookup As LookupModel) As Boolean

End Interface

Public Class LookupService
    Implements ILookupService

    Const sTable = "[dbo].[tpma_dshbd_lookup]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable
    Dim sSQLBuilder As StringBuilder = New StringBuilder("")

    Private sqlHelper As SqlHelper = New SqlHelper()


    Function GetLookUpList(ByVal lookupType As String, Optional ByVal lookupCate As String = "", Optional ByVal lookupCode As String = "") As DataTable Implements ILookupService.GetLookUpList
        sSQLBuilder = New StringBuilder(sSQLTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [LOOKUP_TYPE] = @LOOKUPTYPE ")


        Dim sqlParams As SqlParameter() = {New SqlParameter("@LOOKUPTYPE", lookupType)}


        If Not String.IsNullOrEmpty(lookupCate) Then
            sSQLBuilder.Append(" AND [CATEGORY] = @LOOKUPCATE ")
            ReDim Preserve sqlParams(sqlParams.Length)
            sqlParams(1) = New SqlParameter("@LOOKUPCATE", lookupCate)
        End If

        If Not String.IsNullOrEmpty(lookupCode) Then
            sSQLBuilder.Append(" AND [LOOKUP_CODE] = @LOOKUPCODE ")

            ReDim Preserve sqlParams(sqlParams.Length)
            sqlParams(sqlParams.Length - 1) = New SqlParameter("@LOOKUPCODE", lookupCode)
        End If

        GetLookUpList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)


    End Function


    Function GetBlankLookUp() As DataTable Implements ILookupService.GetBlankLookUp
        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 0 ")

        GetBlankLookUp = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)
    End Function

    Function GetLookUp(ByVal lookupType As String, ByVal lookupCate As String, ByVal lookupCode As String) As DataTable Implements ILookupService.GetLookUp

        If String.IsNullOrEmpty(lookupType) Or String.IsNullOrEmpty(lookupCate) Or String.IsNullOrEmpty(lookupCode) Then
            Return Nothing
        End If

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [LOOKUP_TYPE] = @LOOKUPTYPE ")
        sSQLBuilder.Append(" AND [CATEGORY] = @LOOKUPCATE ")
        sSQLBuilder.Append(" AND [LOOKUP_CODE] = @LOOKUPCODE")

        Dim sqlParams As SqlParameter() = {New SqlParameter("LOOKUPTYPE", lookupType), _
                                           New SqlParameter("LOOKUPCATE", lookupCate), _
                                           New SqlParameter("LOOKUPCODE", lookupCode)}

        GetLookUp = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

    End Function

    Function GetLookUpName(ByVal lookupType As String, ByVal lookupCate As String, ByVal lookupCode As String) As String Implements ILookupService.GetLookUpName
        Dim dt As DataTable = GetLookUp(lookupType, lookupCate, lookupCode)
        Dim sReturn As String = ""

        If Not dt Is Nothing Then
            If dt.Rows.Count > 0 Then
                sReturn = dt.Rows(0).Item("lookup_name").ToString()
            End If
        End If

        GetLookUpName = sReturn

        dt.Dispose()
    End Function

    Function SaveLookup(ByVal dtLookupSave As DataTable) As Boolean Implements ILookupService.SaveLookup
        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 0 ")

        If Not dtLookupSave Is Nothing Then
            Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQLBuilder.ToString, dtLookupSave)}

            SaveLookup = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
        Else
            SaveLookup = False
        End If

    End Function


    Function IsExistedLookup(ByVal lookup As LookupModel) As Boolean Implements ILookupService.IsExistedLookup
        Dim dt As DataTable = GetLookUp(lookup.lookupType, lookup.category, lookup.lookupCode)

        If dt Is Nothing Then
            IsExistedLookup = False
        ElseIf dt.Rows.Count = 0 Then
            IsExistedLookup = False
        Else
            IsExistedLookup = IIf(dt.Rows(0).Item("is_active") = lookup.isActive, True, False)
        End If

        dt.Dispose()

    End Function
End Class

#End Region


Public Class Lookup

    Public Shared Function RAGColor(ByVal lookupCode As String) As String

        Dim sRagColor As String = "#DADADA"
        Select Case lookupCode
            Case "A"
                sRagColor = "#f0ad4e"
            Case "R"
                sRagColor = "Red"
            Case "G"
                sRagColor = "Green"
        End Select

        RAGColor = sRagColor
    End Function

End Class



