﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"



#End Region


#Region "Service"

Public Interface IPmaTssPrjService

    Function GetMyTeamTssPrjList(ByVal sTeamCodes As String) As DataTable
    

End Interface

Class PmaTssPrjService
    Implements IPmaTssPrjService

    Const sTable As String = "[dbo].[tpma_tss_prj]"
    Dim sSQLSel As String = " SELECT [prj_code], [prj_name], [prj_desc], [prj_ld_id], [status] FROM " & sTable & ""
    Private sqlHelper As SqlHelper = New SqlHelper()

    Function GetMyTeamTssPrjList(ByVal sTeamCodes As String) As DataTable Implements IPmaTssPrjService.GetMyTeamTssPrjList
        Dim sSQLBuilder As StringBuilder = New StringBuilder(sSQLSel & " a ")
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND EXISTS (")
        sSQLBuilder.Append(" SELECT 1 FROM [dbo].[tpma_staffbasic] staff WHERE logon_id = a.prj_ld_id and team_code in (" & sTeamCodes & ")")
        sSQLBuilder.Append(" ) ")

        GetMyTeamTssPrjList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

    End Function
End Class


#End Region

