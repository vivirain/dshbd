﻿Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlClient


#Region "Model"

'Public Class PmaTeamModel
'    Property teamCode As Integer
'    Property teamName As String
'    Property status As String

'    Property tlId As String
'    Property dtlId As String

'    Property isDept As String
'    Property isFunc As String

'    Property subordinate As Integer

'    Property tlIdCard As String
'End Class

Public Class TEAMLEVEL
    Public Shared ReadOnly Property FUNC As String
        Get
            Return "F"
        End Get
    End Property

    Public Shared ReadOnly Property SBU As String
        Get
            Return "D"
        End Get
    End Property

End Class

#End Region

#Region "Service"


Public Interface IPmaTeamService
    'Function GetTeamList(Optional ByVal teamCode As Integer = 0) As DataTable
    Function GetTeam(ByVal teamCode As Integer) As DataTable

    Function GetFunctionList(Optional ByVal forSearch As Boolean = False) As DataTable
    Function GetSBUList(Optional ByVal forSearch As Boolean = False, Optional ByVal parentTeamCode As Integer = 0) As DataTable
    Function GetSubTeamList(Optional ByVal parentTeamCode As Integer = 0, Optional ByVal teamLevel As String = "") As DataTable

    Function GetTopTeamCode() As Integer
    Function GetTeam(ByVal teamCode As Integer, ByVal level As String) As DataTable

    Function GetTeamNameByCode(ByVal teamCode As Integer) As String

    Function GetMyFunction(ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String, ByVal teamCode As Integer) As DataTable
    Function GetMySBU(ByVal parentTeamCode As Integer, ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String, ByVal teamCode As Integer) As DataTable
    Function GetMyLeadTeams(ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String, ByVal teamCode As Integer) As DataTable

    Function GetMyLeadTeamCodes(ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String) As String


End Interface

Class PmaTeamService
    Implements IPmaTeamService

    Const sTable = "[dbo].[tpma_team]"
    Dim sSQLTable As String = "select *, rtrim(team_name + ' - ' + cast(team_code as varchar(10))) as display_name from " & sTable
    Dim sSQLBuilder As StringBuilder = New StringBuilder()
    Private sqlHelper As SqlHelper = New SqlHelper


    Function GetTeam(ByVal teamCode As Integer) As DataTable Implements IPmaTeamService.GetTeam

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND [STATUS] = @STATUS ")
        sSQLBuilder.Append(" AND [TEAM_CODE] = @TEAMCODE ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@STATUS", "A"), _
                                           New SqlParameter("@TEAMCODE", teamCode)}


        GetTeam = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetTeam(ByVal teamCode As Integer, ByVal level As String) As DataTable Implements IPmaTeamService.GetTeam
        Dim dtTeam As DataTable = GetTeam(teamCode)

        If dtTeam Is Nothing Then
            Return dtTeam
        ElseIf dtTeam.Rows.Count = 0 Then
            Return dtTeam
        ElseIf String.IsNullOrEmpty(level) Then
            Return dtTeam
        End If

        Select Case level
            Case TEAMLEVEL.FUNC
                If dtTeam.Rows(0).Item("is_func") = "Y" Then
                    Return dtTeam
                Else
                    dtTeam = GetTeam(dtTeam.Rows(0).Item("subordinate"), level)
                End If
            Case TEAMLEVEL.SBU
                If dtTeam.Rows(0).Item("is_dept") = "Y" Then
                    Return dtTeam
                Else
                    dtTeam = GetTeam(dtTeam.Rows(0).Item("subordinate"), level)
                End If
        End Select

        GetTeam = dtTeam
        dtTeam.Dispose()
    End Function

    Function GetFunctionList(Optional ByVal forSearch As Boolean = False) As DataTable Implements IPmaTeamService.GetFunctionList
        If forSearch Then
            sSQLBuilder = New StringBuilder("SELECT team.*, (team_name + '  ' + team_code) as display_name FROM " & sTable & " team ")
        Else
            sSQLBuilder = New StringBuilder(sSQLTable)
        End If

        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [STATUS] = @STATUS ")
        sSQLBuilder.Append(" AND isnull([IS_FUNC],'') = @IS_FUNC ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@STATUS", "A"), _
                                           New SqlParameter("@IS_FUNC", "Y")}

        GetFunctionList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetSBUList(Optional ByVal forSearch As Boolean = False, Optional ByVal parentTeamCode As Integer = 0) As DataTable Implements IPmaTeamService.GetSBUList
        Dim sqlParams As SqlParameter() = Nothing

        If forSearch Then
            sSQLBuilder = New StringBuilder("SELECT team.*, (team_name + ' - ' + team_code) as display_name FROM " & sTable & " team ")
        Else
            sSQLBuilder = New StringBuilder(sSQLTable)
        End If

        sSQLBuilder.Append(" WHERE 1 = 1 ")

        sSQLBuilder.Append(" AND [STATUS] = @STATUS ")
        ReDim Preserve sqlParams(0)
        sqlParams(0) = New SqlParameter("@STATUS", "A")

        sSQLBuilder.Append(" AND isnull([IS_DEPT],'') = @IS_DEPT ")
        ReDim Preserve sqlParams(1)
        sqlParams(1) = New SqlParameter("@STATUS", "A")

        If parentTeamCode > 0 Then 'Get BU list under specific function
            sSQLBuilder.Append(" AND [SUBORDINATE] = @PARENTTEAMCODE ")
            ReDim Preserve sqlParams(2)
            sqlParams(2) = New SqlParameter("@PARENTTEAMCODE", parentTeamCode)
        End If

        GetSBUList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

    End Function

    Function GetSubTeamList(Optional ByVal parentTeamCode As Integer = 0, Optional ByVal teamLevel As String = "") As DataTable Implements IPmaTeamService.GetSubTeamList
        Dim dt As DataTable = New DataTable

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND [STATUS] = @STATUS ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@STATUS", "A")}

        If parentTeamCode > 0 Then
            sSQLBuilder.Append(" AND [SUBORDINATE] = @PARENTTEAMCODE ")

            ReDim Preserve sqlParams(sqlParams.Length)
            sqlParams(sqlParams.Length - 1) = New SqlParameter("@PARENTTEAMCODE", parentTeamCode)
        End If

        If Not String.IsNullOrEmpty(teamLevel) Then
            Select Case teamLevel
                Case "D"
                    'Get SBU
                    sSQLBuilder.Append(" AND isnull([IS_DEPT],'') = @IS_DEPT ")

                    ReDim Preserve sqlParams(sqlParams.Length)
                    sqlParams(sqlParams.Length - 1) = New SqlParameter("@IS_DEPT", "Y")
            End Select
        End If

        GetSubTeamList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function


    Function GetTeamNameByCode(ByVal teamCode As Integer) As String Implements IPmaTeamService.GetTeamNameByCode
        Dim sTeamName As String = ""
        Dim dt As DataTable = New DataTable

        sSQLBuilder = New StringBuilder(sSQLTable)
        sSQLBuilder.Append(" WHERE 1 = 1 ")
        'sSQLBuilder.Append(" AND [STATUS] = @STATUS ")
        sSQLBuilder.Append(" AND [TEAM_CODE] = @TEAMCODE ")

        'Dim sqlParams As SqlParameter() = {New SqlParameter("@STATUS", "A"), _
        '                                   New SqlParameter("@TEAMCODE", teamCode)}

        Dim sqlParams As SqlParameter() = {New SqlParameter("@TEAMCODE", teamCode)}

        dt = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

        If Not dt Is Nothing Then
            If dt.Rows.Count > 0 Then
                sTeamName = dt.Rows(0).Item("team_name").ToString
            End If
        End If

        dt.Dispose()

        GetTeamNameByCode = sTeamName

    End Function

    Function GetTopTeamCode() As Integer Implements IPmaTeamService.GetTopTeamCode
        sSQLBuilder = New StringBuilder("SELECT MIN(team_code) as team_code from " & sTable)

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString)

        If dt Is Nothing Then
            GetTopTeamCode = 0
        ElseIf dt.Rows.Count = 0 Then
            GetTopTeamCode = 0
        Else
            GetTopTeamCode = dt.Rows(0).Item("team_code")
        End If

        dt.Dispose()
    End Function

    Function GetMyFunction(ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String, ByVal teamCode As Integer) As DataTable Implements IPmaTeamService.GetMyFunction
        Dim dtFunc As DataTable = New DataTable


        'I'm Function Head
        sSQLBuilder = New StringBuilder(sSQLTable)

        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND STATUS = 'A' ")
        sSQLBuilder.Append(" AND [IS_FUNC] = 'Y' ")

        sSQLBuilder.Append(" AND ( ([TL_ID] = @LOGONID AND [TL_ID_CARD] = @LOGONIDCARD) OR [DTL_ID] = @LOGONID ) ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@LOGONID", pmaLogonId), _
                                           New SqlParameter("@LOGONIDCARD", pmaLogonIdCard)}

        Try
            dtFunc = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)


            If dtFunc Is Nothing Then
                'I'm not function Head
                dtFunc = GetTeam(teamCode, TEAMLEVEL.FUNC)
            ElseIf dtFunc.Rows.Count = 0 Then
                dtFunc = GetTeam(teamCode, TEAMLEVEL.SBU)
            End If
        Catch ex As Exception
            LogHelper.WriteLog("GetMyFunction: Failed to execute SQL: " & sSQLBuilder.ToString, ex)
        End Try
        
        GetMyFunction = dtFunc

        dtFunc.Dispose()
    End Function

    Function GetMySBU(ByVal parentTeamCode As Integer, ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String, ByVal teamCode As Integer) As DataTable Implements IPmaTeamService.GetMySBU
        Dim dtSBU As DataTable = New DataTable


        'I'm SBU Head
        sSQLBuilder = New StringBuilder(sSQLTable)

        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND STATUS = 'A' ")
        sSQLBuilder.Append(" AND [IS_DEPT] = 'Y' ")

        sSQLBuilder.Append(" AND [SUBORDINATE] = @PARENTTEAMCODE ")
        sSQLBuilder.Append(" AND ( ([TL_ID] = @LOGONID AND [TL_ID_CARD] = @LOGONIDCARD) OR [DTL_ID] = @LOGONID ) ")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@LOGONID", pmaLogonId), _
                                           New SqlParameter("@LOGONIDCARD", pmaLogonIdCard), _
                                           New SqlParameter("@PARENTTEAMCODE", parentTeamCode)}

        Try
            dtSBU = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)


            If dtSBU Is Nothing Then
                'I'm not SBU Head
                dtSBU = GetTeam(teamCode, TEAMLEVEL.SBU)
            ElseIf dtSBU.Rows.Count = 0 Then
                dtSBU = GetTeam(teamCode, TEAMLEVEL.SBU)
            End If
        Catch ex As Exception
            LogHelper.WriteLog("GetMySBU: Failed to execuete SQL: " & sSQLBuilder.ToString, ex)
            Throw ex
        End Try


        GetMySBU = dtSBU

        dtSBU.Dispose()
    End Function

    Function GetMyLeadTeams(ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String, ByVal teamCode As Integer) As DataTable Implements IPmaTeamService.GetMyLeadTeams
        sSQLBuilder = New StringBuilder(sSQLTable)

        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND STATUS = 'A' ")

        sSQLBuilder.Append(" AND ( ([TL_ID] = @LOGONID AND [TL_ID_CARD] = @LOGONIDCARD) OR [DTL_ID] = @LOGONID OR [SUBORDINATE] = @TEAMCODE ) ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@LOGONID", pmaLogonId), _
                                           New SqlParameter("@LOGONIDCARD", pmaLogonIdCard), _
                                           New SqlParameter("@TEAMCODE", teamCode)}

        Try
            GetMyLeadTeams = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

            If Not GetMyLeadTeams Is Nothing Then
                GetMyLeadTeams = GetMyLeadTeams.DefaultView.ToTable(True)
            End If
        Catch ex As Exception
            LogHelper.WriteLog("GetMyLeadTeams: Failed to execute SQL: " & sSQLBuilder.ToString, ex)
            Throw ex
        End Try


    End Function

    Function GetMyLeadTeamCodes(ByVal pmaLogonId As String, ByVal pmaLogonIdCard As String) As String Implements IPmaTeamService.GetMyLeadTeamCodes
        Dim sTeamCodes As String = ""

        sSQLBuilder = New StringBuilder(sSQLTable)

        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND STATUS = 'A' ")

        sSQLBuilder.Append(" AND ( ([TL_ID] = @LOGONID AND [TL_ID_CARD] = @LOGONIDCARD) OR ([DTL_ID] = @LOGONID AND [DTL_ID_CARD] = @LOGONIDCARD) ) ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@LOGONID", pmaLogonId), _
                                           New SqlParameter("@LOGONIDCARD", pmaLogonIdCard)}

        Dim dtTeams As DataTable = New DataTable

        Try
            dtTeams = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

            If dtTeams Is Nothing Then
                Return ""
            ElseIf dtTeams.Rows.Count = 0 Then
                Return ""
            End If

            For Each drTeam As DataRow In dtTeams.Rows

                sTeamCodes = sTeamCodes & IIf(String.IsNullOrEmpty(sTeamCodes), "", ",") & drTeam("team_code")


                GetMyLeadSubTeamCodes(drTeam("team_code"), sTeamCodes)
            Next

        Catch ex As Exception
            LogHelper.WriteLog("GetMyLeadTeamCodes: Failed to execute SQL: " & sSQLBuilder.ToString, ex)
            Throw ex
        Finally
            dtTeams.Dispose()
        End Try


        GetMyLeadTeamCodes = sTeamCodes
    End Function


    Sub GetMyLeadSubTeamCodes(ByVal teamCode As Integer, ByRef sTeamCodes As String)
        sSQLBuilder = New StringBuilder(sSQLTable)

        sSQLBuilder.Append(" WHERE 1 = 1 ")
        sSQLBuilder.Append(" AND STATUS = 'A' ")

        sSQLBuilder.Append(" AND ( [SUBORDINATE] = @TEAMCODE ) ")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@TEAMCODE", teamCode)}

        Dim dtTeams As DataTable = New DataTable
        dtTeams = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)

        If dtTeams Is Nothing Then
            Return
        ElseIf dtTeams.Rows.Count = 0 Then
            Return
        End If

        For Each drTeam As DataRow In dtTeams.Rows
            If Not sTeamCodes.Contains(drTeam("team_code")) Then
                sTeamCodes = sTeamCodes & "," & drTeam("team_code")
            End If
            GetMyLeadSubTeamCodes(drTeam("team_code"), sTeamCodes)
        Next
    End Sub
End Class
#End Region


#Region "Validation"

#End Region
