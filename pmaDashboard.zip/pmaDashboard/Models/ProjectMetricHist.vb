﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization



#Region "Model"



Public Class ProjectMetricHistRawJson
    Private _code As String
    Property code() As String
        Get
            Return _code
        End Get
        Set(ByVal value As String)
            _code = value
        End Set
    End Property

    Private _value As String
    Property value() As String
        Get
            Return _value
        End Get
        Set(ByVal value As String)
            _value = value
        End Set
    End Property

    Public Shared Function DeserializeJsonToList(ByVal jsonText As String) As List(Of ProjectMetricRawJson)

        Dim JsonList As List(Of ProjectMetricRawJson) = Nothing
        If Not String.IsNullOrEmpty(jsonText) Then
            Dim ser As JavaScriptSerializer = New JavaScriptSerializer()
            JsonList = ser.Deserialize(Of List(Of ProjectMetricRawJson))(jsonText)
        End If

        Return JsonList
    End Function
End Class


Public Enum METRICHISTVERSION
    CURRENT = 0
    LAST = -1
End Enum

#End Region

#Region "Service"

Public Interface IProjectMetricHistService

    Function GetBlankProjectMetricHist() As DataTable

    'Get Metric Hist List
    Function GetProjectMetricHistList(ByVal prjCodes As String(), ByVal dataVersion As String, Optional version As Integer = METRICHISTVERSION.CURRENT) As DataTable
    Function GetProjectMetricHistList(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataversion As String, Optional version As Integer = METRICHISTVERSION.CURRENT) As DataTable

    'Get specific Hist version
    Function GetProjectMetricHist(ByVal prjCodes As String(), ByVal dataVersion As String) As DataTable
    Function GetProjectMetricHist(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataversion As String) As DataTable

End Interface

Class ProjectMetricHistService
    Implements IProjectMetricHistService

    Const sHistTable = "[dbo].[tpma_dshbd_prj_metric_hist]"

    Enum EDITMODE As Integer
        ADD = DataRowState.Added
        UPDATE = DataRowState.Modified
        DELETE = DataRowState.Deleted
    End Enum

    Dim mode As Integer = EDITMODE.ADD
    Private sqlHelper As SqlHelper = New SqlHelper()

    Dim pmaPrjService As IPmaProjectService = New PmaProjectService

    Function GetBlankProjectMetricHist() As DataTable Implements IProjectMetricHistService.GetBlankProjectMetricHist
        Dim sSQL As String = "SELECT * FROM " & sHistTable & " WHERE 1 = 0"

        GetBlankProjectMetricHist = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Function GetProjectMetricHistList(ByVal prjCodes As String(), ByVal dataVersion As String, Optional version As Integer = METRICHISTVERSION.CURRENT) As DataTable Implements IProjectMetricHistService.GetProjectMetricHistList
        Dim sSQLPrjCodes As String = ""
        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")

        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        sSQLBuilder.Append(sSQLPrjCodes)


        sSQLBuilder.Append(" AND [DATA_VERSION] = ( ")
        sSQLBuilder.Append(" SELECT MAX([DATA_VERSION]) FROM " & sHistTable & " WHERE [DATA_VERSION] " & IIf(Version = METRICHISTVERSION.CURRENT, "<=", "<") & " @DATAVERSION " & sSQLPrjCodes & ") ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataVersion)


        GetProjectMetricHistList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProjectMetricHistList(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataversion As String, Optional version As Integer = METRICHISTVERSION.CURRENT) As DataTable Implements IProjectMetricHistService.GetProjectMetricHistList

        Dim sSQLPrjCodes As String = ""
        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")


        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        sSQLBuilder.Append(sSQLPrjCodes)


        sSQLBuilder.Append(" AND [metric_code] = @METRICCODE ")
        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@METRICCODE", metricCode)

        sSQLBuilder.Append(" AND [DATA_VERSION] = ( ")
        sSQLBuilder.Append(" SELECT MAX([DATA_VERSION]) FROM " & sHistTable & " WHERE [DATA_VERSION] " & IIf(version = METRICHISTVERSION.LAST, "<", "<=") & " @DATAVERSION " & sSQLPrjCodes & ") ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataversion)


        GetProjectMetricHistList = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProjectMetricHist(ByVal prjCodes As String(), ByVal dataVersion As String) As DataTable Implements IProjectMetricHistService.GetProjectMetricHist
        Dim sSQLPrjCodes As String = ""
        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")

        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        sSQLBuilder.Append(sSQLPrjCodes)


        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION ")
        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataVersion)


        GetProjectMetricHist = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

    Function GetProjectMetricHist(ByVal prjCodes As String(), ByVal metricCode As String, ByVal dataversion As String) As DataTable Implements IProjectMetricHistService.GetProjectMetricHist
        Dim sSQLPrjCodes As String = ""
        Dim iParam As Integer = 0
        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0
        For i As Integer = 0 To prjCodes.Length - 1
            If Not String.IsNullOrEmpty(prjCodes(i)) Then
                If iParam = 0 Then
                    sSQLPrjCodes = sSQLPrjCodes & " AND ( "
                Else
                    sSQLPrjCodes = sSQLPrjCodes & " OR "
                End If

                iParam = iParam + 1
                sSQLPrjCodes = sSQLPrjCodes & " [PRJ_CODE] = @P" & iParam

                iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
                ReDim Preserve sqlParams(iUpperBound)
                sqlParams(iUpperBound) = New SqlParameter("@P" & iParam, prjCodes(i))
            End If
        Next
        If iParam > 0 Then
            sSQLPrjCodes = sSQLPrjCodes & ") "
        End If

        Dim sSQLBuilder As StringBuilder = New StringBuilder("SELECT * FROM " & sHistTable & " WHERE 1 = 1 ")
        sSQLBuilder.Append(sSQLPrjCodes)

        sSQLBuilder.Append(" AND [metric_code] = @METRICCODE ")
        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@METRICCODE", metricCode)

        sSQLBuilder.Append(" AND [DATA_VERSION] = @DATAVERSION ")

        iUpperBound = IIf(sqlParams.Length <= 0, 0, sqlParams.Length)
        ReDim Preserve sqlParams(iUpperBound)
        sqlParams(iUpperBound) = New SqlParameter("@DATAVERSION", dataversion)


        GetProjectMetricHist = sqlHelper.ExecuteReaderQuery(sSQLBuilder.ToString, sqlParams)
    End Function

End Class

#End Region