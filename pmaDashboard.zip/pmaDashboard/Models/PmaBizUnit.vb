﻿Imports System.Data
Imports System.Data.SqlClient



#Region "Model"

'Public Class PmaBizUnitModel
'    Property buCode As Integer
'    Property buName As String
'    Property buFullName As String
'    Property isActive As String

'    Public Sub New()

'    End Sub
'End Class

#End Region


#Region "Service"

Public Interface IPmaBizUnitService

    Function getBizUnitList() As DataTable
    Function getBizUnitFilterList(ByVal viewMode As String) As DataTable
    Function getBizUnitByCode(ByVal buCode As String) As DataTable
    Function getBizUnitNameByCode(ByVal buCode As String) As String

End Interface

Class PmaBizUnitService
    Implements IPmaBizUnitService

    Const sTable = "[dbo].[tpma_business_unit]"
    Private sqlHelper As SqlHelper = New SqlHelper()

    Public Function getBizUnitList() As System.Data.DataTable Implements IPmaBizUnitService.getBizUnitList
        Dim sSQL As String = "SELECT [BU_CODE], [BU_NAME], [BU_NAME] + ' - ' + [BU_CODE] as [DISPLAY_NAME] FROM " & sTable & " WHERE 1 = 1 AND [ACTIVE] = 'Y' "

        getBizUnitList = sqlHelper.ExecuteReaderQuery(sSQL)

    End Function

    Function getBizUnitFilterList(ByVal viewMode As String) As DataTable Implements IPmaBizUnitService.getBizUnitFilterList
        Dim sPrfHistTable As String = "[dbo].[tpma_dshbd_profile_hist]"
        Dim sPrfTable As String = "[dbo].[tpma_dshbd_profile]"

        Dim sSQL As String = "SELECT [BU_CODE], [BU_NAME], [BU_NAME] + ' - ' + [BU_CODE] as [DISPLAY_NAME] FROM " & sTable & " bu WHERE 1 = 1 AND [ACTIVE] = 'Y' "
        If Not String.IsNullOrEmpty(viewMode) Then
            sSQL = sSQL & " AND EXISTS("
            sSQL = sSQL & "SELECT 1 FROM " & IIf(viewMode = PROFILESTATUS.SUBMITTED, sPrfHistTable, sPrfTable) & " WHERE bu_code = bu.bu_code "
            sSQL = sSQL & ")"
        End If

        getBizUnitFilterList = sqlHelper.ExecuteReaderQuery(sSQL)
    End Function

    Function getBizUnitByCode(ByVal buCode As String) As DataTable Implements IPmaBizUnitService.getBizUnitByCode
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE 1 = 1 AND [ACTIVE] = 'Y' AND [BU_CODE] = @BUCODE"
        Dim sqlParams() As SqlParameter = {New SqlParameter("@BUCODE", buCode)}

        getBizUnitByCode = sqlHelper.ExecuteReaderQuery(sSQL, sqlParams)

    End Function

    Function getBizUnitNameByCode(ByVal buCode As String) As String Implements IPmaBizUnitService.getBizUnitNameByCode
        Dim sBUName As String = ""
        Dim dt As DataTable = getBizUnitByCode(buCode)

        If Not dt Is Nothing Then
            If dt.Rows.Count > 0 Then
                sBUName = dt.Rows(0).Item("bu_name").ToString
            End If

        End If

        getBizUnitNameByCode = sBUName
    End Function
End Class

#End Region

