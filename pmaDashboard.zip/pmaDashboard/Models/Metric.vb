﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization



#Region "Model"



Public Class MetricModel
    Private _metricCode As String
    Property metricCode() As String
        Get
            Return _metricCode
        End Get
        Set(ByVal value As String)
            _metricCode = value
        End Set
    End Property

    Private _metricName As String
    Property metricName() As String
        Get
            Return _metricName
        End Get
        Set(ByVal value As String)
            _metricName = value
        End Set
    End Property

    Private _metricDesc As String
    Property metricDesc() As String
        Get
            Return _metricDesc
        End Get
        Set(ByVal value As String)
            _metricDesc = value
        End Set
    End Property


    Private _metricCategory As String
    Property metricCategory() As String
        Get
            Return _metricCategory
        End Get
        Set(ByVal value As String)
            _metricCategory = value
        End Set
    End Property

    Private _metricCategoryDesc As String
    Property metricCategoryDesc() As String
        Get
            Return _metricCategoryDesc
        End Get
        Set(ByVal value As String)
            _metricCategoryDesc = value
        End Set
    End Property

    Private _metricValType As String
    Property metricValType() As String
        Get
            Return _metricValType
        End Get
        Set(ByVal value As String)
            _metricValType = value
        End Set
    End Property

    Private _metricValPrecision As Integer
    Property metricValPrecision() As Integer
        Get
            Return _metricValPrecision
        End Get
        Set(ByVal value As Integer)
            _metricValPrecision = value
        End Set
    End Property

    Private _metricValUpdateMode As String
    Property metricValUpdateMode() As String
        Get
            Return _metricValUpdateMode
        End Get
        Set(ByVal value As String)
            _metricValUpdateMode = value
        End Set
    End Property

    Private _fixedPriceProject As String
    Property fixedPriceProject() As String
        Get
            Return _fixedPriceProject
        End Get
        Set(ByVal value As String)
            _fixedPriceProject = value
        End Set
    End Property

    Private _tssPrjJson As String
    Property tssPrjJson() As String
        Get
            Return _tssPrjJson
        End Get
        Set(ByVal value As String)
            _tssPrjJson = value
        End Set
    End Property

    Private _metricRawJson As String
    Property metricRawJson() As String
        Get
            Return _metricRawJson
        End Get
        Set(ByVal value As String)
            _metricRawJson = value
        End Set
    End Property

    Private _effectBeginDate As Date
    Property effectBeginDate() As Date
        Get
            Return _effectBeginDate
        End Get
        Set(ByVal value As Date)
            _effectBeginDate = value
        End Set
    End Property


    Private _effectEndDate As Date
    Property effectEndDate() As Date
        Get
            Return _effectEndDate
        End Get
        Set(ByVal value As Date)
            _effectEndDate = value
        End Set
    End Property

    Private _isActive As String
    Property isActive() As String
        Get
            Return _isActive
        End Get
        Set(ByVal value As String)
            _isActive = IIf(String.IsNullOrEmpty(value), "Y", value)
        End Set
    End Property

    Private _createdBy As String
    Property createdBy() As String
        Get
            Return _createdBy
        End Get
        Set(ByVal value As String)
            _createdBy = value
        End Set
    End Property

    Private _createdDate As Date
    Property createdDate() As Date
        Get
            Return _createdDate
        End Get
        Set(ByVal value As Date)
            _createdDate = value
        End Set
    End Property

    Private _lastUpdatedBy As String
    Property lastUpdatedBy() As String
        Get
            Return _lastUpdatedBy
        End Get
        Set(ByVal value As String)
            _lastUpdatedBy = value
        End Set
    End Property

    Private _lastUpdatedDate As Date
    Property lastUpdatedDate() As Date
        Get
            Return _lastUpdatedDate
        End Get
        Set(ByVal value As Date)
            _lastUpdatedDate = value
        End Set
    End Property
End Class

Public Enum METRICCODE As Integer
    CSS = 11

    SEV1 = 21
    SEV2 = 22
    DEFECTBAU = 23
    DEFECTPRJ = 24
    DEFECTREMOVAL = 25
    UAT1STPASS = 26
    UATREOPEN = 27
    COPQ = 28

    RESPONSE = 31
    RESOLUTION = 32

    ONSCHEDULE = 41
    SPI = 42
    CPI = 43

End Enum

Public Class TSSPRJMETRIC
    Private _tssPrj As String
    Property tss_prj() As String
        Get
            Return _tssPrj
        End Get
        Set(ByVal value As String)
            _tssPrj = value
        End Set
    End Property

    Private _selected As String
    Property selected() As String
        Get
            Return _selected
        End Get
        Set(ByVal value As String)
            _selected = value
        End Set
    End Property

    Public Shared Function DeserializeJsonToList(ByVal jsonText As String) As List(Of TSSPRJMETRIC)

        Dim JsonList As List(Of TSSPRJMETRIC) = Nothing
        If Not String.IsNullOrEmpty(jsonText) Then
            Dim ser As JavaScriptSerializer = New JavaScriptSerializer()
            JsonList = ser.Deserialize(Of List(Of TSSPRJMETRIC))(jsonText)
        End If

        Return JsonList
    End Function
End Class


Public Class METRICCATEGORY
    Public Shared ReadOnly Property QUALITY As String
        Get
            Return "02"
        End Get
    End Property

    Public Shared ReadOnly Property PRODUCTIONSERVICE As String
        Get
            Return "03"
        End Get
    End Property
End Class
#End Region

#Region "Service"

Public Interface IMetricService


    Function GetMetricList(Optional ByVal isActive As String = "", Optional ByVal metricCategory As String = "") As DataTable
    Function GetMetricListByTssPrj(ByVal tssPrj As String, Optional ByVal isActive As String = "") As DataTable

    Function GetMetric(ByVal metricCode As String, Optional ByVal isActive As String = "Y") As DataTable

    Function GetMetric(ByVal metricModel As MetricModel) As DataTable

    Function GetQualityMetricList() As String


    Function SaveMetric(ByVal dtMetric As DataTable) As Boolean

    Function IsExistedMetric(ByVal metricModal As MetricModel) As Boolean

End Interface

Class MetricService
    Implements IMetricService

    Const sTable = "[dbo].[tpma_dshbd_metric]"
    Dim sSQLTable As String = "SELECT * FROM " & sTable & " "
    Dim sSQL As StringBuilder = New StringBuilder("")
    Private sqlHelper As SqlHelper = New SqlHelper()


    Function GetMetricList(Optional ByVal isActive As String = "", Optional ByVal metricCategory As String = "") As DataTable Implements IMetricService.GetMetricList
        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")

        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0

        If Not String.IsNullOrEmpty(isActive) Then
            sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")

            If sqlParams.Length > 0 Then
                iUpperBound = sqlParams.Length
            End If
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@ISACTIVE", isActive)
        End If

        If Not String.IsNullOrEmpty(metricCategory) Then
            sSQL.Append(" AND [metric_category] = @METRICCATE")

            If sqlParams.Length > 0 Then
                iUpperBound = sqlParams.Length
            End If

            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@METRICCATE", metricCategory)
        End If

        sSQL.Append(" ORDER BY [METRIC_CATEGORY], [METRIC_CODE]")

        If Not sqlParams Is Nothing And sqlParams.Length > 0 Then
            GetMetricList = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
        Else
            GetMetricList = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        End If
    End Function

    Function GetMetricListByTssPrj(ByVal tssPrj As String, Optional isActive As String = "") As DataTable Implements IMetricService.GetMetricListByTssPrj
        If String.IsNullOrEmpty(tssPrj) Then
            Return Nothing
        End If

        Dim dtMetrics As DataTable = New DataTable
        Dim dtReturn As DataTable = New DataTable

        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")

        Dim sqlParams As SqlParameter() = {}
        Dim iUpperBound As Integer = 0

        If Not String.IsNullOrEmpty(isActive) Then
            sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")

            If sqlParams.Length > 0 Then
                iUpperBound = sqlParams.Length
            End If
            ReDim Preserve sqlParams(iUpperBound)
            sqlParams(iUpperBound) = New SqlParameter("@ISACTIVE", isActive)
        End If

        If sqlParams Is Nothing Then
            dtMetrics = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        ElseIf sqlParams.Length = 0 Then
            dtMetrics = sqlHelper.ExecuteReaderQuery(sSQL.ToString)
        Else
            dtMetrics = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
        End If

        If Not dtMetrics Is Nothing Then
            dtReturn = dtMetrics.Clone

            For Each drMetric As DataRow In dtMetrics.Rows
                Dim tssPrjJson As String = drMetric("tss_prj_json").ToString
                Dim tssPrjList As List(Of TSSPRJMETRIC) = TSSPRJMETRIC.DeserializeJsonToList(tssPrjJson)

                If Not tssPrjList Is Nothing Then
                    For i As Integer = 0 To tssPrjList.Count - 1
                        If tssPrjList(i).tss_prj = tssPrj And tssPrjList(i).selected = "Y" Then
                            Dim drPrjMetric As DataRow = dtReturn.NewRow
                            drPrjMetric.ItemArray = drMetric.ItemArray
                            dtReturn.Rows.Add(drPrjMetric)
                            Exit For

                        End If 'End If tssPrjList(i).tss_prj = tssPrj And tssPrjList(i).selected = "Y"

                    Next 'End For i As Integer = 0 To tssPrjList.Count - 1

                End If 'End If Not tssPrjList Is Nothing

            Next 'End For Each drMetric As DataRow In dtMetrics.Rows

        End If 'End If Not dtMetrics Is Nothing

        GetMetricListByTssPrj = dtReturn

        dtMetrics.Dispose()
        dtReturn.Dispose()
    End Function


    Function GetMetric(ByVal metricCode As String, Optional ByVal isActive As String = "Y") As DataTable Implements IMetricService.GetMetric
        sSQL = New StringBuilder(sSQLTable)
        sSQL.Append(" WHERE 1 = 1 ")
        sSQL.Append(" AND [METRIC_CODE] = @METRICCODE")
        sSQL.Append(" AND [IS_ACTIVE] = @ISACTIVE")
        Dim sqlParams As SqlParameter() = {New SqlParameter("@METRICCODE", metricCode), _
                                           New SqlParameter("@ISACTIVE", isActive)}

        GetMetric = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function


    Function GetMetric(ByVal metricModal As MetricModel) As DataTable Implements IMetricService.GetMetric

        sSQL = New StringBuilder(sSQLTable & " WHERE 1 = 1 AND [IS_ACTIVE] = 'Y' ")
        sSQL.Append(" AND [METRIC_CODE] <> @METRICCODE")
        sSQL.Append(" AND [METRIC_CATEGORY] = @METRICCATEGORY ")
        sSQL.Append(" AND [METRIC_NAME] = @METRICNAME ")
        sSQL.Append(" AND [METRIC_VAL_TYPE] = @METRICVALTYPE ")
        sSQL.Append(" AND [METRIC_VAL_PRECISION] = @METRICVALPREC ")
        sSQL.Append(" AND [METRIC_VAL_UPDATE_MODE] = @METRICVALUPD ")
        sSQL.Append(" AND [TSS_PRJ_JSON] = @TSSPRJJSON")
        sSQL.Append(" AND [FIXED_PRICE_PROJECT] = @FIXEDPRICEPRJ")

        Dim sqlParams() As SqlParameter = {New SqlParameter("@METRICCATEGORY", metricModal.metricCategory), _
                                           New SqlParameter("@METRICNAME", metricModal.metricName), _
                                           New SqlParameter("@METRICVALTYPE", metricModal.metricValType), _
                                           New SqlParameter("@METRICVALPREC", metricModal.metricValPrecision), _
                                           New SqlParameter("@METRICVALUPD", metricModal.metricValUpdateMode), _
                                           New SqlParameter("@TSSPRJJSON", metricModal.tssPrjJson), _
                                           New SqlParameter("@FIXEDPRICEPRJ", metricModal.fixedPriceProject), _
                                           New SqlParameter("@METRICCODE", metricModal.metricCode)}

        GetMetric = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)
    End Function

    Function GetQualityMetricList() As String Implements IMetricService.GetQualityMetricList
        Dim sQtyMetricList As String = ""

        sSQL = New StringBuilder(sSQLTable & " WHERE 1 = 1 AND [IS_ACTIVE] = 'Y' ")

        sSQL.Append(" AND ( [METRIC_CATEGORY] = @CATEQTY ")
        sSQL.Append(" OR [METRIC_CATEGORY] = @CATEPRDSERVICE )")

        Dim sqlParams As SqlParameter() = {New SqlParameter("@CATEQTY", METRICCATEGORY.QUALITY), _
                                           New SqlParameter("@CATEPRDSERVICE", METRICCATEGORY.PRODUCTIONSERVICE)}

        Dim dt As DataTable = sqlHelper.ExecuteReaderQuery(sSQL.ToString, sqlParams)

        If Not dt Is Nothing Then
            For Each dr As DataRow In dt.Rows
                sQtyMetricList = sQtyMetricList & IIf(String.IsNullOrEmpty(sQtyMetricList), "", ",") & dr("METRIC_CODE").ToString.Trim
            Next
            dt.Dispose()
        End If

        GetQualityMetricList = sQtyMetricList
    End Function

    Function SaveMetric(ByVal dtmetric As DataTable) As Boolean Implements IMetricService.SaveMetric
        Dim sSQL As String = "SELECT * FROM " & sTable & " WHERE 1 = 0"

        Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sSQL, dtmetric)}
        SaveMetric = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
    End Function


    Function IsExistedMetric(ByVal metricModal As MetricModel) As Boolean Implements IMetricService.IsExistedMetric
        Dim dt As DataTable = GetMetric(metricModal)

        If dt Is Nothing Then
            IsExistedMetric = False
        ElseIf dt.Rows.Count = 0 Then
            IsExistedMetric = False
        Else
            IsExistedMetric = IIf(dt.Rows(0).Item("is_active") = metricModal.isActive, True, False)
        End If

        dt.Dispose()

    End Function
End Class

#End Region