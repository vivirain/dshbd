﻿Imports System.Web
Imports System.IO


Public Class Encrypt
    Inherits System.Web.UI.Page

    Public isValidDashboardUser As Boolean = True
    Public bAlert As Boolean = False
    Public sAlertMsg As String = ""
    Protected app As String = ""

    Shared sKey As String = ""
    Shared sPsw As String = ""

    Dim securityHelper As SecurityHelper = New SecurityHelper

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            sKey = ""
            sPsw = ""

            txtKey.Value = ""
            txtPsw.Value = ""

            txtPasswordEncrypted.Text = ""
            txtPasswordEncrypted.Attributes.Add("readonly", "true")

        End If
    End Sub

    Private Sub btnEncrypt_Click(sender As Object, e As System.EventArgs) Handles btnEncrypt.Click
        Dim _encrypted As String = ""
        sKey = txtKey.Value
        sPsw = txtPsw.Value
        txtPasswordEncrypted.Text = securityHelper.AESRijndaelManaged_Encrypt(sPsw.Trim, sKey.Trim)
    End Sub

End Class
