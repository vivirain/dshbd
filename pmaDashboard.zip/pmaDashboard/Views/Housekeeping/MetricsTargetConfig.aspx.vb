﻿Imports System.Web.Script.Serialization

Public Class MetricsTargetConfig
    Inherits System.Web.UI.Page

    Const LOOKUP_TYPE As String = "B"

    Public Enum PAGEMODE
        ADD = 1
        EDIT = -1
    End Enum

    Shared dtLatestTarget As DataTable = New DataTable
    Shared dtMetric As DataTable = New DataTable("metric")
    Shared dtMetricTarget As DataTable = New DataTable("metricTarget")
    Shared dtMetricTargetView As DataTable = New DataTable("metricTargetView")
    Shared metricTargetId As Integer = 0
    Shared metricTargetYear As Integer = 0
    Shared mode As Integer = PAGEMODE.ADD



    Private lookupService As ILookupService = New LookupService
    Private metricService As IMetricService = New MetricService
    Private metricTargetService As IMetricTargetService = New MetricTargetService


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            metricTargetYear = HttpContext.Current.Items("metricYear")
            mode = HttpContext.Current.Items("mode")

            txtMetricTargetYear.Text = metricTargetYear
            txtMetricTargetYear.ReadOnly = True

            LoadMetricTargetConfigPage()

            EnableButtons()

        End If
    End Sub

#Region "Page_Data"
    Sub LoadMetricTargetConfigPage()

        Dim dtMetrics As DataTable = New DataTable("metrics")

        Dim dtMetricsBau As DataTable = New DataTable("metricsBau")
        Dim dtMetricsBauE As DataTable = New DataTable("metricsBauE")
        Dim dtMetricsPrjDev As DataTable = New DataTable("metricsPrjDev")
        Dim dtMetricsPrjDeploy As DataTable = New DataTable("metricsPrjDeploy")

        dtMetrics = metricService.GetMetricList("Y")

        If Not dtMetrics Is Nothing Then
            dtMetrics.Columns.Add("tss_prj")
            dtMetrics.Columns.Add("metric_target_id")
            dtMetrics.Columns.Add("metric_val")
            dtMetrics.Columns.Add("metric_val_sign")
            dtMetrics.Columns.Add("metric_val_green")
            dtMetrics.Columns.Add("metric_val_amber")
            dtMetrics.Columns.Add("metric_val_red")
            dtMetrics.Columns.Add("metric_val_grey")
            dtMetrics.Columns.Add("percentage")


            dtMetricsBau = dtMetrics.Clone
            dtMetricsBauE = dtMetrics.Clone
            dtMetricsPrjDev = dtMetrics.Clone
            dtMetricsPrjDeploy = dtMetrics.Clone

            For Each drMetric As DataRow In dtMetrics.Rows
                If drMetric("metric_val_type") = "P" Then
                    drMetric("percentage") = "%"
                End If

                Dim sTssPrjJson As String = drMetric("tss_prj_json")
                Dim ser As JavaScriptSerializer = New JavaScriptSerializer
                Dim tssPrjJsonList As List(Of TSSPRJMETRIC) = ser.Deserialize(Of List(Of TSSPRJMETRIC))(sTssPrjJson)
                If Not tssPrjJsonList Is Nothing Then
                    For i As Integer = 0 To tssPrjJsonList.Count - 1
                        Dim tssPrj As String = ""

                        If tssPrjJsonList(i).selected = "Y" Then
                            tssPrj = tssPrjJsonList(i).tss_prj
                            drMetric("tss_prj") = tssPrj

                            Dim drMetricTarget As DataRow = dtMetrics.NewRow
                            drMetricTarget.ItemArray = drMetric.ItemArray

                            If mode = PAGEMODE.EDIT Then
                                LoadMetricTarget(drMetricTarget, tssPrj)
                            End If

                            Select Case tssPrj
                                Case TSSSERVICECATEGORY.BAUM
                                    Dim drMetricBau As DataRow = dtMetricsBau.NewRow
                                    drMetricBau.ItemArray = drMetricTarget.ItemArray
                                    dtMetricsBau.Rows.Add(drMetricBau)

                                Case TSSSERVICECATEGORY.BAUE
                                    Dim drMetricBauE As DataRow = dtMetricsBauE.NewRow
                                    drMetricBauE.ItemArray = drMetricTarget.ItemArray
                                    dtMetricsBauE.Rows.Add(drMetricBauE)

                                Case TSSSERVICECATEGORY.PRJDEVLOPMENT
                                    Dim drMetricsPrjDev As DataRow = dtMetricsPrjDev.NewRow
                                    drMetricsPrjDev.ItemArray = drMetricTarget.ItemArray
                                    dtMetricsPrjDev.Rows.Add(drMetricsPrjDev)

                                Case TSSSERVICECATEGORY.PRJDEPLOY
                                    Dim drMetricsPrjDeploy As DataRow = dtMetricsPrjDeploy.NewRow
                                    drMetricsPrjDeploy.ItemArray = drMetricTarget.ItemArray
                                    dtMetricsPrjDeploy.Rows.Add(drMetricsPrjDeploy)
                            End Select

                        End If
                    Next
                End If 'End If Not tssPrjJsonList Is Nothing
            Next 'End For Each drMetric In dtMetrics.Rows

            If Not dtMetricsBau Is Nothing Then
                WebControlHelper.GridViewDataBind(gvBAU, dtMetricsBau)
            End If
            If Not dtMetricsBauE Is Nothing Then
                WebControlHelper.GridViewDataBind(gvBauE, dtMetricsBauE)
            End If
            If Not dtMetricsPrjDev Is Nothing Then
                WebControlHelper.GridViewDataBind(gvPrjDev, dtMetricsPrjDev)
            End If
            If Not dtMetricsPrjDeploy Is Nothing Then
                WebControlHelper.GridViewDataBind(gvPrjDeploy, dtMetricsPrjDeploy)
            End If

        End If 'End If Not dtMetrics Is Nothing

        dtMetrics.Dispose()
        dtMetricsBau.Dispose()
        dtMetricsBauE.Dispose()
        dtMetricsPrjDev.Dispose()
        dtMetricsPrjDeploy.Dispose()

    End Sub


    Private Sub LoadMetricTarget(ByRef drMetricTarget As DataRow, ByVal tssPrj As String)
        Dim dtMetricTarget As DataTable = New DataTable
        dtMetricTarget = metricTargetService.GetMetricTarget(metricTargetYear, tssPrj, drMetricTarget("metric_code").ToString)
        If Not dtMetricTarget Is Nothing Then
            If dtMetricTarget.Rows.Count > 0 Then
                drMetricTarget("metric_target_id") = dtMetricTarget.Rows(0).Item("metric_target_id").ToString
                drMetricTarget("metric_val") = dtMetricTarget.Rows(0).Item("metric_val").ToString
                drMetricTarget("metric_val_sign") = dtMetricTarget.Rows(0).Item("metric_val_sign").ToString
                drMetricTarget("metric_val_green") = dtMetricTarget.Rows(0).Item("metric_val_green").ToString
                drMetricTarget("metric_val_amber") = dtMetricTarget.Rows(0).Item("metric_val_amber").ToString
                drMetricTarget("metric_val_red") = dtMetricTarget.Rows(0).Item("metric_val_red").ToString
                drMetricTarget("metric_val_grey") = dtMetricTarget.Rows(0).Item("metric_val_grey").ToString
            End If
        End If
    End Sub


    Private Sub PrepareCreateRecord(ByRef gv As GridView, ByRef dtEdit As DataTable, ByVal gvRow As Integer)

        Dim bCreate = True

        Dim txtMetricVal As HtmlInputText = New HtmlInputText
        If Not gv.Rows(gvRow).FindControl("txtMetricVal") Is Nothing Then
            txtMetricVal = CType(gv.Rows(gvRow).FindControl("txtMetricVal"), HtmlInputText)
        End If

        If Not String.IsNullOrEmpty(txtMetricVal.Value.ToString) Then
            Dim drInsert As DataRow = dtEdit.NewRow()

            drInsert.BeginEdit()

            drInsert("metric_year") = metricTargetYear

            Dim txtMetricCode As TextBox = New TextBox
            If Not gv.Rows(gvRow).FindControl("txtMetricCode") Is Nothing Then
                txtMetricCode = CType(gv.Rows(gvRow).FindControl("txtMetricCode"), TextBox)
            End If
            drInsert("metric_code") = txtMetricCode.Text

            Dim txtTssPrj As TextBox = New TextBox
            If Not gv.Rows(gvRow).FindControl("txtTssPrj") Is Nothing Then
                txtTssPrj = CType(gv.Rows(gvRow).FindControl("txtTssPrj"), TextBox)
            End If
            drInsert("tss_prj") = txtTssPrj.Text


            Dim sMetricValType As String = ""
            Dim iMetricValPrec As Integer = 0
            Dim dtMetric As DataTable = New DataTable
            dtMetric = metricService.GetMetric(txtMetricCode.Text)
            If Not dtMetric Is Nothing Then
                If dtMetric.Rows.Count > 0 Then
                    sMetricValType = dtMetric.Rows(0).Item("metric_val_type").ToString
                    iMetricValPrec = dtMetric.Rows(0).Item("metric_val_precision")
                End If
            End If


            Dim ddlMetricValSign As DropDownList = New DropDownList
            If Not gv.Rows(gvRow).FindControl("ddlMetricValSign") Is Nothing Then
                ddlMetricValSign = CType(gv.Rows(gvRow).FindControl("ddlMetricValSign"), DropDownList)
            End If
            drInsert("metric_val_sign") = ddlMetricValSign.SelectedValue.ToString


            drInsert("metric_val") = IIf(sMetricValType = "P", Math.Round(txtMetricVal.Value / 100, iMetricValPrec + 2), txtMetricVal.Value)

            Dim txtMetricValGreen As HtmlInputText = New HtmlInputText
            If Not gv.Rows(gvRow).FindControl("txtMetricValGreen") Is Nothing Then
                txtMetricValGreen = CType(gv.Rows(gvRow).FindControl("txtMetricValGreen"), HtmlInputText)
            End If
            If Not String.IsNullOrEmpty(txtMetricValGreen.Value) Then
                drInsert("metric_val_green") = IIf(sMetricValType = "P", Math.Round(txtMetricValGreen.Value / 100, iMetricValPrec + 2), txtMetricValGreen.Value)
            End If


            Dim txtMetricValAmber As HtmlInputText = New HtmlInputText
            If Not gv.Rows(gvRow).FindControl("txtMetricValAmber") Is Nothing Then
                txtMetricValAmber = CType(gv.Rows(gvRow).FindControl("txtMetricValAmber"), HtmlInputText)
            End If
            If Not String.IsNullOrEmpty(txtMetricValAmber.Value) Then
                drInsert("metric_val_amber") = IIf(sMetricValType = "P", Math.Round(txtMetricValAmber.Value / 100, iMetricValPrec + 2), txtMetricValAmber.Value)
            End If

            Dim txtMetricValRed As HtmlInputText = New HtmlInputText
            If Not gv.Rows(gvRow).FindControl("txtMetricValRed") Is Nothing Then
                txtMetricValRed = CType(gv.Rows(gvRow).FindControl("txtMetricValRed"), HtmlInputText)
            End If
            If Not String.IsNullOrEmpty(txtMetricValRed.Value) Then
                drInsert("metric_val_red") = IIf(sMetricValType = "P", Math.Round(txtMetricValRed.Value / 100, iMetricValPrec + 2), txtMetricValRed.Value)
            End If


            drInsert("is_active") = "Y"
            drInsert("created_by") = Session("logon_id")
            drInsert("created_dt") = Now()
            drInsert("last_updated_by") = Session("logon_id")
            drInsert("last_updated_dt") = Now()

            drInsert.EndEdit()
            dtEdit.Rows.Add(drInsert)
        End If
    End Sub

    Private Sub PrepareUpdateRecord(ByRef gv As GridView, ByRef dtEdit As DataTable, ByVal gvRow As Integer, ByVal metricTargetId As Integer)
        Dim bUpdate As Boolean = False
        Dim bDelete As Boolean = False

        Dim dr As DataRow = dtEdit.Rows.Find(metricTargetId)

        dr.BeginEdit()

        Dim txtMetricVal As HtmlInputText = New HtmlInputText
        If Not gv.Rows(gvRow).FindControl("txtMetricVal") Is Nothing Then
            txtMetricVal = CType(gv.Rows(gvRow).FindControl("txtMetricVal"), HtmlInputText)
        End If
        Dim sMetricVal As String = DataFormatHelper.StringTrim(txtMetricVal.Value)

        'Delete
        If String.IsNullOrEmpty(sMetricVal) Then
            bDelete = True
            'Remove the row
            dr.Delete()
        End If

        'Update
        If Not bDelete Then

            Dim sMetricValType As String = ""
            Dim iMetricValPrec As Integer = 0
            Dim dtMetric As DataTable = New DataTable
            dtMetric = metricService.GetMetric(dr("metric_code").ToString)
            If Not dtMetric Is Nothing Then
                If dtMetric.Rows.Count > 0 Then
                    sMetricValType = dtMetric.Rows(0).Item("metric_val_type").ToString
                    iMetricValPrec = dtMetric.Rows(0).Item("metric_val_precision")
                End If
            End If

            Dim ddlMetricValSign As DropDownList = New DropDownList
            Dim sMetricValSign As String = ""
            If Not gv.Rows(gvRow).FindControl("ddlMetricValSign") Is Nothing Then
                ddlMetricValSign = CType(gv.Rows(gvRow).FindControl("ddlMetricValSign"), DropDownList)
                sMetricValSign = ddlMetricValSign.SelectedValue
            End If
            If IsDBNull(dr("metric_val_sign")) Then
                If String.IsNullOrEmpty(sMetricValSign.Trim) Then
                    'no entry, nothing to do
                ElseIf IsNumeric(sMetricValSign) Then
                    bUpdate = True
                    dr("metric_val_sign") = sMetricValSign
                End If
            ElseIf IsNumeric(dr("metric_val_sign")) Then
                If String.IsNullOrEmpty(sMetricValSign.Trim) Then
                    bUpdate = True
                    dr("metric_val_sign") = DBNull.Value
                ElseIf IsNumeric(sMetricValSign) Then
                    If CInt(dr("metric_val_sign")) <> CInt(sMetricValSign) Then
                        bUpdate = True
                        dr("metric_val_sign") = sMetricValSign
                    End If
                End If
            Else
                If String.IsNullOrEmpty(sMetricValSign.Trim) Then
                    'no entry, nothing to do
                ElseIf IsNumeric(sMetricValSign) Then
                    bUpdate = True
                    dr("metric_val_sign") = sMetricValSign
                End If
            End If

            UpdateMetricValDec(gv, gvRow, "txtMetricVal", dr, "metric_val", bUpdate, sMetricValType, iMetricValPrec)
            UpdateMetricValDec(gv, gvRow, "txtMetricValGreen", dr, "metric_val_green", bUpdate, sMetricValType, iMetricValPrec)
            UpdateMetricValDec(gv, gvRow, "txtMetricValAmber", dr, "metric_val_amber", bUpdate, sMetricValType, iMetricValPrec)
            UpdateMetricValDec(gv, gvRow, "txtMetricValRed", dr, "metric_val_red", bUpdate, sMetricValType, iMetricValPrec)


            If bUpdate Then
                dr("last_updated_by") = Session("logon_id")
                dr("last_updated_dt") = Now()

            End If
        End If 'End If Not bDelete

        If bDelete Or bUpdate Then
            dr.EndEdit()
        Else
            dr.CancelEdit()
        End If

    End Sub

    Private Sub UpdateMetricValDec(ByRef gv As GridView, ByVal gvRow As Integer, ByVal gvControlName As String, ByRef dr As DataRow, ByVal drItemName As String, ByRef bUpdate As Boolean, ByVal metricValType As String, ByVal metricValPrec As Integer)

        Dim txtMetricValDec As HtmlInputText = New HtmlInputText
        If Not gv.Rows(gvRow).FindControl(gvControlName) Is Nothing Then
            txtMetricValDec = CType(gv.Rows(gvRow).FindControl(gvControlName), HtmlInputText)
        End If

        Dim sMetricValDec As String = DataFormatHelper.StringTrim(txtMetricValDec.Value.ToString)
        Dim decMetricVal As Decimal = New Decimal(0)


        If IsDBNull(dr(drItemName)) And String.IsNullOrEmpty(sMetricValDec) Then
            Return
        ElseIf String.IsNullOrEmpty(sMetricValDec) Then
            bUpdate = True
            dr(drItemName) = DBNull.Value
        Else
            decMetricVal = DataFormatHelper.StringToDecimal(sMetricValDec)
            If metricValType = "P" Then
                decMetricVal = Math.Round(decMetricVal / 100, metricValPrec + 2)
            End If

            If IsDBNull(dr(drItemName)) Then
                bUpdate = True
                dr(drItemName) = decMetricVal
            ElseIf dr(drItemName) <> decMetricVal Then
                bUpdate = True
                dr(drItemName) = decMetricVal

            End If

        End If 'End If IsDBNull(dr(drItemName)) And String.IsNullOrEmpty(sMetricValDec)

    End Sub


    Public Sub PrepareEditRecords(ByRef gv As GridView, ByRef dtEdit As DataTable)

        For i As Integer = 0 To gv.Rows.Count - 1
            If gv.Rows(i).RowType = DataControlRowType.DataRow Then

                Dim sMetricTargetId As String = ""
                If Not IsDBNull(gv.DataKeys(i).Values(0)) Then
                    sMetricTargetId = gv.DataKeys(i).Values(0)
                End If


                If String.IsNullOrEmpty(sMetricTargetId) Then
                    'New Records
                    PrepareCreateRecord(gv, dtEdit, i)
                Else
                    'Update / Delete record
                    PrepareUpdateRecord(gv, dtEdit, i, CInt(sMetricTargetId))
                End If
            End If
        Next
    End Sub
#End Region


#Region "Page_Elements"
    Public Sub btnCancel_Click()
        Dim currentCtx As HttpContext = HttpContext.Current
        currentCtx.Items.Remove("metricYear")
        currentCtx.Items.Add("metricYear", metricTargetYear)
        Server.Transfer("MetricsTarget.aspx")
    End Sub


    Public Sub btnSave_Click()
        Dim dtEdit As DataTable = New DataTable
        dtEdit = metricTargetService.GetMetricTargetList(metricTargetYear)
        Dim dtEditPk As DataColumn() = {dtEdit.Columns("metric_target_id")}
        dtEdit.PrimaryKey = dtEditPk

        PrepareEditRecords(gvBAU, dtEdit)
        PrepareEditRecords(gvBauE, dtEdit)
        PrepareEditRecords(gvPrjDev, dtEdit)
        PrepareEditRecords(gvPrjDeploy, dtEdit)


        If metricTargetService.SaveMetricTargetList(dtEdit) Then
            'Page.ClientScript.RegisterStartupScript(Page.GetType(), Guid.NewGuid().ToString(), "<script>alert('Records are updated succefully!');</script>", False)
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "<script>alert('Records are updated succefully!');</script>", False)
            btnCancel_Click()
        Else

        End If
    End Sub

    Private Sub EnableButtons()
        btnCreate_top.Visible = IIf(mode = PAGEMODE.ADD, True, False)
        btnCreate_bottom.Visible = IIf(mode = PAGEMODE.ADD, True, False)

        btnUpdate_top.Visible = IIf(mode = PAGEMODE.ADD, False, True)
        btnUpdate_bottom.Visible = IIf(mode = PAGEMODE.ADD, False, True)


    End Sub

#End Region

#Region "Gridview_Control"
    Public Function GetMetricValSignList() As DataTable
        GetMetricValSignList = lookupService.GetLookUpList(LOOKUP_TYPE, "METRICVALSIGN")
    End Function

    Dim gvRow As Integer = 0
    Private Sub gv_RowDataBound(ByRef gv As GridView, ByRef e As System.Web.UI.WebControls.GridViewRowEventArgs, ByVal colIndex As Integer)

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim txtMetricVal As HtmlInputText = New HtmlInputText
            Dim txtMetricValGreen As HtmlInputText = New HtmlInputText
            Dim txtMetricValAmber As HtmlInputText = New HtmlInputText
            Dim txtMetricValRed As HtmlInputText = New HtmlInputText

            Dim ddlMetricValSignList As DropDownList = New DropDownList
            Dim dtMetricValSign As DataTable = lookupService.GetLookUpList(LOOKUP_TYPE, "METRICVALSIGN")
            Dim drView As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim sMetricValType As String = ""

            Dim iMetricValPrecision As Integer = 0

            If Not e.Row.FindControl("ddlMetricValSign") Is Nothing Then
                ddlMetricValSignList = CType(e.Row.FindControl("ddlMetricValSign"), DropDownList)
                WebControlHelper.DropDownListDataBind(ddlMetricValSignList, dtMetricValSign, "lookup_name", "lookup_code")
                If mode = PAGEMODE.EDIT Then
                    Dim metricValSign As String = ""

                    If Not drView Is Nothing Then
                        metricValSign = DataFormatHelper.StringTrim(drView("metric_val_sign").ToString)
                    End If

                    If Not String.IsNullOrEmpty(metricValSign) Then
                        ddlMetricValSignList.SelectedValue = metricValSign
                    End If
                End If
            End If 'End If Not e.Row.FindControl("ddlMetricValSign") Is Nothing 


            If Not drView Is Nothing Then
                sMetricValType = drView("metric_val_type").ToString
                iMetricValPrecision = DataFormatHelper.StringToInteger(drView("metric_val_precision").ToString)
            End If

            If Not e.Row.FindControl("txtMetricVal") Is Nothing Then
                txtMetricVal = CType(e.Row.FindControl("txtMetricVal"), HtmlInputText)
                RenderInputTextControl(txtMetricVal, sMetricValType, iMetricValPrecision)
            End If

            If Not e.Row.FindControl("txtMetricValGreen") Is Nothing Then
                txtMetricValGreen = CType(e.Row.FindControl("txtMetricValGreen"), HtmlInputText)
                RenderInputTextControl(txtMetricValGreen, sMetricValType, iMetricValPrecision)
            End If

            If Not e.Row.FindControl("txtMetricValAmber") Is Nothing Then
                txtMetricValAmber = CType(e.Row.FindControl("txtMetricValAmber"), HtmlInputText)
                RenderInputTextControl(txtMetricValAmber, sMetricValType, iMetricValPrecision)
            End If

            If Not e.Row.FindControl("txtMetricValRed") Is Nothing Then
                txtMetricValRed = CType(e.Row.FindControl("txtMetricValRed"), HtmlInputText)
                RenderInputTextControl(txtMetricValRed, sMetricValType, iMetricValPrecision)
            End If

            WebControlHelper.GridViewCellMerging(gv, e, colIndex, gvRow)
        End If

    End Sub


    Private Sub RenderInputTextControl(ByRef txtInput As HtmlInputText, ByVal metricType As String, ByVal metricPrec As Integer)
        Dim valInput As String = DataFormatHelper.FormatString(txtInput.Value.ToString, metricType, metricPrec)
        If Not String.IsNullOrEmpty(valInput) Then
            txtInput.Value = IIf(valInput.EndsWith("%"), valInput.Substring(0, valInput.Length - 1), valInput)
        End If

        txtInput.Attributes.Add("onkeyup", "formatNumber(this, '" & metricType & "', " & metricPrec & ")")
        txtInput.Attributes.Add("onblur", "ValidateNumber(this, '" & metricType & "', " & metricPrec & ")")
    End Sub

    Private Sub gvBAU_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvBAU.RowDataBound
        gv_RowDataBound(gvBAU, e, 4)

    End Sub

    Private Sub gvBauE_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvBauE.RowDataBound
        gv_RowDataBound(gvBauE, e, 4)
    End Sub

    Private Sub gvPrjDev_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvPrjDev.RowDataBound
        gv_RowDataBound(gvPrjDev, e, 4)
    End Sub

    Private Sub gvPrjDeploy_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvPrjDeploy.RowDataBound
        gv_RowDataBound(gvPrjDeploy, e, 4)
    End Sub


#End Region

End Class