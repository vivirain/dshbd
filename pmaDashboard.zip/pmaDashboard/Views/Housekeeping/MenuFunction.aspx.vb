﻿Public Class MenuFunction
    Inherits System.Web.UI.Page

    Shared dtMenu As DataTable = New DataTable("menu")

    Dim menuService As IMenuService = New MenuService

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            LoadRoles()
        End If

    End Sub

    Private Sub LoadRoles()

        dtMenu = menuService.GetMenuItems

        If Not dtMenu Is Nothing Then
            BindData()
        End If
    End Sub

    Private Sub BindData()
        Dim sSortExpression As String = ViewState("SortOrder")
        Dim sSortDirection As String = ViewState("SortDirect")

        If Not String.IsNullOrEmpty(sSortExpression) And Not String.IsNullOrEmpty(sSortDirection) Then
            dtMenu.DefaultView.Sort = String.Format("{0} {1}", sSortExpression, sSortDirection)
        End If

        WebControlHelper.GridViewDataBind(gvMenuList, dtMenu)
    End Sub

    Private Sub gvMenuList_DataBound(sender As Object, e As System.EventArgs) Handles gvMenuList.DataBound
        gvMenuList.Columns(1).Visible = False
    End Sub



    Private Sub gvMenuList_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvMenuList.Sorting

        Dim sSortExpression As String = e.SortExpression
        Dim sSortDirection As String = e.SortDirection

        If String.IsNullOrEmpty(ViewState("SortOrder")) Then
            ViewState("SortOrder") = sSortExpression
        End If

        If String.IsNullOrEmpty(ViewState("SortDirect")) Then
            ViewState("SortDirect") = "ASC"
        End If

        If (ViewState("SortOrder").ToString = sSortExpression) Then
            If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                ViewState("SortDirect") = "ASC"
            Else
                ViewState("SortDirect") = "DESC"
            End If
        Else
            ViewState("SortOrder") = e.SortExpression
        End If

        BindData()

    End Sub


    Private Sub gvMenuList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvMenuList.RowDataBound
        Dim sChevronUp As String = " <span class='glyphicon glyphicon-chevron-up'></span>"
        Dim sChevronDown As String = " <span class='glyphicon glyphicon-chevron-down'></span>"
        Dim sChevron As String = sChevronUp

        If e.Row.RowType = DataControlRowType.Header Then
            For i As Integer = 0 To e.Row.Cells.Count - 1
                Dim cons As ControlCollection = e.Row.Cells(i).Controls
                For j As Integer = 0 To e.Row.Cells(i).Controls.Count - 1
                    Dim lb As LinkButton = CType(cons(j), LinkButton)
                    If Not lb Is Nothing Then
                        If Not String.IsNullOrEmpty(ViewState("SortOrder")) Then
                            If ViewState("SortOrder").ToString = lb.CommandArgument Then
                                If Not String.IsNullOrEmpty(ViewState("SortDirect")) Then
                                    If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                                        sChevron = sChevronDown
                                    End If
                                End If
                            End If

                            lb.Text = lb.Text & sChevron
                        End If

                    End If
                Next
            Next
        End If
    End Sub

    Private Sub gvMenuList_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvMenuList.RowCommand
        If e.CommandName = "editData" Then
            Dim index As String = CType(e.CommandArgument(), Integer)

            Dim gvRow As GridViewRow = gvMenuList.Rows(index)


        End If
    End Sub
End Class