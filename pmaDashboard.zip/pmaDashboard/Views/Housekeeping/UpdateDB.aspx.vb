﻿Public Class UpdateDB
    Inherits System.Web.UI.Page

    Shared dtRole As DataTable = New DataTable
    Shared dtBu As DataTable = New DataTable

    Dim sqlHelper As SqlHelper = New SqlHelper

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then


        End If

    End Sub


    Private Sub btnUpd_Click(sender As Object, e As System.EventArgs) Handles btnUpd.Click
        Dim iResult As Integer = sqlHelper.ExecuteNonQuery(txtDBScripts.InnerText)
    End Sub

    Private Sub btnSel_Click(sender As Object, e As System.EventArgs) Handles btnSel.Click
        Dim dt As DataTable = New DataTable
        dt = sqlHelper.ExecuteReaderQuery(txtDBScripts.InnerText)

        If Not dt Is Nothing Then
            WebControlHelper.GridViewDataBind(gvResult, dt)
        End If
    End Sub

    Private Sub btnDrop_Click(sender As Object, e As System.EventArgs) Handles btnDrop.Click
        Dim iResult As Integer = sqlHelper.ExecuteNonQuery(txtDBScripts.InnerText)
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As System.EventArgs) Handles btnCreate.Click
        Dim iResult As Integer = sqlHelper.ExecuteNonQuery(txtDBScripts.InnerText)
    End Sub
End Class