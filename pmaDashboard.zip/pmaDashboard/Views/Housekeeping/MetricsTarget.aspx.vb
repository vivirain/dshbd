﻿Imports System.Web.Script.Serialization

Public Class MetricsTarget
    Inherits System.Web.UI.Page


    Shared dtLatestTarget As DataTable = New DataTable
    Shared dtTargetList As DataTable = New DataTable("metricTarget")
    Shared metricTargetId As Integer = 0
    Shared metricTargetYear As Integer = 0

    Private metricService As IMetricService = New MetricService
    Private metricTargetService As IMetricTargetService = New MetricTargetService



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not Page.IsPostBack Then
            metricTargetYear = HttpContext.Current.Items("metricYear")

            LoadYears()

            If metricTargetYear = 0 Then
                metricTargetYear = lstMetricTargetYear.SelectedValue
            End If

            If metricTargetService.HaveMetricTarget(metricTargetYear) Then
                QueryTargetRecords()
                btnEdit.Visible = True
                btnCreate.Visible = False
                dvMetricTargetList.Style.Add("display", "block")
            Else
                btnEdit.Visible = False
                btnCreate.Visible = True
                'dvMetricTargetList.style.disable = "none"
                dvMetricTargetList.Style.Add("display", "none")
            End If
        End If
    End Sub


#Region "Page_Elements"

    'Handle Create Button
    Private Sub btnCreate_Click(sender As Object, e As System.EventArgs) Handles btnCreate.Click
        metricTargetYear = lstMetricTargetYear.SelectedValue

        Dim currentCtx As HttpContext = HttpContext.Current
        currentCtx.Items.Remove("mode")
        currentCtx.Items.Remove("metricYear")
        currentCtx.Items.Add("mode", 1)
        currentCtx.Items.Add("metricYear", metricTargetYear)
        Server.Transfer("MetricsTargetConfig.aspx")

        'Response.Redirect("MetricsTargetConfig.aspx?mode=1&metricYear=" & metricTargetYear)
    End Sub


    'Handle Edit Button
    Private Sub btnEdit_Click(sender As Object, e As System.EventArgs) Handles btnEdit.Click
        Dim currentCtx As HttpContext = HttpContext.Current
        currentCtx.Items.Remove("mode")
        currentCtx.Items.Remove("metricYear")
        currentCtx.Items.Add("mode", -1)
        currentCtx.Items.Add("metricYear", metricTargetYear)

        Server.Transfer("MetricsTargetConfig.aspx")
    End Sub

    'DropdownList lstMetricTargetYear
    Private Sub lstMetricTargetYear_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles lstMetricTargetYear.SelectedIndexChanged
        metricTargetYear = lstMetricTargetYear.SelectedValue

        If metricTargetService.HaveMetricTarget(metricTargetYear) Then
            btnEdit.Visible = True
            btnCreate.Visible = False

            QueryTargetRecords()
        Else
            btnEdit.Visible = False
            btnCreate.Visible = True
        End If
    End Sub

    Private Sub LoadYears()
        lstMetricTargetYear.Items.Clear()
        For iYear As Integer = 2016 To 2036
            lstMetricTargetYear.Items.Add(New ListItem(iYear))
        Next
        lstMetricTargetYear.DataBind()


        If metricTargetYear = 0 Then
            dtLatestTarget = metricTargetService.GetLatestMetricTargetList()

            If Not dtLatestTarget Is Nothing Then
                If dtLatestTarget.Rows.Count > 0 Then
                    lstMetricTargetYear.SelectedValue = dtLatestTarget.Rows(0).Item("Metric_Year").ToString
                Else
                    lstMetricTargetYear.SelectedValue = Now.Year
                End If
            Else
                lstMetricTargetYear.SelectedValue = Now.Year
            End If
        Else
            lstMetricTargetYear.SelectedValue = metricTargetYear
        End If


    End Sub
#End Region


#Region "Page_Data"
    Private Sub QueryTargetRecords()
        Dim dtMetrics As DataTable = New DataTable("metrics")

        Dim dtMetricsBau As DataTable = New DataTable("metricsBau")
        Dim dtMetricsBauE As DataTable = New DataTable("metricsBauE")
        Dim dtMetricsPrjDev As DataTable = New DataTable("metricsPrjDev")
        Dim dtMetricsPrjDeploy As DataTable = New DataTable("metricsPrjDeploy")


        dtMetrics = metricService.GetMetricList("Y")

        If Not dtMetrics Is Nothing Then
            dtMetrics.Columns.Add("tss_prj")
            dtMetrics.Columns.Add("metric_target_id")
            dtMetrics.Columns.Add("metric_val")
            dtMetrics.Columns.Add("metric_val_sign")
            dtMetrics.Columns.Add("metric_val_green")
            dtMetrics.Columns.Add("metric_val_amber")
            dtMetrics.Columns.Add("metric_val_red")
            dtMetrics.Columns.Add("metric_val_grey")


            dtMetricsBau = dtMetrics.Clone
            dtMetricsBauE = dtMetrics.Clone
            dtMetricsPrjDev = dtMetrics.Clone
            dtMetricsPrjDeploy = dtMetrics.Clone

            For Each drMetric In dtMetrics.Rows
                Dim sTssPrjJson As String = drMetric("tss_prj_json")
                Dim ser As JavaScriptSerializer = New JavaScriptSerializer
                Dim tssPrjJsonList As List(Of TSSPRJMETRIC) = ser.Deserialize(Of List(Of TSSPRJMETRIC))(sTssPrjJson)
                If Not tssPrjJsonList Is Nothing Then
                    For i As Integer = 0 To tssPrjJsonList.Count - 1
                        Dim tssPrj As String = ""

                        If tssPrjJsonList(i).selected = "Y" Then
                            tssPrj = tssPrjJsonList(i).tss_prj
                            drMetric("tss_prj") = tssPrj

                            Dim drMetricTarget As DataRow = dtMetrics.NewRow
                            drMetricTarget.ItemArray = drMetric.ItemArray

                            LoadMetricTarget(drMetricTarget, tssPrj)

                            Select Case tssPrj
                                Case TSSSERVICECATEGORY.BAUM
                                    Dim drMetricBau As DataRow = dtMetricsBau.NewRow
                                    drMetricBau.ItemArray = drMetricTarget.ItemArray
                                    dtMetricsBau.Rows.Add(drMetricBau)

                                Case TSSSERVICECATEGORY.BAUE
                                    Dim drMetricBauE As DataRow = dtMetricsBauE.NewRow
                                    drMetricBauE.ItemArray = drMetricTarget.ItemArray
                                    dtMetricsBauE.Rows.Add(drMetricBauE)

                                Case TSSSERVICECATEGORY.PRJDEVLOPMENT
                                    Dim drMetricsPrjDev As DataRow = dtMetricsPrjDev.NewRow
                                    drMetricsPrjDev.ItemArray = drMetricTarget.ItemArray
                                    dtMetricsPrjDev.Rows.Add(drMetricsPrjDev)

                                Case TSSSERVICECATEGORY.PRJDEPLOY
                                    Dim drMetricsPrjDeploy As DataRow = dtMetricsPrjDeploy.NewRow
                                    drMetricsPrjDeploy.ItemArray = drMetricTarget.ItemArray
                                    dtMetricsPrjDeploy.Rows.Add(drMetricsPrjDeploy)
                            End Select

                        End If
                    Next
                End If 'End If Not tssPrjJsonList Is Nothing
            Next 'End For Each drMetric In dtMetrics.Rows

            If Not dtMetricsBau Is Nothing Then
                WebControlHelper.GridViewDataBind(gvBau, dtMetricsBau)
            End If
            If Not dtMetricsBauE Is Nothing Then
                WebControlHelper.GridViewDataBind(gvBauE, dtMetricsBauE)
            End If
            If Not dtMetricsPrjDev Is Nothing Then
                WebControlHelper.GridViewDataBind(gvPrjDev, dtMetricsPrjDev)
            End If
            If Not dtMetricsPrjDeploy Is Nothing Then
                WebControlHelper.GridViewDataBind(gvPrjDeploy, dtMetricsPrjDeploy)
            End If

        End If 'End If Not dtMetrics Is Nothing

        dtMetrics.Dispose()
        dtMetricsBau.Dispose()
        dtMetricsBauE.Dispose()
        dtMetricsPrjDev.Dispose()
        dtMetricsPrjDeploy.Dispose()

    End Sub


    Private Sub LoadMetricTarget(ByRef drMetric As DataRow, ByVal tssPrj As String)
        Dim dtMetricTarget As DataTable = New DataTable
        dtMetricTarget = metricTargetService.GetMetricTarget(metricTargetYear, tssPrj, drMetric("metric_code").ToString)
        If Not dtMetricTarget Is Nothing Then
            If dtMetricTarget.Rows.Count > 0 Then
                drMetric("metric_target_id") = dtMetricTarget.Rows(0).Item("metric_target_id").ToString
                drMetric("metric_val") = dtMetricTarget.Rows(0).Item("metric_val").ToString
                drMetric("metric_val_sign") = dtMetricTarget.Rows(0).Item("metric_val_sign").ToString
                drMetric("metric_val_green") = dtMetricTarget.Rows(0).Item("metric_val_green").ToString
                drMetric("metric_val_amber") = dtMetricTarget.Rows(0).Item("metric_val_amber").ToString
                drMetric("metric_val_red") = dtMetricTarget.Rows(0).Item("metric_val_red").ToString
                drMetric("metric_val_grey") = dtMetricTarget.Rows(0).Item("metric_val_grey").ToString
            End If
        End If
    End Sub

    Shared Function FormatMetricVal(ByVal metricVal As String, ByVal metricValType As String, ByVal metricValPrecision As String)
        Dim returnVal As String = metricVal

        If Not String.IsNullOrEmpty(metricVal) Then
            FormatMetricVal = DataFormatHelper.FormatString(metricVal, metricVal, metricValPrecision)
        End If

        FormatMetricVal = returnVal
    End Function
#End Region







#Region "Gridview_Control"
    Dim gvRow As Integer = 0
    Private Sub gv_RowDataBound(ByRef gv As GridView, ByRef e As System.Web.UI.WebControls.GridViewRowEventArgs, ByVal colIndex As Integer)

        If e.Row.RowType = DataControlRowType.Header Then
        End If

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lblMetricVal As Label = New Label
            Dim txtMetricValGreen As TextBox = New TextBox
            Dim txtMetricValAmber As TextBox = New TextBox
            Dim txtMetricValRed As TextBox = New TextBox
            Dim drView As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim sMetricValType As String = ""
            Dim iMetricValPrecision As Integer = 0

            If Not drView Is Nothing Then
                sMetricValType = drView("metric_val_type").ToString
                iMetricValPrecision = DataFormatHelper.StringToInteger(drView("metric_val_precision").ToString)
            End If

            e.Row.Cells(9).Text = DataFormatHelper.FormatString(e.Row.Cells(9).Text, sMetricValType, iMetricValPrecision)
            e.Row.Cells(10).Text = DataFormatHelper.FormatString(e.Row.Cells(10).Text, sMetricValType, iMetricValPrecision)
            e.Row.Cells(11).Text = DataFormatHelper.FormatString(e.Row.Cells(11).Text, sMetricValType, iMetricValPrecision)
            e.Row.Cells(12).Text = DataFormatHelper.FormatString(e.Row.Cells(12).Text, sMetricValType, iMetricValPrecision)

            WebControlHelper.GridViewCellMerging(gv, e, colIndex, gvRow)
        End If

    End Sub

    Private Sub gvBAU_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvBAU.RowDataBound
        gv_RowDataBound(gvBAU, e, 4)
    End Sub

    Private Sub gvBauE_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvBauE.RowDataBound
        gv_RowDataBound(gvBauE, e, 4)
    End Sub

    Private Sub gvPrjDev_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvPrjDev.RowDataBound
        gv_RowDataBound(gvPrjDev, e, 4)
    End Sub

    Private Sub gvPrjDeploy_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvPrjDeploy.RowDataBound
        gv_RowDataBound(gvPrjDeploy, e, 4)
    End Sub
#End Region









End Class