﻿Public Class Authority
    Inherits System.Web.UI.Page

    Shared dtRole As DataTable = New DataTable
    Shared dtBu As DataTable = New DataTable

    Dim lookupService As ILookupService = New LookupService
    Dim pmaTeamService As IPmaTeamService = New PmaTeamService
    Dim userRoleService As IUserRoleService = New UserRoleService

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Dim authority As String = HttpContext.Current.Items("Authority")

            If String.IsNullOrEmpty(authority) Then
                InitDropdownList()
            Else
                InitDropdownList(authority)
            End If

            QueryData()
        End If

    End Sub

    Private Sub QueryData()
        dvRoleList.Style.Add("display", "none")
        dvBuList.Style.Add("display", "none")

        Select Case ddlAuthority.SelectedValue
            Case "ROLE"
                LoadRoles()
                dvRoleList.Style.Add("display", "")
            Case "BU"
                LoadBus()
                dvBuList.Style.Add("display", "")
        End Select
    End Sub


#Region "Role"
    Private Sub LoadRoles()
        Dim roleService As IRoleService = New RoleService

        dtRole = roleService.GetRoleList

        If Not dtRole Is Nothing Then
            dtRole.Columns.Add("roleUsers")

            For Each dr As DataRow In dtRole.Rows
                Dim dtRoleUsers As DataTable = New DataTable
                Dim userRoleService As IUserRoleService = New UserRoleService
                dtRoleUsers = userRoleService.GetUserRoleList(dr("role_id"))

                If Not dtRoleUsers Is Nothing Then
                    Dim sRoleUsers As StringBuilder = New StringBuilder("")
                    For Each drRoleUser As DataRow In dtRoleUsers.Rows
                        If Not String.IsNullOrEmpty(sRoleUsers.ToString) Then
                            sRoleUsers.Append(", ")
                        End If
                        'sRoleUsers.Append(drRoleUser("pma_logon_id"))
                        Dim pmaUserService As IPmaUserService = New PmaUserService
                        sRoleUsers.Append(pmaUserService.GetActiveUserNameByLogonId(drRoleUser("pma_logon_id")))
                    Next
                    dr("roleUsers") = sRoleUsers.ToString
                End If
            Next

            BindData(gvRoleList, dtRole)

        End If
    End Sub

    Private Sub gvRoleList_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvRoleList.RowCommand
        If e.CommandName = "editRoleUsers" Then

            Dim index As String = CType(e.CommandArgument(), Integer)

            Dim btnLink As LinkButton = CType(gvRoleList.Rows(index).Cells(1).Controls(0), LinkButton)
            Dim roleName As String = btnLink.Text


            Dim roleId As Integer = gvRoleList.DataKeys(index).Item(0)

            HttpContext.Current.Items.Remove("roleId")
            HttpContext.Current.Items.Remove("roleName")
            HttpContext.Current.Items.Add("roleId", roleId)
            HttpContext.Current.Items.Add("roleName", roleName)

            Server.Transfer("RoleUsers.aspx")
        End If
    End Sub

    Private Sub gvRoleList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvRoleList.RowDataBound
        gv_RowDataBound(gvRoleList, e)
    End Sub

    Private Sub gvRoleList_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvRoleList.Sorting
        gv_Sorting(gvRoleList, dtRole, e)
    End Sub
#End Region

#Region "BU"
    Private Sub LoadBus()
        Dim buService As IPmaBizUnitService = New PmaBizUnitService

        dtBu = buService.getBizUnitList

        If Not dtBu Is Nothing Then
            dtBu.Columns.Add("buUsers")

            For Each drBu As DataRow In dtBu.Rows
                Dim dtBuUsers As DataTable = New DataTable

                Dim userBuService As IUserBuService = New UserBuService
                dtBuUsers = userBuService.GetUserBuList(drBu("bu_code"))


                If Not dtBuUsers Is Nothing Then
                    Dim sBuUsers As StringBuilder = New StringBuilder("")
                    For Each drBuUser As DataRow In dtBuUsers.Rows
                        If Not String.IsNullOrEmpty(sBuUsers.ToString) Then
                            sBuUsers.Append(", ")
                        End If
                        'sRoleUsers.Append(drRoleUser("pma_logon_id"))
                        Dim pmaUserService As IPmaUserService = New PmaUserService
                        sBuUsers.Append(pmaUserService.GetActiveUserNameByLogonId(drBuUser("pma_logon_id")))
                    Next
                    drBu("buUsers") = sBuUsers.ToString
                End If
            Next

            BindData(gvBuList, dtBu)

        End If
    End Sub

    Private Sub gvBuList_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvBuList.RowCommand
        If e.CommandName = "editBuUsers" Then

            Dim index As String = CType(e.CommandArgument(), Integer)
            Dim gvRow As GridViewRow = gvBuList.Rows(index)

            Dim buCode As String = gvBuList.DataKeys(index).Item(0)
            Dim buName As String = CType(gvRow.Cells(1).Controls(0), LinkButton).Text

            HttpContext.Current.Items.Remove("buCode")
            HttpContext.Current.Items.Remove("buName")
            HttpContext.Current.Items.Add("buCode", buCode)
            HttpContext.Current.Items.Add("buName", buName)

            Server.Transfer("BuUsers.aspx")
        End If
    End Sub

    Private Sub gvBuList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvBuList.RowDataBound
        gv_RowDataBound(gvBuList, e)
    End Sub

    Private Sub gvBuList_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvBuList.Sorting
        gv_Sorting(gvBuList, dtBu, e)
    End Sub


#End Region

#Region "Page_Elements"
    Private Sub ddlAuthority_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlAuthority.SelectedIndexChanged
        QueryData()
    End Sub

    Private Sub btnQuery_Click(sender As Object, e As System.EventArgs) Handles btnQuery.Click
        QueryData()
    End Sub

    Private Sub InitDropdownList(Optional ByVal authority As String = "ROLE")
        Dim dtLookup As DataTable = New DataTable
        dtLookup = lookupService.GetLookUpList("S", "AUTHORITY")

        If Not dtLookup Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlAuthority, dtLookup, "lookup_name", "lookup_code", False)
            ddlAuthority.SelectedValue = authority
        End If
    End Sub

    Private Sub BindData(ByRef gv As GridView, ByRef dt As DataTable)
        Dim sSortExpression As String = ViewState("SortOrder")
        Dim sSortDirection As String = ViewState("SortDirect")

        If Not String.IsNullOrEmpty(sSortExpression) And Not String.IsNullOrEmpty(sSortDirection) Then
            dt.DefaultView.Sort = String.Format("{0} {1}", sSortExpression, sSortDirection)
        End If

        gv.DataSource = dt
        gv.DataBind()
    End Sub

    Private Sub gv_Sorting(ByRef gv As GridView, ByRef dt As DataTable, ByRef e As System.Web.UI.WebControls.GridViewSortEventArgs)
        Dim sSortExpression As String = e.SortExpression
        Dim sSortDirection As String = e.SortDirection

        If String.IsNullOrEmpty(ViewState("SortOrder")) Then
            ViewState("SortOrder") = sSortExpression
        End If

        If String.IsNullOrEmpty(ViewState("SortDirect")) Then
            ViewState("SortDirect") = "ASC"
        End If

        If (ViewState("SortOrder").ToString = sSortExpression) Then
            If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                ViewState("SortDirect") = "ASC"
            Else
                ViewState("SortDirect") = "DESC"
            End If
        Else
            ViewState("SortOrder") = e.SortExpression
        End If

        BindData(gv, dt)
    End Sub

    Private Sub gv_RowDataBound(ByRef gv As GridView, ByRef e As System.Web.UI.WebControls.GridViewRowEventArgs)
        Dim sChevronUp As String = " <span class='glyphicon glyphicon-chevron-up'></span>"
        Dim sChevronDown As String = " <span class='glyphicon glyphicon-chevron-down'></span>"
        Dim sChevron As String = sChevronUp

        If e.Row.RowType = DataControlRowType.Header Then
            For i As Integer = 0 To e.Row.Cells.Count - 1
                Dim cons As ControlCollection = e.Row.Cells(i).Controls
                For j As Integer = 0 To e.Row.Cells(i).Controls.Count - 1
                    Dim lb As LinkButton = CType(cons(j), LinkButton)
                    If Not lb Is Nothing Then
                        If Not String.IsNullOrEmpty(ViewState("SortOrder")) Then
                            If ViewState("SortOrder").ToString = lb.CommandArgument Then
                                If Not String.IsNullOrEmpty(ViewState("SortDirect")) Then
                                    If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                                        sChevron = sChevronDown
                                    End If
                                End If
                            End If

                            lb.Text = lb.Text & sChevron
                        End If

                    End If
                Next
            Next
        End If
    End Sub
#End Region

End Class