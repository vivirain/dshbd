﻿Public Class ReferenceDataCategory
    Inherits System.Web.UI.Page

    Const LOOKUP_CATE_BIZ As String = "BIZCATE"
    Const LOOKUP_CATE_SYS As String = "SYSCATE"
    'Const LOOKUP_CATE_DESC As String = "Business Category"

    Enum PAGEMODE As Integer
        EDIT = -1
        READ = 0
        ADD = 1
    End Enum

    Public Shared mode As Integer = PAGEMODE.READ
    Public Shared bAlert As Boolean = False
    Public Shared sAlertMsg As StringBuilder = New StringBuilder("")


    Shared dtLookupList As DataTable = New DataTable("DataCateLitst")
    Shared dtLookup As DataTable = New DataTable("DataCate")

    Shared lookupCode As String = ""
    Shared lookupCate As String = ""
    Shared lookupCateDesc As String = ""
    Shared lookupType As String = ""

    Private lookupService As ILookupService = New LookupService

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lookupType = HttpContext.Current.Items("lookupType")
            lookupCode = HttpContext.Current.Items("lookupCode")

            InitDropDownList()

            LoadDataCatePage()
        End If
    End Sub

    Private Sub LoadDataCatePage()
        If mode = PAGEMODE.READ Then
            PrepareDataCateList()
        Else
            PrepareDataCate()
        End If

        EnableSection()

    End Sub

    Private Sub QueryData()
        lookupCode = ddlRefCategory.SelectedValue
        Session("lookupCode") = lookupCode

        PrepareDataCateList()
    End Sub

#Region "gvDatacateList"

    Private Sub PrepareDataCateList()
        ddlRefCategory.SelectedValue = lookupCode

        dtLookupList = lookupService.GetLookUpList(ddlRef.SelectedValue, lookupCate, lookupCode)


        If Not dtLookupList Is Nothing Then
            WebControlHelper.GridViewDataBind(gvDataCateList, dtLookupList)
        End If

    End Sub

    Private Sub gvDatacateList_PageIndexChanging(sender As Object, e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvDataCateList.PageIndexChanging
        gvDataCateList.PageIndex = e.NewPageIndex

        WebControlHelper.GridViewDataBind(gvDataCateList, dtLookupList)

    End Sub

    Private Sub gvDatacateList_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvDataCateList.RowCommand
        If e.CommandName = "viewDataList" Then
            Dim index As String = CType(e.CommandArgument(), Integer)

            Dim gvRow As GridViewRow = gvDataCateList.Rows(index)

            Dim lookupCate As String = gvRow.Cells(3).Text

            HttpContext.Current.Items.Remove("lookupType")
            HttpContext.Current.Items.Remove("lookupCate")
            HttpContext.Current.Items.Add("lookupType", ddlRef.SelectedValue)
            HttpContext.Current.Items.Add("lookupCate", lookupCate)
            Server.Transfer("ReferenceData.aspx")
        End If
    End Sub

#End Region



#Region "DataCate"
    Private Sub PrepareDataCate()

        If mode = PAGEMODE.ADD Then
            ddlActive.SelectedValue = "Y"

            dtLookup = dtLookupList.Clone
        Else

            ddlRefCategory.SelectedValue = lookupCode

            dtLookup = lookupService.GetLookUp(ddlRef.SelectedValue, lookupCate, lookupCode)

            If Not dtLookup Is Nothing Then
                If dtLookup.Rows.Count > 0 Then
                    Dim drLookUp As DataRow = dtLookup.Rows(0)

                    txtId.Text = drLookUp("lookup_id")
                    txtCategory.Text = drLookUp("category")
                    txtLookupCode.Text = drLookUp("lookup_code")
                    txtLookupName.Text = drLookUp("lookup_name")

                End If

            End If
        End If


    End Sub

    Private Function SaveDataCate(ByRef drLookup As DataRow) As Boolean
        drLookup("last_updated_by") = Session("logon_id")
        drLookup("last_updated_dt") = Now

        If mode = PAGEMODE.ADD Then
            drLookup("created_by") = Session("logon_id")
            drLookup("created_dt") = Now

            dtLookup.Rows.Add(drLookup)

        Else
            dtLookup.Rows(0).Item("last_updated_by") = Session("logon_id")
            dtLookup.Rows(0).Item("last_updated_dt") = Now
        End If 'End If mode = PAGEMODE.ADD

        'process db Saving
        If lookupService.SaveLookup(dtLookup) Then
            dtLookup.AcceptChanges()
        Else
            dtLookup.RejectChanges()
            bAlert = True
        End If

        SaveDataCate = Not bAlert
    End Function

    Function IsDataCateBlank(ByVal lookup As LookupModel) As Boolean
        Dim bBlank As Boolean = False

        If String.IsNullOrEmpty(lookup.lookupCode) Then
            bBlank = True
            sAlertMsg.Append("Reference category code can't be blank." & "\n")
            sAlertMsg.AppendLine()
        End If

        If String.IsNullOrEmpty(lookup.lookupName) Then
            bBlank = True
            sAlertMsg.Append("Reference category name can't be blank." & "\n")
            sAlertMsg.AppendLine()
        End If

        IsDataCateBlank = bBlank
    End Function

    Function IsUpdateRequired(ByRef drLookup As DataRow, ByVal lookup As LookupModel) As Boolean
        Dim bUpdate As Boolean = False

        If mode = PAGEMODE.ADD Then
            bUpdate = True
            drLookup("lookup_type") = lookup.lookupType
            drLookup("category") = lookup.category
            drLookup("category_desc") = lookup.categoryDesc
            drLookup("lookup_code") = lookup.lookupCode
            drLookup("lookup_name") = lookup.lookupName
            drLookup("is_active") = lookup.isActive
        Else
            If drLookup("category") <> lookup.category Then
                bUpdate = True
                drLookup("category") = lookup.category
                drLookup("category_desc") = lookup.categoryDesc

                dtLookup.Rows(0).Item("category") = lookup.category
                dtLookup.Rows(0).Item("category_desc") = lookup.categoryDesc
            End If

            If drLookup("lookup_code") <> lookup.lookupCode Then
                bUpdate = True
                drLookup("lookup_code") = lookup.lookupCode

                dtLookup.Rows(0).Item("lookup_code") = lookup.lookupCode
            End If

            If drLookup("lookup_name") <> lookup.lookupName Then
                bUpdate = True
                drLookup("lookup_name") = lookup.lookupName

                dtLookup.Rows(0).Item("lookup_name") = lookup.lookupName
            End If

            If drLookup("is_active") <> lookup.isActive Then
                bUpdate = True
                drLookup("is_active") = lookup.isActive

                dtLookup.Rows(0).Item("is_active") = lookup.isActive
            End If
        End If

        IsUpdateRequired = bUpdate
    End Function
#End Region


#Region "Page_Elements"
    Sub btnReturn_Click()

        mode = PAGEMODE.READ

        lookupCode = ddlRefCategory.SelectedValue

        LoadDataCatePage()

    End Sub

    Sub btnCreate_Click()
        bAlert = False
        sAlertMsg = New StringBuilder("")
        mode = PAGEMODE.ADD

        lookupCode = ddlRefCategory.SelectedValue
        LoadDataCatePage()
    End Sub

    'Sub btnQuery_Click()
    '    QueryData()
    'End Sub

    Sub btnSave_Click()
        bAlert = False
        sAlertMsg = New StringBuilder("")

        Dim drLookup As DataRow = dtLookup.NewRow

        Dim lookup As LookupModel = New LookupModel
        lookup.lookupType = ddlRef.SelectedValue
        lookup.category = lookupCate
        lookup.categoryDesc = lookupCateDesc
        lookup.lookupCode = DataFormatHelper.StringTrim(txtLookupCode.Text)
        lookup.lookupName = DataFormatHelper.StringTrim(txtLookupName.Text)
        lookup.isActive = ddlActive.SelectedValue

        'Check required fields
        If IsDataCateBlank(lookup) Then
            bAlert = True
        Else
            'Check if save/update required
            If mode = PAGEMODE.EDIT Then
                drLookup = dtLookupList.Rows(0)
            End If

            'Check if IsUpdateRequired(drLookup, lookUp)
            If Not IsUpdateRequired(drLookup, lookup) Then
                btnReturn_Click()
            Else
                'Check if existing record.
                If lookupService.IsExistedLookup(lookup) Then
                    bAlert = True
                    sAlertMsg.Append("This record already exists in database.").AppendLine()
                Else
                    If SaveDataCate(drLookup) Then
                        mode = PAGEMODE.READ
                        sAlertMsg.Append(IIf(mode = PAGEMODE.ADD, "Reference data category is created successfully.", "Reference data category is updated successfully."))

                        ddlRefCategory.SelectedValue = ""
                        lookupCode = ddlRefCategory.SelectedValue

                        LoadDataCatePage()

                    Else
                        sAlertMsg.Append(IIf(mode = PAGEMODE.ADD, "Failed to create reference data category.", "Failed to update reference data category."))
                        bAlert = True
                    End If 'End If SaveDataCate()

                End If 'End If lookupService.IsExistedLookup(lookup)

            End If 'End  If Not IsUpdateRequired(drLookup, lookup)

        End If 'End If IsDataCateBlank(lookup)




    End Sub

    Sub EnableSection()
        dvDataCateList.Style.Item("display") = IIf(mode = PAGEMODE.READ, "", "none")
        dvDataCate.Style.Item("display") = IIf(mode = PAGEMODE.READ, "none", "")
        'dvCategory.Visible = IIf(mode = PAGEMODE.ADD, False, True)

        ddlRefCategory.Enabled = IIf(mode = PAGEMODE.READ, True, False)

    End Sub


    Sub InitDropDownList()

        'Search
        ddlRef.Items.Clear()
        ddlRef.Items.Add(New ListItem("Business", "B"))
        ddlRef.Items.Add(New ListItem("System", "S"))
        ddlRef.DataBind()

        ddlRef.SelectedValue = IIf(String.IsNullOrEmpty(lookupType), "B", lookupType)

        InitCategoryDropDownList()

        'Status Active
        ddlActive.Items.Clear()
        ddlActive.Items.Add(New ListItem("Yes", "Y"))
        ddlActive.Items.Add(New ListItem("No", "N"))
        ddlActive.DataBind()

    End Sub

    Private Sub InitCategoryDropDownList()

        Select Case ddlRef.SelectedValue
            Case "B"
                lookupCate = LOOKUP_CATE_BIZ
                lookupCateDesc = "Business Category"
            Case "S"
                lookupCate = LOOKUP_CATE_SYS
                lookupCateDesc = "System Category"
        End Select

        Dim dtCateListDropDown As DataTable = lookupService.GetLookUpList(ddlRef.SelectedValue, lookupCate)
        WebControlHelper.DropDownListDataBind(ddlRefCategory, dtCateListDropDown, "lookup_name", "lookup_code")

        If Not String.IsNullOrEmpty(lookupCode) Then
            ddlRefCategory.SelectedValue = lookupCode
        End If

    End Sub


    Private Sub ddlRef_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlRef.SelectedIndexChanged
        lookupCode = ""
        InitCategoryDropDownList()

        QueryData()
    End Sub

    Private Sub ddlRefCategory_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlRefCategory.SelectedIndexChanged
        QueryData()
    End Sub

#End Region




End Class