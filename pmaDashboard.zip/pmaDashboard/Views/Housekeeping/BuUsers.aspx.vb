﻿Public Class BuUsers
    Inherits System.Web.UI.Page

    Shared dtUserBu As DataTable = New DataTable
    Shared buCode As String = ""
    Shared buName As String = ""

    Dim userBuService As IUserBuService = New UserBuService
    Dim userRoleService As IUserRoleService = New UserRoleService
    Dim pmaUserService As IPmaUserService = New PmaUserService

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            buCode = HttpContext.Current.Items("buCode")
            buName = HttpContext.Current.Items("buName")

            LoadBuUsers()
        End If
    End Sub



#Region "gvBuUsersList"
    Private Sub LoadBuUsers()


        dtUserBu = userBuService.GetUserBuList(buCode)

        If Not dtUserBu Is Nothing Then
            dtUserBu.Columns.Add("bu_name")
            dtUserBu.Columns.Add("staff_name")

            LoadBuInfo()
            BindBuUsersListData()

        End If
    End Sub

    Private Sub LoadBuInfo()
        If Not dtUserBu Is Nothing Then
            For i As Integer = 0 To dtUserBu.Rows.Count - 1
                Dim logonId As String = dtUserBu.Rows(i).Item("pma_logon_id")

                dtUserBu.Rows(i).Item("bu_name") = buName
                dtUserBu.Rows(i).Item("staff_name") = pmaUserService.GetActiveUserNameByLogonId(logonId)
            Next
        End If

    End Sub

    Private Sub BindBuUsersListData()
        Dim sSortExpression As String = ViewState("SortOrder")
        Dim sSortDirection As String = ViewState("SortDirect")

        If Not String.IsNullOrEmpty(sSortExpression) And Not String.IsNullOrEmpty(sSortDirection) Then
            dtUserBu.DefaultView.Sort = String.Format("{0} {1}", sSortExpression, sSortDirection)
        End If

        WebControlHelper.GridViewDataBind(gvBuUsersList, dtUserBu)

    End Sub

    Private Sub gvBuUsersList_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvBuUsersList.Sorting
        Dim sSortExpression As String = e.SortExpression
        Dim sSortDirection As String = e.SortDirection

        If String.IsNullOrEmpty(ViewState("SortOrder")) Then
            ViewState("SortOrder") = sSortExpression
        End If

        If String.IsNullOrEmpty(ViewState("SortDirect")) Then
            ViewState("SortDirect") = "ASC"
        End If

        If (ViewState("SortOrder").ToString = sSortExpression) Then
            If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                ViewState("SortDirect") = "ASC"
            Else
                ViewState("SortDirect") = "DESC"
            End If
        Else
            ViewState("SortOrder") = e.SortExpression
        End If

        BindBuUsersListData()
    End Sub

    Private Sub gvBuUsersList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvBuUsersList.RowDataBound
        Dim sChevronUp As String = " <span class='glyphicon glyphicon-chevron-up'></span>"
        Dim sChevronDown As String = " <span class='glyphicon glyphicon-chevron-down'></span>"
        Dim sChevron As String = sChevronUp

        If e.Row.RowType = DataControlRowType.Header Then
            For i As Integer = 0 To e.Row.Cells.Count - 1
                Dim cons As ControlCollection = e.Row.Cells(i).Controls
                For j As Integer = 0 To e.Row.Cells(i).Controls.Count - 1
                    Dim lb As LinkButton = CType(cons(j), LinkButton)
                    If Not lb Is Nothing Then
                        If Not String.IsNullOrEmpty(ViewState("SortOrder")) Then
                            If ViewState("SortOrder").ToString = lb.CommandArgument Then
                                If Not String.IsNullOrEmpty(ViewState("SortDirect")) Then
                                    If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                                        sChevron = sChevronDown
                                    End If
                                End If
                            End If

                            lb.Text = lb.Text & sChevron
                        End If

                    End If
                Next
            Next
        End If

    End Sub


    Private Sub gvBuUsersList_PageIndexChanging(sender As Object, e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvBuUsersList.PageIndexChanging
        gvBuUsersList.PageIndex = e.NewPageIndex

        BindBuUsersListData()
    End Sub
#End Region


#Region "dvBuUsersEdit"
    Private Sub BindAmUsers()
        Dim dtAmUsers As DataTable = New DataTable("AmUsers")
        Dim pmaUserService As IPmaUserService = New PmaUserService

        dtAmUsers = userRoleService.GetUserRoleList(9)


        If Not dtAmUsers Is Nothing Then
            dtAmUsers.Columns.Add("staff_name")

            For Each drAmUser As DataRow In dtAmUsers.Rows
                drAmUser("staff_name") = pmaUserService.GetActiveUserNameByLogonId(drAmUser("pma_logon_id"))
            Next

            lstAmUsers.Items.Clear()
            lstAmUsers.DataSource = dtAmUsers
            lstAmUsers.DataValueField = "pma_logon_id"
            lstAmUsers.DataTextField = "staff_name"
            lstAmUsers.DataBind()
        End If

        'Remove users assiged to the bu
        Dim iRow As Integer = 0

        iRow = lstAmUsers.Items.Count - 1

        While iRow >= 0
            If lstBuUsers.Items.Contains(lstAmUsers.Items(iRow)) Then
                lstAmUsers.Items.RemoveAt(iRow)
            End If
            iRow = iRow - 1
        End While

    End Sub

    Private Sub BindBuUsers()

        If Not dtUserBu Is Nothing Then
            lstBuUsers.Items.Clear()
            lstBuUsers.DataSource = dtUserBu
            lstBuUsers.DataValueField = "pma_logon_id"
            lstBuUsers.DataTextField = "staff_name"
            lstBuUsers.DataBind()
        End If

    End Sub
#End Region


#Region "Page_Buttons"


    Private Sub btnReturn_Click(sender As Object, e As System.EventArgs) Handles btnReturn.Click
        HttpContext.Current.Items.Remove("Authority")
        HttpContext.Current.Items.Add("Authority", "BU")

        Server.Transfer("Authority.aspx")
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As System.EventArgs) Handles btnEdit.Click
        'Load Bu Users
        BindBuUsers()

        BindAmUsers()

        EnableEditMode(True)
    End Sub

    Private Sub btnEdit_Add_ServerClick(sender As Object, e As System.EventArgs) Handles btnEdit_Add.ServerClick
        Dim iRow As Integer = 0

        iRow = lstAmUsers.Items.Count - 1

        While iRow >= 0
            If lstAmUsers.Items(iRow).Selected = True Then
                If Not lstBuUsers.Items.Contains(lstAmUsers.Items(iRow)) Then
                    lstBuUsers.Items.Add(lstAmUsers.Items(iRow))
                    lstAmUsers.Items.RemoveAt(iRow)
                End If
            End If
            iRow = iRow - 1
        End While

    End Sub

    Private Sub btnEdit_Remove_ServerClick(sender As Object, e As System.EventArgs) Handles btnEdit_Remove.ServerClick
        Dim iRow As Integer = lstBuUsers.Items.Count - 1

        While iRow >= 0
            If (lstBuUsers.Items(iRow).Selected = True) Then
                lstAmUsers.Items.Add(lstBuUsers.Items(iRow))
                lstBuUsers.Items.RemoveAt(iRow)
            End If
            iRow = iRow - 1
        End While
    End Sub

    Sub EditCancel_Click()
        BindBuUsersListData()
        EnableEditMode(False)
    End Sub

    Sub EditOK_Click()
        If (SaveChanges()) Then
            dtUserBu.AcceptChanges()

            LoadBuInfo()
            BindBuUsersListData()
            EnableEditMode(False)
        Else
            dtUserBu.RejectChanges()
        End If
    End Sub

    Sub EnableEditMode(ByVal mode As Boolean)
        btnReturn.Visible = Not mode
        btnEdit.Visible = Not mode

        dvBuUsersEdit.Style.Item("display") = IIf(mode, "", "none")
        dvBuUsersList.Style.Item("display") = IIf(mode, "none", "")
    End Sub

    Function SaveChanges() As Boolean
        Dim bSave As Boolean = False

        Dim iRow As Integer = 0

        'Add new added BU users to datatable
        For iRow = 0 To lstBuUsers.Items.Count - 1
            Dim buUser As String = ""
            buUser = lstBuUsers.Items(iRow).Value
            Dim drUserBu As DataRow = dtUserBu.NewRow()
            Dim drUserBus As DataRow()

            drUserBus = dtUserBu.Select("pma_logon_id = '" & buUser & "'")
            If Not drUserBus Is Nothing Then
                If drUserBus.Length <= 0 Then
                    'New added bu user
                    drUserBu("pma_logon_id") = buUser
                    drUserBu("bu_code") = buCode
                    drUserBu("is_active") = "Y"
                    drUserBu("last_updated_by") = Session("logon_id")
                    drUserBu("last_updated_dt") = Now
                    dtUserBu.Rows.Add(drUserBu)
                End If
            End If
        Next

        For iRow = dtUserBu.Rows.Count - 1 To 0 Step -1
            Dim buUser As String = dtUserBu.Rows(iRow).Item("pma_logon_id")
            Dim userFound As Boolean = False

            For i As Integer = 0 To lstBuUsers.Items.Count - 1
                If lstBuUsers.Items(i).Value = buUser Then
                    userFound = True
                    Exit For
                End If
            Next

            If Not userFound Then
                dtUserBu.Rows(iRow).Delete()
            End If

        Next

        SaveChanges = userBuService.SaveUserBuList(dtUserBu)


    End Function
#End Region


End Class