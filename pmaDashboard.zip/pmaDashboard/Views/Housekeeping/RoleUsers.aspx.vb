﻿Public Class RoleUsers
    Inherits System.Web.UI.Page

    Shared dtUserRole As DataTable = New DataTable
    Shared roleId As Integer = 0
    Shared roleName As String = ""

    Dim userRoleService As IUserRoleService = New UserRoleService
    Dim pmaUserService As IPmaUserService = New PmaUserService

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            roleId = HttpContext.Current.Items("roleId")
            roleName = HttpContext.Current.Items("roleName")
            LoadRoleUsers()
        End If
    End Sub



#Region "gvRoleUsersList"
    Private Sub LoadRoleUsers()


        dtUserRole = userRoleService.GetUserRoleList(roleId)

        If Not dtUserRole Is Nothing Then
            dtUserRole.Columns.Add("role_name")
            dtUserRole.Columns.Add("staff_name")

            LoadRoleInfo()
            BindRoleUsersListData()

        End If
    End Sub

    Private Sub LoadRoleInfo()
        If Not dtUserRole Is Nothing Then
            For i As Integer = 0 To dtUserRole.Rows.Count - 1
                Dim logonId As String = dtUserRole.Rows(i).Item("pma_logon_id")

                dtUserRole.Rows(i).Item("role_name") = roleName
                dtUserRole.Rows(i).Item("staff_name") = pmaUserService.GetActiveUserNameByLogonId(logonId)
            Next
        End If

    End Sub

    Private Sub BindRoleUsersListData()
        Dim sSortExpression As String = ViewState("SortOrder")
        Dim sSortDirection As String = ViewState("SortDirect")

        If Not String.IsNullOrEmpty(sSortExpression) And Not String.IsNullOrEmpty(sSortDirection) Then
            dtUserRole.DefaultView.Sort = String.Format("{0} {1}", sSortExpression, sSortDirection)
        End If

        WebControlHelper.GridViewDataBind(gvRoleUsersList, dtUserRole)

    End Sub

    Private Sub gvRoleUsersList_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvRoleUsersList.Sorting
        Dim sSortExpression As String = e.SortExpression
        Dim sSortDirection As String = e.SortDirection

        If String.IsNullOrEmpty(ViewState("SortOrder")) Then
            ViewState("SortOrder") = sSortExpression
        End If

        If String.IsNullOrEmpty(ViewState("SortDirect")) Then
            ViewState("SortDirect") = "ASC"
        End If

        If (ViewState("SortOrder").ToString = sSortExpression) Then
            If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                ViewState("SortDirect") = "ASC"
            Else
                ViewState("SortDirect") = "DESC"
            End If
        Else
            ViewState("SortOrder") = e.SortExpression
        End If

        BindRoleUsersListData()
    End Sub

    Private Sub gvRoleUsersList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvRoleUsersList.RowDataBound
        Dim sChevronUp As String = " <span class='glyphicon glyphicon-chevron-up'></span>"
        Dim sChevronDown As String = " <span class='glyphicon glyphicon-chevron-down'></span>"
        Dim sChevron As String = sChevronUp

        If e.Row.RowType = DataControlRowType.Header Then
            For i As Integer = 0 To e.Row.Cells.Count - 1
                Dim cons As ControlCollection = e.Row.Cells(i).Controls
                For j As Integer = 0 To e.Row.Cells(i).Controls.Count - 1
                    Dim lb As LinkButton = CType(cons(j), LinkButton)
                    If Not lb Is Nothing Then
                        If Not String.IsNullOrEmpty(ViewState("SortOrder")) Then
                            If ViewState("SortOrder").ToString = lb.CommandArgument Then
                                If Not String.IsNullOrEmpty(ViewState("SortDirect")) Then
                                    If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                                        sChevron = sChevronDown
                                    End If
                                End If
                            End If

                            lb.Text = lb.Text & sChevron
                        End If

                    End If
                Next
            Next
        End If

    End Sub


    Private Sub gvRoleUsersList_PageIndexChanging(sender As Object, e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvRoleUsersList.PageIndexChanging
        gvRoleUsersList.PageIndex = e.NewPageIndex

        BindRoleUsersListData()
    End Sub
#End Region


#Region "dvRoleUsersEdit"
    Private Sub BindAllUsers()
        Dim dtUsers As DataTable = New DataTable("AllUsers")
        Dim pmaUserService As IPmaUserService = New PmaUserService

        dtUsers = pmaUserService.GetActiveUserList

        If Not dtUsers Is Nothing Then
            lstAllUsers.Items.Clear()
            lstAllUsers.DataSource = dtUsers
            lstAllUsers.DataValueField = "logon_id"
            lstAllUsers.DataTextField = "staff_name"
            lstAllUsers.DataBind()
        End If

        'Remove users assiged to the role
        Dim iRow As Integer = 0

        iRow = lstAllUsers.Items.Count - 1

        While iRow >= 0
            If lstRoleUsers.Items.Contains(lstAllUsers.Items(iRow)) Then
                lstAllUsers.Items.RemoveAt(iRow)
            End If
            iRow = iRow - 1
        End While

    End Sub

    Private Sub BindRoleUsers()

        If Not dtUserRole Is Nothing Then
            lstRoleUsers.Items.Clear()
            lstRoleUsers.DataSource = dtUserRole
            lstRoleUsers.DataValueField = "pma_logon_id"
            lstRoleUsers.DataTextField = "staff_name"
            lstRoleUsers.DataBind()
        End If

    End Sub
#End Region


#Region "Page_Buttons"


    Private Sub btnReturn_Click(sender As Object, e As System.EventArgs) Handles btnReturn.Click
        HttpContext.Current.Items.Remove("Authority")
        HttpContext.Current.Items.Add("Authority", "ROLE")

        Server.Transfer("Authority.aspx")
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As System.EventArgs) Handles btnEdit.Click
        'Load Role Users
        BindRoleUsers()

        'LoadRoleUsers()
        BindAllUsers()

        EnableEditMode(True)
    End Sub

    Private Sub btnEdit_Add_ServerClick(sender As Object, e As System.EventArgs) Handles btnEdit_Add.ServerClick
        Dim iRow As Integer = 0

        iRow = lstAllUsers.Items.Count - 1

        While iRow >= 0
            If lstAllUsers.Items(iRow).Selected = True Then
                If Not lstRoleUsers.Items.Contains(lstAllUsers.Items(iRow)) Then
                    lstRoleUsers.Items.Add(lstAllUsers.Items(iRow))
                    lstAllUsers.Items.RemoveAt(iRow)
                End If
            End If
            iRow = iRow - 1
        End While

    End Sub

    Private Sub btnEdit_Remove_ServerClick(sender As Object, e As System.EventArgs) Handles btnEdit_Remove.ServerClick
        Dim iRow As Integer = lstRoleUsers.Items.Count - 1

        While iRow >= 0
            If (lstRoleUsers.Items(iRow).Selected = True) Then
                lstAllUsers.Items.Add(lstRoleUsers.Items(iRow))
                lstRoleUsers.Items.RemoveAt(iRow)
            End If
            iRow = iRow - 1
        End While
    End Sub

    Sub EditCancel_Click()
        BindRoleUsersListData()
        EnableEditMode(False)
    End Sub

    Sub EditOK_Click()
        If (SaveChanges()) Then
            dtUserRole.AcceptChanges()
            'LoadRoleUsers()
            LoadRoleInfo()
            BindRoleUsersListData()
            EnableEditMode(False)
        Else
            dtUserRole.RejectChanges()
        End If
    End Sub

    Sub EnableEditMode(ByVal mode As Boolean)
        btnReturn.Visible = Not mode
        btnEdit.Visible = Not mode

        dvRoleUsersEdit.Style.Item("display") = IIf(mode, "", "none")
        dvRoleUsersList.Style.Item("display") = IIf(mode, "none", "")
    End Sub

    Function SaveChanges() As Boolean
        Dim bSave As Boolean = False

        Dim iRow As Integer = 0

        'Add new added role users to datatable
        For iRow = 0 To lstRoleUsers.Items.Count - 1
            Dim roleUser As String = lstRoleUsers.Items(iRow).Value
            'Dim roleUserId As String = roleUser.Split("-")(0).ToString
            'Dim roleUserIdCard As String = roleUser.Split("-")(1).ToString

            Dim drUserRole As DataRow = dtUserRole.NewRow()
            Dim drUserRoles() As DataRow

            drUserRoles = dtUserRole.Select("pma_logon_id = '" & roleUser & "'")
            If Not drUserRoles Is Nothing Then
                If drUserRoles.Length <= 0 Then
                    'New added role user
                    drUserRole("pma_logon_id") = roleUser
                    drUserRole("pma_logon_id_card") = pmaUserService.GetActiveUserIdCardByLogonId(roleUser)
                    drUserRole("role_id") = roleId
                    drUserRole("is_active") = "Y"
                    drUserRole("last_updated_by") = Session("logon_id")
                    drUserRole("last_updated_dt") = Now
                    dtUserRole.Rows.Add(drUserRole)
                End If
            End If
        Next

        For iRow = dtUserRole.Rows.Count - 1 To 0 Step -1
            Dim roleUser As String = dtUserRole.Rows(iRow).Item("pma_logon_id")
            Dim userFound As Boolean = False

            For i As Integer = 0 To lstRoleUsers.Items.Count - 1
                If lstRoleUsers.Items(i).Value = roleUser Then
                    userFound = True
                    Exit For
                End If
            Next

            If Not userFound Then
                dtUserRole.Rows(iRow).Delete()
            End If

        Next

        SaveChanges = userRoleService.EditUserRoleList(dtUserRole, roleId)


    End Function
#End Region


End Class