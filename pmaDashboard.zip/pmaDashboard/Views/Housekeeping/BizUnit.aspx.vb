﻿Public Class BizUnit
    Inherits System.Web.UI.Page

    Shared dtRole As DataTable = New DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            LoadRoles()
        End If

    End Sub

    Private Sub LoadRoles()
        Dim roleService As IRoleService = New RoleService

        dtRole = roleService.GetRoleList

        If Not dtRole Is Nothing Then
            dtRole.Columns.Add("roleUsers")

            For Each dr As DataRow In dtRole.Rows
                Dim dtRoleUsers As DataTable = New DataTable
                Dim userRoleService As IUserRoleService = New UserRoleService
                dtRoleUsers = userRoleService.GetUserRoleList(dr("role_id"))

                If Not dtRoleUsers Is Nothing Then
                    Dim sRoleUsers As StringBuilder = New StringBuilder("")
                    For Each drRoleUser As DataRow In dtRoleUsers.Rows
                        If Not String.IsNullOrEmpty(sRoleUsers.ToString) Then
                            sRoleUsers.Append(", ")
                        End If
                        'sRoleUsers.Append(drRoleUser("pma_logon_id"))
                        Dim pmaUserService As IPmaUserService = New PmaUserService
                        sRoleUsers.Append(pmaUserService.GetUserNameByLogonId(drRoleUser("pma_logon_id")))
                    Next
                    dr("roleUsers") = sRoleUsers.ToString
                End If
            Next

            BindData()

        End If
    End Sub

    Private Sub BindData()
        Dim sSortExpression As String = ViewState("SortOrder")
        Dim sSortDirection As String = ViewState("SortDirect")

        If Not String.IsNullOrEmpty(sSortExpression) And Not String.IsNullOrEmpty(sSortDirection) Then
            dtRole.DefaultView.Sort = String.Format("{0} {1}", sSortExpression, sSortDirection)
        End If

        gvBizUnitList.DataSource = dtRole
        gvBizUnitList.DataBind()
    End Sub

    Private Sub gvBizUnitList_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvBizUnitList.Sorting

        Dim sSortExpression As String = e.SortExpression
        Dim sSortDirection As String = e.SortDirection

        If String.IsNullOrEmpty(ViewState("SortOrder")) Then
            ViewState("SortOrder") = sSortExpression
        End If

        If String.IsNullOrEmpty(ViewState("SortDirect")) Then
            ViewState("SortDirect") = "ASC"
        End If

        If (ViewState("SortOrder").ToString = sSortExpression) Then
            If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                ViewState("SortDirect") = "ASC"
            Else
                ViewState("SortDirect") = "DESC"
            End If
        Else
            ViewState("SortOrder") = e.SortExpression
        End If

        BindData()

    End Sub

    Private Sub gvBizUnitList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvBizUnitList.RowDataBound
        Dim sChevronUp As String = " <span class='glyphicon glyphicon-chevron-up'></span>"
        Dim sChevronDown As String = " <span class='glyphicon glyphicon-chevron-down'></span>"
        Dim sChevron As String = sChevronUp

        If e.Row.RowType = DataControlRowType.Header Then
            For i As Integer = 0 To e.Row.Cells.Count - 1
                Dim cons As ControlCollection = e.Row.Cells(i).Controls
                For j As Integer = 0 To e.Row.Cells(i).Controls.Count - 1
                    Dim lb As LinkButton = CType(cons(j), LinkButton)
                    If Not lb Is Nothing Then
                        If Not String.IsNullOrEmpty(ViewState("SortOrder")) Then
                            If ViewState("SortOrder").ToString = lb.CommandArgument Then
                                If Not String.IsNullOrEmpty(ViewState("SortDirect")) Then
                                    If ViewState("SortDirect").ToString.ToUpper = "DESC" Then
                                        sChevron = sChevronDown
                                    End If
                                End If
                            End If

                            lb.Text = lb.Text & sChevron
                        End If

                    End If
                Next
            Next
        End If
    End Sub
End Class