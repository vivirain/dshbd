﻿Public Class ReferenceData
    Inherits System.Web.UI.Page

    'Const LOOKUP_TYPE As String = "B"
    'Const LOOKUP_CATE As String = "BIZCATE"

    Enum PAGEMODE As Integer
        EDIT = -1
        READ = 0
        ADD = 1
    End Enum

    Public Shared mode As Integer = PAGEMODE.READ
    Public Shared bAlert As Boolean = False
    Public Shared sAlertMsg As StringBuilder = New StringBuilder("")

    Shared dtLookupList As DataTable = New DataTable("DataList")
    Shared dtLookup As DataTable = New DataTable("Data")

    Shared lookupType As String = ""
    Shared lookupCate As String = ""
    Shared lookupCode As String = ""

    Private lookupService As ILookupService = New LookupService


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            lookupType = HttpContext.Current.Items("lookupType")
            lookupCate = HttpContext.Current.Items("lookupCate")
            lookupCode = HttpContext.Current.Items("lookupCode")
            mode = HttpContext.Current.Items("mode")

            If Not lookupCate Is Nothing Then
                LoadDataPage()
            End If

        End If
    End Sub

    Private Sub LoadDataPage()

        If mode <> PAGEMODE.ADD Then
            LoadCateListDropDown(ddlRefCategory)
        End If

        If mode = PAGEMODE.READ Then
            PrepareDataList()
        Else
            PrepareData()
        End If

    End Sub

#Region "gvDataList"
    Private Sub PrepareDataList()
        dtLookupList = lookupService.GetLookUpList(lookupType, lookupCate)

        If Not dtLookupList Is Nothing Then
            WebControlHelper.GridViewDataBind(gvDataList, dtLookupList)
        End If
    End Sub

    Private Sub gvDataList_DataBound(sender As Object, e As System.EventArgs) Handles gvDataList.DataBound
        gvDataList.Columns(6).Visible = False
    End Sub

    Private Sub gvDataList_PageIndexChanging(sender As Object, e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvDataList.PageIndexChanging
        gvDataList.PageIndex = e.NewPageIndex

        WebControlHelper.GridViewDataBind(gvDataList, dtLookupList)

    End Sub


    Private Sub gvDataList_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvDataList.RowCommand
        If e.CommandName = "editData" Then
            Dim index As String = CType(e.CommandArgument(), Integer)

            Dim gvRow As GridViewRow = gvDataList.Rows(index)

            'Dim lookupCate As String = gvRow.Cells(1).Text
            Dim lookupCode As String = gvRow.Cells(6).Text

            HttpContext.Current.Items.Remove("lookupType")
            HttpContext.Current.Items.Remove("lookupCate")
            HttpContext.Current.Items.Remove("lookupCode")
            HttpContext.Current.Items.Remove("mode")

            HttpContext.Current.Items.Add("lookupType", lookupType)
            HttpContext.Current.Items.Add("lookupCate", lookupCate)
            HttpContext.Current.Items.Add("lookupCode", lookupCode)
            HttpContext.Current.Items.Add("mode", PAGEMODE.EDIT)

            Server.Transfer("ReferenceData.aspx")
        End If
    End Sub
#End Region


#Region "Data"
    Private Sub PrepareData()
        bAlert = False
        sAlertMsg = New StringBuilder("")
        LoadCateListDropDown(ddlCategory)

        LoadStatusDropDown()

        If mode = PAGEMODE.ADD Then
            dtLookup = lookupService.GetLookUp(lookupType, "", "")
            txtId.Text = ""
            txtCategory.Text = ""
            ddlCategory.Enabled = True
            ddlCategory.SelectedValue = lookupCate
            ddlCategory.Enabled = False
            ddlActive.SelectedValue = "Y"
            txtLookupCode.Text = ""
            txtLookupCode.Enabled = True

        ElseIf mode = PAGEMODE.EDIT Then
            dtLookup = lookupService.GetLookUp(lookupType, lookupCate, lookupCode)

            If Not dtLookup Is Nothing Then
                If dtLookup.Rows.Count > 0 Then
                    Dim drLookUp As DataRow = dtLookup.Rows(0)

                    txtId.Text = drLookUp("lookup_id")
                    txtCategory.Text = drLookUp("category")
                    ddlCategory.SelectedValue = drLookUp("category")


                    txtLookupCode.Text = drLookUp("lookup_code")
                    txtLookupName.Text = drLookUp("lookup_name")

                    ddlActive.SelectedValue = drLookUp("is_active")

                    If drLookUp("lookup_type") = "S" Then
                        ddlCategory.Enabled = False
                        txtLookupCode.Enabled = False
                    End If

                End If

            End If
        End If

    End Sub
#End Region


#Region "Page_Elements"

    Sub btnQuery_Click()
        lookupCate = ddlRefCategory.SelectedValue

        PrepareDataList()
    End Sub

    'READ mode
    Sub btnCreate_Click()
        bAlert = False
        sAlertMsg = New StringBuilder("")

        mode = PAGEMODE.ADD

        PrepareData()

        'EnableSection()
    End Sub

    Sub btnBack_Click()
        HttpContext.Current.Items.Remove("lookupType")
        'HttpContext.Current.Items.Remove("lookupCode")

        HttpContext.Current.Items.Add("lookupType", lookupType)
        HttpContext.Current.Items.Add("lookupCode", ddlRefCategory.SelectedValue)

        Server.Transfer("ReferenceDataCategory.aspx")
    End Sub


    'ADD / EDIT mode
    Sub btnReturn_Click()
        mode = PAGEMODE.READ
        LoadDataPage()
    End Sub


    Sub btnSave_Click()
        bAlert = False
        sAlertMsg = New StringBuilder("")

        Dim lookUp As LookupModel = New LookupModel
        Dim drLookup As DataRow

        If dtLookup Is Nothing Then
            dtLookup = lookupService.GetBlankLookUp
            drLookup = dtLookup.NewRow
        ElseIf dtLookup.Rows.Count = 0 Then
            drLookup = dtLookup.NewRow
        Else
            drLookup = dtLookup.Rows(0)
        End If

        'Retrieve data from page form input
        lookUp.lookupType = lookupType
        lookUp.category = ddlCategory.SelectedValue
        lookUp.categoryDesc = ddlCategory.SelectedItem.Text
        lookUp.lookupCode = DataFormatHelper.StringTrim(txtLookupCode.Text)
        lookUp.lookupName = DataFormatHelper.StringTrim(txtLookupName.Text)
        lookUp.isActive = ddlActive.SelectedValue

        'Check required fields
        If IsDataBlank(lookUp) Then
            bAlert = True

            'Check if save/update required
        ElseIf Not IsUpdateRequired(drLookup, lookUp) Then
            btnReturn_Click()
            Return

            'Check if existing record.
        ElseIf lookupService.IsExistedLookup(lookUp) Then
            If Not (mode = PAGEMODE.EDIT And drLookup("category") = lookUp.category And drLookup("lookup_code") = lookUp.lookupCode) Then
                bAlert = True
                sAlertMsg.Append("This record already exists in database.").AppendLine()
            End If
        End If

        If Not bAlert Then

            drLookup("last_updated_by") = Session("logon_id")
            drLookup("last_updated_dt") = Now

            If mode = PAGEMODE.ADD Then
                drLookup("created_by") = Session("logon_id")
                drLookup("created_dt") = Now
                dtLookup.Rows.Add(drLookup)
            End If 'End If mode = PAGEMODE.ADD

            'Save Records
            If lookupService.SaveLookup(dtLookup) Then
                'dtLookup.AcceptChanges()
                'Dim sAlertString As String = IIf(mode = PAGEMODE.ADD, "Business data is created successfully.", "Business data is updated successfully.")
                'ScriptManager.RegisterStartupScript(Page, Page.GetType, "", String.Format("<script>alert('{0}');</script>", sAlertString), False)

                btnReturn_Click()
            Else
                'dtLookup.RejectChanges()
                sAlertMsg.Append(IIf(mode = PAGEMODE.ADD, "Failed to create reference data.", "Failed to update reference data."))
                bAlert = True
            End If 'End If lookupService.SaveLookup(dtLookup) Then
        End If
    End Sub

    Function IsDataBlank(ByVal lookup As LookupModel) As Boolean
        Dim bBlank As Boolean = False

        If String.IsNullOrEmpty(lookup.lookupCode) Then
            bBlank = True
            sAlertMsg.Append("Reference code can't be blank.")
            sAlertMsg.AppendLine()
        End If

        If String.IsNullOrEmpty(lookup.lookupName) Then
            bBlank = True
            sAlertMsg.Append("Reference value can't be blank.")
            sAlertMsg.AppendLine()
        End If

        IsDataBlank = bBlank
    End Function

    Function IsUpdateRequired(ByRef drLookup As DataRow, ByVal lookup As LookupModel) As Boolean
        Dim bUpdate As Boolean = False

        If mode = PAGEMODE.ADD Then
            bUpdate = True
            drLookup("lookup_type") = lookup.lookupType
            drLookup("category") = lookup.category
            drLookup("category_desc") = lookup.categoryDesc
            drLookup("lookup_code") = lookup.lookupCode
            drLookup("lookup_name") = lookup.lookupName
            drLookup("is_active") = lookup.isActive
        Else
            If drLookup("category") <> lookup.category Then
                bUpdate = True
                drLookup("category") = lookup.category
                drLookup("category_desc") = lookup.categoryDesc

            End If

            If drLookup("lookup_code") <> lookup.lookupCode Then
                bUpdate = True
                drLookup("lookup_code") = lookup.lookupCode
            End If

            If drLookup("lookup_name") <> lookup.lookupName Then
                bUpdate = True
                drLookup("lookup_name") = lookup.lookupName
            End If

            If drLookup("is_active") <> lookup.isActive Then
                bUpdate = True
                drLookup("is_active") = lookup.isActive

            End If
        End If

        IsUpdateRequired = bUpdate
    End Function


    Sub LoadCateListDropDown(ByVal ddl As DropDownList)
        Dim parentLookupCate As String = ""
        Select Case lookupType
            Case "B"
                parentLookupCate = "BIZCATE"
            Case "S"
                parentLookupCate = "SYSCATE"
        End Select
        Dim dtCateListDropDown As DataTable = lookupService.GetLookUpList(lookupType, parentLookupCate)

        If Not dtCateListDropDown Is Nothing Then

            WebControlHelper.DropDownListDataBind(ddl, dtCateListDropDown, "lookup_name", "lookup_code", False)

            If Not String.IsNullOrEmpty(lookupCate) Then
                ddl.SelectedValue = lookupCate
            End If

        End If
    End Sub

    Sub LoadStatusDropDown()
        ddlActive.Items.Clear()

        ddlActive.Items.Add(New ListItem("Yes", "Y"))
        ddlActive.Items.Add(New ListItem("No", "N"))
        ddlActive.DataBind()
    End Sub


#End Region

End Class