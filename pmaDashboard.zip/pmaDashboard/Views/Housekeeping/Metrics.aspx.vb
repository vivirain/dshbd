﻿Imports System.Web.Script.Serialization

Public Class Metrics
    Inherits System.Web.UI.Page

    Const LOOKUP_TYPE As String = "B"

    Public Shared bAlert As Boolean = False
    Public Shared sAlertMsg As StringBuilder = New StringBuilder("")
    Protected sTssPrjChkBoxList As StringBuilder = New StringBuilder("")

    Public Enum PAGEMODE As Integer
        EDIT = -1
        READ = 0
        ADD = 1
    End Enum

    Shared dtMetricList As DataTable = Nothing
    Shared dtMetric As DataTable = New DataTable("metric")
    Shared mode As Integer = PAGEMODE.READ
    Shared metricCode As String = ""

    Private metricService As IMetricService = New MetricService
    Private tssPrjService As IPmaTssProjectService = New PmaTssProjectService
    Private lookupService As ILookupService = New LookupService

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            mode = Request.QueryString("mode")
            metricCode = Request.QueryString("metricCode")

            bAlert = False
            sAlertMsg = New StringBuilder("")

            If mode = PAGEMODE.READ Then
                LoadMetricList()
            Else
                PrepareMetric()
            End If

            EnableSection()
        End If
    End Sub


#Region "Metric_Read"
    Private Sub LoadMetricList()

        dtMetricList = New DataTable("metricList")
        dtMetricList = metricService.GetMetricList()

        If Not dtMetricList Is Nothing Then
            dtMetricList.Columns.Add("active_desc")

            For Each drmetric In dtMetricList.Rows
                drmetric("active_desc") = IIf(drmetric("is_active") = "Y", "Yes", "No")

            Next

            WebControlHelper.GridViewDataBind(gvMetrics, dtMetricList)

        End If



    End Sub
#End Region



#Region "Metric_Edit"

    Private Sub PrepareMetric()
        bAlert = False
        sAlertMsg = New StringBuilder("")


        InitWebControls()

        If mode = PAGEMODE.ADD Then
            dtMetric = dtMetricList.Clone
            ddlMetricCategory.SelectedIndex = -1
            txtMetricName.Text = ""

        ElseIf mode = PAGEMODE.EDIT Then
            dtMetric = metricService.GetMetric(metricCode)

            If Not dtMetric Is Nothing Then
                If dtMetric.Rows.Count > 0 Then
                    Dim drMetric As DataRow = dtMetric.Rows(0)

                    ddlMetricCategory.SelectedValue = drMetric("metric_Category")
                    txtMetricName.Text = drMetric("metric_name")
                    ddlMetricValType.SelectedValue = drMetric("metric_val_type")
                    ddlMetricValPrecision.SelectedValue = drMetric("metric_val_precision")
                    ddlMetricValeUpdMode.SelectedValue = drMetric("metric_val_update_mode")

                    Dim sFixedPricePrj As String = drMetric("fixed_price_project").ToString
                    If Not String.IsNullOrEmpty(sFixedPricePrj) Then
                        If sFixedPricePrj = "Y" Then
                            cbFixedPricePrj.Checked = True
                        End If
                    End If

                    Dim sTssPrjJson As String = drMetric("tss_prj_json").ToString
                    If Not String.IsNullOrEmpty(sTssPrjJson) Then
                        Dim ser As JavaScriptSerializer = New JavaScriptSerializer()

                        Dim JsonList As List(Of TSSPRJMETRIC) = ser.Deserialize(Of List(Of TSSPRJMETRIC))(sTssPrjJson)
                        If Not JsonList Is Nothing Then
                            For i As Integer = 0 To JsonList.Count - 1
                                If JsonList(i).selected = "Y" Then
                                    cblTssPrjJson.Items(i).Selected = True
                                End If
                            Next
                        End If

                    End If


                    ddlActive.SelectedValue = drMetric("is_active")

                End If

            End If
        End If

    End Sub

    Function IsQualicyMetricBlank(ByVal metric As MetricModel) As Boolean
        Dim bBlank As Boolean = False

        If String.IsNullOrEmpty(metric.metricCategory) Then
            bBlank = True
            sAlertMsg.Append("Metric category can't be blank." & "<br/>")
        End If

        If String.IsNullOrEmpty(metric.metricName) Then
            bBlank = True
            sAlertMsg.Append("Metric name can't be blank." & "<br/>")
        End If

        IsQualicyMetricBlank = bBlank
    End Function

    Function IsUpdateRequired(ByRef drMetric As DataRow, ByVal metric As MetricModel) As Boolean
        Dim bUpdate As Boolean = False

        If mode = PAGEMODE.ADD Then
            bUpdate = True
            drMetric("metric_category") = metric.metricCategory
            drMetric("metric_category_desc") = metric.metricCategoryDesc
            drMetric("metric_name") = metric.metricName
            drMetric("metric_val_type") = metric.metricValType
            drMetric("metric_val_precision") = metric.metricValPrecision
            drMetric("metric_val_update_mode") = metric.metricValUpdateMode
            drMetric("tss_prj_json") = metric.tssPrjJson
            drMetric("fixed_price_project") = metric.fixedPriceProject

            drMetric("is_active") = metric.isActive

        Else

            If drMetric("metric_category") <> metric.metricCategory Then
                bUpdate = True
                drMetric("metric_category") = metric.metricCategory
                drMetric("metric_category_desc") = metric.metricCategoryDesc

                'dtMetric.Rows(0).Item("metric_category") = metric.metricCategory
                'dtMetric.Rows(0).Item("metric_category_desc") = metric.metricCategoryDescription
            End If

            If drMetric("metric_name") <> metric.metricName Then
                bUpdate = True
                drMetric("metric_name") = metric.metricName

                'dtMetric.Rows(0).Item("metric_name") = metric.metricName
            End If

            If drMetric("metric_val_type") <> metric.metricValType Then
                bUpdate = True
                drMetric("metric_val_type") = metric.metricValType

                'dtMetric.Rows(0).Item("metric_val_type") = metric.metricValType
            End If

            If drMetric("metric_val_precision") <> metric.metricValPrecision Then
                bUpdate = True
                drMetric("metric_val_precision") = metric.metricValPrecision

                'dtMetric.Rows(0).Item("metric_val_precision") = metric.metricValPrecision
            End If

            If drMetric("metric_val_update_mode") <> metric.metricValUpdateMode Then
                bUpdate = True
                drMetric("metric_val_update_mode") = metric.metricValUpdateMode

                'dtMetric.Rows(0).Item("metric_val_update_mode") = metric.metricValUpdateMode
            End If

            If drMetric("tss_prj_json") <> metric.tssPrjJson Then
                bUpdate = True
                drMetric("tss_prj_json") = metric.tssPrjJson
            End If

            If drMetric("fixed_price_project") <> metric.fixedPriceProject Then
                bUpdate = True
                drMetric("fixed_price_project") = metric.fixedPriceProject
            End If

            If drMetric("is_active") <> metric.isActive Then
                bUpdate = True
                drMetric("is_active") = metric.isActive

                'dtMetric.Rows(0).Item("is_active") = metric.isActive
            End If
        End If

        IsUpdateRequired = bUpdate
    End Function

#End Region



#Region "Page_Elements"

    Protected Sub btnCreateClick()
        bAlert = False
        sAlertMsg = New StringBuilder("")

        mode = PAGEMODE.ADD
        PrepareMetric()
        EnableSection()

    End Sub

    Sub btnCancel_Click()

        mode = PAGEMODE.READ

        LoadMetricList()
        EnableSection()

    End Sub

    Sub btnSave_Click()
        bAlert = False
        sAlertMsg = New StringBuilder("")

        Dim metric As MetricModel = New MetricModel
        Dim drMetric As DataRow = dtMetric.NewRow

        metric.metricCategory = ddlMetricCategory.SelectedValue
        metric.metricCategoryDesc = ddlMetricCategory.SelectedItem.Text
        metric.metricName = DataFormatHelper.StringTrim(txtMetricName.Text)
        metric.metricCode = metricCode
        metric.metricValType = ddlMetricValType.SelectedValue
        metric.metricValPrecision = ddlMetricValPrecision.SelectedValue
        metric.metricValUpdateMode = ddlMetricValeUpdMode.SelectedValue

        Dim sTssPrjJson As StringBuilder = New StringBuilder("[")
        For i As Integer = 0 To cblTssPrjJson.Items.Count - 1
            If i > 0 Then
                sTssPrjJson.Append(", ")
            End If
            sTssPrjJson.Append("{")

            sTssPrjJson.Append("""" & "tss_prj" & """")
            sTssPrjJson.Append(":")
            sTssPrjJson.Append("""" & cblTssPrjJson.Items(i).Value & """")

            sTssPrjJson.Append(", ")

            sTssPrjJson.Append("""" & "selected" & """")
            sTssPrjJson.Append(":")
            sTssPrjJson.Append("""" & IIf(cblTssPrjJson.Items(i).Selected, "Y", "N") & """")

            sTssPrjJson.Append("}")
        Next
        sTssPrjJson.Append("]")
        metric.tssPrjJson = sTssPrjJson.ToString

        metric.fixedPriceProject = IIf(cbFixedPricePrj.Checked, "Y", "N")

        metric.isActive = ddlActive.SelectedValue

        'Check required fields
        bAlert = IsQualicyMetricBlank(metric)

        If Not bAlert Then
            If mode = PAGEMODE.EDIT Then
                drMetric = dtMetric.Rows(0)
            End If

            'Check if create / update required
            If Not IsUpdateRequired(drMetric, metric) Then

                mode = PAGEMODE.READ
                LoadMetricList()
                EnableSection()

            Else
                'Check if existing records.
                If metricService.IsExistedMetric(metric) Then
                    bAlert = True
                    sAlertMsg.Append("This record already exists in database." & "<br/>")
                Else
                    'Save Records
                    drMetric("last_updated_by") = Session("logon_id")
                    drMetric("last_updated_dt") = Now

                    If mode = PAGEMODE.ADD Then
                        drMetric("created_by") = Session("logon_id")
                        drMetric("created_dt") = Now

                        dtMetric.Rows.Add(drMetric)

                    Else
                        dtMetric.Rows(0).ItemArray = drMetric.ItemArray
                    End If 'End If mode = PAGEMODE.ADD

                    'process db Saving
                    If metricService.SaveMetric(dtMetric) Then
                        dtMetric.AcceptChanges()
                        sAlertMsg.Append(String.Format("Metric is {0} successfully.", IIf(mode = PAGEMODE.ADD, "created", "updated")))
                        mode = PAGEMODE.READ
                        btnCancel_Click()
                    Else
                        dtMetric.RejectChanges()
                        bAlert = True
                        sAlertMsg.Append(String.Format("Failed to {0} metric data.", IIf(mode = PAGEMODE.ADD, "created", "updated")))
                    End If 'End If metricService.EditQualityMetric(dtMetric)

                End If 'End If metricService.IsExistedQualityMetric(metric)

            End If 'End If Not IsUpdateRequired(drMetric, metric)

        End If 'End If Not bAlert

    End Sub


    Sub EnableSection()
        dvMetrics.Style.Item("display") = IIf(mode = PAGEMODE.READ, "", "none")
        dvMetricsEdit.Style.Item("display") = IIf(mode = PAGEMODE.READ, "none", "")

        btnCreate.Visible = IIf(mode = PAGEMODE.READ, True, False)
        btnSave_Top.Visible = IIf(mode = PAGEMODE.READ, False, True)
        btnCancel_top.Visible = IIf(mode = PAGEMODE.READ, False, True)

    End Sub

    Sub InitWebControls()

        Dim dtMetricCate As DataTable = New DataTable("MetricCate")
        dtMetricCate = lookupService.GetLookUpList(LOOKUP_TYPE, "METRICCATE")
        ddlMetricCategory.Items.Clear()
        WebControlHelper.DropDownListDataBind(ddlMetricCategory, dtMetricCate, "LOOKUP_NAME", "LOOKUP_CODE")
        dtMetricCate.Dispose()

        Dim dtMetricValType As DataTable = New DataTable("MetricValType")
        dtMetricValType = lookupService.GetLookUpList(LOOKUP_TYPE, "METRICVALTYPE")
        ddlMetricValType.Items.Clear()
        WebControlHelper.DropDownListDataBind(ddlMetricValType, dtMetricValType, "LOOKUP_NAME", "LOOKUP_CODE", False)
        If Not ddlMetricValType Is Nothing Then
            If ddlMetricValType.Items.Count > 0 Then
                ddlMetricValType.SelectedValue = "N"
            End If
        End If
        dtMetricValType.Dispose()

        Dim dtMetricValPrecision As DataTable = New DataTable("MetricValPrecision")
        dtMetricValPrecision = lookupService.GetLookUpList(LOOKUP_TYPE, "METRICVALPREC")
        WebControlHelper.DropDownListDataBind(ddlMetricValPrecision, dtMetricValPrecision, "LOOKUP_NAME", "LOOKUP_CODE", False)
        If Not ddlMetricValPrecision Is Nothing Then
            If ddlMetricValPrecision.Items.Count > 0 Then
                ddlMetricValPrecision.SelectedValue = 1
            End If
        End If
        dtMetricValPrecision.Dispose()


        Dim dtMetricValUpdMode As DataTable = New DataTable("MetricValUpdMode")
        dtMetricValUpdMode = lookupService.GetLookUpList(LOOKUP_TYPE, "METRICVALUPDMODE")
        WebControlHelper.DropDownListDataBind(ddlMetricValeUpdMode, dtMetricValUpdMode, "LOOKUP_NAME", "LOOKUP_CODE", False)
        If Not ddlMetricValeUpdMode Is Nothing Then
            If ddlMetricValeUpdMode.Items.Count > 0 Then
                ddlMetricValeUpdMode.SelectedValue = "U"
            End If
        End If
        dtMetricValUpdMode.Dispose()

        InitTssPrjCheckboxList(cblTssPrjJson)


        ddlActive.Items.Clear()
        ddlActive.Items.Add(New ListItem("Yes", "Y"))
        ddlActive.Items.Add(New ListItem("No", "N"))
        ddlActive.DataBind()

    End Sub

    Sub InitTssPrjCheckboxList(ByRef cbl As CheckBoxList)
        cbl.Items.Clear()
        Dim dtTssPrj As DataTable = New DataTable("TssPrj")
        dtTssPrj = tssPrjService.GetTssProjectFilterList

        sTssPrjChkBoxList = New StringBuilder("")
        If Not dtTssPrj Is Nothing Then
            cbl.DataSource = dtTssPrj
            cbl.DataValueField = "code"
            cbl.DataTextField = "name"
            cbl.DataBind()
        End If
    End Sub
#End Region




    Private Sub gvMetrics_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvMetrics.RowCommand
        If e.CommandName = "editMetric" Then
            Dim index As String = CType(e.CommandArgument(), Integer)

            Dim gvRow As GridViewRow = gvMetrics.Rows(index)

            metricCode = gvMetrics.DataKeys(index).Item(0).ToString()


            mode = PAGEMODE.EDIT

            PrepareMetric()
            EnableSection()
        End If
    End Sub

    Private Sub gvMetrics_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvMetrics.RowDataBound

        If e.Row.RowType = DataControlRowType.Header Then

            Dim dtTssPrj As DataTable = tssPrjService.GetTssProjectFilterList()
            If Not dtTssPrj Is Nothing Then
                For i As Integer = 0 To dtTssPrj.Rows.Count - 1
                    Select Case dtTssPrj.Rows(i).Item("code")
                        Case TSSSERVICECATEGORY.BAUM
                            e.Row.Cells(4).Text = dtTssPrj.Rows(i).Item("name")
                        Case TSSSERVICECATEGORY.BAUE
                            e.Row.Cells(5).Text = dtTssPrj.Rows(i).Item("name")
                        Case TSSSERVICECATEGORY.PRJDEVLOPMENT
                            e.Row.Cells(6).Text = dtTssPrj.Rows(i).Item("name")
                        Case TSSSERVICECATEGORY.PRJDEPLOY
                            e.Row.Cells(7).Text = dtTssPrj.Rows(i).Item("name")
                    End Select
                Next
            End If

        End If
        If e.Row.RowType = DataControlRowType.DataRow Then


            Dim tssPrjJsonHidden As HiddenField = New HiddenField
            If Not e.Row.FindControl("tssPrjJsonHidden") Is Nothing Then
                tssPrjJsonHidden = CType(e.Row.FindControl("tssPrjJsonHidden"), HiddenField)
            End If

            If Not tssPrjJsonHidden Is Nothing Then
                Dim tssPrjJson As String = tssPrjJsonHidden.Value
                Dim tssPrjSelectedList As List(Of TSSPRJMETRIC) = Nothing

                If Not String.IsNullOrEmpty(tssPrjJson) Then
                    tssPrjSelectedList = DeserializeJsonToList(tssPrjJson)

                    If Not tssPrjSelectedList Is Nothing Then
                        For i As Integer = 0 To tssPrjSelectedList.Count - 1
                            Dim tssPrj As String = tssPrjSelectedList(i).tss_prj

                            'Dim tssPrjName As String = tssPrjService.getTssProjectNameByCode(tssPrj)
                            Dim selected As String = tssPrjSelectedList(i).selected

                            If selected = "Y" Then
                                Select Case tssPrj
                                    Case TSSSERVICECATEGORY.BAUM
                                        Dim cbTssPrj01 As CheckBox = New CheckBox
                                        If Not e.Row.FindControl("cbTssPrj01") Is Nothing Then
                                            cbTssPrj01 = CType(e.Row.FindControl("cbTssPrj01"), CheckBox)
                                            cbTssPrj01.Checked = True
                                        End If


                                    Case TSSSERVICECATEGORY.BAUE
                                        Dim cbTssPrj02 As CheckBox = New CheckBox
                                        If Not e.Row.FindControl("cbTssPrj02") Is Nothing Then
                                            cbTssPrj02 = CType(e.Row.FindControl("cbTssPrj02"), CheckBox)
                                            cbTssPrj02.Checked = True
                                        End If

                                    Case TSSSERVICECATEGORY.PRJDEVLOPMENT
                                        Dim cbTssPrj03 As CheckBox = New CheckBox
                                        If Not e.Row.FindControl("cbTssPrj03") Is Nothing Then
                                            cbTssPrj03 = CType(e.Row.FindControl("cbTssPrj03"), CheckBox)
                                            cbTssPrj03.Checked = True
                                        End If

                                    Case TSSSERVICECATEGORY.PRJDEPLOY
                                        Dim cbTssPrj04 As CheckBox = New CheckBox
                                        If Not e.Row.FindControl("cbTssPrj04") Is Nothing Then
                                            cbTssPrj04 = CType(e.Row.FindControl("cbTssPrj04"), CheckBox)
                                            cbTssPrj04.Checked = True
                                        End If
                                End Select
                            End If
                        Next 'End For i As Integer = 0 To tssPrjSelectedList.Count - 1
                    End If 'End If Not tssPrjSelectedList Is Nothing
                End If 'End If Not String.IsNullOrEmpty(tssPrjJson)

            End If 'End If Not tssPrjJsonHidden Is Nothing

        End If 'End If e.Row.RowType = DataControlRowType.DataRow
    End Sub


    Function DeserializeJsonToList(ByVal jsonText As String) As List(Of TSSPRJMETRIC)

        Dim JsonList As List(Of TSSPRJMETRIC) = Nothing
        If Not String.IsNullOrEmpty(jsonText) Then
            Dim ser As JavaScriptSerializer = New JavaScriptSerializer()
            JsonList = ser.Deserialize(Of List(Of TSSPRJMETRIC))(jsonText)
        End If

        Return JsonList
    End Function


End Class