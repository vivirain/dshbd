﻿Imports System.IO
Imports System.Web.Script.Serialization
Imports pmaDashboard.Lookup


Public Class ProfileScheduleTab
    Inherits System.Web.UI.Page

    Const LOOKUP_TYPE = "B"

    Public Enum PAGE_MODE
        READ = 0
        EDIT = -1
        ADD = 1
    End Enum

    Protected Shared mode As Integer


    Protected profileId As Integer = 0
    Protected prfMainCode As String = ""
    Protected fromPg As String = ""
    Protected currentDataVer As String = Format(Now, "yyyyMMdd")
    Private sPrfDesc As String = ""


    'Schedule
    Dim dtIssueTrackStatus As DataTable = Nothing
    Protected dtPrfScheduleView As DataTable = Nothing
    Protected sScheduleNo As String = ""
    Protected sScheduleStage As String = ""
    Protected sScheduleSta As String = ""
    Protected sScheduleTrackSta As String = ""
    Protected sScheduleProgress As String = ""
    Protected sScheduleComment As String = ""
    Protected sScheduleTgtStartDate As String = ""
    Protected sScheduleTgtEndDate As String = ""
    Protected sScheduleActlStartDate As String = ""
    Protected sScheduleActlEndDate As String = ""



    'Profile
    Protected dtProfile As DataTable = New DataTable("prjProfile")

    'Page
    Private isError As Boolean = False
    Public sAlertMsgBuilder As StringBuilder = New StringBuilder("")


    Dim pmaPrjService As IPmaProjectService = New PmaProjectService
    Dim pmaBizUnitService As IPmaBizUnitService = New PmaBizUnitService
    Dim pmaUserService As IPmaUserService = New PmaUserService
    Dim lookupService As ILookupService = New LookupService

    Dim prfService As IProfileService = New ProfileService
    Dim prfIssueService As IProfileIssueService = New ProfileIssueService
    Dim prfScheduleService As IProfileScheduleService = New ProfileScheduleService

    Dim logHelper As LogHelper = New LogHelper



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            If Session("prf_id") Is Nothing Then
                profileId = 0
                Session("prf_id") = profileId
            Else
                profileId = Session("prf_id")
            End If

            If Session("fromPg") Is Nothing Then
                fromPg = "DRAFT"
                Session("fromPg") = fromPg
            Else
                fromPg = Session("fromPg")
            End If

            If Session("current_data_version") Is Nothing Then
                currentDataVer = Format(Now, "yyyyMMdd")
                Session("current_data_version") = currentDataVer
            Else
                currentDataVer = Session("current_data_version")
            End If

            Session("schedule_no") = Nothing
            mode = PAGE_MODE.READ

            'Basic Info
            LoadProfileBasic(profileId)

            'Schedule
            LoadProfileSchedule(profileId)

        End If

    End Sub

#Region "Basic_Info"
    Sub LoadProfileBasic(ByVal profileId As Integer)

        isError = False

        dtProfile = prfService.GetProfile(profileId)

        If dtProfile Is Nothing Then
            'MsgBox("Sorry, profile data is not found.")
            isError = True
        ElseIf dtProfile.Rows.Count > 0 Then

            prfMainCode = dtProfile.Rows(0).Item("PRF_MAIN_CODE")
            Session("prf_main_code") = prfMainCode

            sPrfDesc = dtProfile.Rows(0).Item("PRF_DESC").ToString.Trim
            Dim prfHidden As HiddenField = New HiddenField
            If Not Me.Master.FindControl("prfDesc") Is Nothing Then
                prfHidden = CType(Me.Master.FindControl("prfDesc"), HiddenField)
                prfHidden.Value = sPrfDesc
            End If

        End If
    End Sub



#End Region


#Region "Schedule"
    'View
    Sub LoadProfileSchedule(ByVal profileId As Integer)
        mode = PAGE_MODE.READ
        Session("schedule_no") = Nothing
        dtPrfScheduleView = prfScheduleService.GetProfileScheduleListView(profileId)

        If Not dtPrfScheduleView Is Nothing Then
            If dtPrfScheduleView.Rows.Count > 0 Then
                dtPrfScheduleView = dtPrfScheduleView.Select("1=1", "schedule_est_start_dt, schedule_est_end_dt, schedule_actl_start_dt, schedule_actl_end_dt").CopyToDataTable
            End If
            WebControlHelper.GridViewDataBind(gvSchedule, dtPrfScheduleView)
        End If

    End Sub

    Sub InitProfileScheduleDetail(ByVal mode As String, Optional ByVal ScheduleNo As String = "")

        If String.IsNullOrEmpty(ScheduleNo) Then
            Session("schedule_no") = Nothing
        Else
            Session("schedule_no") = ScheduleNo
        End If
        sScheduleStage = ""
        sScheduleSta = ""
        sScheduleTrackSta = ""
        sScheduleProgress = ""
        sScheduleComment = ""

        sScheduleTgtStartDate = ""
        sScheduleTgtEndDate = ""
        sScheduleActlStartDate = ""
        sScheduleActlEndDate = ""

        'Issue Track Status
        If dtIssueTrackStatus Is Nothing Then
            dtIssueTrackStatus = lookupService.GetLookUpList("B", "STATUS")
        End If
        If Not dtIssueTrackStatus Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlScheduleTrackStatus, dtIssueTrackStatus, "lookup_name", "lookup_code")
        End If

        If mode = PAGE_MODE.ADD Then
            txtScheduleStage.Text = ""
            txtScheduleProgress.Value = ""
            txtScheduleComment.Text = ""

            ddlScheduleTrackStatus.SelectedValue = ""

            'Date
            txtScheduleTgtStartDt.Text = ""
            txtScheduleTgtEndDt.Text = ""
            txtScheduleActlStartDt.Text = ""
            txtScheduleActlEndDt.Text = ""
            txtScheduleTgtStartDt.Attributes.Add("readonly", True)
            txtScheduleTgtEndDt.Attributes.Add("readonly", True)
            txtScheduleActlStartDt.Attributes.Add("readonly", True)
            txtScheduleActlEndDt.Attributes.Add("readonly", True)
        End If


        If mode = PAGE_MODE.EDIT Then
            Dim dtSchedule As DataTable = prfScheduleService.GetProfileSchedule(sScheduleNo)
            If Not dtSchedule Is Nothing Then
                If dtSchedule.Rows.Count > 0 Then
                    Dim drSchedule As DataRow = dtSchedule.Rows(0)

                    sScheduleStage = drSchedule("schedule_stage").ToString
                    txtScheduleStage.Text = drSchedule("schedule_stage").ToString

                    sScheduleComment = drSchedule("schedule_comment").ToString
                    txtScheduleComment.Text = drSchedule("schedule_comment").ToString

                    sScheduleSta = drSchedule("schedule_status").ToString.Trim

                    sScheduleTrackSta = drSchedule("schedule_trace_status").ToString.Trim
                    ddlScheduleTrackStatus.SelectedValue = sScheduleTrackSta

                    If Not IsDBNull(drSchedule("schedule_progress")) Then
                        If IsNumeric(drSchedule("schedule_progress")) Then
                            sScheduleProgress = DataFormatHelper.FormatString(drSchedule("schedule_progress").ToString, "P", 2)
                            txtScheduleProgress.Value = sScheduleProgress
                        End If
                    End If


                    If Not IsDBNull(drSchedule("schedule_est_start_dt")) And IsDate(drSchedule("schedule_est_start_dt")) Then
                        txtScheduleTgtStartDt.Text = Format(drSchedule("schedule_est_start_dt"), Session("date_format"))
                    End If
                    If Not IsDBNull(drSchedule("schedule_est_end_dt")) And IsDate(drSchedule("schedule_est_end_dt")) Then
                        txtScheduleTgtEndDt.Text = Format(drSchedule("schedule_est_end_dt"), Session("date_format"))
                    End If
                    If Not IsDBNull(drSchedule("schedule_actl_start_dt")) And IsDate(drSchedule("schedule_actl_start_dt")) Then
                        txtScheduleActlStartDt.Text = Format(drSchedule("schedule_actl_start_dt"), Session("date_format"))
                    End If
                    If Not IsDBNull(drSchedule("schedule_actl_end_dt")) And IsDate(drSchedule("schedule_actl_end_dt")) Then
                        txtScheduleActlEndDt.Text = Format(drSchedule("schedule_actl_end_dt"), Session("date_format"))
                    End If

                    txtScheduleTgtStartDt.Attributes.Add("readonly", True)
                    txtScheduleTgtEndDt.Attributes.Add("readonly", True)
                    txtScheduleActlStartDt.Attributes.Add("readonly", True)
                    txtScheduleActlEndDt.Attributes.Add("readonly", True)

                End If
            End If
        End If
    End Sub

    Private Sub btnAddSchedule_ServerClick(sender As Object, e As System.EventArgs) Handles btnAddSchedule.ServerClick
        mode = PAGE_MODE.ADD
        InitProfileScheduleDetail(mode)

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalSchedule', true);", True)
    End Sub

    Private Sub btnSaveSchedule_Click(sender As Object, e As System.EventArgs) Handles btnSaveSchedule.Click
        sScheduleStage = Trim(txtScheduleStage.Text)
        sScheduleSta = SCHEDULE_STAUS.OPEN
        sScheduleTrackSta = ddlScheduleTrackStatus.SelectedValue
        sScheduleProgress = txtScheduleProgress.Value
        sScheduleComment = Trim(txtScheduleComment.Text)

        sScheduleProgress = Trim(txtScheduleProgress.Value)

        If Not Session("schedule_no") Is Nothing Then
            sScheduleNo = Session("schedule_no")
        End If

        Dim dtSchedule As DataTable = New DataTable
        Dim drSchedule As DataRow
        Dim sIssueActionSta As String = ISSUE_STAUS.OPEN
        Dim sIssueActionStaBefore As String = ""
        Dim bNew As Boolean = False

        If mode = PAGE_MODE.ADD Then
            dtSchedule = prfScheduleService.GetProfileScheduleList(True)
        Else
            dtSchedule = prfScheduleService.GetProfileSchedule(sScheduleNo)
        End If

        If dtSchedule Is Nothing Then
            Return
        End If

        Try
            If mode = PAGE_MODE.ADD Then
                drSchedule = dtSchedule.NewRow

                sScheduleNo = prfScheduleService.GetNewScheduleNo()
                drSchedule("schedule_no") = sScheduleNo

                'drSchedule("prj_code") = Trim(prfMainCode)
                'drSchedule("prf_id") = profileId
                drSchedule("prj_code") = Trim(Session("prf_main_code"))
                drSchedule("prf_id") = Session("prf_id")

                drSchedule("created_by") = Session("logon_id")
                drSchedule("created_dt") = Now
            Else
                drSchedule = dtSchedule.Rows(0)
            End If

            sScheduleTgtStartDate = txtScheduleTgtStartDt.Text
            If IsDate(sScheduleTgtStartDate) Then
                drSchedule("schedule_est_start_dt") = sScheduleTgtStartDate
            Else
                drSchedule("schedule_est_start_dt") = DBNull.Value
            End If

            sScheduleTgtEndDate = txtScheduleTgtEndDt.Text
            If IsDate(sScheduleTgtEndDate) Then
                drSchedule("schedule_est_end_dt") = sScheduleTgtEndDate
            Else
                drSchedule("schedule_est_end_dt") = DBNull.Value
            End If

            sScheduleActlStartDate = txtScheduleActlStartDt.Text
            If IsDate(sScheduleActlStartDate) Then
                drSchedule("schedule_actl_start_dt") = sScheduleActlStartDate
            Else
                drSchedule("schedule_actl_start_dt") = DBNull.Value
            End If

            sScheduleActlEndDate = txtScheduleActlEndDt.Text
            If IsDate(txtScheduleActlEndDt.Text) Then
                drSchedule("schedule_actl_end_dt") = sScheduleActlEndDate
                sScheduleSta = SCHEDULE_STAUS.CLOSE
            Else
                drSchedule("schedule_actl_end_dt") = DBNull.Value
                sScheduleSta = SCHEDULE_STAUS.OPEN
            End If

            drSchedule("schedule_stage") = sScheduleStage
            drSchedule("schedule_comment") = sScheduleComment

            drSchedule("schedule_status") = sScheduleSta
            drSchedule("schedule_trace_status") = sScheduleTrackSta
            If IsNumeric(sScheduleProgress) Then
                drSchedule("schedule_progress") = Convert.ToDecimal(sScheduleProgress) / 100
            End If


            drSchedule("last_updated_by") = Session("logon_id")
            drSchedule("last_updated_dt") = Now

            If mode = PAGE_MODE.ADD Then
                dtSchedule.Rows.Add(drSchedule)
            End If

            If prfScheduleService.SaveProfileSchedule(dtSchedule) Then
                LoadProfileSchedule(Session("prf_id"))
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "enableContentTab('#navTabSchedule');", True)
            Else
                sAlertMsgBuilder = New StringBuilder("Oops, failed to edit action.")
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalIssueAction', true);", True)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnCancelshedule_Click(sender As Object, e As System.EventArgs) Handles btnCancelshedule.Click
        LoadProfileSchedule(Session("prf_id"))
        mode = PAGE_MODE.READ

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "enableContentTab('#navTabSchedule');", True)

    End Sub

    Private Sub gvSchedule_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvSchedule.RowCommand
        If e.CommandName = "editSchedule" Then
            Dim index = Convert.ToInt32(e.CommandArgument)

            Dim gvRow As GridViewRow = CType(e.CommandSource, GridView).Rows(index)

            sScheduleNo = gvSchedule.DataKeys(index).Item(0).ToString

            mode = PAGE_MODE.EDIT
            InitProfileScheduleDetail(mode, sScheduleNo)

            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalSchedule', true);", True)
        End If
    End Sub
#End Region




#Region "NavTab_Navigation"
    Sub PrepareNavigationParams()
    End Sub

    Private Sub navTabBasic_ServerClick(sender As Object, e As System.EventArgs) Handles navTabBasic.ServerClick
        'PrepareNavigationParams()

        Server.Transfer("ProfileBasicEditTab.aspx")
    End Sub

    Private Sub navTabHealthSta_ServerClick(sender As Object, e As System.EventArgs) Handles navTabHealthSta.ServerClick
        'PrepareNavigationParams()

        Server.Transfer("ProfileHealthTab.aspx")

    End Sub

    Private Sub navTabQualitySta_ServerClick(sender As Object, e As System.EventArgs) Handles navTabQualitySta.ServerClick
        'PrepareNavigationParams()

        Server.Transfer("ProfileQualityTab.aspx")
    End Sub

    Private Sub navTabSchedule_ServerClick(sender As Object, e As System.EventArgs) Handles navTabSchedule.ServerClick
    End Sub

    Private Sub navTabIssue_ServerClick(sender As Object, e As System.EventArgs) Handles navTabIssue.ServerClick
        'PrepareNavigationParams()

        Server.Transfer("ProfileIssueTab.aspx")
    End Sub

    Private Sub navTabPreview_ServerClick(sender As Object, e As System.EventArgs) Handles navTabPreview.ServerClick
        If Session("fromPg") = "LIST" Then
            Server.Transfer("ProfilePreview.aspx")
        Else
            Server.Transfer("ProfilePreviewDraft.aspx")
        End If
    End Sub
#End Region








End Class