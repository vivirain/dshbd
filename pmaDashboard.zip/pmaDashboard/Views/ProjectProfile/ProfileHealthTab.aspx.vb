﻿Imports System.IO
Imports NPOI
Imports System.Web.Script.Serialization
Imports System.Web.Services


Public Class ProfileHealthTab
    Inherits System.Web.UI.Page

    Const LOOKUP_TYPE As String = "B"

    Protected profileId As Integer = 0
    Protected fromPg As String = ""
    Protected sTssPrj As String = ""
    Private dtProfile As DataTable = Nothing

    Protected currentDataVer As String = ""
    Protected prfStatusBefore As ProfileHealthStatusModel = New ProfileHealthStatusModel
    Protected prfStatusAfter As ProfileHealthStatusModel = New ProfileHealthStatusModel

    Private isError As Boolean = False
    Public sErrMsgBuilder As StringBuilder = New StringBuilder("")

    Dim lookupService As ILookupService = New LookupService
    Dim prfService As IProfileService = New ProfileService
    Dim logHelper As LogHelper = New LogHelper
    Dim tranLogService As ILogService = New LogService


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            'Section 0: Retrieve session data
            If Session("prf_id") Is Nothing Then
                profileId = 0
                Session("prf_id") = profileId
                logHelper.WriteLog("profileId is not in session.")
                Server.Transfer("Views/ProjectProfile/ProfileList.aspx")
            Else
                profileId = Session("prf_id")
                prfId.Text = profileId
            End If

            If Session("fromPg") Is Nothing Then
                fromPg = "DRAFT"
                Session("fromPg") = fromPg
            Else
                fromPg = Session("fromPg")
            End If

            If Session("current_data_version") Is Nothing Then
                currentDataVer = Format(Now, "yyyyMMdd")
                Session("current_data_version") = currentDataVer
            Else
                currentDataVer = Session("current_data_version")
            End If
            lblCurrentDataVer.Text = currentDataVer

            'Section 1: Get Basic Info
            Dim hasError As Boolean = False
            LoadProfileBasic(profileId, hasError)
            If hasError Then
                Return
            End If

            'Section 2: Load & Update Health Status
            LoadHealthStatusData(profileId)

            'Section 3: Load Health Status of Last Version
            LoadProfileLast(profileId, currentDataVer)
        End If

    End Sub


#Region "Basic_Info"
    Sub LoadProfileBasic(ByVal profileId As Integer, ByRef hasError As Boolean)
        hasError = False

        dtProfile = prfService.GetProfile(profileId)
        If dtProfile Is Nothing OrElse dtProfile.Rows.Count = 0 Then
            dtProfile = prfService.GetProfileHist(profileId, currentDataVer)
        End If
        Dim sPrfDesc As String = ""

        If dtProfile Is Nothing OrElse dtProfile.Rows.Count = 0 Then
            hasError = True
            sErrMsgBuilder = New StringBuilder("Failed to load profile data.")
            logHelper.WriteLog("Failed to load profile " & profileId)
            tranLogService.WriteTranLog("PROFILE_LOAD", Session("logon_id"), "Profile [" & profileId & "] is not found.")
            Return
        End If

        sTssPrj = dtProfile.Rows(0).Item("TSS_PRJ").ToString
        'lblTssPrj.Text = dtProfile.Rows(0).Item("TSS_PRJ").ToString
        lblTssPrj.Text = sTssPrj
        prfId.Text = profileId

        sPrfDesc = dtProfile.Rows(0).Item("PRF_DESC").ToString.Trim
        Dim prfHidden As HiddenField = New HiddenField
        If Not Me.Master.FindControl("prfDesc") Is Nothing Then
            prfHidden = CType(Me.Master.FindControl("prfDesc"), HiddenField)
            prfHidden.Value = sPrfDesc
        End If

        'currentDataVer = dtProfile.Rows(0).Item("data_version").ToString.Trim
        'If String.IsNullOrEmpty(currentDataVer) Then
        '    currentDataVer = Format(Now, "yyyyMMdd")
        'End If
        'Session("current_data_version") = currentDataVer
        'lblCurrentDataVer.Text = currentDataVer
    End Sub
#End Region



#Region "Health_Status"
    Sub LoadHealthStatusData(ByVal profileId As Integer)

        'Health Status
        BindDropDownListData(ddlHealthSta, True)
        'Quality
        BindDropDownListData(ddlQualitySta, True)
        'Scope
        BindDropDownListData(ddlScopeSta, True)
        'Cost
        BindDropDownListData(ddlCostSta, True)
        If sTssPrj = TSSSERVICECATEGORY.PRJDEVLOPMENT Or sTssPrj = TSSSERVICECATEGORY.PRJDEPLOY Then
            ddlCostSta.Enabled = False
        End If
        'Schedule
        BindDropDownListData(ddlScheduleSta, True)
        'Resource
        BindDropDownListData(ddlResourceSta, True)
        'CSS
        BindDropDownListData(ddlCssSta, True)

        BindDropDownListData(ddlStage, True, "STAGE")

        PrepareHealthStatusData()

        RecalculateCostDetails()
    End Sub

    Sub BindDropDownListData(ByVal ddlControl As DropDownList, Optional ByVal showBlankOption As Boolean = False, Optional ByVal category As String = "STATUS")
        Dim dt As DataTable = lookupService.GetLookUpList(LOOKUP_TYPE, category)

        If Not dt Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlControl, dt, "LOOKUP_NAME", "LOOKUP_CODE", showBlankOption)
            dt = Nothing
        End If

    End Sub


    Private Sub PrepareHealthStatusData()

        If dtProfile Is Nothing OrElse dtProfile.Rows.Count = 0 Then
            Return
        End If

        'Overall HealthStatus
        If Not IsDBNull(dtProfile.Rows(0).Item("health_status")) Then
            ddlHealthSta.SelectedValue = dtProfile.Rows(0).Item("health_status").ToString
            txtHealthSta.Value = dtProfile.Rows(0).Item("health_status").ToString
            prfStatusBefore.healthStatus = txtHealthSta.Value
            btnSubmit.Visible = True
        End If

        'Quality Status
        If Not IsDBNull(dtProfile.Rows(0).Item("quality_status")) Then
            ddlQualitySta.SelectedValue = dtProfile.Rows(0).Item("quality_status").ToString()
            txtQualitySta.Text = dtProfile.Rows(0).Item("quality_status").ToString()
            prfStatusBefore.qualityStatus = txtQualitySta.Text
            btnSubmit.Visible = True
        End If

        'Scope Status
        Dim scopeSta As String = ""
        If Not IsDBNull(dtProfile.Rows(0).Item("scope_status")) Then
            scopeSta = dtProfile.Rows(0).Item("scope_status").ToString()
            ddlScopeSta.SelectedValue = scopeSta
            prfStatusBefore.scopeStatus = scopeSta
            btnSubmit.Visible = True
        End If

        'Cost Status
        Dim costSta As String = ""
        If Not IsDBNull(dtProfile.Rows(0).Item("cost_status")) Then
            costSta = dtProfile.Rows(0).Item("cost_status").ToString()
            ddlCostSta.SelectedValue = costSta
            txtCostSta.Text = costSta
            prfStatusBefore.costStatus = costSta
            btnSubmit.Visible = True
        End If

        'Schedule Status
        If Not IsDBNull(dtProfile.Rows(0).Item("schedule_status")) Then
            ddlScheduleSta.SelectedValue = dtProfile.Rows(0).Item("schedule_status").ToString()
            txtScheduleSta.Text = dtProfile.Rows(0).Item("schedule_status").ToString()
            prfStatusBefore.scheduleStatus = txtScheduleSta.Text
            btnSubmit.Visible = True
        End If
        If dtProfile.Rows(0).Item("tss_prj").ToString <> TSSSERVICECATEGORY.BAUM Then

        End If

        'Resource Status
        Dim resourceSta As String = ""
        If Not IsDBNull(dtProfile.Rows(0).Item("resource_status")) Then
            resourceSta = dtProfile.Rows(0).Item("resource_status").ToString()
            ddlResourceSta.SelectedValue = resourceSta
            prfStatusBefore.resourceStatus = resourceSta
            btnSubmit.Visible = True
        End If

        'Css Status
        Dim cssSta As String = ""
        If Not IsDBNull(dtProfile.Rows(0).Item("css_status")) Then
            cssSta = dtProfile.Rows(0).Item("css_status").ToString()
            ddlCssSta.SelectedValue = cssSta
            prfStatusBefore.cssStatus = cssSta
            btnSubmit.Visible = True
        End If


        'Stage
            Dim txtStage As String = ""
            If Not IsDBNull(dtProfile.Rows(0).Item("prj_stage")) Then
                txtStage = dtProfile.Rows(0).Item("prj_stage").ToString().Trim
                ddlStage.SelectedValue = txtStage
            End If

        'Project Status Summary
        Dim txtStatusRemark As String = ""
        If Not IsDBNull(dtProfile.Rows(0).Item("prj_status_remark")) Then
            txtStatusRemark = dtProfile.Rows(0).Item("prj_status_remark").ToString()
            txtPrjStatSummary.Text = txtStatusRemark
        End If

        'Project CSS Score
        Dim prjMetricService As IProjectMetricService = New ProjectMetricService
        Dim dtPrjMetricCss As DataTable = prjMetricService.GetProjectMetric(dtProfile.Rows(0).Item("prf_main_code").ToString, METRICCODE.CSS)
        If Not dtPrjMetricCss Is Nothing Then
            If dtPrjMetricCss.Rows.Count > 0 Then
                Dim sCssScore As String = dtPrjMetricCss.Rows(0).Item("metric_val").ToString.Trim
                If IsNumeric(sCssScore) Then
                    sCssScore = DataFormatHelper.FormatString(sCssScore, "N", 1)
                End If
                lblCssScore.Text = sCssScore
            End If
            dtPrjMetricCss.Dispose()
        End If

    End Sub

    Private Sub RecalculateCostDetails()
        'Get Profile Projects
        Dim prjCodes As String = dtProfile.Rows(0).Item("prj_codes")
        Dim pmaPrjService As IPmaProjectService = New PmaProjectService
        Dim dtProjects As DataTable = pmaPrjService.GetProjectViewList(prjCodes)
        If dtProjects Is Nothing Then
            Return
        ElseIf dtProjects.Rows.Count = 0 Then
            Return
        End If

        'Get currencyCode
        Dim currencyName As String = ""
        Dim currencyService As IPmaCurrencyService = New PmaCurrencyService
        currencyName = currencyService.getCurrencyName(dtProfile.Rows(0).Item("currency").ToString)

        'Budget
        Dim sBudget As String = ""
        Dim decBudget As Decimal
        If IsDBNull(dtProjects.Compute("SUM(PRJ_TOT_EST_COST)", "")) Then
            sBudget = 0
        Else
            sBudget = dtProjects.Compute("SUM(PRJ_TOT_EST_COST)", "")
        End If
        decBudget = Val(sBudget)
        sBudget = Format(sBudget, "Currency")
        sBudget = currencyName & " " & Right(sBudget, sBudget.Length - 1)
        txtBudget.Text = sBudget


        'Actual (Accural)
        Dim sActlCostAccrual As String = ""
        Dim decActlCostAccrual As Decimal
        'sActlPrj = dtProfile.Rows(0).Item("actl_total_cost").ToString
        'If IsDBNull(dtProjects.Compute("SUM(ATL_COST)", "")) Then
        '    sActlPrj = 0
        'Else
        '    sActlPrj = dtProjects.Compute("SUM(ATL_COST)", "")
        'End If
        If IsDBNull(dtProjects.Compute("SUM(ACTL_COST_ACCRUAL)", "")) Then
            sActlCostAccrual = 0
        Else
            sActlCostAccrual = dtProjects.Compute("SUM(ACTL_COST_ACCRUAL)", "")
        End If
        decActlCostAccrual = Val(sActlCostAccrual)
        sActlCostAccrual = Format(sActlCostAccrual, "Currency")
        sActlCostAccrual = currencyName & " " & Right(sActlCostAccrual, sActlCostAccrual.Length - 1)
        txtActlCostAccural.Text = sActlCostAccrual
        txtActlCostAccuralVal.Value = decActlCostAccrual

        'Calculate Budget Utilization Rate (Accrual)
        If IsNumeric(decBudget) And IsNumeric(decActlCostAccrual) And decBudget <> 0 And decActlCostAccrual <> 0 Then
            Dim decBURPrj As Decimal = Math.Round(decActlCostAccrual / decBudget, 4)
            txtBgtUtlRatePrj.Text = DataFormatHelper.FormatString(decBURPrj.ToString, "P", 2)
        End If

        'Actual (Cash based)
        Dim sActlCostBilled As String = ""
        Dim decActlCostBilled As Decimal
        Dim debitNoteService As IPmaDebitNoteDetailService = New PmaDebitNoteDetailService
        'decActl = debitNoteService.GetActualCost(dtProfile.Rows(0).Item("prj_codes"), Format(Now, "yyyy/MM"))
        decActlCostBilled = debitNoteService.GetActualCost(prjCodes, Format(Now, "yyyy/MM"))
        If decActlCostBilled <> 0 Then
            sActlCostBilled = decActlCostBilled
            sActlCostBilled = Format(sActlCostBilled, "Currency")
            sActlCostBilled = currencyName & " " & Right(sActlCostBilled, sActlCostBilled.Length - 1)
        End If
        txtActlCostBilled.Text = sActlCostBilled
        txtActlCostBilledVal.Value = decActlCostBilled

        'Calculate Budget Utilization Rate (Cash Based)
        If IsNumeric(decBudget) And IsNumeric(decActlCostBilled) And decBudget <> 0 And decActlCostBilled <> 0 Then
            Dim decBUR As Decimal = Math.Round(decActlCostBilled / decBudget, 4)
            txtBgtUtlRate.Text = DataFormatHelper.FormatString(decBUR.ToString, "P", 2)
        End If
    End Sub

#End Region






#Region "LAST_VERSIION"

    Sub LoadProfileLast(ByVal profileId As Integer, ByVal currentDataVer As String)
        Dim dtProfileLast As DataTable = prfService.GetProfileHistLast(profileId, currentDataVer)

        If dtProfileLast Is Nothing Then
            Return
        ElseIf dtProfileLast.Rows.Count = 0 Then
            Return
        End If

        If Not IsDBNull(dtProfileLast.Rows(0).Item("health_status")) Then
            txtHealthStaLast.Value = dtProfileLast.Rows(0).Item("health_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("quality_status")) Then
            txtQualityStaLast.Text = dtProfileLast.Rows(0).Item("quality_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("schedule_status")) Then
            txtScheduleStaLast.Text = dtProfileLast.Rows(0).Item("schedule_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("scope_status")) Then
            txtScopeStaLast.Text = dtProfileLast.Rows(0).Item("scope_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("cost_status")) Then
            txtCostStaLast.Text = dtProfileLast.Rows(0).Item("cost_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("resource_status")) Then
            txtResourceStaLast.Text = dtProfileLast.Rows(0).Item("resource_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("css_status")) Then
            txtCssStaLast.Text = dtProfileLast.Rows(0).Item("css_status").ToString
        End If
        lblHealthStaLast.InnerText = dtProfileLast.Rows(0).Item("data_version").ToString

        dtProfileLast = Nothing

    End Sub

#End Region



#Region "Save_Profile"
    Private Sub btnSave_Click(sender As Object, e As System.EventArgs) Handles btnSave.Click
        Dim bSave As Boolean = False

        Try

            bSave = SaveHealthStatus(Session("prf_id"))

            If bSave Then
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Health status is updated successfully.');</script>", False)
            Else
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Oops, it seems somthing is wrong while saving profile.');</script>", False)
            End If

        Catch ex As Exception
            logHelper.WriteLog("btnSave_Click", ex)
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Oops, system encounters a problem now.');</script>", False)
        End Try

    End Sub

    Function SaveHealthStatus(ByVal profileId As Integer) As Boolean
        Dim bSave As Boolean = False
        Dim prfHealthStaAfter As ProfileHealthStatusModel = New ProfileHealthStatusModel

        Try
            dtProfile = prfService.GetProfile(profileId)
            If dtProfile Is Nothing Then
                bSave = False
                logHelper.WriteLog("Failed to retreive profile data for saving.")
                Return bSave
            ElseIf dtProfile.Rows.Count = 0 Then
                bSave = False
                logHelper.WriteLog("Failed to retreive profile data for saving.")
                Return bSave
            End If

            PrepareHealthFactor4Save(dtProfile, prfHealthStaAfter)

            dtProfile.Rows(0).Item("data_version") = ""
            dtProfile.Rows(0).Item("status") = PROFILESTATUS.DRAFT
            dtProfile.Rows(0).Item("last_updated_by") = Session("logon_id")
            dtProfile.Rows(0).Item("last_updated_dt") = Now

            bSave = prfService.SaveProfile(PROFILESTATUS.DRAFT, dtProfile)


            If bSave Then
                TriggerSRIssueLog(profileId, dtProfile.Rows(0).Item("prf_main_code").ToString, prfHealthStaAfter)
                Session("fromPg") = "DRAFT"
                Session("current_data_version") = Format(Now, "yyyyMMdd")
            End If

        Catch ex As Exception
            bSave = False
            logHelper.WriteLog("SaveHealthStatus", ex)
            Throw ex
        End Try

        SaveHealthStatus = bSave
    End Function

    Function TriggerSRIssueLog(ByVal profileId As Integer, ByVal prfMainCode As String, ByRef prfHealthStaAfter As ProfileHealthStatusModel) As Boolean
        Dim bTrigger As Boolean = False

        Dim issueTag As String = ""
        If prfHealthStaAfter.scopeStatus <> "" And prfHealthStaAfter.scopeStatus <> "G" Then
            issueTag = "SCOPE"
            bTrigger = CreateIssueLog(profileId, prfMainCode, issueTag)
        End If

        If prfHealthStaAfter.costStatus <> "" And prfHealthStaAfter.costStatus <> "G" Then
            issueTag = "COST"
            bTrigger = CreateIssueLog(profileId, prfMainCode, issueTag)
        End If

        If prfHealthStaAfter.scheduleStatus <> "" And prfHealthStaAfter.scheduleStatus <> "G" Then
            issueTag = "SCHEDULE"
            bTrigger = CreateIssueLog(profileId, prfMainCode, issueTag)
        End If

        If prfHealthStaAfter.resourceStatus <> "" And prfHealthStaAfter.resourceStatus <> "G" Then
            issueTag = "RESOURCE"
            bTrigger = CreateIssueLog(profileId, prfMainCode, issueTag)
        End If

        If prfHealthStaAfter.cssStatus <> "" And prfHealthStaAfter.cssStatus <> "G" Then
            issueTag = "CSS"
            bTrigger = CreateIssueLog(profileId, prfMainCode, issueTag)
        End If


        TriggerSRIssueLog = bTrigger

    End Function

    Function CreateIssueLog(ByVal profileId As Integer, ByVal prfMainCode As String, ByVal issueTag As String) As Boolean
        Dim bTrigger As Boolean = False
        Dim prfIssueService As IProfileIssueService = New ProfileIssueService
        Dim sIssueDescShort As String = "Health Indicator " & issueTag & " turned into Amber/Red."

        Try
            'If Not prfIssueService.IsIssueCreated(profileId, "RISK", sIssueDescShort, issueTag) Then
            If Not prfIssueService.IsTagIssueCreated(profileId, issueTag) Then
                Dim dtIssue As DataTable = prfIssueService.GetProfileIssueList(False)
                If Not dtIssue Is Nothing Then
                    Dim drIssue As DataRow = dtIssue.NewRow
                    drIssue.Item("issue_category") = "RISK"
                    drIssue.Item("issue_desc_sys") = sIssueDescShort
                    drIssue.Item("issue_desc_short") = sIssueDescShort
                    drIssue.Item("prj_code") = prfMainCode
                    drIssue.Item("prf_id") = profileId
                    drIssue.Item("issue_tag") = issueTag
                    drIssue.Item("issue_status") = "O"
                    drIssue.Item("created_by") = "SYSTEM"
                    drIssue.Item("created_dt") = Now
                    drIssue.Item("last_updated_by") = "SYSTEM"
                    drIssue.Item("last_updated_dt") = Now
                    drIssue.Item("issue_no") = "RISK-" & prfIssueService.GetNewIssueNo("RISK")
                    dtIssue.Rows.Add(drIssue)
                    bTrigger = prfIssueService.SaveProfileIssue(dtIssue)
                End If

                dtIssue.Dispose()
            End If
        Catch ex As Exception
            logHelper.WriteLog("Failed to create issue within Health Tab.", ex)
        End Try

        CreateIssueLog = bTrigger
    End Function

    Sub PrepareHealthFactor4Save(ByRef dtProfile As DataTable, ByRef prfHealthStaAfter As ProfileHealthStatusModel)

        'sTssPrj = dtProfile.Rows(0).Item("tss_prj").ToString
        sTssPrj = lblTssPrj.Text.Trim

        'Health Status
        prfHealthStaAfter.healthStatus = txtHealthSta.Value
        If txtHealthSta.Value <> dtProfile.Rows(0).Item("health_status").ToString Then
            dtProfile.Rows(0).Item("health_status") = txtHealthSta.Value
        End If

        'Quality
        prfHealthStaAfter.qualityStatus = DataFormatHelper.StringTrim(txtQualitySta.Text)
        If DataFormatHelper.StringTrim(txtQualitySta.Text) <> dtProfile.Rows(0).Item("quality_status").ToString Then
            dtProfile.Rows(0).Item("quality_status") = DataFormatHelper.StringTrim(txtQualitySta.Text)
        End If
        'Scope
        prfHealthStaAfter.scopeStatus = ddlScopeSta.SelectedValue
        If ddlScopeSta.SelectedValue <> dtProfile.Rows(0).Item("scope_status").ToString Then
            dtProfile.Rows(0).Item("scope_status") = ddlScopeSta.SelectedValue
        End If
        'Resource
        prfHealthStaAfter.resourceStatus = ddlResourceSta.SelectedValue
        If ddlResourceSta.SelectedValue <> dtProfile.Rows(0).Item("resource_status").ToString Then
            dtProfile.Rows(0).Item("resource_status") = ddlResourceSta.SelectedValue
        End If
        'CSS
        prfHealthStaAfter.cssStatus = ddlCssSta.SelectedValue
        If ddlCssSta.SelectedValue <> dtProfile.Rows(0).Item("css_status").ToString Then
            dtProfile.Rows(0).Item("css_status") = ddlCssSta.SelectedValue
        End If
        'COST
        prfHealthStaAfter.costStatus = DataFormatHelper.StringTrim(txtCostSta.Text)
        If DataFormatHelper.StringTrim(txtCostSta.Text) <> dtProfile.Rows(0).Item("cost_status").ToString Then
            dtProfile.Rows(0).Item("cost_status") = DataFormatHelper.StringTrim(txtCostSta.Text)
        End If
        'Schedule
        prfHealthStaAfter.scheduleStatus = DataFormatHelper.StringTrim(txtScheduleSta.Text)
        If DataFormatHelper.StringTrim(txtScheduleSta.Text) <> dtProfile.Rows(0).Item("schedule_status").ToString Then
            dtProfile.Rows(0).Item("schedule_status") = DataFormatHelper.StringTrim(txtScheduleSta.Text)
        End If


        If ddlStage.SelectedValue <> dtProfile.Rows(0).Item("prj_stage").ToString Then
            dtProfile.Rows(0).Item("prj_stage") = ddlStage.SelectedValue
        End If

        If txtPrjStatSummary.Text <> dtProfile.Rows(0).Item("prj_status_remark").ToString Then
            dtProfile.Rows(0).Item("prj_status_remark") = txtPrjStatSummary.Text
        End If

        If IsNumeric(txtActlCostAccuralVal.Value) Then
            dtProfile.Rows(0).Item("actl_total_cost") = txtActlCostAccuralVal.Value
        End If
        If IsNumeric(txtActlCostBilledVal.Value) Then
            dtProfile.Rows(0).Item("actl_total_cost_billed") = txtActlCostBilledVal.Value
        End If

        If Not String.IsNullOrEmpty(prfHealthStaAfter.healthStatus) _
            Or Not String.IsNullOrEmpty(prfHealthStaAfter.scopeStatus) Or Not String.IsNullOrEmpty(prfHealthStaAfter.resourceStatus) _
            Or Not String.IsNullOrEmpty(prfHealthStaAfter.costStatus) Or Not String.IsNullOrEmpty(prfHealthStaAfter.cssStatus) Then
            btnSubmit.Visible = True
        End If

    End Sub
#End Region

    Private Sub btnSubmit_Click(sender As Object, e As System.EventArgs) Handles btnSubmit.Click
        Dim bSubmit As Boolean = False

        Try
            bSubmit = SaveHealthStatus(Session("prf_id"))

            If bSubmit Then

                logHelper.WriteLog("Profile is saved as draft for submision successfully.")
                Server.Transfer("ProfilePreviewDraft.aspx")

            Else
                logHelper.WriteLog("Failed to save profile health status as draft before submision.")
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Oops, it seems somthing is wrong while submitting profile.');</script>", False)
            End If

        Catch ex As Exception
            logHelper.WriteLog("btnSubmit_Click", ex)
        End Try


    End Sub

    Private Sub navTabPreview_ServerClick(sender As Object, e As System.EventArgs) Handles navTabPreview.ServerClick
        If Session("fromPg") = "LIST" Then
            Server.Transfer("ProfilePreview.aspx")
        Else
            Server.Transfer("ProfilePreviewDraft.aspx")
        End If
    End Sub
End Class