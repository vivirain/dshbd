﻿Imports System.Web.Services

Public Class ProfileReview
    Inherits System.Web.UI.Page

    Const LOOKUP_TYPE As String = "B"

    Protected profileId As Integer = 0

    'Basic Information
    Protected sPrfDesc As String = ""
    Protected sPrfDescDetail As String = ""
    Protected prjCodes As String = ""
    Protected prfMainCode As String = ""
    Protected sTssPrj As String = ""
    Protected sTssPrjName As String = ""
    Protected sBuName As String = ""
    Protected sPmName As String = ""
    Protected sFixedPricePrj As String = ""
    Protected sEstStartDt As String = ""
    Protected sEstEndDt As String = ""
    Protected sActlStartDt As String = ""
    Protected sActlEndDt As String = ""
    Protected sEstEffort As String = ""
    Protected sActlEffort As String = ""

    'Health Status
    Protected sBudget As String = ""
    Protected sActlCostAccurual As String = ""
    Protected sActlCostBilled As String = ""
    Protected sBudgetUtilRateAccrual As String = ""
    Protected sBudgetUtilRateBilled As String = ""
    Protected sPrjStaSummary As String = ""

    Protected fromPg As String = ""
    Protected dataVersion As String = ""

    Protected prjCodesLast As String = ""

    Protected Shared showMetricPerProfile As String = ""
    Protected currentPrjCode As String = ""
    Protected sMetricTargetYear As String = ""
    Protected currentDataVer As String = ""
    Protected lastDataVer As String = ""

    Protected dtProfile As DataTable = Nothing
    Protected dtProfileLast As DataTable = Nothing

    Protected dtProjects As DataTable = Nothing

    Protected dtPrjMetrics As DataTable = Nothing
    Protected dtPrjMetricRaw As DataTable = Nothing

    Protected dtPrjMetricsLast As DataTable = Nothing
    Protected dtPrjMetricRawLast As DataTable = Nothing
    Protected hsPrjMetricRaw As Hashtable = New Hashtable

    Protected dtPrjMetricsView As DataTable = Nothing
    Protected dtPrjMetricRawsView As DataTable = Nothing


    Dim hasError As Boolean = False
    Public sErrMsgBuilder As StringBuilder = New StringBuilder("")

    Dim pmaPrjService As IPmaProjectService = New PmaProjectService
    Dim pmaBizUnitService As IPmaBizUnitService = New PmaBizUnitService
    Dim pmaUserService As IPmaUserService = New PmaUserService
    Dim lookupService As ILookupService = New LookupService

    Dim metricRawService As IMetricRawService = New MetricRawService
    Dim metricService As IMetricService = New MetricService
    Dim metricRawMappingService As IMetricRawMappingService = New MetricRawMappingService
    Dim metricTargetService As IMetricTargetService = New MetricTargetService

    Shared prfService As IProfileService = New ProfileService
    Dim prjMetricService As IProjectMetricService = New ProjectMetricService
    Dim prjMetricRawService As IProjectMetricRawService = New ProjectMetricRawService
    Dim prfIssueService As IProfileIssueService = New ProfileIssueService
    Dim prfScheduleService As IProfileScheduleService = New ProfileScheduleService

    Dim logHelper As LogHelper = New LogHelper

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            profileId = Session("prf_id")
            dataVersion = Session("dataVersion")
            If String.IsNullOrEmpty(dataVersion) Then
                dataVersion = Format(Now, "yyyyMMdd")
                Session("dataVersion") = dataVersion
            End If

            'Section 1: Profile Basic Information
            Dim hasError As Boolean = False
            LoadProfileBasic(profileId, dataVersion, hasError)

            If hasError Then
                Return
            End If

            'Section 2: Profile Health Status
            LoadHealthStatusData(profileId)
            'Load Profile Last Health Status
            Dim bHaveProfileLast As Boolean = False
            bHaveProfileLast = LoadProfileLastHealthSta(profileId, currentDataVer)

            'Section 3: Projects within profile
            'Load all profile projects
            dtProjects = pmaPrjService.GetProjectViewList(prjCodes)
            showMetricPerProfile = lookupService.GetLookUpName("S", "MISC", "Show_Metric_Per_Profile")
            'Load Project Metric Records for profile main code
            LoadProjectCodesDropDown()

            'Section 4: Project Metric
            'Load metrics for all profile projects
            LoadMetrics4AllProjects(prjCodes, currentDataVer)
            'Load metric raws for all profile projects
            LoadMetricRaws4AllProjects(prjCodes, currentDataVer)
            'Loas metrics & metric raws of last version for all profile projects
            If bHaveProfileLast Then
                dtPrjMetricsLast = prjMetricService.GetProjectMetricHist(prjCodesLast.Split(","), lastDataVer)
                dtPrjMetricRawLast = prjMetricRawService.GetProjectMetricRawHist(prjCodesLast.Split(","), lastDataVer)
            End If
            'Load metric for current project
            PreparePrjMetricsData(currentPrjCode, currentDataVer)
            'Load metric raw for current project
            PreparePrjMetricRawData(currentPrjCode, currentDataVer)

            'Section 5: Load Milestone / Schedule
            LoadProfileSchedule(profileId)
            'Section 6: Risk & Issues
            LoadProfileIssue(profileId)

            InitPageButtons()

        End If
    End Sub

#Region "Basic_Info"
    Sub LoadProfileBasic(ByVal profileId As Integer, ByVal dataVersion As String, ByRef hasError As Boolean)

        Try
            dtProfile = prfService.GetProfileHistViewLatest(profileId, dataVersion)

            If dtProfile Is Nothing Then
                hasError = True
                sErrMsgBuilder = New StringBuilder("Failed to load profile data.")
                Return
            ElseIf dtProfile.Rows.Count = 0 Then
                hasError = True
                sErrMsgBuilder = New StringBuilder("Failed to load profile data.")
                dtProfile = Nothing
                Return
            End If

            Dim drProfile As DataRow = dtProfile.Rows(0)

            prjCodes = drProfile("PRJ_CODES").ToString
            prfMainCode = drProfile("PRF_MAIN_CODE").ToString

            sTssPrj = drProfile("TSS_PRJ").ToString
            sTssPrjName = drProfile("TSSPRJ_NAME").ToString.Trim


            currentDataVer = drProfile("DATA_VERSION").ToString
            If String.IsNullOrEmpty(currentDataVer) Then
                currentDataVer = Format(Now, "yyyyMMdd")
            ElseIf String.IsNullOrEmpty(Trim(currentDataVer)) Then
                currentDataVer = Format(Now, "yyyyMMdd")
            End If
            Session("current_data_version") = currentDataVer

            prfId.Value = profileId
            txtCurrentDataVer.Value = currentDataVer

            sPrfDesc = drProfile("PRF_DESC").ToString.Trim
            sPrfDescDetail = drProfile("PRF_DESC_DETAIL").ToString.Trim

            Dim prfHidden As HiddenField = New HiddenField
            If Not Me.Master.FindControl("prfDesc") Is Nothing Then
                prfHidden = CType(Me.Master.FindControl("prfDesc"), HiddenField)
                prfHidden.Value = sPrfDesc
            End If

            sPmName = drProfile("staff_name").ToString.Trim
            sBuName = drProfile("bu_name").ToString.Trim

            If IsDate(drProfile("EST_START_DT")) Then
                sEstStartDt = Format(CDate(drProfile("EST_START_DT")), Session("date_format"))
            End If
            If IsDate(drProfile("EST_END_DT")) Then
                sEstEndDt = Format(CDate(drProfile("EST_END_DT")), Session("date_format"))
            End If

            If IsNumeric(drProfile("EST_TOTAL_HOURS")) Then
                sEstEffort = DataFormatHelper.FormatString(drProfile("EST_TOTAL_HOURS").ToString, "N", 1)
            End If
            If IsNumeric(drProfile("ACTL_TOTAL_HOURS")) Then
                sActlEffort = DataFormatHelper.FormatString(drProfile("ACTL_TOTAL_HOURS").ToString, "N", 1)
            End If

        Catch ex As Exception
            hasError = True
            dtProfile = Nothing
            logHelper.WriteLog("Profil Review from " & Session("fromPg"), ex)
        End Try
    End Sub
#End Region


#Region "Health_Status"

    Sub LoadHealthStatusData(ByVal profileId As Integer)

        BindDropDownListData(ddlScopeSta, True)
        'Dim sTssPrj As String = dtProfile.Rows(0).Item("tss_prj")

        If sTssPrj = TSSSERVICECATEGORY.BAUM Or sTssPrj = TSSSERVICECATEGORY.BAUE Then
            BindDropDownListData(ddlCostSta, True)
        End If

        BindDropDownListData(ddlCssSta, True)

        BindDropDownListData(ddlResourceSta, True)

        BindDropDownListData(ddlStage, True, "STAGE")

        PrepareHealthStatusData()

    End Sub

    Sub BindDropDownListData(ByVal ddlControl As DropDownList, Optional ByVal showBlankOption As Boolean = False, Optional ByVal category As String = "STATUS")
        Dim dt As DataTable = New DataTable

        dt = lookupService.GetLookUpList(LOOKUP_TYPE, category)
        If Not dt Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlControl, dt, "LOOKUP_NAME", "LOOKUP_CODE", showBlankOption)
            dt = Nothing
        End If
    End Sub


    Private Sub PrepareHealthStatusData()

        Dim PrfHealthStaAfter As ProfileHealthStatusModel = New ProfileHealthStatusModel


        If Not dtProfile Is Nothing Then
            If dtProfile.Rows.Count > 0 Then

                'Overall HealthStatus
                txtHealthSta.Value = dtProfile.Rows(0).Item("health_status").ToString

                'Scope Status
                Dim scopeSta As String = ""
                If Not IsDBNull(dtProfile.Rows(0).Item("scope_status")) Then
                    scopeSta = dtProfile.Rows(0).Item("scope_status").ToString()
                    ddlScopeSta.SelectedValue = scopeSta
                End If

                'Resource Status
                Dim resourceSta As String = ""
                If Not IsDBNull(dtProfile.Rows(0).Item("resource_status")) Then
                    resourceSta = dtProfile.Rows(0).Item("resource_status").ToString()
                    ddlResourceSta.SelectedValue = resourceSta
                End If

                'Css Status
                Dim cssSta As String = ""
                If Not IsDBNull(dtProfile.Rows(0).Item("css_status")) Then
                    cssSta = dtProfile.Rows(0).Item("css_status").ToString()
                    ddlCssSta.SelectedValue = cssSta
                End If

                'Quality Status
                If Not IsDBNull(dtProfile.Rows(0).Item("quality_status")) Then
                    txtQualitySta.Text = dtProfile.Rows(0).Item("quality_status").ToString()
                End If


                'Cost Status
                Dim costSta As String = ""
                If Not IsDBNull(dtProfile.Rows(0).Item("cost_status")) Then
                    costSta = dtProfile.Rows(0).Item("cost_status").ToString()
                    txtCostSta.Text = costSta
                    If sTssPrj = TSSSERVICECATEGORY.BAUM Or sTssPrj = TSSSERVICECATEGORY.BAUE Then
                        ddlCostSta.SelectedValue = costSta
                    End If
                End If

                'Quality Status
                If Not IsDBNull(dtProfile.Rows(0).Item("schedule_status")) Then
                    txtScheduleSta.Text = dtProfile.Rows(0).Item("schedule_status").ToString()
                End If

                If Session("fromPg").ToUpper = "DRAFT" Then
                    PrfHealthStaAfter.qualityStatus = dtProfile.Rows(0)("quality_status").ToString
                    PrfHealthStaAfter.scopeStatus = dtProfile.Rows(0)("scope_status").ToString
                    PrfHealthStaAfter.costStatus = dtProfile.Rows(0)("cost_status").ToString
                    PrfHealthStaAfter.resourceStatus = dtProfile.Rows(0)("resource_status").ToString
                    PrfHealthStaAfter.scheduleStatus = dtProfile.Rows(0)("schedule_status").ToString
                    PrfHealthStaAfter.cssStatus = dtProfile.Rows(0)("css_status").ToString

                End If


                'Stage
                'If sTssPrj = "03" Or sTssPrj = "04" Then
                Dim txtStage As String = ""
                If Not IsDBNull(dtProfile.Rows(0).Item("prj_stage")) Then
                    txtStage = dtProfile.Rows(0).Item("prj_stage").ToString()
                    ddlStage.SelectedValue = txtStage
                End If
                'End If

                'Get currencyCode
                Dim currencyName As String = ""
                Dim currencyService As IPmaCurrencyService = New PmaCurrencyService
                currencyName = currencyService.getCurrencyName(dtProfile.Rows(0).Item("currency").ToString)

                'Budget
                Dim decBudget As Decimal
                sBudget = dtProfile.Rows(0).Item("est_total_cost").ToString
                If Not String.IsNullOrEmpty(DataFormatHelper.StringTrim(sBudget)) Then
                    decBudget = Val(sBudget)
                    sBudget = Format(sBudget, "Currency")
                    sBudget = currencyName & " " & Right(sBudget, sBudget.Length - 1)
                End If

                'Actual (Accural)
                Dim decActlCostAccurual As Decimal
                sActlCostAccurual = dtProfile.Rows(0).Item("actl_total_cost").ToString
                If Not String.IsNullOrEmpty(DataFormatHelper.StringTrim(sActlCostAccurual)) Then
                    decActlCostAccurual = Val(sActlCostAccurual)
                    sActlCostAccurual = Format(sActlCostAccurual, "Currency")
                    sActlCostAccurual = currencyName & " " & Right(sActlCostAccurual, sActlCostAccurual.Length - 1)
                End If
                'Calculate Budget Utilization Rate (Accrual)
                If IsNumeric(decBudget) And IsNumeric(decActlCostAccurual) And decBudget <> 0 And decActlCostAccurual <> 0 Then
                    Dim decBudgetUtilRateAccrual As Decimal = Math.Round(decActlCostAccurual / decBudget, 4)
                    sBudgetUtilRateAccrual = DataFormatHelper.FormatString(decBudgetUtilRateAccrual.ToString, "P", 2)
                End If

                sActlCostBilled = dtProfile.Rows(0).Item("actl_total_cost_billed").ToString
                Dim decActlCostBilled As Decimal
                If Not String.IsNullOrEmpty(DataFormatHelper.StringTrim(sActlCostBilled)) Then
                    decActlCostBilled = Val(sActlCostBilled)
                    sActlCostBilled = Format(sActlCostBilled, "Currency")
                    sActlCostBilled = currencyName & " " & Right(sActlCostBilled, sActlCostBilled.Length - 1)
                End If
                'Calculate Budget Utilization Rate (Cash Based)
                If IsNumeric(decBudget) And IsNumeric(decActlCostBilled) And decBudget <> 0 And decActlCostBilled <> 0 Then
                    Dim decBudgetUtilRateBilled As Decimal = Math.Round(decActlCostBilled / decBudget, 4)
                    sBudgetUtilRateBilled = DataFormatHelper.FormatString(decBudgetUtilRateBilled.ToString, "P", 2)
                End If

                'Project Status Summary
                If Not IsDBNull(dtProfile.Rows(0).Item("prj_status_remark")) Then
                    sPrjStaSummary = dtProfile.Rows(0).Item("prj_status_remark").ToString()
                End If

            End If
        End If


    End Sub

    Function LoadProfileLastHealthSta(ByVal profileId As Integer, ByVal currentDataVer As String) As Boolean
        Dim bHaveLastProfile = False

        dtProfileLast = prfService.GetProfileHistLast(profileId, currentDataVer)

        If dtProfileLast Is Nothing Then
            Return bHaveLastProfile
        ElseIf dtProfileLast.Rows.Count = 0 Then
            dtProfileLast.Dispose()
            Return bHaveLastProfile
        End If

        bHaveLastProfile = True

        lastDataVer = dtProfileLast.Rows(0).Item("data_version").ToString.Trim
        lblLastVer.InnerText = lastDataVer
        Session("last_data_version") = lastDataVer

        prjCodesLast = dtProfileLast.Rows(0).Item("prj_codes").ToString.Trim

        If Not IsDBNull(dtProfileLast.Rows(0).Item("health_status")) Then
            txtHealthStaLast.Value = dtProfileLast.Rows(0).Item("health_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("quality_status")) Then
            txtQualityStaLast.Text = dtProfileLast.Rows(0).Item("quality_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("schedule_status")) Then
            txtScheduleStaLast.Text = dtProfileLast.Rows(0).Item("schedule_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("scope_status")) Then
            txtScopeStaLast.Text = dtProfileLast.Rows(0).Item("scope_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("cost_status")) Then
            txtCostStaLast.Text = dtProfileLast.Rows(0).Item("cost_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("resource_status")) Then
            txtResourceStaLast.Text = dtProfileLast.Rows(0).Item("resource_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("css_status")) Then
            txtCssStaLast.Text = dtProfileLast.Rows(0).Item("css_status").ToString
        End If

        LoadProfileLastHealthSta = bHaveLastProfile
    End Function
#End Region


#Region "Metric"

    'Step 1: Load all project details, project metrics, project metric raws within profile
    Function LoadMetrics4AllProjects(ByVal prjCodes As String, ByVal currentDataVer As String) As DataTable

        If Session("fromPg").ToUpper = "LIST" Then
            dtPrjMetrics = prjMetricService.GetProjectMetricHist(prjCodes.Split(","), currentDataVer)
        Else
            dtPrjMetrics = prjMetricService.GetProjectMetric(prjCodes.Split(","))
        End If
        Dim dtPrjMetricPk As DataColumn() = {dtPrjMetrics.Columns("id")}
        dtPrjMetrics.PrimaryKey = dtPrjMetricPk

        LoadMetrics4AllProjects = dtPrjMetrics

    End Function
    Function LoadMetricRaws4AllProjects(ByVal prjCodes As String, ByVal currentDataVer As String) As DataTable

        If Session("fromPg").ToUpper = "LIST" Then
            dtPrjMetricRaw = prjMetricRawService.GetProjectMetricRawHist(prjCodes.Split(","), currentDataVer)
        Else
            dtPrjMetricRaw = prjMetricRawService.GetProjectMetricRawList(prjCodes.Split(","))
        End If
        Dim dtPrjMetricRawPk As DataColumn() = {dtPrjMetricRaw.Columns("id")}
        dtPrjMetricRaw.PrimaryKey = dtPrjMetricRawPk
        LoadMetricRaws4AllProjects = dtPrjMetricRaw

    End Function

    'Step 2: Load projects' dropdown, set main master code as defaule.
    Sub LoadProjectCodesDropDown()

        If showMetricPerProfile.ToUpper = "Y" Then
            currentPrjCode = prfMainCode
        ElseIf Not String.IsNullOrEmpty(prjCodes) Then
            Dim prjCode() As String = prjCodes.Split(",")

            If Not prjCode Is Nothing Then
                For i As Integer = 0 To prjCode.Length - 1
                    lstPrjCodes.Items.Add(New ListItem(prjCode(i)))
                Next
                If prjCode.Length > 0 Then
                    lstPrjCodes.SelectedValue = prfMainCode
                    currentPrjCode = lstPrjCodes.SelectedValue
                End If
            End If
        End If

    End Sub

    'Step 4: Prepare view data for front end data layout rendering
    Private Sub PreparePrjMetricsData(ByVal currentPrjCode As String, ByVal currentDataVer As String)

        'Retrieve required metric list for specific tss service category
        dtPrjMetricsView = metricService.GetMetricListByTssPrj(sTssPrj, "Y")

        'Retrieve metric target list for specific tss service category having latest target records
        sMetricTargetYear = metricTargetService.GetLatestMetricTargetYear(sTssPrj)
        Dim dtMetricsTarget As DataTable = New DataTable("metricTarget")
        If Not String.IsNullOrEmpty(sMetricTargetYear) Then
            dtMetricsTarget = metricTargetService.GetMetricTargetList(sMetricTargetYear, sTssPrj)
        End If

        'Retrieve project metric list for the selected project
        Dim drPrjMetrics As DataRow() = dtPrjMetrics.Select("prj_code = '" & currentPrjCode & "'")


        If Not dtPrjMetricsView Is Nothing Then
            'target metric config section
            dtPrjMetricsView.Columns.Add("metric_year")
            dtPrjMetricsView.Columns.Add("metric_target_id")
            dtPrjMetricsView.Columns.Add("metric_target_val")
            dtPrjMetricsView.Columns.Add("metric_prj_id")

            'Project metric section
            dtPrjMetricsView.Columns.Add("metric_prj_val")
            dtPrjMetricsView.Columns.Add("metric_prj_status")
            dtPrjMetricsView.Columns.Add("percentage")

            'Project metric for Last
            dtPrjMetricsView.Columns.Add("metric_prj_val_last")

            For Each drPrjMetricView As DataRow In dtPrjMetricsView.Rows
                If drPrjMetricView("metric_val_type") = "P" Then
                    drPrjMetricView("percentage") = "%"
                End If

                Dim sMetricCode As String = drPrjMetricView("metric_code")
                Dim sMetricValType As String = drPrjMetricView("metric_val_type")
                Dim iMetricValPrec As Integer = drPrjMetricView("metric_val_precision")

                'Retrieve target data
                If Not dtMetricsTarget Is Nothing Then
                    If dtMetricsTarget.Rows.Count > 0 Then
                        For Each drMetricsTarget As DataRow In dtMetricsTarget.Rows
                            If drMetricsTarget("metric_code") = drPrjMetricView("metric_code") Then
                                drPrjMetricView("metric_year") = drMetricsTarget("metric_year")
                                drPrjMetricView("metric_target_id") = drMetricsTarget("metric_target_id")
                                drPrjMetricView("metric_target_val") = DataFormatHelper.FormatString(drMetricsTarget("metric_val"), sMetricValType, iMetricValPrec)
                            End If
                        Next
                    End If
                End If

                'Retrieve Project metric data
                If Not drPrjMetrics Is Nothing Then
                    For Each drPrjMetric As DataRow In drPrjMetrics
                        If drPrjMetric("metric_code") = drPrjMetricView("metric_code") Then
                            drPrjMetricView("metric_prj_id") = drPrjMetric("id")
                            Dim prjMetric As Decimal
                            If Not IsDBNull(drPrjMetric("metric_val")) Then
                                prjMetric = drPrjMetric("metric_val")
                                drPrjMetricView("metric_prj_val") = DataFormatHelper.FormatString(prjMetric, sMetricValType, iMetricValPrec)
                            End If
                            If Not IsDBNull(drPrjMetric("metric_status")) Then
                                drPrjMetricView("metric_prj_status") = drPrjMetric("metric_status").ToString
                            End If
                        End If
                    Next
                End If 'End If Not drPrjMetrics Is Nothing

                'Retrieve Last version of Project Metric Data
                If Not dtPrjMetricsLast Is Nothing Then
                    For Each drPrjMetricLast In dtPrjMetricsLast.Rows
                        If drPrjMetricLast("metric_code") = sMetricCode Then
                            If Not IsDBNull(drPrjMetricLast("metric_val")) Then
                                drPrjMetricView("metric_prj_val_last") = DataFormatHelper.FormatString(drPrjMetricLast("metric_val"), sMetricValType, iMetricValPrec)
                            End If

                        End If
                    Next
                End If


            Next 'End  For Each drPrjMetricView As DataRow In dtPrjMetricsView.Rows


            If Not dtPrjMetricsView Is Nothing Then
                WebControlHelper.GridViewDataBind(gvMetrics, dtPrjMetricsView, False)
            End If

        End If

        dtMetricsTarget.Dispose()
    End Sub

    'Step 5: Rendering layout
    Dim iParentRowMetric As Integer = 0
    Private Sub gvMetrics_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvMetrics.RowDataBound

        If e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(0).Text = (New PmaTssProjectService).GetTssProjectNameByCode(sTssPrj)


            If Not String.IsNullOrEmpty(lastDataVer) Then
                e.Row.Cells(3).Text = lastDataVer
            End If
        End If

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drView As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim sMetricValType As String = ""
            Dim iMetricValPrecision As Integer = 0
            Dim sMetricSta As String = ""

            If Not drView Is Nothing Then
                sMetricValType = drView("metric_val_type").ToString
                iMetricValPrecision = DataFormatHelper.StringToInteger(drView("metric_val_precision").ToString)

                If Not IsDBNull(drView("metric_prj_status")) Then
                    If Not e.Row.FindControl("txtPrjMetricStaHidden") Is Nothing Then
                        Dim txtPrjMetricStaHidden As HiddenField = New HiddenField

                        txtPrjMetricStaHidden = CType(e.Row.FindControl("txtPrjMetricStaHidden"), HiddenField)
                        sMetricSta = txtPrjMetricStaHidden.Value

                        Dim iMetricSta As HtmlGenericControl = New HtmlGenericControl
                        If Not e.Row.FindControl("iMetricSta") Is Nothing Then
                            iMetricSta = CType(e.Row.FindControl("iMetricSta"), HtmlGenericControl)
                            Select Case sMetricSta
                                Case "R"
                                    iMetricSta.Style.Add("color", "Red")
                                Case "A"
                                    iMetricSta.Style.Add("color", "#f0ad4e")
                                Case "G"
                                    iMetricSta.Style.Add("color", "Green")
                            End Select
                        End If
                    End If

                End If
            End If

            'e.Row.Cells(3).Text = DataFormatHelper.FormatString(e.Row.Cells(3).Text, sMetricValType, iMetricValPrecision)

            WebControlHelper.GridViewCellMerging(gvMetrics, e, 0, iParentRowMetric)

        End If
    End Sub

#End Region


#Region "Metric_Raw"
    Private Sub PreparePrjMetricRawData(ByVal currentPrjCode As String, ByVal currentDataVer As String)

        'Retrieve all metric raws required manual / upload input
        'dtPrjMetricRawsView = metricRawService.GetMetricRawListBySrc("M")
        dtPrjMetricRawsView = metricRawService.GetMetricRawList("")
        If dtPrjMetricRawsView Is Nothing Then
            Return
        ElseIf dtPrjMetricRawsView.Rows.Count = 0 Then
            Return
        End If

        dtPrjMetricRawsView.Columns.Add("required")
        dtPrjMetricRawsView.Columns.Add("metric_code")
        dtPrjMetricRawsView.Columns.Add("prj_metric_raw_id")
        dtPrjMetricRawsView.Columns.Add("prj_code")
        dtPrjMetricRawsView.Columns.Add("prj_metric_raw_val")


        For Each drPrjMetric As DataRow In dtPrjMetricsView.Rows
            Dim sMetricCode As String = drPrjMetric("metric_code").ToString 'Metric Code

            'Retrieve required metric raw list for specific prject metric
            For Each drPrjMetricRawsView As DataRow In dtPrjMetricRawsView.Rows
                Dim sMetricRawCode As String = ""
                sMetricRawCode = drPrjMetricRawsView("code")  'Metric Raw Code

                '
                If hsPrjMetricRaw.ContainsKey(sMetricRawCode) Then
                    Continue For
                End If

                'Mark the metric raw as required
                If metricRawMappingService.IsMappingFound(sMetricCode, sMetricRawCode) Then
                    drPrjMetricRawsView("required") = "Y"

                    Dim drPrjMetricRawReads As DataRow() = dtPrjMetricRaw.Select("prj_code = '" & currentPrjCode & "' and metric_raw_code = '" & sMetricRawCode & "'")
                    If Not drPrjMetricRawReads Is Nothing Then
                        If drPrjMetricRawReads.Length > 0 Then
                            If Not IsDBNull(drPrjMetricRawReads(0)("metric_raw_val")) Then
                                drPrjMetricRawsView("prj_metric_raw_id") = drPrjMetricRawReads(0)("id")
                                drPrjMetricRawsView("prj_metric_raw_val") = drPrjMetricRawReads(0)("metric_raw_val")
                                hsPrjMetricRaw.Add(sMetricRawCode, drPrjMetricRawReads(0)("metric_raw_val"))
                            End If
                        End If

                    End If
                End If 'End If metricRawMappingService.IsMappingFound(sMetricCode, sMetricRawCode)

            Next 'End For Each drMetricRaw As DataRow In dtMetricRaws.Rows

        Next 'End For Each drPrjMetric As DataRow In dtPrjMetricsView.Rows

        For Each drPrjMetricRawsView As DataRow In dtPrjMetricRawsView.Rows
            If IsDBNull(drPrjMetricRawsView("required")) Then
                drPrjMetricRawsView.Delete()
            End If
        Next

        If dtPrjMetricRawsView.Rows.Count > 0 Then
            WebControlHelper.GridViewDataBind(gvMetricRawList, dtPrjMetricRawsView, False)
        End If


    End Sub

    Private Sub RenderInputTextControl(ByRef txtInput As TextBox, ByVal dataPrec As Integer)
        Dim valInput As String = DataFormatHelper.FormatString(txtInput.Text.ToString, "N", dataPrec)
        If Not String.IsNullOrEmpty(valInput) Then
            txtInput.Text = IIf(valInput.EndsWith("%"), valInput.Substring(0, valInput.Length - 1), valInput)
        End If

        txtInput.Attributes.Add("onkeyup", "formatNumber(this, " & dataPrec & ")")
        txtInput.Attributes.Add("onblur", "ValidateNumber(this, " & dataPrec & ")")
    End Sub

    Private Sub gvMetricRawList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvMetricRawList.RowDataBound


        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim txtMetricRawPrjVal As TextBox = New TextBox
            Dim txtMetricRawPrjId As HiddenField = New HiddenField
            Dim drView As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim iValPrecision As Integer = 0

            If Not drView Is Nothing Then

                iValPrecision = DataFormatHelper.StringToInteger(drView("data_precision").ToString)
                If Not e.Row.FindControl("txtMetricRawPrjVal") Is Nothing Then
                    txtMetricRawPrjVal = CType(e.Row.FindControl("txtMetricRawPrjVal"), TextBox)
                    If Not IsDBNull(drView("prj_metric_raw_val")) Then
                        txtMetricRawPrjVal.Text = drView("prj_metric_raw_val")
                    End If
                    RenderInputTextControl(txtMetricRawPrjVal, iValPrecision)
                End If

                If Not IsDBNull(drView("prj_metric_raw_id")) Then
                    If Not e.Row.FindControl("") Is Nothing Then
                        txtMetricRawPrjId = CType(e.Row.FindControl("txtMetricRawPrjId"), HiddenField)
                        txtMetricRawPrjId.Value = drView("prj_metric_raw_id")
                    End If
                End If

            End If 'End If Not drView Is Nothing Then
        End If
    End Sub
#End Region


#Region "LAST_VERSIION"
    Function GetProfileLast(ByVal profileId As Integer, ByVal currentDataVer As String, ByRef bHaveLastProfile As Boolean) As DataTable

        dtProfileLast = LoadProfileLast(profileId, currentDataVer)

        If dtProfileLast Is Nothing Then
            bHaveLastProfile = False
        ElseIf dtProfileLast.Rows.Count = 0 Then
            bHaveLastProfile = False
        Else
            bHaveLastProfile = True
        End If

        GetProfileLast = dtProfileLast
        dtProfileLast = Nothing

        'If bHaveLastProfile Then
        '    Dim prjCodesLast As String() = dtProfileLast(0).Item("prj_codes").ToString.Split(",")

        '    'Load Metric
        '    'LoadMetricDataLast(prjCodesLast, dtProfileLast.Rows(0).Item("data_version").ToString)

        '    'Load Metric Raw
        '    'LoadMetricRawDataLast(prjCodesLast, dtProfileLast.Rows(0).Item("data_version").ToString)

        '    ''Init Buttons
        '    'InitPageButtons()
        'End If

    End Function

    Function LoadProfileLast(ByVal profileId As Integer, ByVal currentDataVer As String) As DataTable

        dtProfileLast = prfService.GetProfileHistLast(profileId, currentDataVer)

        If dtProfileLast Is Nothing Then
            Return Nothing
        ElseIf dtProfileLast.Rows.Count = 0 Then
            dtProfileLast.Dispose()
            Return Nothing
        End If

        If Not IsDBNull(dtProfileLast.Rows(0).Item("health_status")) Then
            txtHealthStaLast.Value = dtProfileLast.Rows(0).Item("health_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("quality_status")) Then
            txtQualityStaLast.Text = dtProfileLast.Rows(0).Item("quality_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("schedule_status")) Then
            txtScheduleStaLast.Text = dtProfileLast.Rows(0).Item("schedule_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("scope_status")) Then
            txtScopeStaLast.Text = dtProfileLast.Rows(0).Item("scope_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("cost_status")) Then
            txtCostStaLast.Text = dtProfileLast.Rows(0).Item("cost_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("resource_status")) Then
            txtResourceStaLast.Text = dtProfileLast.Rows(0).Item("resource_status").ToString
        End If
        If Not IsDBNull(dtProfileLast.Rows(0).Item("css_status")) Then
            txtCssStaLast.Text = dtProfileLast.Rows(0).Item("css_status").ToString
        End If

        lblLastVer.InnerText = dtProfileLast.Rows(0).Item("data_version").ToString

        LoadProfileLast = dtProfileLast
        dtProfileLast = Nothing
    End Function



#End Region



    Sub LoadProfileSchedule(ByVal profileId As Integer)
        Dim dtPrfScheduleView = prfScheduleService.GetProfileScheduleListView(profileId)

        If Not dtPrfScheduleView Is Nothing Then
            WebControlHelper.GridViewDataBind(gvSchedule, dtPrfScheduleView)
            dtPrfScheduleView.Dispose()
        End If

    End Sub



#Region "Risk&Issue"
    Sub LoadProfileIssue(ByVal profileId As Integer)
        Dim dtPrfIssueView As DataTable = prfIssueService.GetProfileIssueListView(profileId)

        If Not dtPrfIssueView Is Nothing Then
            WebControlHelper.GridViewDataBind(gvIssue, dtPrfIssueView)
            dtPrfIssueView.Dispose()
        End If
    End Sub

    Private Sub gvIssue_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvIssue.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim index As Integer = e.Row.RowIndex

            e.Row.Cells(1).Text = index + 1
        End If
    End Sub
#End Region


#Region "Page_Buttons"

    'Private Sub btnBack_Click(sender As Object, e As System.EventArgs) Handles btnBack.Click
    '    'Response.Redirect(Request.Url.GetLeftPart(UriPartial.Authority) & "/Views/Profile/ProfileList.aspx?prfId=" & profileId)

    '    If String.IsNullOrEmpty("fromPg") Then
    '        Server.Transfer("ProfileDraft.aspx")
    '    ElseIf fromPg.ToUpper = "LIST" Then
    '        Server.Transfer("ProfileList.aspx")
    '    ElseIf fromPg.ToUpper = "TRACK" Then
    '        Server.Transfer("ProfileTracking.aspx")
    '    ElseIf fromPg.ToUpper = "HEALTH" Then
    '        Server.Transfer("ProfileHealth.aspx")
    '    Else
    '        Server.Transfer("ProfileDraft.aspx")
    '    End If

    'End Sub




    Private Sub btnSubmit_Click(sender As Object, e As System.EventArgs) Handles btnSubmit.Click
        Dim bToSubmit As Boolean = True
        Dim profileId As Integer = Session("prf_id")
        Dim dtProfile As DataTable = prfService.GetProfile(profileId)

        'Submit is not allowed if no health status input
        If Not prfService.HasHealthStatus(profileId) Then
            bToSubmit = False
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Please update health status before submitting profile.');</script>", False)
            Return
        End If

        ''Check if any follow up items
        'If Not (prfIssueService.IsAllActionsFollowed(profileId)) Then
        '    bToSubmit = False
        '    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Please add actions under [Risk & Issues] before submitting profile.');</script>", False)
        'End If

        If bToSubmit Then
            Dim dtPrjMetrics As DataTable = prjMetricService.GetProjectMetric(dtProfile.Rows(0).Item("prj_codes").ToString.Split(","))
            Dim dtPrjMetricRaw As DataTable = prjMetricRawService.GetProjectMetricRawList(dtProfile.Rows(0).Item("prj_codes").ToString.Split(","))
            Dim dtProfileSubmit As DataTable = dtProfile.Clone
            Dim dtPrjMetricSubmit As DataTable = dtPrjMetrics.Clone
            Dim dtPrjMetricRawSubmit As DataTable = dtPrjMetricRaw.Clone

            Dim bsave As Boolean = False
            Dim bNewVer As Boolean = False

            Dim drProfile As DataRow = dtProfile.Rows(0)
            Dim dataVer As String = Format(Now, "yyyyMMdd")

            If bNewVer Then
                Dim drProfileSubmit As DataRow = dtProfileSubmit.NewRow
                drProfileSubmit.ItemArray = drProfile.ItemArray

                drProfileSubmit("DATA_VERSION") = dataVer
                drProfileSubmit("STATUS") = "S"

                drProfileSubmit("LAST_UPDATED_BY") = Session("logon_id")
                drProfileSubmit("LAST_UPDATED_DT") = Now
                dtProfileSubmit.Rows.Add(drProfileSubmit)

                For Each drPrjMetric As DataRow In dtPrjMetrics.Rows
                    Dim drPrjMetricSubmit As DataRow = dtPrjMetricSubmit.NewRow
                    drPrjMetricSubmit.ItemArray = drPrjMetric.ItemArray

                    drPrjMetricSubmit("DATA_VERSION") = dataVer

                    drPrjMetricSubmit("LAST_UPDATED_BY") = Session("logon_id")
                    drPrjMetricSubmit("LAST_UPDATED_DT") = Now

                    dtPrjMetricSubmit.Rows.Add(drPrjMetricSubmit)
                Next

                For Each drMetricRaw As DataRow In dtPrjMetricRaw.Rows
                    Dim drPrjMetricRawSubmit As DataRow = dtPrjMetricRawSubmit.NewRow
                    drPrjMetricRawSubmit.ItemArray = drMetricRaw.ItemArray

                    drPrjMetricRawSubmit("DATA_VERSION") = dataVer

                    drPrjMetricRawSubmit("LAST_UPDATED_BY") = Session("logon_id")
                    drPrjMetricRawSubmit("LAST_UPDATED_DT") = Now

                    dtPrjMetricRawSubmit.Rows.Add(drPrjMetricRawSubmit)
                Next

                If prfService.SubmitProfile(dtProfileSubmit, dtPrjMetricSubmit, dtPrjMetricRawSubmit) Then

                    sErrMsgBuilder = New StringBuilder("The profile is submitted successfully.")
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('The profile is submitted successfully.');</script>", False)
                    Server.Transfer("ProfileList.aspx")
                Else
                    sErrMsgBuilder = New StringBuilder("Oops, failed to submit the profile.")
                    'Alert error message
                    'ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "popUpMsg();", True)
                End If
            Else
                drProfile("DATA_VERSION") = dataVer
                drProfile("STATUS") = "S"

                drProfile("LAST_UPDATED_BY") = Session("logon_id")
                drProfile("LAST_UPDATED_DT") = Now

                If drProfile.RowState = DataRowState.Unchanged Then
                    drProfile.SetModified()
                End If

                For Each drMetric As DataRow In dtPrjMetrics.Rows
                    drMetric("DATA_VERSION") = dataVer
                    drMetric("LAST_UPDATED_BY") = Session("logon_id")
                    drMetric("LAST_UPDATED_DT") = Now
                Next

                For Each drMetricRaw As DataRow In dtPrjMetricRaw.Rows
                    drMetricRaw("DATA_VERSION") = dataVer
                    drMetricRaw("LAST_UPDATED_BY") = Session("logon_id")
                    drMetricRaw("LAST_UPDATED_DT") = Now
                Next


                If prfService.SubmitProfile(dtProfile, dtPrjMetrics, dtPrjMetricRaw) Then
                    sErrMsgBuilder = New StringBuilder("The profile is submitted successfully.")
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('The profile is submitted successfully.');</script>", False)
                    Server.Transfer("ProfileList.aspx")
                Else
                    sErrMsgBuilder = New StringBuilder("Oops, failed to submit the profile.")
                End If

            End If
        End If


    End Sub

    Private Sub btnDelete_Click(ByVal profileId As Integer)
        Dim dtPrfDel As DataTable = prfService.GetProfile(profileId)

        If Not dtPrfDel Is Nothing Then
            If dtPrfDel.Rows.Count > 0 Then
                Dim drPrfDel As DataRow = dtPrfDel.Rows(0)
                If Not drPrfDel Is Nothing Then
                    drPrfDel.Delete()
                End If
            End If
        End If

        If prfService.SaveProfile("D", dtPrfDel) Then
            Server.Transfer("ProfileList.aspx")
        Else

        End If
    End Sub
#End Region


#Region "Page_Navigation"

    Private Sub InitPageButtons()


        If Session("fromPg").ToUpper = "LIST" Then
            btnSubmit.Visible = False
        End If

    End Sub


#End Region



    <WebMethod()>
    Public Shared Function UpdateProfile(ByVal profileId As Integer, ByVal currentDataVer As String) As String
        Dim msg As String = ""
        If prfService.HasNewDraftVersion(profileId, currentDataVer) Then
            msg = "Attention! You have another update of this profile to be submitted, please retrieve it in the DRAFT PROFILE!"
        ElseIf prfService.HasNewerVersion(profileId, currentDataVer) Then
            msg = "Attention! You have another updated version of profile, please retrieve it in the PROFILE BROWSER for further updating!"
        End If
        UpdateProfile = msg
    End Function

    'Private Sub btnEditProfile_Click(sender As Object, e As System.EventArgs) Handles btnEditProfile.Click
    '    Dim profileId As Integer = Session("prf_id")
    '    Dim currentDataVer As String = Session("current_data_version")
    '    If Session("fromPg").ToUpper = "LIST" And prfService.HasNewDraftVersion(profileId, currentDataVer) Then
    '        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Attention! You have another update of this profile to be submitted, please retrieve it in the DRAFT PROFILE!');</script>", False)
    '    Else

    '        Server.Transfer("ProfileHealthTab.aspx")
    '    End If


    'End Sub





End Class