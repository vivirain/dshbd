﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO


Public Class ProfileDraft
    Inherits System.Web.UI.Page


    Private dtProfile As DataTable = New DataTable
    Private dtProfileResult As DataTable = New DataTable

    Private userRoles() As String = Nothing

    Protected dataVersion As String = ""

    Protected totalRecords As Integer = 0
    Protected iPage As Integer
    Protected sAlertMsg As StringBuilder = New StringBuilder("")

    'Page
    Private currentSortExpression As String = ""
    Private currentSortDirection As String = ""

    Dim prfService As IProfileService = New ProfileService
    Dim pmaTssPrjService As IPmaTssProjectService = New PmaTssProjectService
    Dim pmaTeamService As IPmaTeamService = New PmaTeamService
    Dim pmaBizUnitService As IPmaBizUnitService = New PmaBizUnitService
    Dim pmaUserService As IPmaUserService = New PmaUserService

    Dim excelHelper As ExcelHelper = New ExcelHelper
    Dim logHelper As LogHelper = New LogHelper
    Dim tranLogService As ILogService = New LogService

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Session("userRoles") Is Nothing Then
            userRoles = Session("userRoles").ToString.Split(",")
        End If

        If Not Page.IsPostBack Then

            Session("prf_id") = Nothing
            Session("fromPg") = "DRAFT"

            txtDataReloadDt.Attributes.Add("readonly", True)

            BindSearchDropDown()

            currentSortExpression = ""
            currentSortDirection = ""

            btnQueryClick()

            EnableCreateDeleteButtons()
        End If


    End Sub


#Region "Search_Section"
    Sub BindSearchDropDown()
        'Function
        ddlFunc.Items.Clear()
        BindFunction()

        'SBU
        ddlSBU.Items.Clear()
        BindSBU()

        'TSS Service Category
        ddlTssPrj.Items.Clear()
        Dim dtTssPrj As DataTable = New DataTable("TssPrj")
        dtTssPrj = pmaTssPrjService.GetTssProjectFilterList()

        If Not dtTssPrj Is Nothing Then
            If dtTssPrj.Rows.Count > 0 Then
                dtTssPrj = dtTssPrj.Select("1=1", "display_name").CopyToDataTable
            End If
            WebControlHelper.DropDownListDataBind(ddlTssPrj, dtTssPrj, "display_name", "CODE")
        End If

        'Business Unit
        Dim dtBU As DataTable = New DataTable("BU")
        dtBU = pmaBizUnitService.getBizUnitFilterList(PROFILESTATUS.DRAFT)
        If Not dtBU Is Nothing Then
            If dtBU.Rows.Count > 1 Then
                dtBU = dtBU.Select("1=1", "display_name").CopyToDataTable
            End If
            WebControlHelper.ListBoxDataBind(lbBU, dtBU, "display_name", "BU_CODE")

            If dtBU.Rows.Count = 1 Then
                lbBU.SelectedValue = dtBU.Rows(0).Item("bu_code").ToString
            End If
        End If

    End Sub

    Sub BindFunction()
        Dim dtFunc As DataTable = New DataTable

        Dim bLoadAllFunction As Boolean = False

        If userRoles Is Nothing Then
            Return
        End If

            If userRoles.Length > 0 Then
                If userRoles.Contains(DASHBORADROLES.ADM) Or userRoles.Contains(DASHBORADROLES.AM) Or userRoles.Contains(DASHBORADROLES.EXCO) Or userRoles.Contains(DASHBORADROLES.GM) Or userRoles.Contains(DASHBORADROLES.QAG) Then
                    bLoadAllFunction = True
                End If

                If bLoadAllFunction Then
                    dtFunc = pmaTeamService.GetFunctionList
            ElseIf userRoles.Contains(DASHBORADROLES.FH) Then
                dtFunc = pmaTeamService.GetMyFunction(Session("logon_id"), Session("id_card"), Session("team_code"))
            Else
                dtFunc = pmaTeamService.GetTeam(Session("team_code"), TEAMLEVEL.FUNC)
                End If
            End If


        If dtFunc Is Nothing Then
            Return
        ElseIf dtFunc.Rows.Count <= 0 Then
            Return
        End If

        If dtFunc.Rows.Count = 1 Then
            WebControlHelper.DropDownListDataBind(ddlFunc, dtFunc, "display_name", "TEAM_CODE", False)
            ddlFunc.SelectedValue = dtFunc.Rows(0).Item("team_code")
        Else
            dtFunc = dtFunc.Select(" 1 = 1 ", "display_name").CopyToDataTable
            WebControlHelper.DropDownListDataBind(ddlFunc, dtFunc, "display_name", "TEAM_CODE")
        End If
    End Sub

    Sub BindSBU()
        If ddlFunc Is Nothing Then
            Return
        ElseIf String.IsNullOrEmpty(ddlFunc.SelectedValue) Then
            Return
        ElseIf userRoles Is Nothing Then
            Return
        End If

        'SBU
                Dim dtSBU As DataTable = New DataTable("SBU")
                Dim bLoadAllSBU As Boolean = False

                    For i As Integer = 0 To userRoles.Length - 1
                        If Not String.IsNullOrEmpty(userRoles(i)) Then
                            Dim userRole As Integer = CInt(userRoles(i))
                            If userRole <> DASHBORADROLES.PM And userRole <> DASHBORADROLES.TL And userRole <> DASHBORADROLES.SBUH Then
                                bLoadAllSBU = True
                                Exit For
                            End If
                        End If
                    Next

                    If bLoadAllSBU Then
                        dtSBU = pmaTeamService.GetSubTeamList(ddlFunc.SelectedValue, TEAMLEVEL.SBU)
                    Else
            dtSBU = pmaTeamService.GetMySBU(ddlFunc.SelectedValue, Session("logon_id"), Session("id_card"), Session("team_code"))
                    End If 'End If bLoadAllBU

        If dtSBU Is Nothing Then
            Return
        ElseIf dtSBU.Rows.Count <= 0 Then
            Return
        End If

                        If dtSBU.Rows.Count = 1 Then
                            WebControlHelper.DropDownListDataBind(ddlSBU, dtSBU, "display_name", "TEAM_CODE", False)
                            ddlSBU.SelectedValue = dtSBU.Rows(0).Item("team_code")
        Else
            dtSBU = dtSBU.Select("1=1", "display_name").CopyToDataTable
            WebControlHelper.DropDownListDataBind(ddlSBU, dtSBU, "display_name", "TEAM_CODE")
            ddlSBU.Enabled = True
                        End If


    End Sub

    Private Sub ddlFunc_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlFunc.SelectedIndexChanged
        ddlSBU.Items.Clear()
        BindSBU()
        QueryData()
    End Sub
#End Region

#Region "page_elements"
    Sub EnableCreateDeleteButtons()
        If Not userRoles Is Nothing Then
            For i As Integer = 0 To userRoles.Length - 1
                Dim userRole As Integer = 0

                If Not String.IsNullOrEmpty(userRoles(i).ToString) Then
                    userRole = CInt(userRoles(i).ToString)
                End If

                If userRole = DASHBORADROLES.PM Or userRole = DASHBORADROLES.TL Then
                    btnCreate.Visible = True
                    btnDelete.Visible = True
                    Exit For
                End If
            Next
        End If

    End Sub

    Private Sub btnCreate_Click(sender As Object, e As System.EventArgs) Handles btnCreate.Click

        Session("prf_id") = 0
        Session("fromPg") = "DRAFT"
        Session("current_data_version") = Format(Now, "yyyyMMdd")


        Server.Transfer("ProfileBasicTab.aspx")
    End Sub

    Public Sub btnQueryClick()
        Try
            QueryData()
        Catch ex As Exception
            sAlertMsg = New StringBuilder("Oops, failed to query profiles.")
            logHelper.WriteLog(Session("logon_id") & " failed to query draft profiles.", ex)
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "popUpMsg();", True)
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As System.EventArgs) Handles btnDelete.Click
        Dim sMsg As String = ""

        If DeleteProfile(sMsg) Then
            sAlertMsg = New StringBuilder("Record(s) are deleted successfully.")
            QueryData()
        ElseIf sMsg = "" Then
            sAlertMsg = New StringBuilder("Sorry, failed to delete records.")
        Else
            sAlertMsg = New StringBuilder(sMsg)
        End If
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "popUpMsg();", True)
    End Sub

    Private Sub btnExport_Click(sender As Object, e As System.EventArgs) Handles btnExport.Click
        Dim fileName As String = "Profile_" & Format(Now, "yyyyMMddHHmmss") & ".xlsx"
        Dim bExportAll As Boolean = True

        Try

            For i As Integer = 0 To gvPrjProfile.Rows.Count - 1
                Dim cbPrf As CheckBox = New CheckBox
                If Not gvPrjProfile.Rows(i).FindControl("cbPrf") Is Nothing Then
                    cbPrf = CType(gvPrjProfile.Rows(i).FindControl("cbPrf"), CheckBox)
                    If cbPrf.Checked Then
                        bExportAll = False
                    End If
                End If

                If Not bExportAll Then
                    Exit For
                End If
            Next

            If bExportAll Then
                Dim bAllowPaging As Boolean = gvPrjProfile.AllowPaging
                Dim iPageIndex As Integer = 0
                If bAllowPaging Then
                    iPageIndex = gvPrjProfile.PageIndex
                End If

                gvPrjProfile.AllowPaging = False
                QueryData()
                ExportToExcel(fileName)

                gvPrjProfile.AllowPaging = bAllowPaging
                QueryData()
                If bAllowPaging Then
                    gvPrjProfile.PageIndex = iPageIndex
                End If

            Else
                ExportToExcel(fileName)
            End If

            logHelper.WriteLog(Session("logon_id") & " exported draft profile successfully.")
        Catch ex As Exception
            logHelper.WriteLog("btnExport_Click failed", ex)
            sAlertMsg = New StringBuilder("Oops, failed to export profiles.")
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "popUpMsg();", True)
        End Try

    End Sub


    Function DeleteProfile(ByRef msg As String) As Boolean
        Dim bToDelete As Boolean = True
        Dim sSelPrfId As StringBuilder = New StringBuilder("")
        Dim dtProfileDel As DataTable = New DataTable
        userRoles = HttpContext.Current.Session("userRoles").ToString.Split(",")

        dtProfileDel = prfService.GetProfileList()
        Dim dtProfileDelPk As DataColumn() = {dtProfileDel.Columns("prf_id")}
        dtProfileDel.PrimaryKey = dtProfileDelPk

        For iRow As Integer = gvPrjProfile.Rows.Count - 1 To 0 Step -1
            Dim cbPrf As CheckBox = gvPrjProfile.Rows(iRow).FindControl("cbPrf")
            Dim gvRowPrfId As Integer = gvPrjProfile.DataKeys(iRow).Value
            Dim gvRowPrj As String = gvPrjProfile.Rows(iRow).Cells(20).Text
            Dim gvRowPrjCodes As String = gvPrjProfile.Rows(iRow).Cells(21).Text
            Dim gvRowDataVer As String = gvPrjProfile.Rows(iRow).Cells(22).Text


            If cbPrf.Checked = True Then
                'If Not userRoles.Contains(DASHBORADROLES.ADM) Then
                'Check if having any project metrics records.
                Dim prjMetricService As IProjectMetricService = New ProjectMetricService
                'If prjMetricService.HasProjectMetrics(gvRowPrjCodes.Split(",")) Then
                If prjMetricService.HasProjectMetrics(gvRowPrjCodes.Split(",")) And String.IsNullOrEmpty(gvRowDataVer) Then
                    msg = "Oops, failed to delete profiles as profile \'" & Replace(gvPrjProfile.Rows(iRow).Cells(12).Text, "'", "\'") & "\' already has project metric data entry."
                    bToDelete = False
                    Exit For
                End If
                'End If

                'Delete Profile
                Dim drPrfDel As DataRow = dtProfileDel.Rows.Find(gvRowPrfId)
                Dim dtPrfLatest As DataTable = prfService.GetProfileLatestSubmit(gvRowPrfId)
                If Not dtPrfLatest Is Nothing AndAlso dtPrfLatest.Rows.Count > 0 AndAlso Not drPrfDel Is Nothing Then
                    'If having history version, rollback to latest submitted version
                    'drPrfDel.ItemArray = dtPrfLatest.Rows(0).ItemArray
                    prfService.CopyHistDataToDraft(dtPrfLatest.Rows(0), drPrfDel)
                ElseIf Not drPrfDel Is Nothing Then
                    'If having no history version, delete it directly
                    drPrfDel.Delete()
                End If


                'If Not String.IsNullOrEmpty(gvRowDataVer) Then
                '    Dim dtProfileHist As DataTable = prfService.GetProfileHist(gvRowPrfId, gvRowDataVer)
                '    If Not dtProfileHist Is Nothing Then
                '        If dtProfileHist.Rows.Count > 0 Then
                '            Dim drPrfHist As DataRow = dtProfileDel.NewRow
                '            drPrfHist.ItemArray = dtProfileHist.Rows(0).ItemArray
                '            dtProfileDel.Rows.Add(drPrfHist)
                '        End If
                '    End If
                'End If

                If Not String.IsNullOrEmpty(sSelPrfId.ToString) Then
                    sSelPrfId.Append(",")
                End If
                sSelPrfId.Append(gvRowPrfId.ToString)

            End If
        Next

        If bToDelete Then
            'DeleteProfile = prfService.SaveProfile("D", dtProfileDel)
            bToDelete = prfService.SaveProfile("D", dtProfileDel)
        End If

        If bToDelete Then
            tranLogService.WriteTranLog("PROFILE_DELETE", HttpContext.Current.Session("logon_id"), "Delete profile(s) [" & sSelPrfId.ToString & "] successfully.")
        Else
            tranLogService.WriteTranLog("PROFILE_DELETE", HttpContext.Current.Session("logon_id"), "Failed to delete profile(s) [" & sSelPrfId.ToString & "].")
        End If

        DeleteProfile = bToDelete
    End Function

    Sub ExportToExcel(ByVal fileName As String)
        Dim bExportAll As Boolean = True
        Dim bReturn As Boolean = False
        Dim dtExportPart As DataTable = New DataTable("dtExport")
        Dim dtExportAll As DataTable = New DataTable("dtExport")

        dtExportAll.Columns.Add("Function")
        dtExportAll.Columns.Add("SBU")
        dtExportAll.Columns.Add("Project_Name")
        dtExportAll.Columns.Add("Chinese_Project_Name")
        dtExportAll.Columns.Add("High_Level_Project_Background")
        dtExportAll.Columns.Add("Master_Code")
        dtExportAll.Columns.Add("Associated_Projects")
        dtExportAll.Columns.Add("Project_Leader")
        dtExportAll.Columns.Add("Business_Unit")
        dtExportAll.Columns.Add("TSS_Service_Category")
        dtExportAll.Columns.Add("Fixed_Price_Project")

        dtExportAll.Columns.Add("Estimated_Start_Date")
        dtExportAll.Columns.Add("Estimated_Completion_Date")
        dtExportAll.Columns.Add("Estimated_Total_Effort")
        dtExportAll.Columns.Add("Actual_Total_Effort")

        dtExportAll.Columns.Add("Overall_Health")
        dtExportAll.Columns.Add("Quality")
        dtExportAll.Columns.Add("Scope")
        dtExportAll.Columns.Add("Cost")
        dtExportAll.Columns.Add("Schedule")
        dtExportAll.Columns.Add("Resource")
        dtExportAll.Columns.Add("CSS")
        dtExportAll.Columns.Add("Project_Stage")
        dtExportAll.Columns.Add("Project_Status_Summary")

        dtExportAll.Columns.Add("Last_Submitted_Date")

        dtExportPart = dtExportAll.Clone

        Dim sSelPrfId As StringBuilder = New StringBuilder("")
        For iRow As Integer = 0 To gvPrjProfile.Rows.Count - 1
            Dim exportPrfId As Integer = gvPrjProfile.DataKeys(iRow).Item("prf_id")
            Dim dtPrfExport As DataTable = prfService.GetProfileView(exportPrfId)

            Dim cbPrf As CheckBox = New CheckBox
            If Not gvPrjProfile.Rows(iRow).FindControl("cbPrf") Is Nothing Then
                cbPrf = CType(gvPrjProfile.Rows(iRow).FindControl("cbPrf"), CheckBox)
            End If

            Dim txtHealthSta As TextBox = New TextBox
            If Not gvPrjProfile.Rows(iRow).FindControl("txtHealthSta") Is Nothing Then
                txtHealthSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtHealthSta"), TextBox)
            End If

            Dim txtQualitySta As TextBox = New TextBox
            If Not gvPrjProfile.Rows(iRow).FindControl("txtQualitySta") Is Nothing Then
                txtQualitySta = CType(gvPrjProfile.Rows(iRow).FindControl("txtQualitySta"), TextBox)
            End If

            Dim txtScopeSta As TextBox = New TextBox
            If Not gvPrjProfile.Rows(iRow).FindControl("txtScopeSta") Is Nothing Then
                txtScopeSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtScopeSta"), TextBox)
            End If

            Dim txtCostSta As TextBox = New TextBox
            If Not gvPrjProfile.Rows(iRow).FindControl("txtCostSta") Is Nothing Then
                txtCostSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtCostSta"), TextBox)
            End If

            Dim txtScheduleSta As TextBox = New TextBox
            If Not gvPrjProfile.Rows(iRow).FindControl("txtScheduleSta") Is Nothing Then
                txtScheduleSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtScheduleSta"), TextBox)
            End If

            Dim txtResourceSta As TextBox = New TextBox
            If Not gvPrjProfile.Rows(iRow).FindControl("txtResourceSta") Is Nothing Then
                txtResourceSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtResourceSta"), TextBox)
            End If

            Dim txtCssSta As TextBox = New TextBox
            If Not gvPrjProfile.Rows(iRow).FindControl("txtCssSta") Is Nothing Then
                txtCssSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtCssSta"), TextBox)
            End If

            Dim btnPrf As Button = New Button

            Dim drExport As DataRow = dtExportAll.NewRow
            drExport("Function") = gvPrjProfile.Rows(iRow).Cells(2).Text
            drExport("SBU") = gvPrjProfile.Rows(iRow).Cells(3).Text

            drExport("Project_Name") = gvPrjProfile.Rows(iRow).Cells(12).Text
            drExport("Chinese_Project_Name") = DataFormatHelper.StringTrim(dtPrfExport.Rows(0).Item("prf_desc_chn").ToString)
            drExport("High_Level_Project_Background") = DataFormatHelper.StringTrim(dtPrfExport.Rows(0).Item("prf_desc_detail").ToString)

            drExport("master_code") = DataFormatHelper.StringTrim(dtPrfExport.Rows(0).Item("prf_main_code").ToString)
            drExport("associated_projects") = DataFormatHelper.StringTrim(dtPrfExport.Rows(0).Item("prj_codes").ToString)
            drExport("Project_Leader") = gvPrjProfile.Rows(iRow).Cells(6).Text
            drExport("Business_Unit") = gvPrjProfile.Rows(iRow).Cells(8).Text
            drExport("TSS_Service_Category") = dtPrfExport.Rows(0).Item("tssprj_name").ToString
            drExport("Fixed_Price_Project") = dtPrfExport.Rows(0).Item("fixed_price_project").ToString

            If IsDate(gvPrjProfile.Rows(iRow).Cells(9).Text.Trim) Then
                drExport("Estimated_Start_Date") = Format(Convert.ToDateTime(gvPrjProfile.Rows(iRow).Cells(9).Text.Trim), Session("date_format"))
            End If

            If IsDate(gvPrjProfile.Rows(iRow).Cells(10).Text.Trim) Then
                drExport("Estimated_Completion_Date") = Format(Convert.ToDateTime(gvPrjProfile.Rows(iRow).Cells(10).Text.Trim), Session("date_format"))
            End If

            drExport("Estimated_Total_Effort") = dtPrfExport.Rows(0).Item("est_total_hours").ToString
            drExport("Actual_Total_Effort") = dtPrfExport.Rows(0).Item("actl_total_hours").ToString


            drExport("Overall_Health") = DataFormatHelper.GetRAGDesc(txtHealthSta.Text)
            drExport("Quality") = DataFormatHelper.GetRAGDesc(txtQualitySta.Text)
            drExport("Scope") = DataFormatHelper.GetRAGDesc(txtScopeSta.Text)
            drExport("Cost") = DataFormatHelper.GetRAGDesc(txtCostSta.Text)
            drExport("Schedule") = DataFormatHelper.GetRAGDesc(txtScheduleSta.Text)
            drExport("Resource") = DataFormatHelper.GetRAGDesc(txtResourceSta.Text)
            drExport("CSS") = txtCssSta.Text
            drExport("Project_Stage") = DataFormatHelper.StringTrim(gvPrjProfile.Rows(iRow).Cells(11).Text)
            drExport("Project_Status_Summary") = DataFormatHelper.StringTrim(dtPrfExport.Rows(0).Item("prj_status_remark").ToString)

            drExport("Last_Submitted_Date") = DataFormatHelper.StringTrim(gvPrjProfile.Rows(iRow).Cells(22).Text)


            If cbPrf.Checked = True Then
                sSelPrfId.Append(IIf(iRow = 0, "", ", " & gvPrjProfile.Rows(iRow).Cells(1).Text.ToString))

                Dim drExportPart As DataRow = dtExportPart.NewRow
                drExportPart.ItemArray = drExport.ItemArray
                dtExportPart.Rows.Add(drExportPart)
                bExportAll = False
            End If

            If bExportAll Then
                dtExportAll.Rows.Add(drExport)
            End If

        Next


        If Not bExportAll And Not dtExportPart Is Nothing Then

            If dtExportPart.Rows.Count > 0 Then
                'Export selected rows
                excelHelper.NpoiDataTable2Excel(fileName, {New ExcelSheetContent("Profile", dtExportPart)})
                bExportAll = False
            End If

        End If

        If bExportAll And Not dtExportAll Is Nothing Then
            If dtExportAll.Rows.Count > 0 Then
                'Export all rows
                excelHelper.NpoiDataTable2Excel(fileName, {New ExcelSheetContent("Profile", dtExportAll)})
            End If
        End If

    End Sub
#End Region

#Region "Query"
    Sub QueryData()
        Dim filterString As StringBuilder = New StringBuilder("")
        Dim sPMFilter As StringBuilder = New StringBuilder("")
        Dim userRoleFilter As StringBuilder = New StringBuilder("1 = 1 ")
        Dim buFilter As String = ""
        Dim sFilter As String = ""
        Dim dr() As DataRow = Nothing

        If Not String.IsNullOrEmpty(txtDataReloadDt.Text) Then
            If IsDate(txtDataReloadDt.Text) Then
                dataVersion = Format(CDate(txtDataReloadDt.Text), "yyyyMMdd")
                filterString.Append(" AND [data_version] <= '" & dataVersion & "' ")
            Else
                dataVersion = Format(Now, "yyyyMMdd")
            End If
        Else
            dataVersion = Format(Now, "yyyyMMdd")
        End If
        Session("dataVersion") = dataVersion

        filterString.Append(" AND [status] = 'D' ")
        If Not String.IsNullOrEmpty(txtPrjName.Text) Then
            filterString.Append(" AND prf_desc like '%" & txtPrjName.Text & "%' ")
        End If

        If Not String.IsNullOrEmpty(txtPrjCode.Text) Then
            filterString.Append(" AND prj_codes like '%" & txtPrjCode.Text & "%' ")
        End If

        If Not String.IsNullOrEmpty(ddlTssPrj.SelectedValue) Then
            filterString.Append(" AND tss_prj = '" & ddlTssPrj.SelectedValue & "' ")
        End If

        buFilter = GetSelectedBU()
        If Not String.IsNullOrEmpty(buFilter) Then
            filterString.Append(" AND bu_code in (" & buFilter & ") ")
        End If

        'PM List
        Dim sPMList As StringBuilder = New StringBuilder("")
        Dim sTeamPrfList As StringBuilder = New StringBuilder("")

        If userRoles Is Nothing Then
            Return
        End If

        If userRoles.Contains(DASHBORADROLES.GM) Or userRoles.Contains(DASHBORADROLES.EXCO) Or userRoles.Contains(DASHBORADROLES.AM) _
        Or userRoles.Contains(DASHBORADROLES.QAG) Or userRoles.Contains(DASHBORADROLES.ADM) Then

        Else
            sPMFilter.Append(" And ( prj_ld_id = '" & Session("logon_id") & "' OR created_by = '" & Session("logon_id") & "' ")

            If userRoles.Contains(DASHBORADROLES.FH) Or userRoles.Contains(DASHBORADROLES.SBUH) Or userRoles.Contains(DASHBORADROLES.TL) Then
                prfService.GetMyTeamProfiles(sTeamPrfList, Session("my_teams"), dataVersion)

                If Not String.IsNullOrEmpty(sTeamPrfList.ToString) Then
                    sPMFilter.Append(" OR prf_id in (" & sTeamPrfList.ToString & ") ")
                End If
            End If

            sPMFilter.Append(" ) ")
        End If
        filterString.Append(sPMFilter)

        Try
            dtProfile = prfService.GetProfileViewList("D", filterString.ToString)

            If Not dtProfile Is Nothing Then
                'dtProfile.Columns.Add("sbu_code", GetType(Integer))
                'dtProfile.Columns.Add("sbu_name", GetType(String))
                'dtProfile.Columns.Add("func_code", GetType(Integer))
                'dtProfile.Columns.Add("func_name", GetType(String))

                dtProfileResult = dtProfile.Clone

                For Each drProfile As DataRow In dtProfile.Rows

                    If IsDBNull(drProfile("team_code")) Then
                        Continue For
                    End If

                    'Dim dtSBU As DataTable = New DataTable()
                    'Dim dtFunc As DataTable = New DataTable()

                    'dtSBU = pmaTeamService.GetTeam(drProfile("team_code"), TEAMLEVEL.SBU)
                    'If Not dtSBU Is Nothing Then
                    '    If dtSBU.Rows.Count > 0 And Not IsDBNull(dtSBU.Rows(0).Item("team_code")) Then
                    '        drProfile("sbu_code") = dtSBU.Rows(0).Item("team_code")
                    '        drProfile("sbu_name") = dtSBU.Rows(0).Item("team_name")
                    '    End If
                    'End If
                    'dtFunc = pmaTeamService.GetTeam(drProfile("team_code"), TEAMLEVEL.FUNC)
                    'If Not dtFunc Is Nothing Then
                    '    If dtFunc.Rows.Count > 0 And Not IsDBNull(dtFunc.Rows(0).Item("team_code")) Then
                    '        drProfile("func_code") = dtFunc.Rows(0).Item("team_code")
                    '        drProfile("func_name") = dtFunc.Rows(0).Item("team_name")
                    '    End If
                    'End If

                    If String.IsNullOrEmpty(ddlFunc.SelectedValue) Then
                        Dim drProfileResult As DataRow = dtProfileResult.NewRow
                        drProfileResult.ItemArray = drProfile.ItemArray

                        dtProfileResult.Rows.Add(drProfileResult)

                    ElseIf ddlFunc.SelectedValue = drProfile("func_code") Then
                        If String.IsNullOrEmpty(ddlSBU.SelectedValue) Then
                            Dim drProfileResult As DataRow = dtProfileResult.NewRow
                            drProfileResult.ItemArray = drProfile.ItemArray

                            dtProfileResult.Rows.Add(drProfileResult)

                        ElseIf ddlSBU.SelectedValue = drProfile("sbu_code") Then
                            Dim drProfileResult As DataRow = dtProfileResult.NewRow
                            drProfileResult.ItemArray = drProfile.ItemArray

                            dtProfileResult.Rows.Add(drProfileResult)
                        End If

                    End If

                Next
            End If


            If Not dtProfileResult Is Nothing Then
                WebControlHelper.GridViewDataBind(gvPrjProfile, dtProfileResult)
            End If

        Catch ex As Exception
            logHelper.WriteLog("Query Draft", ex)
            sAlertMsg = New StringBuilder("Failed to query data")
        End Try



    End Sub

    Private Function GetSelectedBU() As String
        Dim sBUSelected As String = ""

        For i As Integer = 0 To lbBU.Items.Count - 1
            If lbBU.Items(i).Selected = True Then
                sBUSelected = sBUSelected & IIf(sBUSelected = "", "'", ", '") & lbBU.Items(i).Value & "'"
            End If
        Next

        GetSelectedBU = sBUSelected
    End Function

    Private Sub GetFilterPMList(ByRef sPMList As StringBuilder, ByVal teamCode As String)

        Dim dtPM As DataTable = New DataTable
        dtPM = pmaUserService.GetActiveUserListByTeamCode(teamCode)
        If Not dtPM Is Nothing Then
            For Each drPM As DataRow In dtPM.Rows
                If String.IsNullOrEmpty(sPMList.ToString) Then
                    sPMList.Append(" '" & drPM("logon_id") & "'")
                ElseIf Not sPMList.ToString.Contains(drPM("logon_id")) Then
                    sPMList.Append(", ")
                    sPMList.Append(" '" & drPM("logon_id") & "'")
                End If

            Next
        End If

        Dim dtSubTeam As DataTable = New DataTable
        dtSubTeam = pmaTeamService.GetSubTeamList(teamCode)
        If Not dtSubTeam Is Nothing Then
            For Each drSubTeam In dtSubTeam.Rows
                GetFilterPMList(sPMList, drSubTeam("team_code"))
            Next
        End If

    End Sub
#End Region



#Region "gvPrjProfile"


    Sub BindEmptyData()
        Dim emptyDt As DataTable = New DataTable

        emptyDt.NewRow()
        emptyDt.Rows.Add()
        emptyDt.Columns.Add()
        emptyDt.Columns.Add("prf_id")
        emptyDt.Columns.Add("Function_Head")
        emptyDt.Columns.Add("SBU_HEAD")
        emptyDt.Columns.Add("prf_desc")
        emptyDt.Columns.Add("prj_ld_id")
        emptyDt.Columns.Add("bu_code")
        emptyDt.Columns.Add("bu_name")
        emptyDt.Columns.Add("est_start_dt")
        emptyDt.Columns.Add("est_end_dt")
        emptyDt.Columns.Add("prj_stage")
        emptyDt.Columns.Add("health_status")

        gvPrjProfile.DataSource = emptyDt
        gvPrjProfile.DataBind()
        Dim gvDataKeyNames As String() = {"prf_id"}
        gvPrjProfile.DataKeyNames = gvDataKeyNames
    End Sub

    Private Sub gvPrjProfile_DataBinding(sender As Object, e As System.EventArgs) Handles gvPrjProfile.DataBinding
        gvPrjProfile.Columns(1).Visible = True
        gvPrjProfile.Columns(2).Visible = True
        gvPrjProfile.Columns(3).Visible = True
        gvPrjProfile.Columns(6).Visible = True
        gvPrjProfile.Columns(12).Visible = True
        gvPrjProfile.Columns(20).Visible = True
        gvPrjProfile.Columns(21).Visible = True
    End Sub

    Private Sub gvPrjProfile_DataBound(sender As Object, e As System.EventArgs) Handles gvPrjProfile.DataBound
        If ddlSBU.Items.Count = 1 Then
            gvPrjProfile.Columns(2).Visible = False
            gvPrjProfile.Columns(3).Visible = False
        End If

        gvPrjProfile.Columns(1).Visible = False
        gvPrjProfile.Columns(12).Visible = False
        gvPrjProfile.Columns(20).Visible = False
        gvPrjProfile.Columns(21).Visible = False

        Dim bHidePM As Boolean = True
        For iRow As Integer = 0 To gvPrjProfile.Rows.Count - 1
            If gvPrjProfile.Rows(iRow).RowType = DataControlRowType.DataRow Then
                If gvPrjProfile.Rows(iRow).Cells(6).Text <> Session("logon_id") Then
                    bHidePM = False
                    Exit For
                End If
            End If
        Next
        If bHidePM Then
            gvPrjProfile.Columns(6).Visible = False
        End If

        If gvPrjProfile.AllowSorting Then
            WebControlHelper.InitSortingIcon(gvPrjProfile)
        End If

        If gvPrjProfile.Rows.Count = 1 Then
            If gvPrjProfile.DataKeys(0).Values("prf_id").ToString = "" Then
                gvPrjProfile.Rows(0).Cells.Clear()
                Dim tableCell As TableCell = New TableCell
                tableCell.ColumnSpan = gvPrjProfile.Columns.Count
                tableCell.Text = gvPrjProfile.EmptyDataText
                gvPrjProfile.Rows(0).Cells.Add(tableCell)
                gvPrjProfile.Rows(0).Style.Add("text-align", "center")
            End If
        End If
    End Sub

    Private Sub gvPrjProfile_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvPrjProfile.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drView As DataRowView = CType(e.Row.DataItem, DataRowView)

            Dim rowPrfId As Integer = drView("prf_id")

            Dim sLastSubmittedDt As String = prfService.GetProfileLastSubmittedDate(rowPrfId)

            If String.IsNullOrEmpty(sLastSubmittedDt) Then
                e.Row.ForeColor = Drawing.Color.Red
            Else
                e.Row.Cells(22).Text = sLastSubmittedDt
            End If

            Dim gvLabel As HtmlGenericControl = New HtmlGenericControl
            If Not e.Row.FindControl("lblHealthSta") Is Nothing Then
                gvLabel = CType(e.Row.FindControl("lblHealthSta"), HtmlGenericControl)
            End If


            If Not drView Is Nothing Then
                If Not IsDBNull(drView("health_status")) Then
                    gvLabel.InnerText = drView("health_status")
                    SetHealthStatusIconColor(drView("health_status"), "iHealthSta", e)
                End If

                If Not IsDBNull(drView("css_status")) Then
                    SetHealthStatusIconColor(drView("css_status"), "iCssSta", e)
                End If

                If Not IsDBNull(drView("quality_status")) Then
                    SetHealthStatusIconColor(drView("quality_status"), "iQualitySta", e)
                End If
                If Not IsDBNull(drView("scope_status")) Then
                    SetHealthStatusIconColor(drView("scope_status"), "iScopeSta", e)
                End If
                If Not IsDBNull(drView("cost_status")) Then
                    SetHealthStatusIconColor(drView("cost_status"), "iCostSta", e)
                End If
                If Not IsDBNull(drView("schedule_status")) Then
                    SetHealthStatusIconColor(drView("schedule_status"), "iScheduleSta", e)
                End If
                If Not IsDBNull(drView("resource_status")) Then
                    SetHealthStatusIconColor(drView("resource_status"), "iResourceSta", e)
                End If

            End If
        End If
    End Sub

    Private Sub gvPrjProfile_PageIndexChanging(sender As Object, e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvPrjProfile.PageIndexChanging
        QueryData()
        gvPrjProfile.PageIndex = e.NewPageIndex

        WebControlHelper.GridViewDataBind(gvPrjProfile, dtProfileResult)
    End Sub

    Private Sub gvPrjProfile_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvPrjProfile.Sorting
        QueryData()
        WebControlHelper.GridViewSorting(gvPrjProfile, e, dtProfileResult)
    End Sub

    Private Sub gvPrjProfile_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvPrjProfile.RowCommand
        If e.CommandName = "previewProfile" Then
            Dim index As String = CType(e.CommandArgument(), Integer)
            Dim gvRow As GridViewRow = gvPrjProfile.Rows(index)

            Dim prf_id As Integer = gvPrjProfile.DataKeys(index).Item(0)

            Session("prf_id") = prf_id
            Session("fromPg") = "DRAFT"
            Session("dataVersion") = Format(Now, "yyyyMMdd")

            Dim dtProfile As DataTable = prfService.GetProfile(prf_id)
            If Not dtProfile Is Nothing Then
                If dtProfile.Rows.Count > 0 Then
                    Session("current_data_version") = dtProfile.Rows(0).Item("data_version")
                End If
                dtProfile.Dispose()
            End If

            Server.Transfer("ProfileHealthTab.aspx")


            'Server.Transfer("ProfilePreviewDraft.aspx")
        End If
    End Sub

    Private Sub SetHealthStatusIconColor(ByVal sSta As String, ByVal ctlName As String, ByRef e As System.Web.UI.WebControls.GridViewRowEventArgs)
        Dim iSta As HtmlGenericControl = New HtmlGenericControl
        If Not e.Row.FindControl(ctlName) Is Nothing Then
            iSta = CType(e.Row.FindControl(ctlName), HtmlGenericControl)
            Select Case sSta
                Case "R"
                    iSta.Style.Add("color", "Red")
                Case "A"
                    iSta.Style.Add("color", "#f0ad4e")
                Case "G"
                    iSta.Style.Add("color", "Green")
            End Select
        End If
    End Sub
#End Region


    



End Class