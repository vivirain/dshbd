﻿Imports System.Web.Services


Public Class ProfileBasicCreate
    Inherits System.Web.UI.Page

    Protected sErrMsgBuilder As StringBuilder = New StringBuilder("")

    Protected prfObj As ProfileModel = New ProfileModel
    Protected profileId As Integer = 0

    Protected sPrfMainCode As String = ""
    Protected sPrjCodes As String = ""
    Protected sPrfDesc As String = ""
    Protected sPrfDescChn As String = ""
    Protected sPrfDescDetail As String = ""
    Protected sPM As String = ""
    Protected sTeam As String = ""
    Protected sFixedPricePrj As String = ""
    Protected sTssPrjList As String = ""


    Dim pmaTeamService As IPmaTeamService = New PmaTeamService
    Dim pmaUserService As IPmaUserService = New PmaUserService
    Dim pmaTssPrjService As IPmaTssProjectService = New PmaTssProjectService
    Dim pmaBizUnitService As IPmaBizUnitService = New PmaBizUnitService
    Dim pmaPrjService As IPmaProjectService = New PmaProjectService
    Shared prfService As IProfileService = New ProfileService

    Dim logHelper As LogHelper = New LogHelper

    Private sReturnPage As String = ""
    Private fromPg As String = ""
    Private dataVersion As String = ""
    Private currentDataVer As String = Format(Now, "yyyyMMdd")


    'Page
    Protected currentSortExpression As String = ""
    Protected currentSortDirection As String = ""

    Shared sqlAdapterUpdates As SqlAdapterUpdate()


    Private orderString As String = "TSS_PRJ ASC, BU_CODE ASC, PRJ_CODE ASC"

    Protected Shared dtTssPrj As DataTable = New DataTable("TssPrj")
    Protected Shared dtBU As DataTable = New DataTable("BU")
    Protected dtPM As DataTable = New DataTable("PM")

    Protected dtSRViewRaw As DataTable = Nothing
    Protected dtSRViewResult As DataTable = Nothing

    Enum SAVEMODE
        ADD = 1
        UPDATE = -1
        SELECTSR = 0
    End Enum

    Protected mode As Integer = SAVEMODE.SELECTSR

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            profileId = 0
            Session("prf_id") = profileId

            fromPg = HttpContext.Current.Items("fromPg")
            currentDataVer = Format(Now, "yyyyMMdd")
            dataVersion = HttpContext.Current.Items("dataVersion")

            'Init
            InitVariables()
            ResetProfileBasicInfo()

            btnCreateProfile_Click()


        End If
    End Sub

#Region "Init_Variables"

    Sub InitVariables()
        'TSS Service Category
        dtTssPrj = pmaTssPrjService.GetTssProjectFilterList()
        If Not dtTssPrj Is Nothing Then
            If dtTssPrj.Rows.Count > 1 Then
                dtTssPrj = dtTssPrj.Select("1=1", "display_name").CopyToDataTable
            End If
        End If

        'Business Unit
        dtBU = pmaBizUnitService.getBizUnitList()
        If Not dtBU Is Nothing Then
            If dtBU.Rows.Count > 0 Then
                dtBU = dtBU.Select("1=1", "display_name").CopyToDataTable
            End If
        End If

        'txtActlStartDate.Attributes.Add("readonly", True)
        'txtActlEndDate.Attributes.Add("readonly", True)
        'txtEstTotalHours.Attributes.Add("readonly", True)
        'txtActlTotalHours.Attributes.Add("readonly", True)
        txtPrjCode.Attributes.Add("readonly", True)

    End Sub


    Sub ResetProfileBasicInfo()
        txtMainPrjCode.Text = ""
        txtCurrency.Text = ""
        txtPrjName.Text = ""
        txtPrjName.Enabled = False
        txtPrjNameChn.Text = ""
        txtPrjNameChn.Enabled = False
        txtBackGround.Text = ""
        txtBackGround.Enabled = False

        ddlBU.Items.Clear()
        ddlBU.Enabled = False
        ddlTssPrj.Items.Clear()
        ddlTssPrj.Enabled = False

        txtFixedPricePrj.Text = ""
        sFixedPricePrj = ""

        lstPrjManager.Items.Clear()
        lstPrjManager.Enabled = False

        lblEstStartDate.InnerText = ""
        lblEstEndDate.InnerText = ""
        lblActlStartDate.InnerText = ""
        lblActlEndDate.InnerText = ""
        'txtActlEndDate.Text = ""

        'txtEstTotalHours.Text = ""
        'txtActlTotalHours.Text = ""
        lblEstTotalHours.InnerText = ""
        lblActlTotalHours.InnerText = ""

        lblEstTotalCost.Text = ""
        lblActlTotalCost.Text = ""
        lblActlTotalCostBilled.Text = ""

        'lblStatus.Text = ""
    End Sub

#End Region


#Region "SR_Select"
    'Add SR
    Public Sub btnCreateProfile_Click()
        InitFilterTssPrj(ddlTssPrjSRFilter)
        InitFilterPrjSta(ddlPrjStaSRFilter)

        SelectSR(gvSRList, ddlTssPrjSRFilter.SelectedValue, ddlPrjStaSRFilter.SelectedValue)
    End Sub
    'Add/Remove SR
    Public Sub btnEdit_Click()
        InitFilterTssPrj(ddlTssPrjModalSRFilter)
        InitFilterPrjSta(ddlPrjStaModalSRFilter)

        SelectSR(gvModalSRList, ddlTssPrjModalSRFilter.SelectedValue, ddlPrjStaModalSRFilter.SelectedValue)

        scriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalSRList',true);", True)
    End Sub

    Private Sub InitFilterTssPrj(ByRef ddlTssPrjFilter As DropDownList)
        WebControlHelper.DropDownListDataBind(ddlTssPrjFilter, dtTssPrj, "display_name", "CODE")
    End Sub

    Private Sub InitFilterPrjSta(ByRef ddlPrjStaFilter As DropDownList)
        ddlPrjStaFilter.Items.Clear()
        ddlPrjStaFilter.Items.Add(New ListItem("All", ""))
        ddlPrjStaFilter.Items.Add(New ListItem("A - Active", "A"))
        ddlPrjStaFilter.Items.Add(New ListItem("C - Close", "C"))
        ddlPrjStaFilter.DataBind()
        ddlPrjStaFilter.SelectedValue = "A"
    End Sub

    Sub SelectSR(ByRef gv As GridView, tssPrjFilter As String, prjStaFilter As String)
        dtSRViewResult = Nothing
        dtSRViewResult = GetSRList()

        If Not dtSRViewResult Is Nothing Then
            If dtSRViewResult.Rows.Count > 0 Then
                FilterSRList(dtSRViewResult, tssPrjFilter, prjStaFilter)
            End If
            BindGridViewData(gv, dtSRViewResult)
        End If
    End Sub
    Private Function GetSRList() As DataTable
        Dim userRoles As String() = CType(Session("userRoleList"), String())
        If userRoles Is Nothing Then
            Return Nothing
        End If

        If IsNumeric(Session("prf_id")) Then
            profileId = Session("prf_id")
        End If

        Dim dtViewRaw As DataTable = Nothing

        Try
            If userRoles.Contains(DASHBORADROLES.ADM) Or userRoles.Contains(DASHBORADROLES.QAG) Or userRoles.Contains(DASHBORADROLES.AM) _
            Or userRoles.Contains(DASHBORADROLES.GM) Or userRoles.Contains(DASHBORADROLES.EXCO) Then
                'Load all projects (ADM, QAG, AM, GM, EXCO)
                dtViewRaw = pmaPrjService.GetAllNoneProfiledProjectViewList(profileId)

            ElseIf userRoles.Length = 1 And userRoles(0) = DASHBORADROLES.PM Then
                'Load projects owned by session user (PM)
                dtViewRaw = pmaPrjService.GetPmNoneProfiledProjectViewList(Session("logon_id"), Session("id_card"), profileId)
            Else

                'Load projects within team (TL / SBUH / FUNCH)
                dtViewRaw = pmaPrjService.GetTeamNoneProfiledProjectViewList(Session("logon_id"), Session("id_card"), Session("my_teams"), profileId)
            End If

            If Not dtViewRaw Is Nothing Then
                If dtViewRaw.Rows.Count > 0 Then
                    dtViewRaw = dtViewRaw.Select("1=1", orderString).CopyToDataTable
                End If
            End If
        Catch ex As Exception
            logHelper.WriteLog("Failed to load SR list.", ex)
            dtViewRaw = Nothing
        End Try

        GetSRList = dtViewRaw

        dtViewRaw = Nothing

    End Function
    Sub FilterSRList(ByRef dtSR As DataTable, ByVal tssPrjFilter As String, ByVal prjStaFilter As String)

        If String.IsNullOrEmpty(tssPrjFilter) And String.IsNullOrEmpty(prjStaFilter) Then
            Return
        End If

        'Handling filtering
        Dim dr As DataRow() = Nothing
        Dim filterString As StringBuilder = New StringBuilder("1 = 1")
        'Filter by project status
        If Not String.IsNullOrEmpty(prjStaFilter) Then
            filterString.Append(" AND ")
            If prjStaFilter.ToUpper = "A" Then
                filterString.Append(" status <> '10' ")
            ElseIf prjStaFilter.ToUpper = "C" Then
                filterString.Append(" status = '10' ")
            End If
        End If

        'Filter by project status
        If Not String.IsNullOrEmpty(tssPrjFilter) Then
            filterString.Append(" AND ")
            filterString.Append(" tss_prj = '" & tssPrjFilter & "' ")
        End If

        'Process filtering
        dr = dtSR.Select(filterString.ToString, orderString)

        If dr Is Nothing Then
            dtSR = Nothing
        ElseIf dr.Length = 0 Then
            dtSR = dtSR.Clone
            dr = Nothing
        Else
            dtSR = dr.CopyToDataTable
            dr = Nothing
        End If

    End Sub
    Private Sub BindGridViewData(ByRef gv As GridView, ByRef dt As DataTable)
        WebControlHelper.GridViewDataBind(gv, dt)
    End Sub


    Private Sub ddlTssPrjSRFilter_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlTssPrjSRFilter.SelectedIndexChanged
        SelectSR(gvSRList, ddlTssPrjSRFilter.SelectedValue, ddlPrjStaSRFilter.SelectedValue)
    End Sub
    Private Sub ddlPrjStaSRFilter_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlPrjStaSRFilter.SelectedIndexChanged
        SelectSR(gvSRList, ddlTssPrjSRFilter.SelectedValue, ddlPrjStaSRFilter.SelectedValue)
    End Sub
    Private Sub ddlTssPrjModalSRFilter_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlTssPrjModalSRFilter.SelectedIndexChanged
        SelectSR(gvModalSRList, ddlTssPrjModalSRFilter.SelectedValue, ddlPrjStaModalSRFilter.SelectedValue)
        scriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalSRList', true);", True)
    End Sub
    Private Sub ddlPrjStaModalSRFilter_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlPrjStaModalSRFilter.SelectedIndexChanged
        SelectSR(gvModalSRList, ddlTssPrjModalSRFilter.SelectedValue, ddlPrjStaModalSRFilter.SelectedValue)
        scriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalSRList', true);", True)
    End Sub

    Private Sub gvSRList_DataBound(sender As Object, e As System.EventArgs) Handles gvSRList.DataBound
        If gvSRList.AllowSorting Then
            WebControlHelper.InitSortingIcon(gvSRList)
        End If
    End Sub

    Private Sub gvSRList_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvSRList.Sorting
        If gvSRList.Rows.Count > 0 Then
            SelectSR(gvSRList, ddlTssPrjSRFilter.SelectedValue, ddlPrjStaSRFilter.SelectedValue)
            WebControlHelper.GridViewSorting(gvSRList, e, dtSRViewResult)
        End If
    End Sub

    Private Sub gvModalSRList_DataBound(sender As Object, e As System.EventArgs) Handles gvModalSRList.DataBound
        If gvModalSRList.AllowSorting Then
            WebControlHelper.InitSortingIcon(gvModalSRList)
        End If
    End Sub
    Private Sub gvModalSRList_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvModalSRList.Sorting
        If gvModalSRList.Rows.Count > 0 Then
            SelectSR(gvModalSRList, ddlTssPrjModalSRFilter.SelectedValue, ddlPrjStaModalSRFilter.SelectedValue)
            WebControlHelper.GridViewSorting(gvModalSRList, e, dtSRViewResult)
        End If

        scriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalSRList', true);", True)
    End Sub

    Private Sub gvModalSRList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvModalSRList.RowDataBound

        If Not e.Row.RowType = DataControlRowType.DataRow Then
            Return
        End If

        Dim sPrjCodes As String = txtPrjCode.Text
        Dim sPrjCode As String = ""
        Dim sBU As String = ""
        Dim sTssPrj As String = ""
        Dim sFixedPricePrj As String = ""

        Dim drv As DataRowView = CType(e.Row.DataItem, DataRowView)

        sPrjCode = drv("prj_code")


        Dim cb As CheckBox = New CheckBox
        If Not e.Row.FindControl("cbPrj") Is Nothing Then
            cb = CType(e.Row.FindControl("cbPrj"), CheckBox)

            If sPrjCodes.IndexOf(sPrjCode) >= 0 Then
                cb.Checked = True
            End If

        End If




    End Sub

    Private Sub btnSelect_Click(sender As Object, e As System.EventArgs) Handles btnSelect.Click
        sErrMsgBuilder = New StringBuilder("")
        If Not ValidateSRSelection(gvSRList) Then
            Return
        End If

        ReloadProfileMainCode(gvSRList)

        If Not String.IsNullOrEmpty(ddlSRSelected.SelectedValue) Then
            btnCreate.Visible = True
        End If

        mode = SAVEMODE.ADD
        dvSRList.Style.Add("display", "none")
        dvProfileForm.Style.Add("display", "")
    End Sub
    Private Sub btnModalSelect_Click(sender As Object, e As System.EventArgs) Handles btnModalSelect.Click
        sErrMsgBuilder = New StringBuilder("")
        If Not ValidateSRSelection(gvModalSRList) Then
            scriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalSRList', true);", True)
            Return
        End If

        ReloadProfileMainCode(gvModalSRList)
    End Sub

    Public Function ValidateSRSelection(ByRef gv As GridView) As Boolean
        Dim sBU As String = ""
        Dim sTssPrj As String = ""
        Dim dEstiEffort As Decimal = Nothing
        Dim bValidSelection As Boolean = True
        Dim sTssPrjDescBauM As String = pmaTssPrjService.GetTssProjectNameByCode(TSSSERVICECATEGORY.BAUM)
        Dim sTssPrjDescBauE As String = pmaTssPrjService.GetTssProjectNameByCode(TSSSERVICECATEGORY.BAUE)

        For iRow As Integer = 0 To gv.Rows.Count - 1
            Dim gvSRRow As GridViewRow = gv.Rows(iRow)
            Dim gvRowBU As String = ""
            Dim gvRowTssPrj As String = ""
            Dim gvRowPrjCode As String = ""
            Dim gvRowFixedPricePrj As String = ""
            Dim gvRowEstiEffort As Decimal = Nothing

            Dim cb As CheckBox = New CheckBox
            If Not gvSRRow.FindControl("cbPrj") Is Nothing Then
                cb = gvSRRow.FindControl("cbPrj")
            End If
            If cb.Checked = False Then
                Continue For
            End If

            If Not gvSRRow Is Nothing Then
                gvRowBU = gvSRRow.Cells(3).Text
                gvRowTssPrj = gvSRRow.Cells(4).Text
                gvRowPrjCode = gvSRRow.Cells(1).Text
                gvRowFixedPricePrj = gvSRRow.Cells(14).Text
                If IsNumeric(gvSRRow.Cells(8).Text) AndAlso gvRowTssPrj = sTssPrjDescBauE Then
                    gvRowEstiEffort = gvSRRow.Cells(8).Text
                Else
                    gvRowEstiEffort = Nothing
                End If
            End If

            If sBU = "" And sTssPrj = "" Then
                sBU = gvRowBU
                sTssPrj = gvRowTssPrj
                dEstiEffort = gvRowEstiEffort
            End If

            'Should from same BU
            If gvRowBU <> sBU Then
                bValidSelection = False
                sErrMsgBuilder.AppendLine("Selected project(s) should be from the same business unit.<br/>")
            End If

            'Should have same TSS service category
            If IsNumeric(gvRowEstiEffort) AndAlso gvRowEstiEffort >= 750 AndAlso gvRowTssPrj = sTssPrjDescBauE AndAlso sTssPrj = sTssPrjDescBauM Then
                bValidSelection = False
                sErrMsgBuilder.AppendLine("BAU Enhancement project (Estimated effort >= 750 hours) should NOT be grouped with BAU project.<br/>")
            ElseIf IsNumeric(dEstiEffort) AndAlso dEstiEffort >= 750 AndAlso sTssPrj = sTssPrjDescBauE AndAlso gvRowTssPrj = sTssPrjDescBauM Then
                bValidSelection = False
                sErrMsgBuilder.AppendLine("BAU Enhancement project (estimated effort >= 750 hours) should NOT be grouped with BAU project.<br/>")
            ElseIf gvRowTssPrj <> sTssPrj AndAlso sTssPrj <> sTssPrjDescBauM AndAlso sTssPrj <> sTssPrjDescBauE Then
                bValidSelection = False
                sErrMsgBuilder.AppendLine("Selected project(s) cannot be grouped due to different quality measurements.<br/>")
            ElseIf gvRowTssPrj <> sTssPrj AndAlso gvRowTssPrj <> sTssPrjDescBauM AndAlso gvRowTssPrj <> sTssPrjDescBauE Then
                bValidSelection = False
                sErrMsgBuilder.AppendLine("Selected project(s) cannot be grouped due to different quality measurements.<br/>")
            End If

            'Should not be grouped into any profile yet.
            If String.IsNullOrEmpty(gvRowPrjCode) Then
                bValidSelection = False
                sErrMsgBuilder.AppendLine("SR# is not found.<br/>")
            End If

            If Not bValidSelection Then
                Exit For
            End If

            Dim dtExistingProfile As DataTable = prfService.GetProfileHistView(gvRowPrjCode, PROFILESTATUS.SUBMITTED)
            Dim bSubmitted As Boolean = True

            If dtExistingProfile Is Nothing Then
                bSubmitted = False
                dtExistingProfile = prfService.GetDraftProfileViewWithPrjCode(gvRowPrjCode)
            ElseIf dtExistingProfile.Rows.Count = 0 Then
                bSubmitted = False
                dtExistingProfile = prfService.GetDraftProfileViewWithPrjCode(gvRowPrjCode)
            End If

            If dtExistingProfile Is Nothing Then
                Continue For
            ElseIf dtExistingProfile.Rows.Count = 0 Then
                Continue For
            End If


            For Each drExistingProfile As DataRow In dtExistingProfile.Rows
                If drExistingProfile("prf_id").ToString <> CType(Session("prf_id"), String) Then
                    bValidSelection = False
                    sErrMsgBuilder.AppendLine("Project " & gvRowPrjCode & " is already grouped into profile '" & drExistingProfile("prf_desc") & "' ")
                    If Not bSubmitted Then
                        sErrMsgBuilder.Append(" in [Draft Folder]")
                    End If
                    sErrMsgBuilder.Append(".<br/>")
                    Exit For
                End If
            Next

        Next

        ValidateSRSelection = bValidSelection
    End Function

#End Region

#Region "Profile_Basic"

    Private Sub LoadProfileBasicInfo(profileId)
        Dim dtProfile As DataTable = prfService.GetProfile(profileId)
        If dtProfile Is Nothing Then
            logHelper.WriteLog("Failed to load profile basic info for " & profileId)
            sErrMsgBuilder = New StringBuilder("Failed to load profile basic information.")
            Return
        ElseIf dtProfile.Rows.Count = 0 Then
            logHelper.WriteLog("Failed to load profile basic info for " & profileId)
            sErrMsgBuilder = New StringBuilder("Failed to load profile basic information.")
            Return
        End If

        Dim drProfile As DataRow = dtProfile.Rows(0)
        'ProfileId
        txtProfileId.Text = profileId

        'SR# grouped into profile
        txtPrjCode.Text = drProfile("prj_codes").ToString
        sPrjCodes = drProfile("prj_codes").ToString

        'Profile Main Code
        txtMainPrjCode.Text = drProfile("prf_main_code").ToString
        sPrfMainCode = drProfile("prf_main_code").ToString
        ddlSRSelected.Items.Clear()
        ddlSRSelected.Items.Add(sPrfMainCode)
        ddlSRSelected.SelectedValue = sPrfMainCode
        ddlSRSelected.Enabled = False

        'Profile Name
        txtPrjName.Text = drProfile("prf_desc").ToString.Trim
        sPrfDesc = txtPrjName.Text
        txtPrjName.Enabled = True
        'Profile Name (Chinese)
        txtPrjNameChn.Text = drProfile("prf_desc_chn").ToString.Trim
        sPrfDescChn = txtPrjNameChn.Text
        txtPrjNameChn.Enabled = True
        'Profile Background
        txtBackGround.Text = drProfile("prf_desc_detail").ToString.Trim
        sPrfDescDetail = txtBackGround.Text
        txtBackGround.Enabled = True

        'BU
        WebControlHelper.DropDownListDataBind(ddlBU, dtBU, "display_name", "bu_code")
        ddlBU.SelectedValue = drProfile("bu_code").ToString
        ddlBU.Enabled = False
        Session("bu_code") = ddlBU.SelectedValue

        'TSS Service Category
        WebControlHelper.DropDownListDataBind(ddlTssPrj, dtTssPrj, "display_name", "code")
        ddlTssPrj.SelectedValue = drProfile("tss_prj").ToString
        ddlTssPrj.Enabled = False
        Session("tss_prj") = ddlTssPrj.SelectedValue

        'Fixed Price Project
        sFixedPricePrj = drProfile("fixed_price_project").ToString
        txtFixedPricePrj.Text = sFixedPricePrj
        Session("fixed_price_project") = sFixedPricePrj

        'Project Leader
        dtPM = pmaUserService.GetActiveUserHashByMyTeams(Session("my_teams"))
        If Not dtPM Is Nothing Then
            If dtPM.Rows.Count > 0 Then
                dtPM = dtPM.Select("1=1", "display_name").CopyToDataTable
            End If
            dtPM.PrimaryKey = {dtPM.Columns("pmaId")}
        End If
        WebControlHelper.DropDownListDataBind(lstPrjManager, dtPM, "display_name", "pmaId", False)
        lstPrjManager.Enabled = True

        Dim selectedPmId As String = drProfile("PRJ_LD_ID").ToString.Trim.ToUpper
        Dim selectedPmIdCard As String = drProfile("PRJ_LD_ID_CARD_NO").ToString.Trim.ToUpper
        Dim selectedPMItem As ListItem = lstPrjManager.Items.FindByValue(selectedPmId & "-" & selectedPmIdCard)
        If Not selectedPMItem Is Nothing Then
            lstPrjManager.SelectedValue = selectedPmId & "-" & selectedPmIdCard
        End If

        If Session("userRoles").ToString.Length = 1 And Session("userRoles").ToString = DASHBORADROLES.PM Then
            lstPrjManager.Enabled = False
        End If

        Dim dtSRSelected As DataTable = pmaPrjService.GetProjectViewList(sPrjCodes)
        ReCalProfileBasicInfo(dtSRSelected)

        'lblStatus.Text = drProfile("status").ToString

    End Sub

    Private Sub ddlSRSelected_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlSRSelected.SelectedIndexChanged
        ReloadProfileBasicInfo()
        If Not String.IsNullOrEmpty(ddlSRSelected.SelectedValue) Then
            btnCreate.Visible = True
        End If
    End Sub

    Private Sub ReloadProfileMainCode(ByRef gv As GridView)
        Dim sPrjCodesSelected As StringBuilder = New StringBuilder("")
        sTssPrjList = ""
        ddlSRSelected.Items.Clear()
        ddlSRSelected.Items.Add("")

        For iRow As Integer = 0 To gv.Rows.Count - 1
            Dim cb As CheckBox = New CheckBox
            If Not gv.Rows(iRow).FindControl("cbPrj") Is Nothing Then
                cb = gv.Rows(iRow).FindControl("cbPrj")
            End If

            If cb.Checked = False Then
                Continue For
            End If

            If sTssPrjList.Length = 0 Then
                sTssPrjList = gv.Rows(iRow).Cells(4).Text.ToString.Trim
            ElseIf Not sTssPrjList.Contains(gv.Rows(iRow).Cells(4).Text.ToString.ToString) Then
                sTssPrjList = sTssPrjList & "," & gv.Rows(iRow).Cells(4).Text.ToString.ToString
            End If

            Dim sSRNo As String = gv.Rows(iRow).Cells(1).Text.ToString.Trim
            Dim sSRName As String = gv.Rows(iRow).Cells(2).Text.ToString.Trim

            If Not String.IsNullOrEmpty(sPrjCodesSelected.ToString) Then
                sPrjCodesSelected.Append(",")
            End If
            sPrjCodesSelected.Append(sSRNo)

            Dim prjItem As ListItem = New ListItem
            prjItem.Value = sSRNo
            prjItem.Text = sSRName & " - " & sSRNo
            ddlSRSelected.Items.Add(prjItem)
        Next

        txtTssPrjSelected.Text = sTssPrjList
        txtPrjCode.Text = sPrjCodesSelected.ToString
        If sPrjCodesSelected.ToString.IndexOf(",") < 0 Then
            ddlSRSelected.Items.Remove("")
            ddlSRSelected.SelectedValue = sPrjCodesSelected.ToString
            ddlSRSelected.Enabled = False
            txtMainPrjCode.Text = sPrjCodesSelected.ToString
        Else
            ddlSRSelected.Enabled = True
        End If

        ReloadProfileBasicInfo()

    End Sub

    Sub ReloadProfileBasicInfo(Optional ByVal profileId As Integer = 0)

        sPrjCodes = DataFormatHelper.StringTrim(txtPrjCode.Text)
        sPrfMainCode = ddlSRSelected.SelectedValue
        txtMainPrjCode.Text = sPrfMainCode

        If String.IsNullOrEmpty(sPrfMainCode) Then
            ResetProfileBasicInfo()
            Exit Sub
        End If

        Dim dtSRSelected As DataTable = pmaPrjService.GetProjectViewList(sPrjCodes)
        If dtSRSelected Is Nothing Then
            Return
        ElseIf dtSRSelected.Rows.Count = 0 Then
            Return
        End If

        Dim drMainProject As DataRow = dtSRSelected.Select("PRJ_CODE = '" & sPrfMainCode & "'")(0)

        txtCurrency.Text = drMainProject("CURRENCY").ToString
        If profileId = 0 Then
            txtPrjName.Text = DataFormatHelper.StringTrim(drMainProject("PRJ_DESC").ToString)
            txtPrjNameChn.Text = DataFormatHelper.StringTrim(drMainProject("PRJ_DESC_CHN").ToString)
            txtBackGround.Text = DataFormatHelper.StringTrim(drMainProject("DESC_DETAIL").ToString)
        End If
        txtPrjName.Enabled = True
        txtPrjNameChn.Enabled = True
        txtBackGround.Enabled = True

        'Fixed Price Project
        If Not IsDBNull(drMainProject("FIXED_PRICE_PRJ")) Then
            sFixedPricePrj = DataFormatHelper.StringTrim(drMainProject("FIXED_PRICE_PRJ").ToString)
            txtFixedPricePrj.Text = sFixedPricePrj
        End If

        'Get BU
        WebControlHelper.DropDownListDataBind(ddlBU, dtBU, "display_name", "bu_code", False)
        ddlBU.SelectedValue = drMainProject("BU_CODE").ToString
        ddlBU.Enabled = False

        'TSS Service Category
        WebControlHelper.DropDownListDataBind(ddlTssPrj, dtTssPrj, "display_name", "code", False)
        ddlTssPrj.SelectedValue = drMainProject("TSS_PRJ").ToString
        ddlTssPrj.Enabled = False

        'Get Team Name & PM Name List
        dtPM = pmaUserService.GetActiveUserHashByMyTeams(Session("my_teams"))
        If Not dtPM Is Nothing Then
            If dtPM.Rows.Count > 0 Then
                dtPM = dtPM.Select("1=1", "display_name").CopyToDataTable
            End If
            dtPM.PrimaryKey = {dtPM.Columns("pmaId")}
        End If
        Dim selectedPmId As String = drMainProject("PRJ_LD_ID").ToString.Trim.ToUpper
        Dim selectedPmIdCard As String = drMainProject("PRJ_LD_ID_CARD_NO").ToString.Trim.ToUpper
        WebControlHelper.DropDownListDataBind(lstPrjManager, dtPM, "display_name", "pmaId", False)
        Dim selectedPMItem As ListItem = lstPrjManager.Items.FindByValue(selectedPmId & "-" & selectedPmIdCard)
        If Not selectedPMItem Is Nothing Then
            lstPrjManager.SelectedValue = selectedPmId & "-" & selectedPmIdCard
        End If

        If Session("userRoles").ToString.Length = 1 And Session("userRoles").ToString = DASHBORADROLES.PM Then
            lstPrjManager.Enabled = False
        Else
            lstPrjManager.Enabled = True
        End If


        ReCalProfileBasicInfo(dtSRSelected)

    End Sub

    Sub ReCalProfileBasicInfo(ByRef dtSRSelected As DataTable)
        '(re)calculate emtimated start date as earliest estimated start date of all selecte projects (SRs)
        If IsDate(dtSRSelected.Compute("MIN(EST_STRT_DATE)", "")) Then
            lblEstStartDate.InnerText = Format(dtSRSelected.Compute("MIN(EST_STRT_DATE)", ""), Session("date_format"))
        Else
            lblEstStartDate.InnerText = ""
        End If

        '(re)calculate estimated end date as latest estimated completion date of all selecte projects (SRs)
        If IsDate(dtSRSelected.Compute("MAX(EST_CMPL_DATE)", "")) Then
            lblEstEndDate.InnerText = Format(dtSRSelected.Compute("MAX(EST_CMPL_DATE)", ""), Session("date_format"))

        Else
            lblEstEndDate.InnerText = ""
        End If

        '(re)calculate actual start date as earliest estimated start date of all selecte projects (SRs)
        If IsDate(dtSRSelected.Compute("MIN(ATL_START)", "")) Then
            lblActlStartDate.InnerText = Format(dtSRSelected.Compute("MIN(ATL_START)", ""), Session("date_format"))
        Else
            lblActlStartDate.InnerText = ""
        End If

        '(re)calculate actual end date as earliest estimated start date of all selecte projects (SRs)
        If IsDate(dtSRSelected.Compute("MAX(ATL_FINISH)", "")) Then
            lblActlEndDate.InnerText = Format(dtSRSelected.Compute("MAX(ATL_FINISH)", ""), Session("date_format"))
        Else
            lblActlEndDate.InnerText = ""
        End If

        'Estimated total Effort(Hours)
        If IsDBNull(dtSRSelected.Compute("SUM(PRJ_TOT_EST_HOUR)", "")) Then
            lblEstTotalHours.InnerText = 0
        Else
            lblEstTotalHours.InnerText = DataFormatHelper.FormatString(dtSRSelected.Compute("SUM(PRJ_TOT_EST_HOUR)", ""), "N", 1)
        End If
        'Actual total Effort(Hours)
        If IsDBNull(dtSRSelected.Compute("SUM(actl_hours_accrual)", "")) Then
            lblActlTotalHours.InnerText = 0
        Else
            lblActlTotalHours.InnerText = DataFormatHelper.FormatString(dtSRSelected.Compute("SUM(actl_hours_accrual)", ""), "N", 1)
        End If

        'Estimated total Cost
        If IsDBNull(dtSRSelected.Compute("SUM(PRJ_TOT_EST_COST)", "")) Then
            lblEstTotalCost.Text = 0
        Else
            lblEstTotalCost.Text = dtSRSelected.Compute("SUM(PRJ_TOT_EST_COST)", "")
        End If

        'Actual total cost (accrual)
        If IsDBNull(dtSRSelected.Compute("SUM(ATL_COST)", "")) Then
            lblActlTotalCost.Text = 0
        Else
            lblActlTotalCost.Text = dtSRSelected.Compute("SUM(ATL_COST)", "")
        End If

        'Actual total cost (cash based)
        Dim pmaDebtNoteDetailService As IPmaDebitNoteDetailService = New PmaDebitNoteDetailService
        Dim dnYearMonth As String = Year(Now) & "/" & IIf(Month(Now) < 10, "0", "") & Month(Now)
        lblActlTotalCostBilled.Text = pmaDebtNoteDetailService.GetActualCost(sPrjCodes, dnYearMonth)
    End Sub

    Sub EnableFieldsEdit()

        If Not String.IsNullOrEmpty(txtMainPrjCode.Text) Then
            txtPrjName.ReadOnly = False
            txtPrjNameChn.ReadOnly = False
            txtBackGround.ReadOnly = False

        End If
    End Sub
#End Region

#Region "Create_Profile"
    <WebMethod(True)>
    Public Sub CreateProfile()
        If Not ValidateProfileData() Then
            scriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "popUpMsg();", True)
            Return
        End If

        Try
            If SaveProfileData() Then
                ddlSRSelected.Enabled = False
                sErrMsgBuilder = New StringBuilder("alert('Profile is created successfully. You can retrieve it from [Draft Folder].');window.location ='ProfileBasicEditTab.aspx';")

            Else
                sErrMsgBuilder = New StringBuilder("alert(Oops, something is wrong while creating profile.);")
            End If
        Catch ex As Exception
            sErrMsgBuilder = New StringBuilder("alert(Oops, system encounters a problem now.);")
            logHelper.WriteLog("btnCreate_Click", ex)
        End Try

        scriptManager.RegisterStartupScript(Page, Page.GetType(), "alert", sErrMsgBuilder.ToString, True)
    End Sub

    Function ValidateProfileData() As Boolean
        Dim bValid As Boolean = True
        sErrMsgBuilder = New StringBuilder("")

        If txtPrjName.Text.ToString.Trim() = "" Then
            bValid = False
            sErrMsgBuilder.Append("Project Name is required.\r\n")
        End If

        If txtBackGround.Text.ToString.Trim() = "" Then
            bValid = False
            sErrMsgBuilder.Append("High level background is required.\r\n")
        End If

        If ddlTssPrj.SelectedIndex < 0 Then
            bValid = False
            sErrMsgBuilder.Append("TSS Servcie Category can't be blank.\r\n")
        End If

        If lstPrjManager.SelectedIndex < 0 Then
            bValid = False
            sErrMsgBuilder.Append("Project Leader can't be blank. Seek help from system administrator if you can't (re) select any project leader.\r\n")
        End If

        ValidateProfileData = bValid
    End Function

    Function SaveProfileData() As Boolean

        Dim bSave As Boolean = False

        Dim dtProfileSave As DataTable = New DataTable("profileSave")

        Try
            dtProfileSave = prfService.GetProfile(profileId)

            If dtProfileSave Is Nothing Then
                Return bSave
            End If

            Dim drProfileSave As DataRow = dtProfileSave.NewRow

            PrepareProfileData4Save(drProfileSave)

            bSave = True
            drProfileSave("DATA_VERSION") = ""
            drProfileSave("STATUS") = PROFILESTATUS.DRAFT

            drProfileSave("LAST_UPDATED_BY") = Session("logon_id")
            drProfileSave("LAST_UPDATED_DT") = Now

            drProfileSave("CREATED_BY") = Session("logon_id")
            drProfileSave("CREATED_DT") = Now

            If drProfileSave.RowState = DataRowState.Unchanged Then
                drProfileSave.SetAdded()
            End If

            dtProfileSave.Rows.Add(drProfileSave)

            bSave = prfService.CreateProfile(dtProfileSave, profileId)

            If bSave Then
                Session("prf_id") = profileId

                TriggerSRIssueLog(profileId, dtProfileSave)
            End If

        Catch ex As Exception
            logHelper.WriteLog("Failed to save profile basic infomation.", ex)
            bSave = False
            dtProfileSave = Nothing
        Finally
            dtProfileSave = Nothing
        End Try

        SaveProfileData = bSave

    End Function

    Private Sub PrepareProfileData4Save(ByRef drProfileSave As DataRow)

        sPrfDesc = DataFormatHelper.StringTrim(txtPrjName.Text)

        If IIf(IsDBNull(drProfileSave("prf_desc")), "", drProfileSave("prf_desc").ToString.Trim) <> sPrfDesc Then
            drProfileSave("prf_desc") = sPrfDesc
        End If

        sPrfDescDetail = DataFormatHelper.StringTrim(txtBackGround.Text)
        If IIf(IsDBNull(drProfileSave("prf_desc_detail")), "", drProfileSave("prf_desc_detail").ToString.Trim) <> sPrfDescDetail Then
            drProfileSave("prf_desc_detail") = sPrfDescDetail
        End If

        sPrfDescChn = DataFormatHelper.StringTrim(txtPrjNameChn.Text)
        If IIf(IsDBNull(drProfileSave("prf_desc_chn")), "", drProfileSave("prf_desc_chn").ToString.Trim) <> sPrfDescChn Then
            drProfileSave("prf_desc_chn") = sPrfDescChn
        End If

        drProfileSave("tss_prj") = ddlTssPrj.SelectedValue
        drProfileSave("bu_code") = ddlBU.SelectedValue

        sFixedPricePrj = DataFormatHelper.StringTrim(txtFixedPricePrj.Text)
        If String.IsNullOrEmpty(sFixedPricePrj) Then
            sFixedPricePrj = "N"
        End If
        drProfileSave("fixed_price_project") = sFixedPricePrj

        sPM = lstPrjManager.SelectedValue
        If Not String.IsNullOrEmpty(sPM) Then
            drProfileSave("prj_ld_id") = sPM.Split("-")(0)
            drProfileSave("prj_ld_id_card_no") = sPM.Split("-")(1)
        End If

        drProfileSave("prf_main_code") = txtMainPrjCode.Text
        drProfileSave("prj_codes") = txtPrjCode.Text

        drProfileSave("currency") = txtCurrency.Text

        If IsDate(lblEstStartDate.InnerText) Then
            drProfileSave("est_start_dt") = lblEstStartDate.InnerText
        Else
            drProfileSave("est_start_dt") = DBNull.Value
        End If

        If IsDate(lblEstEndDate.InnerText) Then
            drProfileSave("est_end_dt") = lblEstEndDate.InnerText
        Else
            drProfileSave("est_end_dt") = DBNull.Value
        End If

        If IsDate(lblActlStartDate.InnerText) Then
            drProfileSave("actl_start_dt") = lblActlStartDate.InnerText
        Else
            drProfileSave("actl_start_dt") = DBNull.Value
        End If

        If IsDate(lblActlEndDate.InnerText) Then
            drProfileSave("actl_end_dt") = lblActlEndDate.InnerText
        Else
            drProfileSave("actl_end_dt") = DBNull.Value
        End If

        If IsNumeric(lblEstTotalCost.Text) Then
            drProfileSave("est_total_cost") = lblEstTotalCost.Text
        Else
            drProfileSave("est_total_cost") = 0
        End If

        If IsNumeric(lblActlTotalCost.Text) Then
            drProfileSave("actl_total_cost") = lblActlTotalCost.Text
        End If

        If IsNumeric(lblActlTotalCostBilled.Text) Then
            drProfileSave("actl_total_cost_billed") = lblActlTotalCostBilled.Text
        End If

        If IsNumeric(lblEstTotalHours.InnerText) Then
            drProfileSave("est_total_hours") = lblEstTotalHours.InnerText
        Else
            drProfileSave("est_total_hours") = 0
        End If

        If IsNumeric(lblActlTotalHours.InnerText) Then
            drProfileSave("actl_total_hours") = lblActlTotalHours.InnerText
        Else
            drProfileSave("actl_total_hours") = 0
        End If

    End Sub

    Function TriggerSRIssueLog(ByRef profielId As Integer, ByRef dtProfileSave As DataTable) As Boolean
        Dim bTrigger As Boolean = False

        sPrjCodes = dtProfileSave.Rows(0).Item("prj_codes")

        Dim prjCodeList As String() = sPrjCodes.Split(",")
        If Not prjCodeList Is Nothing Then
            For Each prjCode In prjCodeList
                Dim dtPrj As DataTable = pmaPrjService.GetProjectView(prjCode)
                If Not dtPrj Is Nothing Then
                    If dtPrj.Rows.Count > 0 Then
                        Dim drPrj As DataRow = dtPrj.Rows(0)
                        If dtPrj.Rows(0).Item("status") = "00" Or dtPrj.Rows(0).Item("status") = "01" Then
                            Dim prfIssueService As IProfileIssueService = New ProfileIssueService
                            Dim dtIssue As DataTable = New DataTable

                            If Not prfIssueService.IsNotApprovedSRIssueCreated(profileId, "RISK", "SR# " & prjCode & " NOT approved", "MISC") Then
                                dtIssue = prfIssueService.GetProfileIssueList(False)
                                If Not dtIssue Is Nothing Then
                                    Dim drIssue As DataRow = dtIssue.NewRow
                                    drIssue.Item("issue_category") = "RISK"
                                    drIssue.Item("issue_desc_short") = "SR# " & prjCode & " NOT approved"
                                    drIssue.Item("issue_desc_sys") = "SR# " & prjCode & " NOT approved"
                                    drIssue.Item("prj_code") = prjCode
                                    drIssue.Item("prf_id") = profileId
                                    drIssue.Item("issue_tag") = "MISC"
                                    drIssue.Item("issue_status") = "O"
                                    drIssue.Item("created_by") = "SYSTEM"
                                    drIssue.Item("created_dt") = Now
                                    drIssue.Item("last_updated_by") = "SYSTEM"
                                    drIssue.Item("last_updated_dt") = Now
                                    drIssue.Item("issue_no") = "RISK-" & prfIssueService.GetNewIssueNo("RISK")
                                    dtIssue.Rows.Add(drIssue)
                                    bTrigger = prfIssueService.SaveProfileIssue(dtIssue)

                                End If
                            End If

                        End If
                    End If
                End If
            Next
        End If

        TriggerSRIssueLog = bTrigger
    End Function
#End Region









End Class