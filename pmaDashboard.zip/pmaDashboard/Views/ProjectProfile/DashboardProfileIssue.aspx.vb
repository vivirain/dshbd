﻿Imports System.IO
Imports System.Web.Script.Serialization


Public Class DashboardProfileIssue
    Inherits System.Web.UI.Page

    Const LOOKUP_TYPE = "B"
    Const ISSUE_CATE_ISSUE = "ISSUE"
    Const ISSUE_CATE_RISK = "RISK"

    Public Enum PAGE_MODE
        READ = 0
        EDIT = -1
        ADD = 1
    End Enum

    Protected Shared mode As Integer


    Protected profileId As Integer = 0
    Protected fromPg As String = ""
    Protected currentDataVer As String = ""


    'Issue & Risks
    Protected Shared dtIssueCategory As DataTable = Nothing
    Protected Shared dtIssueSeverity As DataTable = Nothing
    Protected Shared dtIssueSta As DataTable = Nothing
    Protected Shared dtIssueTrackStatus As DataTable = Nothing
    Protected Shared dtIssueTag As DataTable = Nothing
    Protected sIssueNo As String = ""
    Protected sIssueParentNo As String = ""
    Protected sIssueCate As String = ""
    Protected sIssueSta As String = ""
    Protected sIssueTag As String = ""

    Protected sIssueOwner As String = ""
    Protected sIssueOwnerIdCard As String = ""
    Protected sIssueSeverity As String = ""
    Protected sIssueProbability As String = ""
    Protected sIssueTrackSta As String = ""

    Protected sIssuedCreatedBy As String = "SYSTEM"

    Protected sIssueTgtStartDate As String = ""
    Protected sIssueTgtEndDate As String = ""
    Protected sIssueActlStartDate As String = ""
    Protected sIssueActlEndDate As String = ""
    Protected sIssueCreatedDate As String = ""

    Protected sIssueDesc As String = ""
    Protected sIssueDescDetail As String = ""
    Protected iIssueActionCnt As Integer = 0

    Protected sIssueActionNo As String = ""
    Protected sIssueActionDesc As String = ""
    Protected sIssueActionDescDetail As String = ""
    Protected sIssueActionSta As String = ""
    Protected sIssueActionOwner As String = ""
    Protected sIssueActionOwnerIdCard As String = ""
    Protected sIssueActionProgress As String = ""
    Protected sIssueActionTgtStartDate As String = ""
    Protected sIssueActionTgtEndDate As String = ""
    Protected sIssueActionActlStartDate As String = ""
    Protected sIssueActionActlEndDate As String = ""

    'Page
    Private isError As Boolean = False
    Public sAlertMsgBuilder As StringBuilder = New StringBuilder("")

    Dim pmaUserService As IPmaUserService = New PmaUserService
    Dim lookupService As ILookupService = New LookupService
    Dim prfService As IProfileService = New ProfileService
    Dim prfIssueService As IProfileIssueService = New ProfileIssueService
    Dim logHelper As LogHelper = New LogHelper



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            If Session("prf_id") Is Nothing Then
                profileId = 0
                Session("prf_id") = profileId
            Else
                profileId = Session("prf_id")
            End If

            If Session("fromPg") Is Nothing Then
                fromPg = "LIST"
                Session("fromPg") = fromPg
            Else
                fromPg = Session("fromPg")
            End If

            If Session("current_data_version") Is Nothing Then
                currentDataVer = Format(Now, "yyyyMMdd")
                Session("current_data_version") = currentDataVer
            Else
                currentDataVer = Session("current_data_version")
            End If

            Session("issue_no") = Nothing
            Session("issue_action_no") = Nothing

            mode = PAGE_MODE.READ

            'Basic Info
            LoadProfileBasic(profileId)

            'Issue
            LoadProfileIssue(profileId)

        End If

    End Sub

#Region "Basic_Info"
    Sub LoadProfileBasic(ByVal profileId As Integer)

        isError = False

        Dim dtProfile As DataTable = prfService.GetProfile(profileId)

        If dtProfile Is Nothing Then
            isError = True
        ElseIf dtProfile.Rows.Count > 0 Then

            Session("prf_main_code") = dtProfile.Rows(0).Item("PRF_MAIN_CODE").ToString.Trim

            Dim sPrfDesc As String = dtProfile.Rows(0).Item("PRF_DESC").ToString.Trim

            Dim prfHidden As HiddenField = New HiddenField
            If Not Me.Master.FindControl("prfDesc") Is Nothing Then
                prfHidden = CType(Me.Master.FindControl("prfDesc"), HiddenField)
                prfHidden.Value = sPrfDesc
            End If

            dtProfile.Dispose()
        End If
    End Sub

#End Region


#Region "Issue_List"
    Sub InitIssueVariables()
        'Issue Category
        If dtIssueCategory Is Nothing Then
            dtIssueCategory = lookupService.GetLookUpList("B", "ISSUECATE")
        End If

        'Issue State
        If dtIssueSta Is Nothing Then
            dtIssueSta = lookupService.GetLookUpList("B", "ISSUESTA")
        End If

        'Issue Severity & Probability
        If dtIssueSeverity Is Nothing Then
            dtIssueSeverity = lookupService.GetLookUpList("B", "SEVERITY")
        End If

        'Issue Track Status
        If dtIssueTrackStatus Is Nothing Then
            dtIssueTrackStatus = lookupService.GetLookUpList("B", "STATUS")
        End If

        'Issue Tag
        If dtIssueTag Is Nothing Then
            dtIssueTag = lookupService.GetLookUpList("B", "ISSUETAG")
        End If

    End Sub

    'View
    Sub LoadProfileIssue(ByVal profileId As Integer)

        Dim dtPrfIssueView As DataTable = prfIssueService.GetProfileIssueListView(profileId)

        'FilterProfileIssue(dtPrfIssueView, "issue_status <> 'C' ")

        If Not dtPrfIssueView Is Nothing Then
            If dtPrfIssueView.Rows.Count > 0 Then
                dtPrfIssueView = dtPrfIssueView.Select("1=1", "issue_status, issue_trace_status, issue_no").CopyToDataTable
            End If

            WebControlHelper.GridViewDataBind(gvIssue, dtPrfIssueView)
        End If

        InitIssueButtons()
    End Sub

    Sub FilterProfileIssue(ByRef dtPrfIssueView As DataTable, ByVal filterString As String)
        If dtPrfIssueView Is Nothing Then
            Return
        End If

        Dim dr As DataRow() = dtPrfIssueView.Select(filterString)
        If dr Is Nothing Then
            dtPrfIssueView = Nothing
        ElseIf dr.Length = 0 Then
            dtPrfIssueView = dtPrfIssueView.Clone
        Else
            dtPrfIssueView = dr.CopyToDataTable
        End If

    End Sub


    Private Sub gvIssue_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvIssue.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim index As Integer = e.Row.RowIndex

            'Dim gvrIssueNo As String = e.Row.Cells(0).Text
            Dim gvrIssueNo As String = gvIssue.DataKeys(index).Item(0).ToString

            If Not String.IsNullOrEmpty(gvrIssueNo) Then
                e.Row.Cells(1).Text = index + 1
                e.Row.Cells(13).Text = prfIssueService.CountOpenProfileIssueAction(gvrIssueNo)
                e.Row.Cells(14).Text = prfIssueService.CountProfileIssueAction(gvrIssueNo)
            End If
        End If

    End Sub


    'Create
    Private Sub btnAddIssue_Click(sender As Object, e As System.EventArgs) Handles btnAddIssue.Click

        mode = PAGE_MODE.ADD
        InitIssueVariables()
        sIssueNo = ""
        Session("issue_no") = Nothing
        Session("issue_action_no") = Nothing

        InitProfileIssueDetail(PAGE_MODE.ADD)

        InitIssueButtons()

    End Sub


    'Edit
    Private Sub gvIssue_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvIssue.RowCommand
        If e.CommandName = "editIssueDetail" Then
            Dim index = Convert.ToInt32(e.CommandArgument)

            Dim gvRow As GridViewRow = CType(e.CommandSource, GridView).Rows(index)

            sIssueNo = gvIssue.DataKeys(index).Item(0).ToString
            Session("issue_no") = sIssueNo
            Session("issue_action_no") = Nothing

            mode = PAGE_MODE.EDIT
            InitIssueVariables()
            InitProfileIssueDetail(PAGE_MODE.EDIT, sIssueNo)
            ddlIssueCate.Enabled = False

            InitIssueButtons()

        End If
    End Sub



    'Handle Button Display
    Private Sub InitIssueButtons()
        btnAddIssueAction.Visible = False

        If mode = PAGE_MODE.EDIT Then
            btnSaveIssue.Text = "Update"
            btnAddIssueAction.Visible = True
        ElseIf mode = PAGE_MODE.ADD Then
            btnSaveIssue.Text = "Create"
        End If
    End Sub




    Private Sub btnViewIssueAction_ServerClick(sender As Object, e As System.EventArgs) Handles btnViewIssueAction.ServerClick
        If mode = PAGE_MODE.EDIT Then
            LoadProfileIssueActions(False)
        End If
    End Sub

    Private Sub btnViewOpenIssueAction_ServerClick(sender As Object, e As System.EventArgs) Handles btnViewOpenIssueAction.ServerClick
        If mode = PAGE_MODE.EDIT Then
            LoadProfileIssueActions(True)
        End If
    End Sub

    Private Sub btnAddIssueAction_Click(sender As Object, e As System.EventArgs) Handles btnAddIssueAction.Click

        sIssueActionNo = ""
        Session("issue_action_no") = Nothing
        InitIssueActionDetail(sIssueActionNo)

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalIssueAction', true);", True)
    End Sub

#End Region

#Region "Issue_Detail"
    Sub InitProfileIssueDetail(ByVal mode As String, Optional ByVal issueNo As String = "")

        DisableTabs(True)

        'Session Issue No
        If String.IsNullOrEmpty(issueNo) Then
            Session("issue_no") = Nothing
        Else
            Session("issue_no") = issueNo
        End If

        'Isse Category
        If Not dtIssueCategory Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlIssueCate, dtIssueCategory, "lookup_name", "lookup_code", False)
        End If
        ddlIssueCate.SelectedValue = ISSUE_CATE_RISK
        ddlIssueCate.Enabled = True

        'Issue State
        If Not dtIssueSta Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlIssueStatus, dtIssueSta, "lookup_name", "lookup_code", False)
        End If
        ddlIssueStatus.Enabled = True

        'IssueSeverity
        If Not dtIssueSeverity Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlIssueSeverity, dtIssueSeverity, "lookup_name", "lookup_code")
            WebControlHelper.DropDownListDataBind(ddlIssueProbability, dtIssueSeverity, "lookup_name", "lookup_code")
        End If
        ddlIssueProbability.Enabled = True

        'Issue Owner
        Dim dtIssueOwner As DataTable = New DataTable
        dtIssueOwner = pmaUserService.GetActiveUserList()
        If Not dtIssueOwner Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlIssueOwner, dtIssueOwner, "display_name", "logon_id")
        End If
        ddlIssueOwner.Enabled = True

        'Issue Track Status
        If Not dtIssueTrackStatus Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlIssueTrackStatus, dtIssueTrackStatus, "lookup_name", "lookup_code")
        End If
        ddlIssueTrackStatus.Enabled = True

        'Issue Tag
        If Not dtIssueTag Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlIssueTag, dtIssueTag, "lookup_name", "lookup_code")
        End If
        ddlIssueTag.Enabled = True


        lblIssueNo.Text = ""

        txtIssueDesc.Value = ""
        txtIssueDesc.Attributes.Remove("readonly")
        txtIssueDescDetail.Value = ""
        sIssueDesc = ""
        sIssueDescDetail = ""


        'Date
        sIssueCreatedDate = Format(Now, Session("date_format"))
        sIssueTgtStartDate = ""
        sIssueTgtEndDate = ""
        sIssueActlStartDate = ""
        sIssueActlEndDate = ""
        txtIssueActlEndDt.Text = ""
        txtIssueActlEndDt.Attributes.Add("readonly", True)

        'Action
        lblIssueActionCnt.InnerText = 0
        lblIssueOpenActionCnt.InnerText = 0
        gvIssueActionList.DataSource = Nothing

        If mode = PAGE_MODE.EDIT Then
            Dim dtIssue As DataTable = prfIssueService.GetProfileIssue(sIssueNo)
            If Not dtIssue Is Nothing Then
                If dtIssue.Rows.Count > 0 Then
                    Dim drIssue As DataRow = dtIssue.Rows(0)

                    lblIssueNo.Text = sIssueNo

                    sIssueDesc = drIssue("issue_desc_short").ToString
                    txtIssueDesc.Value = drIssue("issue_desc_short").ToString
                    sIssueDescDetail = drIssue("issue_desc_long").ToString
                    txtIssueDescDetail.Value = drIssue("issue_desc_long").ToString
                    txtIssueParentNo.Text = drIssue("parent_issue_no").ToString
                    ddlIssueCate.SelectedValue = drIssue("issue_category").ToString
                    ddlIssueTag.SelectedValue = drIssue("issue_tag").ToString
                    ddlIssueStatus.SelectedValue = drIssue("issue_status").ToString

                    If Not IsDBNull(drIssue("issue_owner")) Then
                        If Not DataFormatHelper.StringTrim(drIssue("issue_owner").ToString) = "" Then
                            ddlIssueOwner.SelectedValue = DataFormatHelper.StringTrim(drIssue("issue_owner").ToString)
                            'ddlIssueOwner.Enabled = False
                        End If
                    End If

                    If Not IsDBNull(drIssue("issue_severity")) Then
                        If DataFormatHelper.StringTrim(drIssue("issue_severity").ToString) <> "" Then
                            ddlIssueSeverity.SelectedValue = DataFormatHelper.StringTrim(drIssue("issue_severity").ToString)
                        End If
                    End If


                    If Not IsDBNull(drIssue("issue_trace_status")) Then
                        ddlIssueTrackStatus.SelectedValue = DataFormatHelper.StringTrim(drIssue("issue_trace_status").ToString)
                    End If

                    If ddlIssueCate.SelectedValue = ISSUE_CATE_RISK Then
                        ddlIssueProbability.SelectedValue = drIssue("issue_probability").ToString
                    End If


                    If Not IsDBNull(drIssue("issue_est_start_dt")) And IsDate(drIssue("issue_est_start_dt")) Then
                        sIssueTgtStartDate = Format(drIssue("issue_est_start_dt"), Session("date_format"))
                    End If
                    If Not IsDBNull(drIssue("issue_est_end_dt")) And IsDate(drIssue("issue_est_end_dt")) Then
                        sIssueTgtEndDate = Format(drIssue("issue_est_end_dt"), Session("date_format"))
                    End If
                    If Not IsDBNull(drIssue("issue_actl_start_dt")) And IsDate(drIssue("issue_actl_start_dt")) Then
                        sIssueActlStartDate = Format(drIssue("issue_actl_start_dt"), Session("date_format"))
                    End If
                    If Not IsDBNull(drIssue("issue_actl_end_dt")) And IsDate(drIssue("issue_actl_end_dt")) Then
                        txtIssueActlEndDt.Text = Format(drIssue("issue_actl_end_dt"), Session("date_format"))
                    End If

                    sIssueCreatedDate = Format(drIssue("created_dt"), Session("date_format"))

                    If drIssue("CREATED_BY") = "SYSTEM" Then
                        ddlIssueTag.Enabled = False
                    End If

                    'Action Count
                    lblIssueActionCnt.InnerText = prfIssueService.CountProfileIssueAction(sIssueNo)
                    lblIssueOpenActionCnt.InnerText = prfIssueService.CountOpenProfileIssueAction(sIssueNo)

                    'Actions
                    LoadProfileIssueActions(False)
                End If
            End If
        End If
    End Sub

    'Save Issue (both create & edit)
    Protected Sub btnSaveIssueClick()

        sIssueCate = ddlIssueCate.SelectedValue


        sIssueDesc = Trim(txtIssueDesc.Value)
        sIssueDescDetail = Trim(txtIssueDescDetail.Value)
        sIssueParentNo = DataFormatHelper.StringTrim(txtIssueParentNo.Text)
        sIssueTag = ddlIssueTag.SelectedValue

        sIssueSta = ddlIssueStatus.SelectedValue
        sIssueOwner = ddlIssueOwner.SelectedValue
        sIssueOwnerIdCard = pmaUserService.GetActiveUserIdCardByLogonId(sIssueOwner)
        sIssueSeverity = ddlIssueSeverity.SelectedValue
        If sIssueCate = ISSUE_CATE_RISK Then
            sIssueProbability = ddlIssueProbability.SelectedValue
        End If

        sIssueTrackSta = ddlIssueTrackStatus.SelectedValue

        sIssueActlEndDate = Trim(txtIssueActlEndDt.Text)

        If mode = PAGE_MODE.ADD Then
            Dim issueNo As String = prfIssueService.GetNewIssueNo(sIssueCate)
            sIssueNo = ddlIssueCate.SelectedValue & "-" & issueNo
        End If

        If SaveIssue(Session("prf_id")) Then

            'bPageDirty = True

            If mode = PAGE_MODE.ADD Then
                sAlertMsgBuilder = New StringBuilder("Create successfully.")

                mode = PAGE_MODE.EDIT

                ddlIssueCate.Enabled = False
                btnSaveIssue.Text = "Update"
                btnAddIssueAction.Visible = True
                lblIssueNo.Text = sIssueNo

            ElseIf mode = PAGE_MODE.EDIT Then
                sAlertMsgBuilder = New StringBuilder("Update successfully.")
            End If
            Session("issue_no") = sIssueNo

            InitProfileIssueDetail(PAGE_MODE.EDIT, sIssueNo)
        Else
            If mode = PAGE_MODE.ADD Then
                sAlertMsgBuilder = New StringBuilder("Oops, failed to create " & sIssueCate & ".")
            ElseIf mode = PAGE_MODE.EDIT Then
                sAlertMsgBuilder = New StringBuilder("Oops, failed to update " & sIssueCate & ".")
            End If

        End If

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "popUpMsg();", True)

    End Sub


    Private Function SaveIssue(ByVal profileId As Integer) As Boolean
        Dim drIssue As DataRow

        If Not Session("issue_no") Is Nothing Then
            sIssueNo = Session("issue_no")
        End If


        Dim dtIssue As DataTable = prfIssueService.GetProfileIssue(sIssueNo)

        If dtIssue Is Nothing Then
            Return False
        ElseIf dtIssue.Rows.Count = 0 Then
            drIssue = dtIssue.NewRow
        Else
            drIssue = dtIssue.Rows(0)
        End If

        drIssue("issue_no") = sIssueNo
        drIssue("issue_category") = sIssueCate
        drIssue("issue_desc_short") = sIssueDesc
        drIssue("issue_desc_long") = sIssueDescDetail
        drIssue("parent_issue_no") = sIssueParentNo
        drIssue("issue_status") = sIssueSta


        drIssue("issue_owner") = sIssueOwner
        drIssue("issue_owner_id_card") = sIssueOwnerIdCard
        drIssue("issue_trace_status") = sIssueTrackSta

        drIssue("issue_severity") = sIssueSeverity
        If sIssueCate = ISSUE_CATE_RISK Then
            drIssue("issue_probability") = sIssueProbability
        End If

        drIssue("issue_tag") = sIssueTag
        'If IsDate(sIssueTgtStartDate) Then
        '    drIssue("issue_est_start_dt") = sIssueTgtStartDate
        'Else
        '    drIssue("issue_est_start_dt") = DBNull.Value
        'End If
        'If IsDate(sIssueTgtEndDate) Then
        '    drIssue("issue_est_end_dt") = sIssueTgtEndDate
        'Else
        '    drIssue("issue_est_end_dt") = DBNull.Value
        'End If
        'If IsDate(sIssueActlStartDate) Then
        '    drIssue("issue_actl_start_dt") = sIssueActlStartDate
        'Else
        '    drIssue("issue_actl_start_dt") = DBNull.Value
        'End If
        If IsDate(sIssueActlEndDate) Then
            drIssue("issue_actl_end_dt") = sIssueActlEndDate
        ElseIf sIssueSta = ISSUE_STAUS.CLOSED Then
            drIssue("issue_actl_end_dt") = Today
        Else
            drIssue("issue_actl_end_dt") = DBNull.Value
        End If


        drIssue("prf_id") = profileId
        drIssue("prj_code") = Trim(Session("prf_main_code"))



        drIssue("last_updated_by") = Session("logon_id")
        drIssue("last_updated_dt") = Now


        If mode = PAGE_MODE.ADD Then
            drIssue("created_by") = Session("logon_id")
            drIssue("created_dt") = Now

            dtIssue.Rows.Add(drIssue)

        End If

        SaveIssue = prfIssueService.SaveProfileIssue(dtIssue)

    End Function

    'Back to Read mode
    Private Sub btnCancelIssue_Click(sender As Object, e As System.EventArgs) Handles btnCancelIssue.Click
        mode = PAGE_MODE.READ
        LoadProfileIssue(Session("prf_id"))

        DisableTabs(False)
    End Sub
#End Region

#Region "Action_List"
    Sub LoadProfileIssueActions(ByVal openAction As Boolean)
        Dim dtPrfIssueAction As DataTable = New DataTable

        If Not Session("issue_no") Is Nothing Then
            sIssueNo = Session("issue_no")
        End If
        dtPrfIssueAction = prfIssueService.GetProfileIssueActionView(sIssueNo, openAction)

        If Not dtPrfIssueAction Is Nothing Then
            If dtPrfIssueAction.Rows.Count > 0 Then
                dtPrfIssueAction = dtPrfIssueAction.Select("1=1", "issue_status, issue_trace_status, issue_no").CopyToDataTable
            End If
            WebControlHelper.GridViewDataBind(gvIssueActionList, dtPrfIssueAction)
        End If

        InitIssueButtons()

    End Sub

    Private Sub gvIssueActionList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvIssueActionList.RowDataBound
        Dim index As Integer = e.Row.RowIndex

        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(1).Text = index + 1
        End If
    End Sub

    Private Sub gvIssueActionList_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvIssueActionList.RowCommand
        If e.CommandName = "editIssueActionDetail" Then
            Dim index = Convert.ToInt32(e.CommandArgument)

            Dim gvRow As GridViewRow = CType(e.CommandSource, GridView).Rows(index)

            sIssueActionNo = gvIssueActionList.DataKeys(index).Item(0).ToString
            Session("issue_action_no") = sIssueActionNo
            InitIssueActionDetail(sIssueActionNo)

            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalIssueAction', true);", True)
        End If
    End Sub


#End Region

#Region "Action_Detail"
    Private Sub InitIssueActionDetail(ByVal sIssueActionNo As String)
        sIssueActionDesc = ""
        sIssueActionDescDetail = ""

        sIssueActionSta = ISSUE_STAUS.OPEN
        If dtIssueSta Is Nothing Then
            dtIssueSta = lookupService.GetLookUpList("B", "ISSUESTA")
        End If
        If Not dtIssueSta Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlIssueActionSta, dtIssueSta, "lookup_name", "lookup_code", False)
        End If

        sIssueActionOwner = ""
        sIssueActionOwnerIdCard = ""
        Dim dtIssueActionOwner As DataTable = New DataTable
        dtIssueActionOwner = pmaUserService.GetActiveUserList()
        If Not dtIssueActionOwner Is Nothing Then
            WebControlHelper.DropDownListDataBind(ddlIssueActionOwner, dtIssueActionOwner, "display_name", "logon_id")
        End If
        ddlIssueActionOwner.Enabled = True

        sIssueActionProgress = ""

        sIssueActionTgtEndDate = ""
        sIssueActionActlEndDate = ""
        sIssueActionTgtStartDate = ""
        sIssueActionActlStartDate = ""

        If Not String.IsNullOrEmpty(sIssueActionNo) Then
            Session("issue_action_no") = sIssueActionNo
            Dim dtIssueAction As DataTable = prfIssueService.GetProfileIssue(sIssueActionNo)
            If Not dtIssueAction Is Nothing Then
                If dtIssueAction.Rows.Count > 0 Then
                    sIssueActionDesc = dtIssueAction(0).Item("issue_desc_short").ToString
                    sIssueActionDescDetail = dtIssueAction(0).Item("issue_desc_long").ToString

                    If Not IsDBNull(dtIssueAction(0).Item("issue_status")) Then
                        sIssueActionSta = dtIssueAction(0).Item("issue_status").ToString.Trim
                    End If

                    If Not IsDBNull(dtIssueAction(0).Item("issue_owner")) Then
                        sIssueActionOwner = dtIssueAction(0).Item("issue_owner").ToString
                        sIssueActionOwnerIdCard = dtIssueAction(0).Item("issue_owner_id_card").ToString
                    End If

                    If IsNumeric(dtIssueAction(0).Item("issue_progress")) Then
                        sIssueActionProgress = DataFormatHelper.FormatString(dtIssueAction(0).Item("issue_progress").ToString, "P", 2)
                        If sIssueActionProgress.EndsWith("%") Then
                            sIssueActionProgress = sIssueActionProgress.Replace("%", "")
                        End If
                    End If

                    If Not IsDBNull(dtIssueAction(0).Item("issue_est_end_dt")) Then
                        sIssueActionTgtEndDate = dtIssueAction(0).Item("issue_est_end_dt")
                    End If
                    If Not IsDBNull(dtIssueAction(0).Item("issue_actl_end_dt")) Then
                        sIssueActionActlEndDate = dtIssueAction(0).Item("issue_actl_end_dt")
                    End If

                    If Not IsDBNull(dtIssueAction(0).Item("issue_est_start_dt")) Then
                        sIssueActionTgtStartDate = dtIssueAction(0).Item("issue_est_start_dt")
                    End If
                    If Not IsDBNull(dtIssueAction(0).Item("issue_actl_start_dt")) Then
                        sIssueActionActlStartDate = dtIssueAction(0).Item("issue_actl_start_dt")
                    End If
                End If
            End If
        End If


        txtIssueAction.Text = sIssueActionDesc
        txtIssueActionDetail.Text = sIssueActionDescDetail

        txtIssueActionProgress.Value = sIssueActionProgress
        ddlIssueActionSta.SelectedValue = sIssueActionSta
        ddlIssueActionOwner.SelectedValue = sIssueActionOwner

        txtIssueActionTgtStartDt.Text = sIssueActionTgtStartDate
        txtIssueActionActlStartDt.Text = sIssueActionActlStartDate

        txtIssueActionTgtEndDt.Text = sIssueActionTgtEndDate
        txtIssueActionActlEndDt.Text = sIssueActionActlEndDate

        txtIssueActionTgtStartDt.Attributes.Add("readonly", True)
        txtIssueActionTgtEndDt.Attributes.Add("readonly", True)

        txtIssueActionActlStartDt.Attributes.Add("readonly", True)
        txtIssueActionActlEndDt.Attributes.Add("readonly", True)


    End Sub

    Private Sub btnSaveIssueAction_Click(sender As Object, e As System.EventArgs) Handles btnSaveIssueAction.Click
        sIssueActionDesc = Trim(txtIssueAction.Text)
        sIssueActionDescDetail = DataFormatHelper.StringTrim(txtIssueActionDetail.Text)

        profileId = Session("prf_id")
        sIssueNo = Session("issue_no")
        sIssueActionNo = Session("issue_action_no")

        Dim dtIssue As DataTable = New DataTable
        Dim dtIssueAction As DataTable = New DataTable
        Dim drIssueAction As DataRow
        Dim sIssueActionSta As String = ISSUE_STAUS.OPEN
        Dim sIssueActionStaBefore As String = ""
        Dim bNew As Boolean = False
        Dim bUpdIssue As Boolean = False
        Dim bSaveAction As Boolean = False

        Dim dIssueEstStartDtExcMe As Nullable(Of Date)
        Dim dIssueEstEndDtExcMe As Nullable(Of Date)
        Dim dIssueActlStartDtExcMe As Nullable(Of Date) = Nothing
        Dim dIssueActlEndDtExcMe As Nullable(Of Date) = Nothing

        dtIssue = prfIssueService.GetProfileIssue(sIssueNo)

        If String.IsNullOrEmpty(sIssueActionNo) Then
            dtIssueAction = prfIssueService.GetProfileIssueList(False)
            If IsDate(dtIssue.Rows(0).Item("issue_est_start_dt")) Then
                dIssueEstStartDtExcMe = dtIssue.Rows(0).Item("issue_est_start_dt")
            End If
            If IsDate(dtIssue.Rows(0).Item("issue_est_end_dt")) Then
                dIssueEstEndDtExcMe = dtIssue.Rows(0).Item("issue_est_end_dt")
            End If
            If IsDate(dtIssue.Rows(0).Item("issue_actl_start_dt")) Then
                dIssueActlStartDtExcMe = dtIssue.Rows(0).Item("issue_actl_start_dt")
            End If
            If IsDate(dtIssue.Rows(0).Item("issue_actl_end_dt")) Then
                dIssueActlEndDtExcMe = dtIssue.Rows(0).Item("issue_actl_end_dt")
            End If
            bNew = True
        Else
            dtIssueAction = prfIssueService.GetProfileIssue(sIssueActionNo)

            dIssueEstStartDtExcMe = prfIssueService.CalculateProfileIssueDate(profileId, sIssueNo, sIssueActionNo, ISSUE_DATE_TYPE.TARGET_START_DATE)
            dIssueEstEndDtExcMe = prfIssueService.CalculateProfileIssueDate(profileId, sIssueNo, sIssueActionNo, ISSUE_DATE_TYPE.TARGET_END_DATE)
            dIssueActlStartDtExcMe = prfIssueService.CalculateProfileIssueDate(profileId, sIssueNo, sIssueActionNo, ISSUE_DATE_TYPE.ACTUAL_START_DATE)
            dIssueActlEndDtExcMe = prfIssueService.CalculateProfileIssueDate(profileId, sIssueNo, sIssueActionNo, ISSUE_DATE_TYPE.ACTUAL_END_DATE)
        End If

        Try
            If String.IsNullOrEmpty(sIssueActionNo) Then
                drIssueAction = dtIssueAction.NewRow
                sIssueActionNo = sIssueNo & "_" & (lblIssueActionCnt.InnerText + 1)
                drIssueAction("issue_no") = sIssueActionNo
                drIssueAction("parent_issue_no") = sIssueNo
                drIssueAction("prj_code") = Trim(Session("prf_main_code"))
                drIssueAction("prf_id") = profileId
                drIssueAction("issue_category") = ddlIssueCate.SelectedValue

                drIssueAction("created_by") = Session("logon_id")
                drIssueAction("created_dt") = Now
            Else
                drIssueAction = dtIssueAction.Rows(0)
                sIssueActionStaBefore = drIssueAction("issue_status")
            End If


            drIssueAction("issue_desc_short") = Trim(sIssueActionDesc)
            drIssueAction("issue_desc_long") = Trim(sIssueActionDescDetail)

            sIssueActionSta = ddlIssueActionSta.SelectedValue
            drIssueAction("issue_status") = ddlIssueActionSta.SelectedValue
            drIssueAction("issue_owner") = ddlIssueActionOwner.SelectedValue
            drIssueAction("issue_owner_id_card") = pmaUserService.GetActiveUserIdCardByLogonId(ddlIssueActionOwner.SelectedValue)

            If IsNumeric(txtIssueActionProgress.Value) Then
                sIssueActionProgress = txtIssueActionProgress.Value.Trim
                If IsNumeric(sIssueActionProgress) Then
                    drIssueAction("issue_progress") = sIssueActionProgress / 100
                End If
            End If

            sIssueActionTgtStartDate = txtIssueActionTgtStartDt.Text
            If IsDate(sIssueActionTgtStartDate) Then
                drIssueAction("issue_est_start_dt") = sIssueActionTgtStartDate
            Else
                drIssueAction("issue_est_start_dt") = DBNull.Value
            End If

            sIssueActionTgtEndDate = txtIssueActionTgtEndDt.Text
            If IsDate(sIssueActionTgtEndDate) Then
                drIssueAction("issue_est_end_dt") = sIssueActionTgtEndDate
            Else
                drIssueAction("issue_est_end_dt") = DBNull.Value
            End If

            sIssueActionActlStartDate = txtIssueActionActlStartDt.Text
            If IsDate(sIssueActionActlStartDate) Then
                drIssueAction("issue_actl_start_dt") = sIssueActionActlStartDate
            Else
                drIssueAction("issue_actl_start_dt") = DBNull.Value
            End If

            sIssueActionActlEndDate = txtIssueActionActlEndDt.Text
            If IsDate(sIssueActionActlEndDate) Then
                drIssueAction("issue_actl_end_dt") = sIssueActionActlEndDate
            ElseIf ddlIssueActionSta.SelectedValue = ISSUE_STAUS.CLOSED Or ddlIssueActionSta.SelectedValue = ISSUE_STAUS.CANCELLED Then
                drIssueAction("issue_actl_end_dt") = Today
            Else
                drIssueAction("issue_actl_end_dt") = DBNull.Value
            End If

            drIssueAction("last_updated_by") = Session("logon_id")
            drIssueAction("last_updated_dt") = Now

            'Update Issue Start Date
            If sIssueActionSta = ISSUE_STAUS.CANCELLED Then
                dtIssue.Rows(0).Item("issue_est_start_dt") = IIf(dIssueEstStartDtExcMe.HasValue, dIssueEstStartDtExcMe, DBNull.Value)
                dtIssue.Rows(0).Item("issue_est_end_dt") = IIf(dIssueEstEndDtExcMe.HasValue, dIssueEstEndDtExcMe, DBNull.Value)
                dtIssue.Rows(0).Item("issue_actl_start_dt") = IIf(dIssueActlStartDtExcMe.HasValue, dIssueActlStartDtExcMe, DBNull.Value)
                bUpdIssue = True
            End If

            If Not sIssueActionSta = ISSUE_STAUS.CANCELLED Then
                If Not dIssueEstStartDtExcMe.HasValue And IsDate(sIssueActionTgtStartDate) Then
                    dtIssue.Rows(0).Item("issue_est_start_dt") = drIssueAction("issue_est_start_dt")
                    bUpdIssue = True
                ElseIf dIssueEstStartDtExcMe.HasValue And IsDate(sIssueActionTgtStartDate) Then
                    If dIssueEstStartDtExcMe > drIssueAction("issue_est_start_dt") Then
                        dtIssue.Rows(0).Item("issue_est_start_dt") = drIssueAction("issue_est_start_dt")
                        bUpdIssue = True
                    End If
                Else
                    dtIssue.Rows(0).Item("issue_est_start_dt") = IIf(dIssueEstStartDtExcMe.HasValue, dIssueEstStartDtExcMe, DBNull.Value)
                End If

                If Not dIssueEstEndDtExcMe.HasValue And IsDate(sIssueActionTgtEndDate) Then
                    dtIssue.Rows(0).Item("issue_est_end_dt") = drIssueAction("issue_est_end_dt")
                    bUpdIssue = True
                ElseIf dIssueEstEndDtExcMe.HasValue And IsDate(sIssueActionTgtEndDate) Then
                    If dIssueEstEndDtExcMe < drIssueAction("issue_est_end_dt") Then
                        dtIssue.Rows(0).Item("issue_est_end_dt") = drIssueAction("issue_est_end_dt")
                        bUpdIssue = True
                    End If
                Else
                    dtIssue.Rows(0).Item("issue_est_end_dt") = IIf(dIssueEstEndDtExcMe.HasValue, dIssueEstEndDtExcMe, DBNull.Value)
                    bUpdIssue = True
                End If

                If Not dIssueActlStartDtExcMe.HasValue And IsDate(sIssueActionActlStartDate) Then
                    dtIssue.Rows(0).Item("issue_actl_start_dt") = drIssueAction("issue_actl_start_dt")
                    bUpdIssue = True
                ElseIf dIssueActlStartDtExcMe.HasValue And IsDate(sIssueActionActlStartDate) Then
                    If dIssueActlStartDtExcMe > drIssueAction("issue_actl_start_dt") Then
                        dtIssue.Rows(0).Item("issue_actl_start_dt") = drIssueAction("issue_actl_start_dt")
                        bUpdIssue = True
                    End If
                Else
                    dtIssue.Rows(0).Item("issue_actl_start_dt") = IIf(dIssueActlStartDtExcMe.HasValue, dIssueActlStartDtExcMe, DBNull.Value)
                    bUpdIssue = True
                End If

            End If

            If bUpdIssue Then
                dtIssue.Rows(0).Item("last_updated_by") = Session("logon_id")
                dtIssue.Rows(0).Item("last_updated_dt") = Now
            End If

            If bNew Then
                dtIssueAction.Rows.Add(drIssueAction)
            End If

            If bUpdIssue Then
                bSaveAction = prfIssueService.SaveProfileIssueAndAction(dtIssue, dtIssueAction)
            Else
                bSaveAction = prfIssueService.SaveProfileIssue(dtIssueAction)
            End If

            If bSaveAction Then

                If bNew Then
                    lblIssueActionCnt.InnerText = lblIssueActionCnt.InnerText + 1
                End If

                InitIssueVariables()
                InitProfileIssueDetail(PAGE_MODE.EDIT, sIssueNo)
                ddlIssueCate.Enabled = False


                Session("issue_action_no") = sIssueActionNo

                InitIssueButtons()
            Else
                sAlertMsgBuilder = New StringBuilder("Oops, failed to edit action.")
            End If
        Catch ex As Exception
            logHelper.WriteLog("failed to save issue action for:" & sIssueActionNo, ex)
        End Try
    End Sub
#End Region

#Region "NavTab_Navigation"

    Sub DisableTabs(ByVal disabled As Boolean)
        navTabPreview.Disabled = disabled
    End Sub

    Sub PrepareNavigationParams()
        dtIssueCategory = Nothing
        dtIssueSeverity = Nothing
        dtIssueSta = Nothing
        dtIssueTrackStatus = Nothing
        dtIssueTag = Nothing

        Session("issue_no") = Nothing
        Session("issue_action_no") = Nothing
        Session("prf_main_code") = Nothing
        Session("current_data_version") = Nothing
    End Sub




    Private Sub navTabIssue_ServerClick(sender As Object, e As System.EventArgs) Handles navTabIssue.ServerClick
    End Sub

    Private Sub navTabPreview_ServerClick(sender As Object, e As System.EventArgs) Handles navTabPreview.ServerClick
        PrepareNavigationParams()

        Session("dataVersion") = Format(Now, "yyyyMMdd")
        Server.Transfer("ProfilePreview.aspx")
    End Sub
#End Region








End Class