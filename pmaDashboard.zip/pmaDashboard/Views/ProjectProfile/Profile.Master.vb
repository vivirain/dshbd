﻿Imports System.IO

Public Class Profile
    Inherits System.Web.UI.MasterPage

    Shared profileId As Integer = 0

    Dim sbMenu As StringBuilder = New StringBuilder("")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    End Sub



    Private Sub navTabHealthSta_ServerClick(sender As Object, e As System.EventArgs) Handles navTabHealthSta.ServerClick
        Server.Transfer("ProfileHealthTab.aspx")
    End Sub


End Class