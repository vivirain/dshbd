﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO


Public Class ProfileList
    Inherits System.Web.UI.Page

    Protected dtProfile As DataTable = Nothing
    Protected dtProfileResult As DataTable = Nothing

    Protected userRoles As String() = Nothing

    Protected dataVersion As String = ""
    Protected sHealthSta As String = ""

    Protected totalRecords As Integer = 0
    Public iPage As Integer
    Public sAlertMsg As StringBuilder = New StringBuilder("")

    'Page
    Protected currentSortExpression As String = ""
    Protected currentSortDirection As String = ""

    Dim prfService As IProfileService = New ProfileService
    Dim prjMetricService As IProjectMetricService = New ProjectMetricService
    Dim prjMetricRawService As IProjectMetricRawService = New ProjectMetricRawService

    Dim pmaTssPrjService As IPmaTssProjectService = New PmaTssProjectService
    Dim pmaTeamService As IPmaTeamService = New PmaTeamService
    Dim pmaBizUnitService As IPmaBizUnitService = New PmaBizUnitService
    Dim pmaUserService As IPmaUserService = New PmaUserService

    Dim excelHelper As ExcelHelper = New ExcelHelper
    Dim logHelper As LogHelper = New LogHelper

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Session("userRoles") Is Nothing Then
            userRoles = Session("userRoles").ToString.Split(",")
        End If

        If Not Page.IsPostBack Then

            txtDataReloadDt.Attributes.Add("readonly", True)
            ddlSBU.Enabled = False

            currentSortExpression = ""
            currentSortDirection = ""

            sHealthSta = HttpContext.Current.Items("healthSta")

            BindSearchDropDown()

            btnQueryClick()

        End If


    End Sub


#Region "Search_Section_Data"
    Sub BindSearchDropDown()
        'Function
        ddlFunc.Items.Clear()
        BindFunction()

        'SBU
        ddlSBU.Items.Clear()
        BindSBU()

        'TSS Service Category
        ddlTssPrj.Items.Clear()
        Dim dtTssPrj As DataTable = New DataTable("TssPrj")
        dtTssPrj = pmaTssPrjService.GetTssProjectFilterList()
        If Not dtTssPrj Is Nothing Then
            If dtTssPrj.Rows.Count > 1 Then
                dtTssPrj = dtTssPrj.Select("1=1", "display_name").CopyToDataTable
            End If
            WebControlHelper.DropDownListDataBind(ddlTssPrj, dtTssPrj, "display_name", "CODE")

        End If

        'Business Unit
        Dim dtBU As DataTable = New DataTable("BU")
        dtBU = pmaBizUnitService.getBizUnitFilterList(PROFILESTATUS.SUBMITTED)
        If Not dtBU Is Nothing Then
            If dtBU.Rows.Count > 0 Then
                dtBU = dtBU.Select("1=1", "display_name").CopyToDataTable
            End If
            WebControlHelper.ListBoxDataBind(lbBU, dtBU, "display_name", "BU_CODE")

            If dtBU.Rows.Count = 1 Then
                lbBU.SelectedValue = dtBU.Rows(0).Item("bu_code").ToString
            End If
        End If

    End Sub

    Sub BindFunction()
        Dim dtFunc As DataTable = New DataTable

        Dim bLoadAllFunction As Boolean = False

        If userRoles Is Nothing Then
            Return
        End If

            If userRoles.Length > 0 Then
                If userRoles.Contains(DASHBORADROLES.ADM) Or userRoles.Contains(DASHBORADROLES.AM) Or userRoles.Contains(DASHBORADROLES.EXCO) Or userRoles.Contains(DASHBORADROLES.GM) Or userRoles.Contains(DASHBORADROLES.QAG) Then
                    bLoadAllFunction = True
                End If

                If bLoadAllFunction Then
                    dtFunc = pmaTeamService.GetFunctionList
                ElseIf userRoles.Contains(DASHBORADROLES.FH) Then
                    dtFunc = pmaTeamService.GetMyFunction(Session("logon_Id"), Session("id_card"), Session("team_code"))
                Else
                    dtFunc = pmaTeamService.GetTeam(Session("team_code"), TEAMLEVEL.FUNC)
                End If
            End If

        If dtFunc Is Nothing Then
            Return
        ElseIf dtFunc.Rows.Count <= 0 Then
            Return
        End If

                If dtFunc.Rows.Count = 1 Then
                    WebControlHelper.DropDownListDataBind(ddlFunc, dtFunc, "display_name", "TEAM_CODE", False)
                    ddlFunc.SelectedValue = dtFunc.Rows(0).Item("team_code")
                ElseIf dtFunc.Rows.Count > 1 Then
                    dtFunc = dtFunc.Select(" 1 = 1 ", "display_name").CopyToDataTable
                    WebControlHelper.DropDownListDataBind(ddlFunc, dtFunc, "display_name", "TEAM_CODE")
                End If
    End Sub

    Sub BindSBU()
        If ddlFunc Is Nothing Then
            Return
        ElseIf String.IsNullOrEmpty(ddlFunc.SelectedValue) Then
            Return
        ElseIf userRoles Is Nothing Then
            Return
        End If

        'SBU
        Dim dtSBU As DataTable = New DataTable("SBU")
        Dim bLoadAllSBU As Boolean = False

        For i As Integer = 0 To userRoles.Length - 1
            If Not String.IsNullOrEmpty(userRoles(i)) Then
                Dim userRole As Integer = CInt(userRoles(i))
                If userRole <> DASHBORADROLES.PM And userRole <> DASHBORADROLES.TL And userRole <> DASHBORADROLES.SBUH Then
                    bLoadAllSBU = True
                    Exit For
                End If
            End If
        Next

        If bLoadAllSBU Then
            dtSBU = pmaTeamService.GetSubTeamList(ddlFunc.SelectedValue, TEAMLEVEL.SBU)
        Else
            dtSBU = pmaTeamService.GetMySBU(ddlFunc.SelectedValue, Session("logon_id"), Session("id_card"), Session("team_code"))
        End If 'End If bLoadAllBU

        If dtSBU Is Nothing Then
            Return
        ElseIf dtSBU.Rows.Count <= 0 Then
            Return
        End If

        If dtSBU.Rows.Count = 1 Then
            WebControlHelper.DropDownListDataBind(ddlSBU, dtSBU, "display_name", "TEAM_CODE", False)
            ddlSBU.SelectedValue = dtSBU.Rows(0).Item("team_code")
        Else
            dtSBU = dtSBU.Select("1=1", "display_name").CopyToDataTable
            WebControlHelper.DropDownListDataBind(ddlSBU, dtSBU, "display_name", "TEAM_CODE")
            ddlSBU.Enabled = True
        End If
    End Sub
#End Region

#Region "Search_Section_Buttons"

    Private Sub btnCreate_Click(sender As Object, e As System.EventArgs) Handles btnCreate.Click

        Session("prf_id") = 0
        Session("fromPg") = "LIST"
        Session("current_data_version") = Format(Now, "yyyyMMdd")

        Server.Transfer("ProfileBasicTab.aspx")
    End Sub

    Public Sub btnQueryClick()
        Try
            QueryData()
        Catch ex As Exception
            sAlertMsg = New StringBuilder("Oops, failed to query profiles.")
            logHelper.WriteLog(Session("logon_id") & " failed to query profiles.", ex)
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "popUpMsg();", True)
        End Try
    End Sub


    Private Sub btnExport_Click(sender As Object, e As System.EventArgs) Handles btnExport.Click
        'Dim s As String = System.IO.Path.GetTempFileName()
        Dim fileName As String = "Profile_" & Format(Now, "yyyyMMddHHmmss") & ".xlsx"
        Dim bExportAll As Boolean = True

        Try
            For i As Integer = 0 To gvPrjProfile.Rows.Count - 1
                Dim cbPrf As CheckBox = New CheckBox
                If Not gvPrjProfile.Rows(i).FindControl("cbPrf") Is Nothing Then
                    cbPrf = CType(gvPrjProfile.Rows(i).FindControl("cbPrf"), CheckBox)
                    If cbPrf.Checked Then
                        bExportAll = False
                    End If
                End If

                If Not bExportAll Then
                    Exit For
                End If
            Next

            If bExportAll Then
                Dim bAllowPaging As Boolean = gvPrjProfile.AllowPaging
                Dim iPageIndex As Integer = 0
                If bAllowPaging Then
                    iPageIndex = gvPrjProfile.PageIndex
                End If

                gvPrjProfile.AllowPaging = False
                QueryData()
                ExportToExcel(fileName, True)

                gvPrjProfile.AllowPaging = bAllowPaging
                QueryData()
                If bAllowPaging Then
                    gvPrjProfile.PageIndex = iPageIndex
                End If

            Else
                ExportToExcel(fileName, False)
            End If

            logHelper.WriteLog(Session("logon_id") & " exported profile successfully.")
        Catch ex As Exception
            logHelper.WriteLog("btnExport_Click failed", ex)
            sAlertMsg = New StringBuilder("Oops, failed to export profiles.")
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "popUpMsg();", True)
        End Try

    End Sub

    Function ObsoleteProfileHist() As Boolean
        Dim dtProfileHist As DataTable = New DataTable
        Dim dtProfileObsolete As DataTable = New DataTable

        dtProfileHist = prfService.GetProfileHistList(dataVersion, True)
        Dim dtProfileHistPk As DataColumn() = {dtProfileHist.Columns("prf_id"), dtProfileHist.Columns("data_version")}
        dtProfileHist.PrimaryKey = dtProfileHistPk

        dtProfileObsolete = prfService.GetProfileList()
        Dim dtProfileObsoltePks As DataColumn() = {dtProfileHist.Columns("prf_id")}
        dtProfileObsolete.PrimaryKey = dtProfileObsoltePks

        For iRow As Integer = 0 To gvPrjProfile.Rows.Count - 1
            Dim cbPrf As CheckBox = gvPrjProfile.Rows(iRow).FindControl("cbPrf")
            Dim gvRowPrfId As Integer = gvPrjProfile.DataKeys(iRow).Value

            If cbPrf.Checked = True Then
                Dim drHist As DataRow = dtProfileHist.Rows.Find(gvRowPrfId)
                If Not drHist Is Nothing Then
                    drHist("status") = "O"
                End If
            End If
        Next

        ObsoleteProfileHist = prfService.SaveProfile("S", dtProfileHist)

    End Function

    Sub ExportToExcel(ByVal fileName As String, ByVal bExportAll As Boolean)
        'Dim bExportAll As Boolean = True

        Dim templateFile As String = "Profile_Dashboard_Template.xlsx"
        Dim templateFilePath As String = Server.MapPath("..\..\Report\Excel-Template\" & templateFile)

        Dim dtExportPart As DataTable = New DataTable("dtExportPart")
        Dim dtExportAll As DataTable = New DataTable("dtExportAll")
        Dim dtIssueExportPart As DataTable = New DataTable("dtIssuePart")
        Dim dtIssueExportAll As DataTable = New DataTable("dtIssueAll")

        Try
            dtExportAll = excelHelper.NpoiExcelTemplate2DataTable(templateFilePath, "Profile")

            If dtExportAll Is Nothing Then
                sAlertMsg = New StringBuilder("Failed to export data.")
                Return
            ElseIf dtExportAll.Columns.Count = 0 Then
                sAlertMsg = New StringBuilder("Failed to export data.")
                Return
            End If

            dtExportPart = dtExportAll.Clone

            'Issue & Risk
            dtIssueExportAll = excelHelper.NpoiExcelTemplate2DataTable(templateFilePath, "Risk&Issue")

            If dtIssueExportAll Is Nothing Then
                sAlertMsg = New StringBuilder("Failed to export risk & issue data.")
                Return
            ElseIf dtIssueExportAll.Columns.Count <= 0 Then
                sAlertMsg = New StringBuilder("Failed to export risk & issue data.")
                Return
            End If

            dtIssueExportPart = dtIssueExportAll.Clone
            Dim iIssueRow As Integer = 0


            Dim sSelPrfId As StringBuilder = New StringBuilder("")
            Dim dt As DataTable = gvPrjProfile.DataSource
            For iRow As Integer = 0 To gvPrjProfile.Rows.Count - 1
                'Dim prfId As Integer = gvPrjProfile.Rows(iRow).Cells(1).Text
                Dim prfId As Integer = gvPrjProfile.DataKeys(iRow).Item("prf_id")
                Dim prfVersion As String = gvPrjProfile.Rows(iRow).Cells(22).Text
                Dim prfDesc As String = gvPrjProfile.Rows(iRow).Cells(12).Text

                Dim dtPrfExport As DataTable = prfService.GetProfileHistView(prfId, prfVersion)

                Dim cbPrf As CheckBox = New CheckBox
                If Not gvPrjProfile.Rows(iRow).FindControl("cbPrf") Is Nothing Then
                    cbPrf = CType(gvPrjProfile.Rows(iRow).FindControl("cbPrf"), CheckBox)
                End If

                Dim txtHealthSta As TextBox = New TextBox
                If Not gvPrjProfile.Rows(iRow).FindControl("txtHealthSta") Is Nothing Then
                    txtHealthSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtHealthSta"), TextBox)
                End If

                Dim txtQualitySta As TextBox = New TextBox
                If Not gvPrjProfile.Rows(iRow).FindControl("txtQualitySta") Is Nothing Then
                    txtQualitySta = CType(gvPrjProfile.Rows(iRow).FindControl("txtQualitySta"), TextBox)
                End If

                Dim txtScopeSta As TextBox = New TextBox
                If Not gvPrjProfile.Rows(iRow).FindControl("txtScopeSta") Is Nothing Then
                    txtScopeSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtScopeSta"), TextBox)
                End If

                Dim txtCostSta As TextBox = New TextBox
                If Not gvPrjProfile.Rows(iRow).FindControl("txtCostSta") Is Nothing Then
                    txtCostSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtCostSta"), TextBox)
                End If

                Dim txtScheduleSta As TextBox = New TextBox
                If Not gvPrjProfile.Rows(iRow).FindControl("txtScheduleSta") Is Nothing Then
                    txtScheduleSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtScheduleSta"), TextBox)
                End If

                Dim txtResourceSta As TextBox = New TextBox
                If Not gvPrjProfile.Rows(iRow).FindControl("txtResourceSta") Is Nothing Then
                    txtResourceSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtResourceSta"), TextBox)
                End If

                Dim txtCssSta As TextBox = New TextBox
                If Not gvPrjProfile.Rows(iRow).FindControl("txtCssSta") Is Nothing Then
                    txtCssSta = CType(gvPrjProfile.Rows(iRow).FindControl("txtCssSta"), TextBox)
                End If

                'Dim btnPrf As Button = New Button

                Dim drExport As DataRow = dtExportAll.NewRow
                'Function
                drExport(0) = gvPrjProfile.Rows(iRow).Cells(24).Text.ToString.Trim
                'SBU
                drExport(1) = gvPrjProfile.Rows(iRow).Cells(3).Text.ToString.Trim
                'Profile Name
                drExport(2) = dtPrfExport.Rows(0).Item("prf_desc").ToString.Trim
                'Chinese Project Name
                drExport(3) = dtPrfExport.Rows(0).Item("prf_desc_chn").ToString.Trim
                'Project Background
                drExport(4) = dtPrfExport.Rows(0).Item("prf_desc_detail").ToString.Trim
                'Profile Main Code
                drExport(5) = dtPrfExport.Rows(0).Item("prf_main_code").ToString.Trim
                'Profile Associated Projects
                drExport(6) = dtPrfExport.Rows(0).Item("prj_codes").ToString.Trim
                'PM
                drExport(7) = gvPrjProfile.Rows(iRow).Cells(6).Text.ToString.Trim
                'BU
                drExport(8) = gvPrjProfile.Rows(iRow).Cells(8).Text.ToString.Trim
                'TSS Service Category
                drExport(9) = gvPrjProfile.Rows(iRow).Cells(2).Text.ToString.Trim
                'Fixed Price Project
                drExport(10) = dtPrfExport.Rows(0).Item("fixed_price_project").ToString.Trim
                'Estimated Start Date
                drExport(11) = gvPrjProfile.Rows(iRow).Cells(9).Text.ToString.Trim
                'Estimated End Date
                drExport(12) = gvPrjProfile.Rows(iRow).Cells(10).Text.ToString.Trim
                'Estimated Effort
                drExport(13) = dtPrfExport.Rows(0).Item("est_total_hours").ToString.Trim
                'Actual Effort
                drExport(14) = dtPrfExport.Rows(0).Item("actl_total_hours").ToString.Trim


                'Overall Health Status
                drExport(15) = DataFormatHelper.GetRAGDesc(txtHealthSta.Text)
                'Quality
                drExport(16) = DataFormatHelper.GetRAGDesc(txtQualitySta.Text)
                'Scope
                drExport(17) = DataFormatHelper.GetRAGDesc(txtScopeSta.Text)
                'Cost
                drExport(18) = DataFormatHelper.GetRAGDesc(txtCostSta.Text)
                'Schedule
                drExport(19) = DataFormatHelper.GetRAGDesc(txtScheduleSta.Text)
                'Resource
                drExport(20) = DataFormatHelper.GetRAGDesc(txtResourceSta.Text)
                'CSS
                drExport(21) = DataFormatHelper.GetRAGDesc(txtCssSta.Text)
                'Stage
                drExport(22) = DataFormatHelper.StringTrim(gvPrjProfile.Rows(iRow).Cells(11).Text)
                'Project Status Summary
                drExport(23) = DataFormatHelper.StringTrim(dtPrfExport.Rows(0).Item("prj_status_remark").ToString.Trim())
                'Last Submitted Date
                drExport(24) = gvPrjProfile.Rows(iRow).Cells(22).Text.ToString.Trim

                'Metric 
                Dim hsPrjMeric As Hashtable = New Hashtable
                hsPrjMeric = prjMetricService.GetProjectMetricHist(dtPrfExport.Rows(0).Item("prf_main_code").ToString, prfVersion)

                If Not hsPrjMeric Is Nothing Then
                    If IsNumeric(hsPrjMeric("11")) Then
                        drExport(25) = hsPrjMeric("11")
                    End If

                    If IsNumeric(hsPrjMeric("21")) Then
                        drExport(26) = hsPrjMeric.Item("21")
                    End If
                    If IsNumeric(hsPrjMeric("22")) Then
                        drExport(27) = hsPrjMeric.Item("22")
                    End If
                    If IsNumeric(hsPrjMeric("23")) Then
                        drExport(28) = hsPrjMeric.Item("23")
                    End If
                    If IsNumeric(hsPrjMeric("24")) Then
                        drExport(29) = hsPrjMeric.Item("24")
                    End If
                    If IsNumeric(hsPrjMeric("25")) Then
                        drExport(30) = hsPrjMeric.Item("25")
                    End If
                    If IsNumeric(hsPrjMeric("26")) Then
                        drExport(31) = hsPrjMeric.Item("26")
                    End If
                    If IsNumeric(hsPrjMeric("27")) Then
                        drExport(32) = hsPrjMeric.Item("27")
                    End If
                    If IsNumeric(hsPrjMeric("28")) Then
                        drExport(33) = hsPrjMeric.Item("28")
                    End If
                    If IsNumeric(hsPrjMeric("31")) Then
                        drExport(34) = hsPrjMeric.Item("31")
                    End If
                    If IsNumeric(hsPrjMeric("32")) Then
                        drExport(35) = hsPrjMeric.Item("32")
                    End If

                    If IsNumeric(hsPrjMeric("41")) Then
                        drExport(36) = hsPrjMeric.Item("41")
                    End If
                    If IsNumeric(hsPrjMeric("42")) Then
                        drExport(37) = hsPrjMeric.Item("42")
                    End If

                    If IsNumeric(hsPrjMeric("43")) Then
                        drExport(38) = hsPrjMeric.Item("43")

                    End If


                End If

                'Metric Raw
                Dim hsPrjMericRaw As Hashtable = New Hashtable
                hsPrjMericRaw = prjMetricRawService.GetProjectMetricRawHist(dtPrfExport.Rows(0).Item("prf_main_code").ToString, prfVersion)

                If Not hsPrjMericRaw Is Nothing Then
                    If IsNumeric(hsPrjMericRaw("css_score")) Then
                        drExport(39) = hsPrjMericRaw("css_score")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("s1")) Then
                        drExport(40) = hsPrjMericRaw.Item("s1")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("s2")) Then
                        drExport(41) = hsPrjMericRaw.Item("s2")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("sit_defect")) Then
                        drExport(42) = hsPrjMericRaw.Item("sit_defect")
                    End If
                    If IsNumeric(hsPrjMericRaw.Item("uat_critical_defect")) Then
                        drExport(43) = hsPrjMericRaw.Item("uat_critical_defect")
                    End If
                    If IsNumeric(hsPrjMericRaw.Item("uat_major_defect")) Then
                        drExport(44) = hsPrjMericRaw.Item("uat_major_defect")
                    End If
                    If IsNumeric(hsPrjMericRaw.Item("uat_minor_defect")) Then
                        drExport(45) = hsPrjMericRaw.Item("uat_minor_defect")
                    End If
                    If IsNumeric(hsPrjMericRaw.Item("uat_trivial_defect")) Then
                        drExport(46) = hsPrjMericRaw.Item("uat_trivial_defect")
                    End If
                    If IsNumeric(hsPrjMericRaw.Item("prd_critical_defect")) Then
                        drExport(47) = hsPrjMericRaw.Item("prd_critical_defect")
                    End If
                    If IsNumeric(hsPrjMericRaw.Item("prd_major_defect")) Then
                        drExport(48) = hsPrjMericRaw.Item("prd_major_defect")
                    End If
                    If IsNumeric(hsPrjMericRaw.Item("prd_minor_defect")) Then
                        drExport(49) = hsPrjMericRaw.Item("prd_minor_defect")
                    End If
                    If IsNumeric(hsPrjMericRaw.Item("prd_trivial_defect")) Then

                        drExport(50) = hsPrjMericRaw.Item("prd_trivial_defect")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("reopen_uat_defects")) Then
                        drExport(51) = hsPrjMericRaw.Item("reopen_uat_defects")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("1st_time_passed_uat_test_cases")) Then
                        drExport(52) = hsPrjMericRaw.Item("1st_time_passed_uat_test_cases")
                    End If
                    If IsNumeric(hsPrjMericRaw.Item("uat_test_cases_executed")) Then
                        drExport(53) = hsPrjMericRaw.Item("uat_test_cases_executed")

                    End If

                    If IsNumeric(hsPrjMericRaw.Item("comp_task")) Then
                        drExport(54) = hsPrjMericRaw.Item("comp_task")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("comp_task_und_ctrl")) Then
                        drExport(55) = hsPrjMericRaw.Item("comp_task_und_ctrl")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("received_incident")) Then
                        drExport(56) = hsPrjMericRaw.Item("received_incident")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("response_on_time")) Then
                        drExport(57) = hsPrjMericRaw.Item("response_on_time")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("resolution_on_time")) Then
                        drExport(58) = hsPrjMericRaw.Item("resolution_on_time")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("failure_effort")) Then
                        drExport(59) = hsPrjMericRaw.Item("failure_effort")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("actual_effort")) Then
                        drExport(60) = hsPrjMericRaw.Item("actual_effort")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("PV")) Then
                        drExport(61) = hsPrjMericRaw.Item("PV")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("ev")) Then
                        drExport(62) = hsPrjMericRaw.Item("ev")
                    End If

                    If IsNumeric(hsPrjMericRaw.Item("ac")) Then
                        drExport(63) = hsPrjMericRaw.Item("ac")
                    End If

                End If

                'Risk & Issues
                Dim prfIssueService As IProfileIssueService = New ProfileIssueService
                Dim dtIssues As DataTable = prfIssueService.GetProfileIssueListView(prfId)

                If Not dtIssues Is Nothing Then
                    For i As Integer = 0 To dtIssues.Rows.Count - 1
                        Dim drIssue As DataRow = dtIssues.Rows(i)

                        Dim dtIssueAction As DataTable = prfIssueService.GetProfileIssueActionView(drIssue("issue_no"), False)
                        Dim bHaveIssueAction As Boolean = True
                        If dtIssueAction Is Nothing Then
                            bHaveIssueAction = False
                        ElseIf dtIssueAction.Rows.Count = 0 Then
                            bHaveIssueAction = False
                        End If
                        If Not bHaveIssueAction Then
                            Dim drIssueExport As DataRow = dtIssueExportAll.NewRow
                            iIssueRow = iIssueRow + 1
                            drIssueExport(0) = iIssueRow
                            drIssueExport(1) = drIssue("issue_cate_desc")
                            drIssueExport(2) = drIssue("issue_desc_sys")
                            drIssueExport(3) = drIssue("issue_desc_short")
                            drIssueExport(4) = drIssue("issue_desc_long")
                            drIssueExport(5) = drIssue("issue_tag_desc")
                            drIssueExport(6) = drIssue("issue_owner_name")
                            drIssueExport(7) = drIssue("issue_severity_desc")
                            drIssueExport(8) = drIssue("issue_probability_desc")
                            drIssueExport(9) = drIssue("issue_status_desc")
                            drIssueExport(10) = drIssue("issue_track_status_desc")
                            If IsDate(drIssue("created_dt")) Then
                                drIssueExport(11) = Format(drIssue("created_dt"), Session("date_format"))
                            End If
                            If IsDate(drIssue("issue_est_start_dt")) Then
                                drIssueExport(12) = Format(drIssue("issue_est_start_dt"), Session("date_format"))
                            End If
                            If IsDate(drIssue("issue_est_end_dt")) Then
                                drIssueExport(13) = Format(drIssue("issue_est_end_dt"), Session("date_format"))
                            End If
                            If IsDate(drIssue("issue_actl_start_dt")) Then
                                drIssueExport(14) = Format(drIssue("issue_actl_start_dt"), Session("date_format"))
                            End If
                            If IsDate(drIssue("issue_actl_end_dt")) Then
                                drIssueExport(15) = Format(drIssue("issue_actl_end_dt"), Session("date_format"))
                            End If

                            drIssueExport(25) = prfDesc
                            dtIssueExportAll.Rows.Add(drIssueExport)

                            If cbPrf.Checked Then
                                Dim drIssuePart As DataRow = dtIssueExportPart.NewRow
                                drIssuePart.ItemArray = drIssueExport.ItemArray
                                dtIssueExportPart.Rows.Add(drIssuePart)
                            End If
                        End If

                        If bHaveIssueAction Then
                            For j As Integer = 0 To dtIssueAction.Rows.Count - 1
                                Dim drIssueAction As DataRow = dtIssueAction.Rows(j)
                                Dim drIssueExport As DataRow = dtIssueExportAll.NewRow
                                iIssueRow = iIssueRow + 1
                                drIssueExport(0) = iIssueRow
                                drIssueExport(1) = drIssue("issue_cate_desc")
                                drIssueExport(2) = drIssue("issue_desc_sys")
                                drIssueExport(3) = drIssue("issue_desc_short")
                                drIssueExport(4) = drIssue("issue_desc_long")
                                drIssueExport(5) = drIssue("issue_tag_desc")
                                drIssueExport(6) = drIssue("issue_owner_name")
                                drIssueExport(7) = drIssue("issue_severity_desc")
                                drIssueExport(8) = drIssue("issue_probability_desc")

                                drIssueExport(9) = drIssue("issue_status_desc")
                                drIssueExport(10) = drIssue("issue_track_status_desc")
                                If IsDate(drIssue("created_dt")) Then
                                    drIssueExport(11) = Format(drIssue("created_dt"), Session("date_format"))
                                End If
                                If IsDate(drIssue("issue_est_start_dt")) Then
                                    drIssueExport(12) = Format(drIssue("issue_est_start_dt"), Session("date_format"))
                                End If
                                If IsDate(drIssue("issue_est_end_dt")) Then
                                    drIssueExport(13) = Format(drIssue("issue_est_end_dt"), Session("date_format"))
                                End If
                                If IsDate(drIssue("issue_actl_start_dt")) Then
                                    drIssueExport(14) = Format(drIssue("issue_actl_start_dt"), Session("date_format"))
                                End If
                                If IsDate(drIssue("issue_actl_end_dt")) Then
                                    drIssueExport(15) = Format(drIssue("issue_actl_end_dt"), Session("date_format"))
                                End If

                                drIssueExport(16) = drIssueAction("issue_desc_short")
                                drIssueExport(17) = drIssueAction("issue_desc_long")

                                If IsDate(drIssueAction("issue_est_start_dt")) Then
                                    drIssueExport(18) = Format(drIssueAction("issue_est_start_dt"), Session("date_format"))
                                End If
                                If IsDate(drIssueAction("issue_est_end_dt")) Then
                                    drIssueExport(19) = Format(drIssueAction("issue_est_end_dt"), Session("date_format"))
                                End If
                                If IsDate(drIssueAction("issue_actl_start_dt")) Then
                                    drIssueExport(20) = Format(drIssueAction("issue_actl_start_dt"), Session("date_format"))
                                End If
                                If IsDate(drIssueAction("issue_actl_end_dt")) Then
                                    drIssueExport(21) = Format(drIssueAction("issue_actl_end_dt"), Session("date_format"))
                                End If

                                drIssueExport(22) = drIssueAction("issue_status_desc")
                                drIssueExport(23) = drIssueAction("issue_owner_name")
                                drIssueExport(24) = drIssueAction("issue_progress")


                                drIssueExport(25) = prfDesc

                                dtIssueExportAll.Rows.Add(drIssueExport)

                                If cbPrf.Checked Then
                                    Dim drIssuePart As DataRow = dtIssueExportPart.NewRow
                                    drIssuePart.ItemArray = drIssueExport.ItemArray
                                    dtIssueExportPart.Rows.Add(drIssuePart)
                                End If
                            Next
                        End If
                    Next
                End If


                If cbPrf.Checked = True Then
                    sSelPrfId.Append(IIf(iRow = 0, "", ", " & gvPrjProfile.Rows(iRow).Cells(1).Text.ToString))

                    Dim drExportPart As DataRow = dtExportPart.NewRow
                    drExportPart.ItemArray = drExport.ItemArray
                    dtExportPart.Rows.Add(drExportPart)
                    bExportAll = False
                End If

                If bExportAll Then
                    dtExportAll.Rows.Add(drExport)
                End If

            Next


            If Not bExportAll And Not dtExportPart Is Nothing Then

                If dtExportPart.Rows.Count > 0 Then
                    'Export selected rows
                    'excelHelper.NpoiDataTable2Excel(fileName, "Profile", dtExportPart)
                    Dim sheetContentsPart As ExcelSheetContent() = {New ExcelSheetContent("Profile", dtExportPart), _
                                                                New ExcelSheetContent("Risk&Issue", dtIssueExportPart)}
                    excelHelper.NpoiDataTable2Excel(fileName, sheetContentsPart)
                    bExportAll = False
                End If

            End If

            If bExportAll And Not dtExportAll Is Nothing Then
                If dtExportAll.Rows.Count > 0 Then
                    'Export all rows
                    'excelHelper.NpoiDataTable2Excel(fileName, "Profile", dtExportAll)
                    Dim sheetContentsAll As ExcelSheetContent() = {New ExcelSheetContent("Profile", dtExportAll), _
                                                New ExcelSheetContent("Risk&Issue", dtIssueExportAll)}
                    excelHelper.NpoiDataTable2Excel(fileName, sheetContentsAll)
                End If
            End If
        Catch ex As Exception
            logHelper.WriteLog("failed to export to excel ", ex)
            Throw ex
        Finally
            dtExportPart = Nothing
            dtExportAll = Nothing
            dtIssueExportPart = Nothing
            dtIssueExportAll = Nothing
        End Try

    End Sub
#End Region

#Region "Query"
    Sub QueryData()
        Dim filterString As StringBuilder = New StringBuilder("")
        Dim userRoleFilter As StringBuilder = New StringBuilder("1 = 1 ")
        Dim sPMFilter As StringBuilder = New StringBuilder("")
        Dim buFilter As String = ""
        Dim dr() As DataRow = Nothing


        If Not String.IsNullOrEmpty(txtDataReloadDt.Text) Then
            dataVersion = Format(CDate(txtDataReloadDt.Text), "yyyyMMdd")
        Else
            dataVersion = Format(Now, "yyyyMMdd")
        End If
        Session("dataVersion") = dataVersion

        If Not String.IsNullOrEmpty(sHealthSta) Then
            filterString.Append(" AND [health_status] = '" & sHealthSta & "' ")
        End If

        If Not String.IsNullOrEmpty(txtPrjName.Text) Then
            filterString.Append(" AND prf_desc like '%" & txtPrjName.Text & "%' ")
        End If

        If Not String.IsNullOrEmpty(txtPrjCode.Text) Then
            filterString.Append(" AND prj_codes like '%" & txtPrjCode.Text & "%' ")
        End If

        If Not String.IsNullOrEmpty(ddlTssPrj.SelectedValue) Then
            filterString.Append(" AND tss_prj = '" & ddlTssPrj.SelectedValue & "' ")
        End If

        buFilter = GetSelectedBU()
        If Not String.IsNullOrEmpty(buFilter) Then
            filterString.Append(" AND bu_code in (" & buFilter & ") ")
        End If

        'profile status: Submtted
        filterString.Append(" AND [status] = '" & PROFILESTATUS.SUBMITTED & "' ")

        'PM List
        Dim sPMList As StringBuilder = New StringBuilder("")
        Dim sTeamPrfList As StringBuilder = New StringBuilder("")

        If Not userRoles Is Nothing Then
            If userRoles.Contains(DASHBORADROLES.GM) Or userRoles.Contains(DASHBORADROLES.EXCO) Or userRoles.Contains(DASHBORADROLES.AM) _
            Or userRoles.Contains(DASHBORADROLES.QAG) Or userRoles.Contains(DASHBORADROLES.ADM) Then

            Else
                sPMFilter.Append(" And ( prj_ld_id = '" & Session("logon_id") & "' OR created_by = '" & Session("logon_id") & "' ")

                If userRoles.Contains(DASHBORADROLES.FH) Or userRoles.Contains(DASHBORADROLES.SBUH) Or userRoles.Contains(DASHBORADROLES.TL) Then
                    prfService.GetMyTeamProfilesHist(sTeamPrfList, Session("my_teams"), dataVersion)

                    If Not String.IsNullOrEmpty(sTeamPrfList.ToString) Then
                        sPMFilter.Append(" OR prf_id in (" & sTeamPrfList.ToString & ") ")
                    End If
                End If

                sPMFilter.Append(" ) ")
            End If
        End If
        filterString.Append(sPMFilter)


        Try
            dtProfile = prfService.GetProfileHistViewList(dataVersion, filterString.ToString)


            If Not dtProfile Is Nothing Then
                'dtProfile.Columns.Add("sbu_code")
                'dtProfile.Columns.Add("sbu_name")
                'dtProfile.Columns.Add("func_code")
                'dtProfile.Columns.Add("func_name")

                dtProfileResult = dtProfile.Clone

                If dtProfile.Rows.Count > 0 Then
                    dtProfile = dtProfile.Select("1=1", "team_code, prj_ld_id").CopyToDataTable
                End If

                For Each drProfile As DataRow In dtProfile.Rows

                    'Dim dtSBU As DataTable = New DataTable()
                    'Dim dtFunc As DataTable = New DataTable()

                    'dtSBU = pmaTeamService.GetTeam(drProfile("team_code"), TEAMLEVEL.SBU)
                    'If Not dtSBU Is Nothing Then
                    '    If dtSBU.Rows.Count > 0 Then
                    '        drProfile("sbu_code") = dtSBU.Rows(0).Item("team_code")
                    '        drProfile("sbu_name") = dtSBU.Rows(0).Item("team_name")
                    '    End If
                    'End If
                    'dtFunc = pmaTeamService.GetTeam(drProfile("team_code"), TEAMLEVEL.FUNC)
                    'If Not dtFunc Is Nothing Then
                    '    If dtFunc.Rows.Count > 0 Then
                    '        drProfile("func_code") = dtFunc.Rows(0).Item("team_code")
                    '        drProfile("func_name") = dtFunc.Rows(0).Item("team_name")
                    '    End If
                    'End If

                    If String.IsNullOrEmpty(ddlFunc.SelectedValue) Then
                        Dim drProfileResult As DataRow = dtProfileResult.NewRow
                        drProfileResult.ItemArray = drProfile.ItemArray

                        dtProfileResult.Rows.Add(drProfileResult)
                    ElseIf ddlFunc.SelectedValue = drProfile("func_code") Then
                        If String.IsNullOrEmpty(ddlSBU.SelectedValue) Then
                            Dim drProfileResult As DataRow = dtProfileResult.NewRow
                            drProfileResult.ItemArray = drProfile.ItemArray
                            dtProfileResult.Rows.Add(drProfileResult)
                        ElseIf ddlSBU.SelectedValue = drProfile("sbu_code") Then
                            Dim drProfileResult As DataRow = dtProfileResult.NewRow
                            drProfileResult.ItemArray = drProfile.ItemArray
                            dtProfileResult.Rows.Add(drProfileResult)
                        End If

                    End If
                Next
            End If

            If Not dtProfileResult Is Nothing Then
                WebControlHelper.GridViewDataBind(gvPrjProfile, dtProfileResult)
            End If

        Catch ex As Exception
            logHelper.WriteLog("QueryData: failed to query data.", ex)
            Throw ex
        End Try

        

    End Sub



    Private Function GetSelectedBU() As String
        Dim sBUSelected As String = ""

        For i As Integer = 0 To lbBU.Items.Count - 1
            If lbBU.Items(i).Selected = True Then
                sBUSelected = sBUSelected & IIf(sBUSelected = "", "'", ", '") & lbBU.Items(i).Value & "'"
            End If
        Next

        GetSelectedBU = sBUSelected
    End Function


#End Region


#Region "gvPrjProfile"

    Private Sub gvPrjProfile_DataBinding(sender As Object, e As System.EventArgs) Handles gvPrjProfile.DataBinding
        gvPrjProfile.Columns(1).Visible = True
        gvPrjProfile.Columns(2).Visible = True
        gvPrjProfile.Columns(3).Visible = True
        gvPrjProfile.Columns(6).Visible = True
        gvPrjProfile.Columns(12).Visible = True
        gvPrjProfile.Columns(21).Visible = True
        gvPrjProfile.Columns(23).Visible = True
        gvPrjProfile.Columns(24).Visible = True
        gvPrjProfile.Columns(25).Visible = True
        gvPrjProfile.Columns(26).Visible = True
    End Sub
    Private Sub gvPrjProfile_DataBound(sender As Object, e As System.EventArgs) Handles gvPrjProfile.DataBound

        gvPrjProfile.Columns(1).Visible = False
        gvPrjProfile.Columns(12).Visible = False
        gvPrjProfile.Columns(21).Visible = False
        'gvPrjProfile.Columns(22).Visible = False
        gvPrjProfile.Columns(23).Visible = False
        gvPrjProfile.Columns(24).Visible = False
        gvPrjProfile.Columns(25).Visible = False
        gvPrjProfile.Columns(26).Visible = False


        If ddlSBU.Items.Count = 1 Then
            gvPrjProfile.Columns(2).Visible = False
            gvPrjProfile.Columns(3).Visible = False
        End If

        Dim bHidePM As Boolean = True
        For iRow As Integer = 0 To gvPrjProfile.Rows.Count - 1


            If gvPrjProfile.Rows(iRow).RowType = DataControlRowType.DataRow Then
                If gvPrjProfile.Rows(iRow).Cells(6).Text <> Session("logon_id") Then
                    bHidePM = False
                    Exit For
                End If
            End If
        Next
        If bHidePM Then
            gvPrjProfile.Columns(6).Visible = False
        End If

        WebControlHelper.InitSortingIcon(gvPrjProfile)

        If gvPrjProfile.Rows.Count = 1 Then
            If gvPrjProfile.DataKeys(0).Values("prf_id").ToString = "" Then
                gvPrjProfile.Rows(0).Cells.Clear()
                Dim tableCell As TableCell = New TableCell
                tableCell.ColumnSpan = gvPrjProfile.Columns.Count
                tableCell.Text = gvPrjProfile.EmptyDataText
                gvPrjProfile.Rows(0).Cells.Add(tableCell)
                gvPrjProfile.Rows(0).Style.Add("text-align", "center")
            End If
        End If
    End Sub


    Sub BindEmptyData()
        Dim emptyDt As DataTable = New DataTable

        emptyDt.NewRow()
        emptyDt.Rows.Add()
        emptyDt.Columns.Add()
        emptyDt.Columns.Add("prf_id")
        emptyDt.Columns.Add("Function_Head")
        emptyDt.Columns.Add("SBU_HEAD")
        emptyDt.Columns.Add("prf_desc")
        emptyDt.Columns.Add("prj_ld_id")
        emptyDt.Columns.Add("bu_code")
        emptyDt.Columns.Add("bu_name")
        emptyDt.Columns.Add("est_start_dt")
        emptyDt.Columns.Add("est_end_dt")
        emptyDt.Columns.Add("prj_stage")
        emptyDt.Columns.Add("health_status")
        emptyDt.Columns.Add("quality_status")
        emptyDt.Columns.Add("scope_status")
        emptyDt.Columns.Add("cost_status")
        emptyDt.Columns.Add("schedule_status")
        emptyDt.Columns.Add("resource_status")
        emptyDt.Columns.Add("css_status")

        gvPrjProfile.DataSource = emptyDt
        gvPrjProfile.DataBind()
        Dim gvDataKeyNames As String() = {"prf_id"}
        gvPrjProfile.DataKeyNames = gvDataKeyNames
    End Sub


    Private Sub gvPrjProfile_PageIndexChanging(sender As Object, e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvPrjProfile.PageIndexChanging
        QueryData()

        gvPrjProfile.PageIndex = e.NewPageIndex

        WebControlHelper.GridViewDataBind(gvPrjProfile, dtProfileResult)
    End Sub

    Private Sub gvPrjProfile_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvPrjProfile.RowCommand
        If e.CommandName = "previewProfile" Then
            Dim index As String = CType(e.CommandArgument(), Integer)
            Dim gvRow As GridViewRow = gvPrjProfile.Rows(index)

            Dim prf_id As Integer = gvPrjProfile.DataKeys(index).Item(0)


            Session("prf_id") = prf_id
            Session("fromPg") = "LIST"
            Session("dataVersion") = Session("dataVersion")

            Server.Transfer("ProfilePreview.aspx")
            'Server.Transfer("Profile.aspx")
        End If
    End Sub

    Private Sub gvPrjProfile_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvPrjProfile.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drView As DataRowView = CType(e.Row.DataItem, DataRowView)

            If Not drView Is Nothing Then
                If Not IsDBNull(drView("health_status")) Then
                    setHealthStatusIconColor(drView("health_status"), "iHealthSta", e)
                End If

                If Not IsDBNull(drView("css_status")) Then
                    setHealthStatusIconColor(drView("css_status"), "iCssSta", e)
                End If

                If Not IsDBNull(drView("quality_status")) Then
                    setHealthStatusIconColor(drView("quality_status"), "iQualitySta", e)
                End If
                If Not IsDBNull(drView("scope_status")) Then
                    setHealthStatusIconColor(drView("scope_status"), "iScopeSta", e)
                End If
                If Not IsDBNull(drView("schedule_status")) Then
                    setHealthStatusIconColor(drView("schedule_status"), "iScheduleSta", e)
                End If
                If Not IsDBNull(drView("cost_status")) Then
                    setHealthStatusIconColor(drView("cost_status"), "iCostSta", e)
                End If
                If Not IsDBNull(drView("resource_status")) Then
                    setHealthStatusIconColor(drView("resource_status"), "iResourceSta", e)
                End If

            End If
        End If
    End Sub

    Private Sub gvPrjProfile_Sorting(sender As Object, e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvPrjProfile.Sorting
        QueryData()

        WebControlHelper.GridViewSorting(gvPrjProfile, e, dtProfileResult)
    End Sub

    Private Sub setHealthStatusIconColor(ByVal sSta As String, ByVal ctlName As String, ByRef e As System.Web.UI.WebControls.GridViewRowEventArgs)
        Dim iSta As HtmlGenericControl = New HtmlGenericControl
        If Not e.Row.FindControl(ctlName) Is Nothing Then
            iSta = CType(e.Row.FindControl(ctlName), HtmlGenericControl)
            Select Case sSta
                Case "R"
                    iSta.Style.Add("color", "Red")
                Case "A"
                    iSta.Style.Add("color", "#f0ad4e")
                Case "G"
                    iSta.Style.Add("color", "Green")
            End Select
        End If
    End Sub

    Public Function GetPages() As IEnumerable(Of Integer)
        Return Enumerable.Range(1, gvPrjProfile.PageCount)

    End Function

    Protected Sub PageIndexChanging(sender As Object, e As EventArgs)
        Dim pageLink As LinkButton = CType(sender, LinkButton)

        'Select Case e.CommandName
        '    Case "Page"
        '        gvPrjProfile.PageIndex = Integer.Parse(pageLink.CommandArgument) - 1
        '    Case "First"
        '        gvPrjProfile.PageIndex = 0
        '    Case "Last"
        '        gvPrjProfile.PageIndex = gvPrjProfile.PageCount - 1
        '    Case "Previous"
        '    Case "Next"

        'End Select

        gvPrjProfile.PageIndex = Integer.Parse(pageLink.CommandArgument) - 1

        QueryData()

    End Sub

    Sub LoadPagenation()
        Dim maxPageNumberCount As Integer = 5
        Dim gvPageCount As Integer = gvPrjProfile.PageCount

        Dim pageCount As Integer = maxPageNumberCount
        If gvPageCount < pageCount Then
            pageCount = gvPageCount
        End If

        Dim httpText As StringBuilder = New StringBuilder("")
        For i = 1 To pageCount

        Next

    End Sub

#End Region


    Private Sub ddlFunc_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlFunc.SelectedIndexChanged
        ddlSBU.Items.Clear()
        BindSBU()
        QueryData()
    End Sub




    Private Sub btnDelete_Click(sender As Object, e As System.EventArgs) Handles btnDelete.Click
        Dim sMsg As String = ""

        Try
            If DeleteProfileHist(sMsg) Then
                logHelper.WriteLog(Session("logon_id") & " deleted profiles successfully.")
                sAlertMsg = New StringBuilder("Records are deleted successfully.")
                'dtProfile.AcceptChanges()
                QueryData()
                'ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "popUpMsg();", True)
            ElseIf sMsg = "" Then
                'dtProfile.RejectChanges()
                sAlertMsg = New StringBuilder("Sorry, failed to delete records.")
                logHelper.WriteLog(Session("logon_id") & " failed to delete profiles.")
            Else
                sAlertMsg = New StringBuilder(sMsg)
            End If
        Catch ex As Exception
            logHelper.WriteLog("btnDelete_Click", ex)
        End Try


        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "popUpMsg();", True)
    End Sub

    Private Function ObsoleteProfile() As Boolean
        Dim sSelPrfId As StringBuilder = New StringBuilder("")
        Dim sSelPrjCodes As StringBuilder = New StringBuilder("")
        Dim dtProfileDel As DataTable = New DataTable
        Dim dtPrjMetricHist As DataTable = Nothing
        Dim dtPrjMetricRawHist As DataTable = Nothing

        If String.IsNullOrEmpty(dataVersion) Then
            dataVersion = Format(Now, "yyyyMMdd")
        End If

        dtProfileDel = prfService.GetProfileHistList(dataVersion, True)

        Dim dtProfileDelPk As DataColumn() = {dtProfileDel.Columns("prf_id")}
        dtProfileDel.PrimaryKey = dtProfileDelPk

        For iRow As Integer = gvPrjProfile.Rows.Count - 1 To 0 Step -1
            Dim cbPrf As CheckBox = gvPrjProfile.Rows(iRow).FindControl("cbPrf")
            Dim gvRowPrfId As Integer = gvPrjProfile.DataKeys(iRow).Value
            Dim gvRowPrj As String = gvPrjProfile.Rows(iRow).Cells(21).Text

            If cbPrf.Checked = True Then
                If Not String.IsNullOrEmpty(sSelPrfId.ToString) Then
                    sSelPrfId.Append(", ")
                End If

                sSelPrfId.Append(gvRowPrfId.ToString)
                If Not String.IsNullOrEmpty(sSelPrjCodes.ToString) Then
                    sSelPrjCodes.Append(", ")
                End If
                sSelPrjCodes.Append(gvRowPrj)

                dtProfileDel.Rows.Find(gvRowPrfId).Item("health_status") = "O"
            End If
        Next

        If Not String.IsNullOrEmpty(sSelPrjCodes.ToString) Then
            Dim prjCodeList As String() = sSelPrjCodes.ToString.Split(",")

            dtPrjMetricHist = prjMetricService.GetProjectMetricHistList(prjCodeList, dataVersion)
            dtPrjMetricRawHist = prjMetricRawService.GetProjectMetricRawHistList(prjCodeList, dataVersion, False)

            For Each drPrjMetricHist As DataRow In dtPrjMetricHist.Rows
                drPrjMetricHist.Delete()
            Next

            For Each drPrjMetricRawHist As DataRow In dtPrjMetricRawHist.Rows
                drPrjMetricRawHist.Delete()
            Next
        End If

        ObsoleteProfile = prfService.ObsoleteProfileHist(dtProfileDel, dtPrjMetricHist, dtPrjMetricRawHist)
    End Function

    Private Function DeleteProfileHist(ByRef sMsg As String) As Boolean
        Dim bToDelete As Boolean = True
        Dim sSelPrfId As StringBuilder = New StringBuilder("")
        Dim sSelPrjCodes As StringBuilder = New StringBuilder("")
        Dim dtProfileHistDel As DataTable = New DataTable
        Dim dtProfileDel As DataTable = New DataTable

        If String.IsNullOrEmpty(dataVersion) Then
            dataVersion = Format(Now, "yyyyMMdd")
        End If

        dtProfileHistDel = prfService.GetProfileHistList(dataVersion, True)
        Dim dtProfileHistDelPk As DataColumn() = {dtProfileHistDel.Columns("prf_id"), dtProfileHistDel.Columns("data_version")}
        dtProfileHistDel.PrimaryKey = dtProfileHistDelPk

        dtProfileDel = prfService.GetProfileList()
        Dim dtProfileDelPk As DataColumn() = {dtProfileDel.Columns("prf_id")}
        dtProfileDel.PrimaryKey = dtProfileDelPk

        For iRow As Integer = gvPrjProfile.Rows.Count - 1 To 0 Step -1
            Dim cbPrf As CheckBox = gvPrjProfile.Rows(iRow).FindControl("cbPrf")
            Dim gvRowPrfId As Integer = gvPrjProfile.DataKeys(iRow).Value
            Dim gvRowPrj As String = gvPrjProfile.Rows(iRow).Cells(21).Text
            Dim gvRowPrjCodes As String = gvPrjProfile.Rows(iRow).Cells(23).Text
            Dim gvRowDataVersion As String = gvPrjProfile.Rows(iRow).Cells(22).Text

            If cbPrf.Checked = True Then
                If prjMetricService.HasProjectMetrics(gvRowPrjCodes.Split(",")) Then
                    bToDelete = False
                    sMsg = "Oops, failed to delete profiles as profile \'" & Replace(gvPrjProfile.Rows(iRow).Cells(12).Text, "'", "\'") & "\' already has project metric data entry."
                    Exit For
                End If
                If Not String.IsNullOrEmpty(sSelPrfId.ToString) Then
                    sSelPrfId.Append(", ")
                End If

                sSelPrfId.Append(gvRowPrfId.ToString)
                If Not String.IsNullOrEmpty(sSelPrjCodes.ToString) Then
                    sSelPrjCodes.Append(", ")
                End If
                sSelPrjCodes.Append(gvRowPrj)

                'Delete profile history record
                Dim drHistDel As DataRow = dtProfileHistDel.Rows.Find({gvRowPrfId, gvRowDataVersion})
                If Not drHistDel Is Nothing Then
                    drHistDel.Delete()
                End If
                'Delete profile record
                Dim drPrfDel As DataRow = dtProfileDel.Rows.Find(gvRowPrfId)
                If Not drPrfDel Is Nothing Then
                    drPrfDel.Delete()
                End If
            End If
        Next


        If bToDelete Then
            DeleteProfileHist = prfService.DeleteProfileHist(dtProfileHistDel, dtProfileDel)
        Else
            DeleteProfileHist = False
        End If
    End Function

    Private Function ValidateBeforeDeleting() As Boolean
        Dim bReturn As Boolean = False

        For Each gvRow As GridViewRow In gvPrjProfile.Rows
            Dim cbPrf As CheckBox = New CheckBox
            If Not gvRow.FindControl("cbPrf") Is Nothing Then
                cbPrf = CType(gvRow.FindControl("cbPrf"), CheckBox)

                If cbPrf.Checked Then
                    Dim dtPrfHist As DataTable = New DataTable
                    Dim prjMetricService As IProjectMetricService = New ProjectMetricService
                    'dtPrfHist = 
                End If
            End If
        Next

        ValidateBeforeDeleting = bReturn
    End Function


    Public Sub ddlPageSizeSelectedIndexChanged(sender As Object, e As System.EventArgs)
        Dim ddlPageSize As DropDownList = CType(sender, DropDownList)
        Dim pgSize As Integer = ddlPageSize.SelectedValue

        If pgSize = 0 Then
            gvPrjProfile.AllowPaging = False
        Else
            gvPrjProfile.AllowPaging = True
            gvPrjProfile.PageSize = ddlPageSize.SelectedValue
        End If

        QueryData()
    End Sub
End Class