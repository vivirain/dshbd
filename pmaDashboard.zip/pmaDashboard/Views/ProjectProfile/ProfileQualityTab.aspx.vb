﻿Imports System.IO
Imports NPOI
Imports System.Web.Script.Serialization
Imports System.Web.Services


Public Class ProfileQualityTab
    Inherits System.Web.UI.Page

    Const LOOKUP_TYPE As String = "B"

    Protected profileId As Integer = 0

    Protected fromPg As String = ""
    Protected currentDataVer As String = Format(Now, "yyyyMMdd")
    Protected lastDataVer As String = ""

    Protected prfMainCode As String = ""
    Protected sTssPrj As String = ""
    Protected sTssPrjName As String = ""
    Protected prjCodes As String = ""
    Protected prjCodesLast As String = ""
    Protected currentPrjCode As String = ""
    Protected sMetricTargetYear As String = ""

    Protected Shared showMetricPerProfile As String = ""
    Protected Shared saveMetricRaw2Db As String = ""

    Public sErrMsgBuilder As StringBuilder = New StringBuilder("")

    Protected dtProfile As DataTable = Nothing
    Protected dtProfileLast As DataTable = Nothing
    Protected dtProjects As DataTable = Nothing
    Protected dtPrjMetrics As DataTable = Nothing
    Protected dtPrjMetricRaw As DataTable = Nothing
    Protected dtPrjMetricsLast As DataTable = Nothing
    Protected dtPrjMetricRawLast As DataTable = Nothing
    Protected dtPrjMetricsView As DataTable = Nothing
    Protected dtPrjMetricRawsView As DataTable = Nothing
    Protected dtMetricsTarget As DataTable = Nothing

    Dim pmaPrjService As IPmaProjectService = New PmaProjectService
    Dim pmaBizUnitService As IPmaBizUnitService = New PmaBizUnitService
    Dim pmaUserService As IPmaUserService = New PmaUserService
    Dim pmaTssPrjService As IPmaTssProjectService = New PmaTssProjectService
    Dim lookupService As ILookupService = New LookupService

    Dim metricRawService As IMetricRawService = New MetricRawService
    Dim metricService As IMetricService = New MetricService
    Dim metricRawMappingService As IMetricRawMappingService = New MetricRawMappingService
    Dim metricTargetService As IMetricTargetService = New MetricTargetService

    Dim prfService As IProfileService = New ProfileService
    Dim prjMetricService As IProjectMetricService = New ProjectMetricService
    Dim prjMetricRawService As IProjectMetricRawService = New ProjectMetricRawService

    Dim excelHelper As ExcelHelper = New ExcelHelper
    Dim logHelper As LogHelper = New LogHelper


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            'Section 0: Retrieve session data
            If Session("prf_id") Is Nothing Then
                profileId = 0
                Session("prf_id") = profileId
                logHelper.WriteLog("profileId is not in session.")
                Server.Transfer("Views/ProjectProfile/ProfileList.aspx")
            Else
                profileId = Session("prf_id")
                prfId.Text = profileId
            End If

            If Session("fromPg") Is Nothing Then
                fromPg = "DRAFT"
                Session("fromPg") = fromPg
            Else
                fromPg = Session("fromPg")
            End If

            If Session("current_data_version") Is Nothing Then
                currentDataVer = Format(Now, "yyyyMMdd")
                Session("current_data_version") = currentDataVer
            Else
                currentDataVer = Session("current_data_version")
            End If

            InitVariables()

            'Section 1: Get Basic Info
            Dim hasError As Boolean = False
            LoadProfileBasic(profileId, hasError)
            If hasError Then
                Return
            End If


            'Section 2: Load Last Version
            Dim bHaveProfileLast As Boolean = False
            bHaveProfileLast = LoadProfileLast(profileId, currentDataVer)

            'Section 3: Projects within profile
            'Load all profile projects
            dtProjects = pmaPrjService.GetProjectViewList(prjCodes)
            showMetricPerProfile = lookupService.GetLookUpName("S", "MISC", "Show_Metric_Per_Profile")
            saveMetricRaw2Db = lookupService.GetLookUpName("S", "MISC", "Save_Metric_Raw_Directly")
            'Load Project Metric Records for profile main code
            LoadProjectCodesDropDown()


            'Section 4: Project Metric & Metric Raw
            'Load Metric Target
            LoadMetricTarget()

            'Load metrics for all profile projects
            LoadMetrics4AllProjects(prjCodes, currentDataVer)

            'Load metric raws for all profile projects
            'LoadMetricRaws4AllProjects(prjCodes, currentDataVer)
            'Loas metrics & metric raws of last version for all profile projects
            If bHaveProfileLast Then
                dtPrjMetricsLast = prjMetricService.GetProjectMetricHist(prjCodesLast.Split(","), lastDataVer)
                dtPrjMetricRawLast = prjMetricRawService.GetProjectMetricRawHist(prjCodesLast.Split(","), lastDataVer)
            End If
            'Load metric for current project
            PreparePrjMetricsData(currentPrjCode, currentDataVer)
            'Load metric raw for current project
            'PreparePrjMetricRawData(currentPrjCode, currentDataVer)
        End If

    End Sub

#Region "Init"
    Sub InitVariables()
        lblTssPrj.Text = ""
        prfId.Text = ""
        lblCurrentPrjCodeHidden.Text = ""
        lblPrjCodes.Text = ""
        lblPrjCodesLast.Text = ""
        lblDataVerLast.Text = ""
        lblCurrentPrjCode.Text = ""
        txtHealthSta.Value = ""
        txtQualitySta.Text = ""
        txtScopeSta.Value = ""
        txtCostSta.Text = ""
        txtScheduleSta.Text = ""
        txtResourceSta.Value = ""
        txtCssSta.Text = ""
        Session("last_data_version") = Nothing
        Session("hsPrjMetricRaw") = Nothing
        Session("metric_target_year") = Nothing
        'Session("tss_prj") = Nothing
    End Sub
    

#End Region
#Region "Profile_Basic"
    Sub LoadProfileBasic(ByVal profileId As Integer, ByRef hasError As Boolean)

        dtProfile = prfService.GetProfile(profileId)
        'Dim sTssPrj As String = ""

        If dtProfile Is Nothing Then
            hasError = True
            sErrMsgBuilder = New StringBuilder("Failed to load profile data.")
            logHelper.WriteLog("failed to load profile.")
            Return

        ElseIf dtProfile.Rows.Count = 0 Then
            hasError = True
            sErrMsgBuilder = New StringBuilder("Failed to load profile data.")
            logHelper.WriteLog("failed to load profile.")
            Return
        End If

        Dim drProfile As DataRow = dtProfile.Rows(0)

        sTssPrj = drProfile("TSS_PRJ").ToString
        lblTssPrj.Text = drProfile("TSS_PRJ").ToString
        sTssPrjName = pmaTssPrjService.GetTssProjectNameByCode(sTssPrj)
        prjCodes = drProfile("PRJ_CODES").ToString
        lblPrjCodes.Text = prjCodes

        prfMainCode = drProfile("PRF_MAIN_CODE").ToString.Trim
        lblPrfMainCode.Text = prfMainCode

        Dim sPrfDesc As String = drProfile("PRF_DESC").ToString.Trim
        Dim prfHidden As HiddenField = New HiddenField
        If Not Me.Master.FindControl("prfDesc") Is Nothing Then
            prfHidden = CType(Me.Master.FindControl("prfDesc"), HiddenField)
            prfHidden.Value = sPrfDesc
        End If

        'sHealthStaBefore = drProfile("health_status").ToString.Trim
        'sQualityStaBefore = drProfile("quality_status").ToString.Trim
        'sScopeStaBefore = drProfile("scope_status").ToString.Trim
        'sCostStaBefore = drProfile("cost_status").ToString.Trim
        'sResourceStaBefore = drProfile("resource_status").ToString.Trim
        'sCSSStaBefore = drProfile("css_status").ToString.Trim
        'sScheduleStaBefore = drProfile("schedule_status").ToString.Trim

        txtHealthSta.Value = drProfile("health_status").ToString.Trim
        txtQualitySta.Text = drProfile("quality_status").ToString.Trim
        txtScopeSta.Value = drProfile("scope_status").ToString.Trim
        txtCostSta.Text = drProfile("cost_status").ToString.Trim
        txtScheduleSta.Text = drProfile("schedule_status").ToString.Trim
        txtResourceSta.Value = drProfile("resource_status").ToString.Trim
        txtCssSta.Text = drProfile("css_status").ToString.Trim


        'prfHealthSta.costStatus = sCostStaBefore
        'prfHealthSta.cssStatus = sCSSStaBefore
        'prfHealthSta.qualityStatus = sQualityStaBefore
        'prfHealthSta.resourceStatus = sResourceStaBefore
        'prfHealthSta.scheduleStatus = sScheduleStaBefore
        'prfHealthSta.scopeStatus = sScopeStaBefore

    End Sub

    Function LoadProfileLast(ByVal profileId As Integer, ByVal currentDataVer As String) As Boolean
        Dim bHaveProfileLast As Boolean = False

        Dim dtProfileLast As DataTable = prfService.GetProfileHistLast(profileId, currentDataVer)

        If Not dtProfileLast Is Nothing Then
            If dtProfileLast.Rows.Count > 0 Then
                bHaveProfileLast = True
                lastDataVer = dtProfileLast.Rows(0).Item("data_version").ToString
                Session("last_data_version") = dtProfileLast.Rows(0).Item("data_version").ToString
                lblPrjCodesLast.Text = dtProfileLast.Rows(0).Item("prj_codes").ToString
                lblDataVerLast.Text = lastDataVer
            End If
        End If

        LoadProfileLast = bHaveProfileLast
        dtProfileLast = Nothing

    End Function
#End Region

#Region "Profile_SR"
    'Load projects' dropdown, set main master code as defaule.
    Sub LoadProjectCodesDropDown()
        If showMetricPerProfile.ToUpper = "Y" Then
            currentPrjCode = prfMainCode
        ElseIf Not String.IsNullOrEmpty(prjCodes) Then
            Dim prjCode() As String = prjCodes.Split(",")

            If Not prjCode Is Nothing Then
                For i As Integer = 0 To prjCode.Length - 1
                    lstPrjCodes.Items.Add(New ListItem(prjCode(i)))
                Next
                If prjCode.Length > 0 Then
                    lstPrjCodes.SelectedValue = prfMainCode
                    currentPrjCode = lstPrjCodes.SelectedValue
                End If
            End If
        End If
        lblCurrentPrjCode.Text = currentPrjCode
        lblCurrentPrjCodeHidden.Text = currentPrjCode
    End Sub
#End Region

#Region "Prj_Metric"
    'Load all project within profile
    Sub LoadMetrics4AllProjects(ByVal prjCodes As String, ByVal currentDataVer As String)
        dtPrjMetrics = prjMetricService.GetProjectMetric(prjCodes.Split(","))
        dtPrjMetrics.PrimaryKey = {dtPrjMetrics.Columns("id")}
    End Sub

    Sub LoadMetricTarget()
        'Retrieve metric target list for specific tss service category having latest target records
        sMetricTargetYear = metricTargetService.GetLatestMetricTargetYear(sTssPrj)
        Session("metric_target_year") = sMetricTargetYear
        If Not String.IsNullOrEmpty(sMetricTargetYear) Then
            dtMetricsTarget = metricTargetService.GetMetricTargetList(sMetricTargetYear, sTssPrj)
        End If
    End Sub

    'Step 4: Prepare view data for front end data layout rendering
    Private Sub PreparePrjMetricsData(ByVal currentPrjCode As String, ByVal currentDataVer As String)
        'Retrieve required project metric list for specific tss service category
        dtPrjMetricsView = metricService.GetMetricListByTssPrj(lblTssPrj.Text, "Y")

        If dtPrjMetricsView Is Nothing Then
            Return
        ElseIf dtPrjMetricsView.Rows.Count = 0 Then
            WebControlHelper.GridViewDataBind(gvMetrics, dtPrjMetricsView)
            Return
        End If

        'Remove Copq
        Dim bRemoveCopq As Boolean = False
        If IsDBNull(dtProfile.Rows(0).Item("fixed_price_project")) Then
            bRemoveCopq = True
        ElseIf dtProfile.Rows(0).Item("fixed_price_project").ToString.Trim.ToUpper <> "Y" Then
            bRemoveCopq = True
        End If

        If bRemoveCopq Then
            Dim dr As DataRow() = dtPrjMetricsView.Select("fixed_price_project <> 'Y'")

            If dr Is Nothing Then
                Return
            ElseIf dr.Length = 0 Then
                dtPrjMetricsView = dtPrjMetricsView.Clone
                WebControlHelper.GridViewDataBind(gvMetrics, dtPrjMetricsView)
                Return
            End If

            dtPrjMetricsView = dr.CopyToDataTable
        End If

        'LoadMetricTarget()

        'Retrieve project metric list for the selected project
        Dim drPrjMetrics As DataRow() = dtPrjMetrics.Select("prj_code = '" & currentPrjCode & "'")

        'target metric config section
        dtPrjMetricsView.Columns.Add("metric_year")
        dtPrjMetricsView.Columns.Add("metric_target_id")
        dtPrjMetricsView.Columns.Add("metric_target_val")
        dtPrjMetricsView.Columns.Add("metric_prj_id")

        'Project metric section
        dtPrjMetricsView.Columns.Add("metric_prj_val")
        dtPrjMetricsView.Columns.Add("metric_prj_status")
        dtPrjMetricsView.Columns.Add("percentage")

        'Project metric for Last
        dtPrjMetricsView.Columns.Add("metric_prj_val_last")
        dtPrjMetricsView.Columns.Add("metric_prj_status_last")

        For Each drPrjMetricView As DataRow In dtPrjMetricsView.Rows

            If drPrjMetricView("metric_val_type") = "P" Then
                drPrjMetricView("percentage") = "%"
            End If

            Dim sMetricCode As String = drPrjMetricView("metric_code")
            Dim sMetricValType As String = drPrjMetricView("metric_val_type")
            Dim iMetricValPrec As Integer = drPrjMetricView("metric_val_precision")

            'Retrieve target data
            If Not dtMetricsTarget Is Nothing Then
                If dtMetricsTarget.Rows.Count > 0 Then
                    Dim drPrjMetricTgt As DataRow() = dtMetricsTarget.Select("metric_code = '" & sMetricCode & "'")
                    If Not drPrjMetricTgt Is Nothing Then
                        If drPrjMetricTgt.Length > 0 Then
                            drPrjMetricView("metric_year") = drPrjMetricTgt(0)("metric_year").ToString.Trim
                            drPrjMetricView("metric_target_id") = drPrjMetricTgt(0)("metric_target_id")
                            drPrjMetricView("metric_target_val") = DataFormatHelper.FormatString(drPrjMetricTgt(0)("metric_val").ToString, sMetricValType, iMetricValPrec)
                        End If
                    End If
                End If
            End If

            'Retrieve Project metric data
            If Not drPrjMetrics Is Nothing Then
                If drPrjMetrics.Length > 0 Then
                    Dim dr As DataRow() = drPrjMetrics.CopyToDataTable.Select("metric_code = '" & sMetricCode & "'")
                    If Not dr Is Nothing Then
                        If dr.Length > 0 Then
                            drPrjMetricView("metric_prj_id") = dr(0)("id")
                            Dim decPrjMetricVal As Decimal
                            If Not IsDBNull(dr(0)("metric_val")) Then
                                decPrjMetricVal = dr(0)("metric_val")
                                drPrjMetricView("metric_prj_val") = DataFormatHelper.FormatString(decPrjMetricVal, sMetricValType, iMetricValPrec)
                            End If
                            If Not IsDBNull(dr(0)("metric_status")) Then
                                drPrjMetricView("metric_prj_status") = dr(0)("metric_status").ToString
                            End If
                        End If
                    End If
                End If
            End If 'End If Not drPrjMetrics Is Nothing

            'Retrieve Last version of Project Metric Data
            If Not dtPrjMetricsLast Is Nothing Then
                If dtPrjMetricsLast.Rows.Count > 0 Then
                    Dim drPrjMetricslast As DataRow() = dtPrjMetricsLast.Select("metric_code = '" & sMetricCode & "'")
                    If Not drPrjMetricslast Is Nothing Then
                        If drPrjMetricslast.Length > 0 Then
                            If Not IsDBNull(drPrjMetricslast(0)("metric_val")) Then
                                drPrjMetricView("metric_prj_val_last") = DataFormatHelper.FormatString(drPrjMetricslast(0)("metric_val"), sMetricValType, iMetricValPrec)
                                drPrjMetricView("metric_prj_status_last") = drPrjMetricslast(0)("metric_status").ToString
                            End If
                        End If
                    End If
                End If
            End If


        Next 'End  For Each drPrjMetricView As DataRow In dtPrjMetricsView.Rows


        If Not dtPrjMetricsView Is Nothing Then
            WebControlHelper.GridViewDataBind(gvMetrics, dtPrjMetricsView, False)
        End If
    End Sub

    'Step 5: Rendering layout
    Dim iParentRowMetric As Integer = 0
    Private Sub gvMetrics_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvMetrics.RowDataBound

        If e.Row.RowType = DataControlRowType.Header Then
            'e.Row.Cells(0).Text = sTssPrjName

            If Not String.IsNullOrEmpty(Session("last_data_version")) Then
                e.Row.Cells(3).Text = Session("last_data_version")
            End If
        End If

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drView As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim sMetricValType As String = ""
            Dim iMetricValPrecision As Integer = 0
            Dim sMetricSta As String = ""

            If Not drView Is Nothing Then
                sMetricValType = drView("metric_val_type").ToString
                iMetricValPrecision = DataFormatHelper.StringToInteger(drView("metric_val_precision").ToString)

                If Not IsDBNull(drView("metric_prj_status")) Then
                    If Not e.Row.FindControl("txtPrjMetricStaHidden") Is Nothing Then
                        Dim txtPrjMetricStaHidden As HiddenField = New HiddenField

                        txtPrjMetricStaHidden = CType(e.Row.FindControl("txtPrjMetricStaHidden"), HiddenField)
                        sMetricSta = txtPrjMetricStaHidden.Value

                        Dim iMetricSta As HtmlGenericControl = New HtmlGenericControl
                        If Not e.Row.FindControl("iMetricSta") Is Nothing Then
                            iMetricSta = CType(e.Row.FindControl("iMetricSta"), HtmlGenericControl)
                            Select Case sMetricSta
                                Case "R"
                                    iMetricSta.Style.Add("color", "Red")
                                Case "A"
                                    iMetricSta.Style.Add("color", "#f0ad4e")
                                Case "G"
                                    iMetricSta.Style.Add("color", "Green")
                            End Select
                        End If
                    End If

                End If

                If Not IsDBNull(drView("metric_prj_status_last")) Then
                    If Not e.Row.FindControl("txtPrjMetricStaLastHidden") Is Nothing Then
                        Dim txtPrjMetricStaLastHidden As HiddenField = New HiddenField

                        txtPrjMetricStaLastHidden = CType(e.Row.FindControl("txtPrjMetricStaLastHidden"), HiddenField)
                        Dim sMetricStaLast As String = txtPrjMetricStaLastHidden.Value

                        Dim iMetricStaLast As HtmlGenericControl = New HtmlGenericControl
                        If Not e.Row.FindControl("iMetricStaLast") Is Nothing Then
                            iMetricStaLast = CType(e.Row.FindControl("iMetricStaLast"), HtmlGenericControl)
                            Select Case sMetricStaLast
                                Case "R"
                                    iMetricStaLast.Style.Add("color", "Red")
                                Case "A"
                                    iMetricStaLast.Style.Add("color", "#f0ad4e")
                                Case "G"
                                    iMetricStaLast.Style.Add("color", "Green")
                            End Select
                        End If
                    End If

                End If
            End If

            'e.Row.Cells(3).Text = DataFormatHelper.FormatString(e.Row.Cells(3).Text, sMetricValType, iMetricValPrecision)

            WebControlHelper.GridViewCellMerging(gvMetrics, e, 0, iParentRowMetric)

        End If
    End Sub


    Sub ReLoadPrjMetric()
        LoadMetricTarget()
        'Load metrics for all profile projects
        LoadMetrics4AllProjects(lblPrjCodes.Text.Trim, Session("current_data_version"))
        If Not String.IsNullOrEmpty(lblDataVerLast.Text.Trim) Then
            dtPrjMetricsLast = prjMetricService.GetProjectMetricHist(lblPrjCodesLast.Text.Trim.Split(","), lblDataVerLast.Text.Trim)
        End If
        PreparePrjMetricsData(lblCurrentPrjCode.Text.Trim, Session("current_data_version"))
    End Sub

    'Rebind gridview
    'Sub ReBindData(ByVal currentPrjCode As String, ByRef dtPrjMetrics As DataTable, ByRef dtPrjMetricsView As DataTable)
    '    For Each drPrjMetricView In dtPrjMetricsView.Rows
    '        Dim sPrjMetricCodeView As String = drPrjMetricView("metric_code")
    '        Dim drList As DataRow() = dtPrjMetrics.Select("metric_code = '" & sPrjMetricCodeView & "' and prj_code = '" & currentPrjCode & "'")
    '        If drList.Length > 0 Then
    '            drPrjMetricView("metric_prj_val") = drList(0).Item("metric_val")
    '            drPrjMetricView("metric_prj_status") = drList(0).Item("metric_status")
    '            dtPrjMetricsView.AcceptChanges()
    '        End If
    '    Next

    '    WebControlHelper.GridViewDataBind(gvMetrics, dtPrjMetricsView, False)

    'End Sub

    Public Sub btnUpdRaw_Click()
        Try
            'PreparePrjMetricRawData(lblPrjCodes.Text.Trim, Session("current_data_version"))
            PreparePrjMetricRawData(Session("current_data_version"))
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", "openModal('modalMetricRawList', true);", True)
        Catch ex As Exception
            logHelper.WriteLog("Error occured while initializing metric raw data", ex)
        End Try
    End Sub
#End Region


#Region "Metric_Raw"
    'Load all project metric raw within profile
    Sub LoadMetricRaws4AllProjects(ByVal prjCodes As String, ByVal currentDataVer As String)
        dtPrjMetricRaw = prjMetricRawService.GetProjectMetricRawList(prjCodes.Split(","))
        dtPrjMetricRaw.PrimaryKey = {dtPrjMetricRaw.Columns("id")}
    End Sub

    'Public Sub PreparePrjMetricRawData(ByVal currentPrjCode As String, ByVal currentDataVer As String)
    Public Sub PreparePrjMetricRawData(ByVal currentDataVer As String)
        Dim hsPrjMetricRaw As Hashtable = New Hashtable

        LoadMetricRaws4AllProjects(lblPrjCodes.Text.Trim, currentDataVer)

        'Retrieve all metric raws required manual / upload input
        dtPrjMetricRawsView = metricRawService.GetMetricRawList("Y")

        If dtPrjMetricRawsView Is Nothing Then
            Return
        ElseIf dtPrjMetricRawsView.Rows.Count = 0 Then
            Return
        End If

        dtPrjMetricRawsView = dtPrjMetricRawsView.Select("1=1", "data_source asc").CopyToDataTable

        dtPrjMetricRawsView.Columns.Add("required")
        dtPrjMetricRawsView.Columns.Add("metric_code")
        dtPrjMetricRawsView.Columns.Add("prj_metric_raw_id")
        dtPrjMetricRawsView.Columns.Add("prj_code")
        dtPrjMetricRawsView.Columns.Add("prj_metric_raw_val")
        dtPrjMetricRawsView.Columns.Add("prj_metric_raw_val_last")

        Dim dtPrjKpi As DataTable = New DataTable
        'dtPrjKpi = pmaPrjService.GetProjectKpi(currentPrjCode, Session("current_data_version"))
        dtPrjKpi = pmaPrjService.GetProjectKpi(lblCurrentPrjCodeHidden.Text, Session("current_data_version"))

        'For Each drPrjMetric As DataRow In dtPrjMetricsView.Rows
        'Dim sMetricCode As String = drPrjMetric("metric_code").ToString 'Metric Code
        For i As Integer = 0 To gvMetrics.Rows.Count - 1
            Dim sMetricCode As String = ""
            Dim txtMetricCode As HiddenField = New HiddenField
            If Not gvMetrics.Rows(i).FindControl("txtMetricCode") Is Nothing Then
                txtMetricCode = CType(gvMetrics.Rows(i).FindControl("txtMetricCode"), HiddenField)
                sMetricCode = txtMetricCode.Value.Trim
            End If

            If String.IsNullOrEmpty(sMetricCode) Then
                Continue For
            End If
            'Retrieve required metric raw list for specific prject metric
            For Each drPrjMetricRawsView As DataRow In dtPrjMetricRawsView.Rows
                Dim sMetricRawCode As String = ""
                sMetricRawCode = drPrjMetricRawsView("code")  'Metric Raw Code

                '
                If hsPrjMetricRaw.ContainsKey(sMetricRawCode) Then
                    Continue For
                End If

                'Mark the metric raw as required
                Dim bMetricRawMapped As Boolean = metricRawMappingService.IsMappingFound(sMetricCode, sMetricRawCode)
                If Not bMetricRawMapped Then
                    Continue For
                End If 'End If metricRawMappingService.IsMappingFound(sMetricCode, sMetricRawCode)

                drPrjMetricRawsView("required") = "Y"

                currentPrjCode = lblCurrentPrjCodeHidden.Text.Trim
                Dim drPrjMetricRawReads As DataRow() = dtPrjMetricRaw.Select("prj_code = '" & currentPrjCode & "' and metric_raw_code = '" & sMetricRawCode & "'")
                'Dim drPrjMetricRawReads As DataRow() = dtPrjMetricRaw.Select("prj_code = '" & lblCurrentPrjCodeHidden.Text.Trim & "' and metric_raw_code = '" & sMetricRawCode & "'")
                If drPrjMetricRawReads Is Nothing Then
                    Continue For
                ElseIf drPrjMetricRawReads.Length = 0 And String.Compare(drPrjMetricRawsView("data_source").ToString, "S", True) <> 0 Then
                    Continue For
                End If

                'Load DB record if any
                If drPrjMetricRawReads.Length > 0 Then
                    If Not IsDBNull(drPrjMetricRawReads(0)("metric_raw_val")) Then
                        drPrjMetricRawsView("prj_metric_raw_id") = drPrjMetricRawReads(0)("id")
                        drPrjMetricRawsView("prj_metric_raw_val") = drPrjMetricRawReads(0)("metric_raw_val")
                        hsPrjMetricRaw.Add(sMetricRawCode, drPrjMetricRawReads(0)("metric_raw_val"))
                    End If
                End If

                'Recalculate system data
                Dim sRecalMetricRawPrjVal As String = ""
                Select Case sMetricRawCode
                    Case "actual_effort"
                        'Dim dtPrj As DataTable = pmaPrjService.GetProjectViewList(dtProfile.Rows(0).Item("PRJ_CODES"))
                        Dim dtPrj As DataTable = pmaPrjService.GetProjectViewList(lblPrjCodes.Text.Trim)
                        If Not dtPrj Is Nothing Then
                            If dtPrj.Rows.Count > 0 Then
                                sRecalMetricRawPrjVal = IIf(Convert.IsDBNull(dtPrj.Compute("SUM(actl_hours_accrual)", "")), "", dtPrj.Compute("SUM(actl_hours_accrual)", ""))
                            End If
                        End If
                        dtPrj.Dispose()

                    Case "failure_effort"
                        Dim pmaTaskService As IPmaTaskService = New PmaTaskService
                        'sRecalMetricRawPrjVal = pmaTaskService.getFailureEffort(dtProfile.Rows(0).Item("PRJ_CODES"), Session("current_data_version"))
                        sRecalMetricRawPrjVal = pmaTaskService.getFailureEffort(lblPrjCodes.Text.Trim, currentDataVer)

                    Case "ev"
                        If Not dtPrjKpi Is Nothing Then
                            If dtPrjKpi.Rows.Count > 0 Then
                                sRecalMetricRawPrjVal = dtPrjKpi.Rows(0).Item("EV").ToString.Trim
                            End If
                        End If

                    Case "pv"
                        If Not dtPrjKpi Is Nothing Then
                            If dtPrjKpi.Rows.Count > 0 Then
                                sRecalMetricRawPrjVal = dtPrjKpi.Rows(0).Item("PV").ToString.Trim
                            End If
                        End If
                    Case "ac"
                        If Not dtPrjKpi Is Nothing Then
                            If dtPrjKpi.Rows.Count > 0 Then
                                sRecalMetricRawPrjVal = dtPrjKpi.Rows(0).Item("AC").ToString.Trim
                            End If
                        End If
                End Select

                If sMetricRawCode = "actual_effort" Or sMetricRawCode = "failure_effort" Or _
                    sMetricRawCode = "ev" Or sMetricRawCode = "pv" Or sMetricRawCode = "ac" Then
                    drPrjMetricRawsView("prj_metric_raw_val") = IIf(IsNumeric(sRecalMetricRawPrjVal), sRecalMetricRawPrjVal, 0)

                    If hsPrjMetricRaw.ContainsKey(sMetricRawCode) Then
                        hsPrjMetricRaw(sMetricRawCode) = IIf(IsNumeric(sRecalMetricRawPrjVal), sRecalMetricRawPrjVal, 0)
                    End If

                End If


            Next 'End For Each drMetricRaw As DataRow In dtMetricRaws.Rows

        Next 'End For Each drPrjMetric As DataRow In dtPrjMetricsView.Rows

        For Each drPrjMetricRawsView As DataRow In dtPrjMetricRawsView.Rows
            If IsDBNull(drPrjMetricRawsView("required")) Then
                drPrjMetricRawsView.Delete()
            End If
        Next

        If dtPrjMetricRawsView.Rows.Count > 0 Then
            WebControlHelper.GridViewDataBind(gvMetricRawList, dtPrjMetricRawsView, False)
        End If

        If Not hsPrjMetricRaw Is Nothing Then
            Session("hsPrjMetricRaw") = hsPrjMetricRaw
        End If

    End Sub

    'Save button for metric raw data update
    Sub btnSaveRaw_Click()
        Dim bSave As Boolean = False
        Dim hsPrjMetricRawSave As Hashtable = New Hashtable
        Dim bSavePrjMetricRaw As Boolean = False
        Dim bSavePrjMetric As Boolean = False
        Dim bSaveProfile As Boolean = False
        'Dim hshsPrjMetricRaw As Hashtable = Session("hsPrjMetricRaw")

        Try
            currentDataVer = Session("current_data_version")
            LoadMetricRaws4AllProjects(lblPrjCodes.Text.Trim, currentDataVer)
            If PrepareSave4ManualMetricRaw(gvMetricRawList, dtPrjMetricRaw, hsPrjMetricRawSave) Then
                bSavePrjMetricRaw = True
            End If

            If bSavePrjMetricRaw Then
                LoadMetrics4AllProjects(lblPrjCodes.Text.Trim, currentDataVer)
                If Not gvMetrics.DataSource() Is Nothing Then
                    'dtPrjMetrics()
                End If
                bSavePrjMetric = PrepareSave4Metric(gvMetrics, dtPrjMetrics, hsPrjMetricRawSave)

                If bSavePrjMetric Then
                    'bSavePrjMetric = True
                    dtProfile = prfService.GetProfile(Session("prf_id"))
                    bSaveProfile = PrepareSave4ProfileStatus(dtProfile, dtPrjMetrics)
                End If
            End If

            If Not String.IsNullOrEmpty(saveMetricRaw2Db) Then
                If Trim(saveMetricRaw2Db).ToUpper = "Y" And (bSaveProfile Or bSavePrjMetric Or bSavePrjMetricRaw) Then
                    bSave = SaveProfile(dtProfile, dtPrjMetrics, dtPrjMetricRaw, True)
                End If
            End If

            If bSave Then
                logHelper.WriteLog("Project metric is updated by " & Session("logon_id") & " on " & Now.ToString)
                Session("fromPg") = PROFILESTATUS.DRAFT
                'LoadMetrics(dtProfile, dtProfile.Rows(0).Item("prj_codes").ToString, Nothing)
                ReLoadPrjMetric()
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Project metric raw data is updated successfully.');</script>", False)
            Else
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Failed to update project metric raw data.');</script>", False)
            End If
        Catch ex As Exception
            logHelper.WriteLog("Error occured while updating metric raw data", ex)
        End Try


    End Sub

    'Save manual input
    Private Function PrepareSave4ManualMetricRaw(ByRef gv As GridView, ByRef dtPrjMetricRaw As DataTable, _
                                                 ByRef hsPrjMetricRawSave As Hashtable) As Boolean
        Dim bSave As Boolean = False
        currentPrjCode = lblCurrentPrjCode.Text.Trim
        Dim hsPrjMetricRaw As Hashtable
        If Session("hsPrjMetricRaw") Is Nothing Then
            Return bSave
        Else
            hsPrjMetricRaw = Session("hsPrjMetricRaw")
        End If

        'Check changes from online manual input
        For i As Integer = 0 To gv.Rows.Count - 1
            If gv.Rows(i).RowType = DataControlRowType.DataRow Then

                Dim sMetricRawCode As String = ""
                If Not IsDBNull(gv.DataKeys(i).Values(0)) Then
                    sMetricRawCode = gv.DataKeys(i).Values(0)
                End If

                Dim txtMetricRawPrjVal As TextBox = New TextBox
                If Not gv.Rows(i).FindControl("txtMetricRawPrjVal") Is Nothing Then
                    txtMetricRawPrjVal = CType(gv.Rows(i).FindControl("txtMetricRawPrjVal"), TextBox)
                End If
                Dim sRawVal As String = txtMetricRawPrjVal.Text

                Dim txtMetricRawPrjId As HiddenField = New HiddenField
                If Not gv.Rows(i).FindControl("txtMetricRawPrjId") Is Nothing Then
                    txtMetricRawPrjId = CType(gv.Rows(i).FindControl("txtMetricRawPrjId"), HiddenField)
                End If
                Dim sPrjRawId As String = txtMetricRawPrjId.Value

                If Not String.IsNullOrEmpty(txtMetricRawPrjVal.Text) Then
                    hsPrjMetricRawSave.Add(sMetricRawCode, sRawVal)
                End If

                Dim drPrjMetricRawSave As DataRow = Nothing
                If Not hsPrjMetricRaw.ContainsKey(sMetricRawCode) And Not hsPrjMetricRawSave.ContainsKey(sMetricRawCode) Then 'No record

                ElseIf Not hsPrjMetricRaw.ContainsKey(sMetricRawCode) And hsPrjMetricRawSave.ContainsKey(sMetricRawCode) Then 'Add
                    drPrjMetricRawSave = dtPrjMetricRaw.NewRow
                    drPrjMetricRawSave("prj_code") = currentPrjCode
                    drPrjMetricRawSave("metric_raw_code") = sMetricRawCode
                    drPrjMetricRawSave("metric_raw_val") = sRawVal

                    drPrjMetricRawSave("is_active") = "Y"
                    drPrjMetricRawSave("created_by") = Session("logon_id")
                    drPrjMetricRawSave("created_dt") = Now
                    drPrjMetricRawSave("last_updated_by") = Session("logon_id")
                    drPrjMetricRawSave("last_updated_dt") = Now

                    dtPrjMetricRaw.Rows.Add(drPrjMetricRawSave)

                    bSave = True

                ElseIf hsPrjMetricRaw.ContainsKey(sMetricRawCode) And Not hsPrjMetricRawSave.ContainsKey(sMetricRawCode) Then 'Delete
                    drPrjMetricRawSave = dtPrjMetricRaw.Rows.Find(sPrjRawId)

                    drPrjMetricRawSave.Delete()

                    bSave = True
                ElseIf hsPrjMetricRaw.Item(sMetricRawCode).ToString <> hsPrjMetricRawSave.Item(sMetricRawCode).ToString Then 'Update
                    drPrjMetricRawSave = dtPrjMetricRaw.Rows.Find(sPrjRawId)
                    drPrjMetricRawSave("metric_raw_val") = sRawVal

                    drPrjMetricRawSave("last_updated_by") = Session("logon_id")
                    drPrjMetricRawSave("last_updated_dt") = Now

                    bSave = True
                End If

            End If
        Next

        Return bSave
    End Function

    'Save system data
    Private Function PrepareSave4SystemMetricRaw(ByRef dtPrjMetricRaw As DataTable, ByRef hsPrjMetricRawSave As Hashtable) As Boolean
        Dim bSave As Boolean = False
        currentPrjCode = lblCurrentPrjCodeHidden.Text.Trim
        prjCodes = lblPrjCodes.Text.Trim

        Dim dtMetricRawSys As DataTable = New DataTable
        dtMetricRawSys = metricRawService.GetMetricRawListBySrc("S")

        If Not dtMetricRawSys Is Nothing Then
            Dim dtPrjKpi As DataTable = New DataTable
            dtPrjKpi = pmaPrjService.GetProjectKpi(currentPrjCode, Session("current_data_version"))
            For Each drMetricRawSys As DataRow In dtMetricRawSys.Rows
                Dim sMetricRawCode As String = drMetricRawSys("code").ToString
                Dim sMetricRawPrjVal As String = ""

                If Not hsPrjMetricRawSave.ContainsKey(sMetricRawCode) Then
                    Select Case sMetricRawCode
                        Case "actual_effort"
                            Dim dtPrj As DataTable = pmaPrjService.GetProjectViewList(prjCodes)
                            If Not dtPrj Is Nothing Then
                                If dtPrj.Rows.Count > 0 Then
                                    sMetricRawPrjVal = IIf(Convert.IsDBNull(dtPrj.Compute("SUM(actl_hours_accrual)", "")), "", dtPrj.Compute("SUM(actl_hours_accrual)", ""))
                                End If
                            End If
                            dtPrj.Dispose()

                        Case "failure_effort"
                            Dim pmaTaskService As IPmaTaskService = New PmaTaskService
                            sMetricRawPrjVal = pmaTaskService.getFailureEffort(prjCodes, Session("current_data_version"))

                        Case "ev"
                            If Not dtPrjKpi Is Nothing Then
                                If dtPrjKpi.Rows.Count > 0 Then
                                    sMetricRawPrjVal = dtPrjKpi.Rows(0).Item("EV").ToString.Trim
                                End If
                            End If

                        Case "pv"
                            If Not dtPrjKpi Is Nothing Then
                                If dtPrjKpi.Rows.Count > 0 Then
                                    sMetricRawPrjVal = dtPrjKpi.Rows(0).Item("PV").ToString.Trim
                                End If
                            End If
                        Case "ac"
                            If Not dtPrjKpi Is Nothing Then
                                If dtPrjKpi.Rows.Count > 0 Then
                                    sMetricRawPrjVal = dtPrjKpi.Rows(0).Item("AC").ToString.Trim
                                End If
                            End If
                    End Select

                    hsPrjMetricRawSave.Add(sMetricRawCode, sMetricRawPrjVal)


                    Dim drPrjMetricRawSave As DataRow = Nothing
                    Dim drPrjMetricRawList As DataRow() = dtPrjMetricRaw.Select("prj_code = '" & currentPrjCode & "' and metric_raw_code = '" & sMetricRawCode & "'")
                    If drPrjMetricRawList.Length = 0 Then 'Add
                        If Not String.IsNullOrEmpty(sMetricRawPrjVal) Then
                            drPrjMetricRawSave = dtPrjMetricRaw.NewRow
                            drPrjMetricRawSave("prj_code") = currentPrjCode
                            drPrjMetricRawSave("metric_raw_code") = sMetricRawCode
                            If IsNumeric(sMetricRawPrjVal) Then
                                drPrjMetricRawSave("metric_raw_val") = sMetricRawPrjVal
                                bSave = True
                            End If

                            If bSave Then
                                drPrjMetricRawSave("is_active") = "Y"
                                drPrjMetricRawSave("created_by") = Session("logon_id")
                                drPrjMetricRawSave("created_dt") = Now
                                drPrjMetricRawSave("last_updated_by") = Session("logon_id")
                                drPrjMetricRawSave("last_updated_dt") = Now

                                dtPrjMetricRaw.Rows.Add(drPrjMetricRawSave)
                            End If

                        End If

                    ElseIf Not hsPrjMetricRawSave.ContainsKey(sMetricRawCode) Then 'Delete
                        drPrjMetricRawSave = drPrjMetricRawList(0)
                        drPrjMetricRawSave.Delete()
                        bSave = True

                    Else 'Update
                        drPrjMetricRawSave = drPrjMetricRawList(0)
                        If IsDBNull(drPrjMetricRawSave("metric_raw_val")) And IsNumeric(sMetricRawPrjVal) Then
                            drPrjMetricRawSave("metric_raw_val") = Convert.ToDecimal(sMetricRawPrjVal)
                            bSave = True
                        ElseIf Not IsDBNull(drPrjMetricRawSave("metric_raw_val")) And IsNumeric(sMetricRawPrjVal) Then
                            If drPrjMetricRawSave("metric_raw_val") <> Convert.ToDecimal(sMetricRawPrjVal) Then
                                drPrjMetricRawSave("metric_raw_val") = Convert.ToDecimal(sMetricRawPrjVal)
                                bSave = True
                            End If
                        ElseIf Not IsDBNull(drPrjMetricRawSave("metric_raw_val")) And Not IsNumeric(sMetricRawPrjVal) Then
                            drPrjMetricRawSave("metric_raw_val") = 0
                            bSave = True
                        End If

                        If bSave Then
                            drPrjMetricRawSave("last_updated_by") = Session("logon_id")
                            drPrjMetricRawSave("last_updated_dt") = Now
                        End If
                    End If
                End If

            Next
        End If

        PrepareSave4SystemMetricRaw = bSave
    End Function

    'Recalculate metric value and metric status
    Private Function PrepareSave4Metric(ByRef gvMetrics As GridView, ByRef dtPrjMetric As DataTable, ByRef hsPrjMetricRawSave As Hashtable) As Boolean

        Dim bSave As Boolean = True
        currentDataVer = Session("current_data_version")

        Try
            For i As Integer = 0 To gvMetrics.Rows.Count - 1
                If gvMetrics.Rows(i).RowType = DataControlRowType.DataRow Then
                    Dim gvrMetric As GridViewRow = gvMetrics.Rows(i)
                    Dim drMetricView As DataRowView = CType(gvMetrics.Rows(i).DataItem, DataRowView)
                    If Not gvrMetric Is Nothing Then

                        Dim sMetricCode As String = ""
                        Dim txtMetricCode As HiddenField = New HiddenField
                        If Not gvrMetric.FindControl("txtMetricCode") Is Nothing Then
                            txtMetricCode = CType(gvrMetric.FindControl("txtMetricCode"), HiddenField)
                            sMetricCode = txtMetricCode.Value
                        End If

                        Dim sMetricValType As String = ""
                        Dim txtMetricValType As HiddenField = New HiddenField
                        If Not gvrMetric.FindControl("txtMetricValType") Is Nothing Then
                            txtMetricValType = CType(gvrMetric.FindControl("txtMetricValType"), HiddenField)
                            sMetricValType = txtMetricValType.Value
                        End If

                        Dim iMetricValPrecision As Integer = 0
                        Dim txtMetricValPrecision As HiddenField = New HiddenField
                        If Not gvrMetric.FindControl("txtMetricValPrecision") Is Nothing Then
                            txtMetricValPrecision = CType(gvrMetric.FindControl("txtMetricValPrecision"), HiddenField)
                            iMetricValPrecision = txtMetricValPrecision.Value
                        End If

                        Dim sPrjMetricValBefore As String = ""
                        Dim lblPrjMetricVal As Label = New Label
                        If Not gvrMetric.FindControl("lblPrjMetricVal") Is Nothing Then
                            lblPrjMetricVal = CType(gvrMetric.FindControl("lblPrjMetricVal"), Label)
                            sPrjMetricValBefore = lblPrjMetricVal.Text
                        End If

                        Dim decPrjMetricValAfter As Nullable(Of Decimal) = Nothing
                        Dim sPrjMetricStaAfter As String = ""

                        If sMetricCode = "11" Then
                            If hsPrjMetricRawSave.ContainsKey("css_score") Then
                                If IsNumeric(hsPrjMetricRawSave("css_score")) Then
                                    Dim cssScore As Decimal = hsPrjMetricRawSave("css_score")
                                    decPrjMetricValAfter = cssScore
                                End If
                            End If

                        Else
                            decPrjMetricValAfter = prjMetricService.CalculateMetricValue(sMetricCode, hsPrjMetricRawSave)
                        End If

                        If IsNumeric(sPrjMetricValBefore) And Not decPrjMetricValAfter.HasValue Then
                            decPrjMetricValAfter = 0
                        End If


                        If decPrjMetricValAfter.HasValue Then
                            Select Case sMetricValType
                                Case "P"
                                    decPrjMetricValAfter = (Decimal.Round(decPrjMetricValAfter * 100, iMetricValPrecision, MidpointRounding.AwayFromZero)) / 100
                                Case "N"
                                    decPrjMetricValAfter = Decimal.Round(decPrjMetricValAfter, iMetricValPrecision, MidpointRounding.AwayFromZero)
                            End Select
                            'decPrjMetricValAfter = Decimal.Round(decPrjMetricValAfter, iMetricValPrecision, MidpointRounding.AwayFromZero)

                            sPrjMetricStaAfter = prjMetricService.CalculateMetricStatus(Session("metric_target_year"), lblTssPrj.Text.Trim, sMetricCode, decPrjMetricValAfter)
                        End If

                        If sMetricCode = METRICCODE.ONSCHEDULE Then
                            'sScheduleStaAfter = sPrjMetricStaAfter
                            txtScheduleSta.Text = sPrjMetricStaAfter
                        ElseIf sMetricCode = METRICCODE.SPI Then
                            'sScheduleStaAfter = sPrjMetricStaAfter
                            txtScheduleSta.Text = sPrjMetricStaAfter
                        ElseIf sMetricCode = METRICCODE.CPI Then
                            'sCostStaAfter = sPrjMetricStaAfter
                            txtCostSta.Text = sPrjMetricStaAfter
                        End If


                        If saveMetricRaw2Db.ToUpper <> "Y" Then
                            Dim sPrjMetricStaBefore As String = ""
                            Dim txtPrjMetricStaHidden As HiddenField = New HiddenField
                            If Not gvrMetric.FindControl("txtPrjMetricStaHidden") Is Nothing Then
                                txtPrjMetricStaHidden = CType(gvrMetric.FindControl("txtPrjMetricStaHidden"), HiddenField)
                                sPrjMetricStaBefore = txtPrjMetricStaHidden.Value
                                txtPrjMetricStaHidden.Value = sPrjMetricStaAfter
                            End If

                            If decPrjMetricValAfter.HasValue Then

                                Dim iMetricSta As HtmlGenericControl = New HtmlGenericControl
                                If Not gvrMetric.FindControl("iMetricSta") Is Nothing Then
                                    iMetricSta = CType(gvrMetric.FindControl("iMetricSta"), HtmlGenericControl)
                                    Select Case sPrjMetricStaAfter
                                        Case "R"
                                            iMetricSta.Style.Add("color", "Red")
                                        Case "A"
                                            iMetricSta.Style.Add("color", "#f0ad4e")
                                        Case "G"
                                            iMetricSta.Style.Add("color", "Green")
                                        Case ""
                                            iMetricSta.Style.Add("color", "#f0f0f0")
                                    End Select
                                End If
                            End If

                        End If


                        Dim sPrjMetricId As String = ""
                        Dim txtPrjMetricId As HiddenField = New HiddenField
                        If Not gvrMetric.FindControl("txtPrjMetricId") Is Nothing Then
                            txtPrjMetricId = CType(gvrMetric.FindControl("txtPrjMetricId"), HiddenField)
                            sPrjMetricId = txtPrjMetricId.Value
                        End If

                        Dim drPrjMetric As DataRow = Nothing
                        Dim drPrjMetricList As DataRow() = dtPrjMetric.Select("prj_code = '" & lblCurrentPrjCode.Text.Trim & "' and metric_code = '" & sMetricCode & "'")

                        If drPrjMetricList.Length = 0 Then 'Add
                            drPrjMetric = dtPrjMetric.NewRow

                            drPrjMetric("prj_code") = currentPrjCode
                            drPrjMetric("metric_code") = sMetricCode

                            If decPrjMetricValAfter.HasValue Then
                                drPrjMetric("metric_val") = decPrjMetricValAfter
                                drPrjMetric("metric_status") = sPrjMetricStaAfter
                            End If

                            drPrjMetric("is_active") = "Y"
                            drPrjMetric("created_by") = Session("logon_id")
                            drPrjMetric("created_dt") = Now

                            drPrjMetric("last_updated_by") = Session("logon_id")
                            drPrjMetric("last_updated_dt") = Now

                            dtPrjMetric.Rows.Add(drPrjMetric)

                            bSave = True
                        ElseIf decPrjMetricValAfter.HasValue Then

                            drPrjMetric = dtPrjMetric.Rows.Find(drPrjMetricList(0).Item("id"))

                            If drPrjMetric Is Nothing Then
                                bSave = False
                            Else
                                'Update timestamp
                                drPrjMetric("data_version") = ""
                                drPrjMetric("last_updated_by") = Session("logon_id")
                                drPrjMetric("last_updated_dt") = Now
                            End If

                            If bSave Then
                                'Update metric value
                                If IsDBNull(drPrjMetric("metric_val")) Then
                                    drPrjMetric("metric_val") = decPrjMetricValAfter
                                ElseIf Not IsNumeric(drPrjMetric("metric_val")) Then
                                    drPrjMetric("metric_val") = decPrjMetricValAfter
                                ElseIf drPrjMetric("metric_val") <> decPrjMetricValAfter Then
                                    drPrjMetric("metric_val") = decPrjMetricValAfter
                                End If

                                'Update metric status
                                If IsDBNull(drPrjMetric("metric_status")) Then
                                    drPrjMetric("metric_status") = sPrjMetricStaAfter
                                ElseIf drPrjMetric("metric_status") <> sPrjMetricStaAfter Then
                                    drPrjMetric("metric_status") = sPrjMetricStaAfter
                                End If
                            End If
                        End If
                    End If 'End If Not gvrMetric Is Nothing Then



                End If 'End If gvMetrics.Rows(i).RowType = DataControlRowType.DataRow Then
            Next
        Catch ex As Exception
            bSave = False
            logHelper.WriteLog("failed to update metric ", ex)
            Throw ex
        End Try



        PrepareSave4Metric = bSave
    End Function

    Private Function PrepareSave4ProfileStatus(ByRef dtProfile As DataTable, ByRef dtPrjMetric As DataTable) As Boolean
        Dim bToSave As Boolean = True

        Dim sQualityStaAfter As String = ProfileHealthStatus.GetProfileQualityStatus(dtPrjMetric)

        If Not sQualityStaAfter.Equals(dtProfile.Rows(0).Item("quality_status").ToString) Then
            dtProfile.Rows(0).Item("quality_status") = sQualityStaAfter
            txtQualitySta.Text = sQualityStaAfter
            bToSave = True
        End If

        If lblTssPrj.Text = TSSSERVICECATEGORY.BAUM Then
            txtScheduleSta.Text = dtProfile.Rows(0).Item("schedule_status").ToString
        End If
        dtProfile.Rows(0).Item("schedule_status") = txtScheduleSta.Text

        If lblTssPrj.Text = TSSSERVICECATEGORY.BAUM Or lblTssPrj.Text = TSSSERVICECATEGORY.BAUE Then
            txtCostSta.Text = dtProfile.Rows(0).Item("cost_status").ToString
        End If
        dtProfile.Rows(0).Item("cost_status") = txtCostSta.Text

        Dim prfHealthAfter As ProfileHealthStatusModel = New ProfileHealthStatusModel
        prfHealthAfter.costStatus = txtCostSta.Text
        prfHealthAfter.qualityStatus = sQualityStaAfter
        prfHealthAfter.scheduleStatus = txtScheduleSta.Text
        prfHealthAfter.cssStatus = dtProfile.Rows(0).Item("css_status").ToString
        prfHealthAfter.resourceStatus = dtProfile.Rows(0).Item("resource_status").ToString
        prfHealthAfter.scopeStatus = dtProfile.Rows(0).Item("scope_status").ToString

        Dim sHealthStaAfter As String = ProfileHealthStatus.CalculateProfileHealthStatus(prfHealthAfter)

        Dim sHealthStaBefore = dtProfile.Rows(0).Item("health_status").ToString
        If Not sHealthStaAfter.Equals(sHealthStaBefore) Then
            dtProfile.Rows(0).Item("health_status") = sHealthStaAfter
            txtHealthSta.Value = sHealthStaAfter
            bToSave = True
        End If

        dtProfile.Rows(0).Item("data_version") = ""
        dtProfile.Rows(0).Item("status") = PROFILESTATUS.DRAFT
        dtProfile.Rows(0).Item("last_updated_by") = Session("logon_id")
        dtProfile.Rows(0).Item("last_updated_dt") = Now

        bToSave = True
        PrepareSave4ProfileStatus = bToSave
    End Function

    Private Sub RenderInputTextControl(ByRef txtInput As TextBox, ByVal dataPrec As Integer)
        Dim valInput As String = DataFormatHelper.FormatString(txtInput.Text.ToString, "N", dataPrec)
        If Not String.IsNullOrEmpty(valInput) Then
            txtInput.Text = IIf(valInput.EndsWith("%"), valInput.Substring(0, valInput.Length - 1), valInput)
        End If

        txtInput.Attributes.Add("onkeyup", "formatNumber(this, " & dataPrec & ")")
        txtInput.Attributes.Add("onblur", "ValidateNumber(this, " & dataPrec & ")")
    End Sub

    Private Sub gvMetricRawList_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvMetricRawList.RowDataBound


        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim txtMetricRawPrjVal As TextBox = New TextBox
            Dim txtMetricRawPrjId As HiddenField = New HiddenField
            Dim drView As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim iValPrecision As Integer = 0

            If Not drView Is Nothing Then

                iValPrecision = DataFormatHelper.StringToInteger(drView("data_precision").ToString)
                If Not e.Row.FindControl("txtMetricRawPrjVal") Is Nothing Then
                    txtMetricRawPrjVal = CType(e.Row.FindControl("txtMetricRawPrjVal"), TextBox)
                    If Not IsDBNull(drView("prj_metric_raw_val")) Then
                        txtMetricRawPrjVal.Text = drView("prj_metric_raw_val")
                    End If
                    RenderInputTextControl(txtMetricRawPrjVal, iValPrecision)
                End If

                If Not IsDBNull(drView("prj_metric_raw_id")) Then
                    If Not e.Row.FindControl("") Is Nothing Then
                        txtMetricRawPrjId = CType(e.Row.FindControl("txtMetricRawPrjId"), HiddenField)
                        txtMetricRawPrjId.Value = drView("prj_metric_raw_id")
                    End If
                End If

                If Not IsDBNull(drView("data_source")) Then
                    If DataFormatHelper.StringTrim(drView("data_source").ToString).ToUpper = "S" Then
                        txtMetricRawPrjVal.Attributes.Add("readonly", True)
                    End If
                End If
            End If 'End If Not drView Is Nothing Then

        End If
    End Sub
#End Region


#Region "LAST_VERSIION"


    'Function LoadMetricDataLast(ByVal prjCodesLast As String())
    '    If bHaveLastProfile Then

    '        'dtPrjMetricsLast = prjMetricService.GetProjectMetricHistList(prjCodesLast, currentDataVer)
    '        dtPrjMetricsLast = prjMetricService.GetProjectMetricHist(prjCodesLast, lastDataVer)

    '        If Not dtPrjMetricsLast Is Nothing Then
    '            If dtPrjMetricsLast.Rows.Count > 0 Then
    '                bHaveLastMetric = True
    '            End If
    '        End If

    '    End If
    'End Function

    'Sub LoadMetricRawDataLast(ByVal prjCodesLast As String())
    '    If bHaveLastMetric Then

    '        'dtPrjMetricRawLast = prjMetricRawService.GetProjectMetricRawHistList(prjCodesLast, currentDataVer)
    '        dtPrjMetricRawLast = prjMetricRawService.GetProjectMetricRawHist(prjCodesLast, lastDataVer)

    '        If Not dtPrjMetricRawLast Is Nothing Then
    '            If dtPrjMetricRawLast.Rows.Count > 0 Then
    '                bHaveLastMetricRaw = True
    '            End If
    '        End If

    '    End If
    'End Sub

#End Region


#Region "Page_Button"



    'Private Sub btnSave_Click(sender As Object, e As System.EventArgs) Handles btnSave.Click
    '    Dim bSave As Boolean = False

    '    Try
    '        bSave = SaveProfile(False)
    '    Catch ex As Exception
    '        logHelper.WriteLog("Error occurred while saving profile.", ex)
    '    End Try

    '    If bSave Then
    '        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "initColor();", True)
    '    Else
    '        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "", "<script>alert('Oops, it seems somthing is wrong while saving profile.');</script>", False)
    '    End If

    'End Sub

    Private Function SaveProfile(ByRef dtProfile As DataTable, ByRef dtPrjMetrics As DataTable, ByRef dtprjMetricRaw As DataTable, ByVal updRaw As Boolean) As Boolean


        Dim bSave As Boolean = False

        Try
            bSave = prfService.SaveProjectMetric(dtprjMetricRaw, dtPrjMetrics, dtProfile)
            If bSave Then
                dtprjMetricRaw.AcceptChanges()
                dtPrjMetrics.AcceptChanges()
                dtProfile.AcceptChanges()
                'bSaveProfile = True
                TriggerSRIssueLog(Session("prf_id"), dtProfile)
            Else
                'bSaveProfile = False
                dtprjMetricRaw.RejectChanges()
                dtPrjMetrics.RejectChanges()
                dtProfile.RejectChanges()
            End If
            'If bSaveProfile And bSavePrjMetric And bSavePrjMetricRaw Then
            '    bSave = prfService.SaveProjectMetric(dtprjMetricRaw, dtPrjMetrics, dtProfile)
            '    If bSave Then
            '        dtprjMetricRaw.AcceptChanges()
            '        dtPrjMetrics.AcceptChanges()
            '        dtProfile.AcceptChanges()
            '        bSaveProfile = True
            '    Else
            '        bSaveProfile = False
            '        dtprjMetricRaw.RejectChanges()
            '        dtPrjMetrics.RejectChanges()
            '        dtProfile.RejectChanges()
            '    End If
            'ElseIf bSaveProfile And bSavePrjMetric Then
            '    bSave = prfService.SaveProjectMetric(Nothing, dtPrjMetrics, dtProfile)
            '    If bSave Then
            '        dtPrjMetrics.AcceptChanges()
            '        dtProfile.AcceptChanges()
            '        bSaveProfile = True
            '    Else
            '        bSaveProfile = False
            '        dtPrjMetrics.RejectChanges()
            '        dtProfile.RejectChanges()
            '    End If
            'ElseIf bSaveProfile And bSavePrjMetricRaw Then
            '    bSave = prfService.SaveProjectMetric(dtprjMetricRaw, Nothing, dtProfile)
            '    If bSave Then
            '        dtprjMetricRaw.AcceptChanges()
            '        dtProfile.AcceptChanges()
            '        bSaveProfile = True
            '    Else
            '        bSaveProfile = False
            '        dtprjMetricRaw.RejectChanges()
            '        dtProfile.RejectChanges()
            '    End If
            'ElseIf bSavePrjMetric And bSavePrjMetricRaw Then
            '    bSave = prfService.SaveProjectMetric(dtprjMetricRaw, dtPrjMetrics, Nothing)
            '    If bSave Then
            '        dtprjMetricRaw.AcceptChanges()
            '        dtPrjMetrics.AcceptChanges()
            '        bSaveProfile = True
            '    Else
            '        bSaveProfile = False
            '        dtprjMetricRaw.RejectChanges()
            '        dtPrjMetrics.RejectChanges()
            '    End If
            'ElseIf bSaveProfile Then
            '    bSave = prfService.SaveProjectMetric(Nothing, Nothing, dtProfile)
            '    If bSave Then
            '        dtProfile.AcceptChanges()
            '        bSaveProfile = True
            '    Else
            '        bSaveProfile = False
            '        dtProfile.RejectChanges()
            '    End If
            'ElseIf bSavePrjMetric Then
            '    bSave = prfService.SaveProjectMetric(Nothing, dtPrjMetrics, Nothing)
            '    If bSave Then
            '        dtPrjMetrics.AcceptChanges()
            '        bSaveProfile = True
            '    Else
            '        bSaveProfile = False
            '        dtPrjMetrics.RejectChanges()
            '    End If
            'ElseIf bSavePrjMetricRaw Then
            '    bSave = prfService.SaveProjectMetric(dtprjMetricRaw, Nothing, Nothing)
            '    If bSave Then
            '        dtprjMetricRaw.AcceptChanges()
            '        bSaveProfile = True
            '    Else
            '        bSaveProfile = False
            '        dtprjMetricRaw.RejectChanges()
            '    End If
            'Else
            '    bSaveProfile = True
            'End If

        Catch ex As Exception
            Throw ex
            bSave = False
        End Try

        SaveProfile = bSave
    End Function

    Function TriggerSRIssueLog(ByVal profileId As Integer, ByRef dtProfile As DataTable) As Boolean
        Dim bTrigger As Boolean = False
        Dim issueTag As String = ""

        Dim sPrfQtySta As String = dtProfile.Rows(0).Item("quality_status").ToString
        Dim sPrfCostSta As String = dtProfile.Rows(0).Item("cost_status").ToString
        Dim sPrfScheduleSta As String = dtProfile.Rows(0).Item("schedule_status").ToString

        Dim prfMainCode As String = dtProfile.Rows(0).Item("prf_main_code").ToString

        'Quality
        If sPrfQtySta <> "" And sPrfQtySta <> "G" Then
            issueTag = "QUALITY"
            bTrigger = CreateIssueLog(profileId, prfMainCode, issueTag)
        End If
        'Cost
        If sPrfCostSta <> "" And sPrfCostSta <> "G" Then
            issueTag = "COST"
            bTrigger = CreateIssueLog(profileId, prfMainCode, issueTag)
        End If
        'Schedule
        If sPrfScheduleSta <> "" And sPrfScheduleSta <> "G" Then
            issueTag = "SCHEDULE"
            bTrigger = CreateIssueLog(profileId, prfMainCode, issueTag)
        End If

        TriggerSRIssueLog = bTrigger

    End Function

    Function CreateIssueLog(ByVal profileId As Integer, ByVal prfMainCode As String, ByVal issueTag As String) As Boolean
        Dim bTrigger As Boolean = False
        Dim prfIssueService As IProfileIssueService = New ProfileIssueService
        Dim sIssueDescShort As String = "Health Indicator " & issueTag & " turned into Amber/Red."

        Try
            'If Not prfIssueService.IsIssueCreated(profileId, "RISK", sIssueDescShort, issueTag) Then
            If Not prfIssueService.IsTagIssueCreated(profileId, issueTag) Then
                Dim dtIssue As DataTable = prfIssueService.GetProfileIssueList(False)
                If Not dtIssue Is Nothing Then
                    Dim drIssue As DataRow = dtIssue.NewRow
                    drIssue.Item("issue_category") = "RISK"
                    drIssue.Item("issue_desc_sys") = sIssueDescShort
                    drIssue.Item("issue_desc_short") = sIssueDescShort
                    drIssue.Item("prj_code") = prfMainCode
                    drIssue.Item("prf_id") = profileId
                    drIssue.Item("issue_tag") = issueTag
                    drIssue.Item("issue_status") = "O"
                    drIssue.Item("created_by") = "SYSTEM"
                    drIssue.Item("created_dt") = Now
                    drIssue.Item("last_updated_by") = "SYSTEM"
                    drIssue.Item("last_updated_dt") = Now
                    drIssue.Item("issue_no") = "RISK-" & prfIssueService.GetNewIssueNo("RISK")
                    dtIssue.Rows.Add(drIssue)
                    bTrigger = prfIssueService.SaveProfileIssue(dtIssue)
                End If

                dtIssue.Dispose()
            End If
        Catch ex As Exception
            logHelper.WriteLog("Failed to create issue within Health Tab.", ex)
        End Try

        CreateIssueLog = bTrigger
    End Function

    Private Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click

        Dim sFileTemplate As String = "Quality_Raw_Data_Template.xlsx"
        Dim sFileName As String = sFileTemplate.Replace("Template", Now.ToString("yyyyMMddhhmmssffff"))


        'If excelHelper.NpoiDataTable2Excel(sFileName, {New ExcelSheetContent("Quality_Metric", dtPrjMetricRaw)}) Then
        'End If

    End Sub


    Private Sub btnSubmit_Click(sender As Object, e As System.EventArgs) Handles btnSubmit.Click

        Dim bSubmit As Boolean = False

        fromPg = "DRAFT"
        Server.Transfer("ProfilePreviewDraft.aspx")



    End Sub
#End Region



End Class