﻿Namespace Account
    Public Class Logout
        Inherits System.Web.UI.Page


        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

            Session("logon_id") = Nothing
            Session("prf_id") = Nothing
            Session.Abandon()

        End Sub
    End Class
End Namespace
