﻿Imports System.Web
Imports System.IO
Imports log4net



Namespace Account
    Public Class Login
        Inherits System.Web.UI.Page

        Public isValidDashboardUser As Boolean = True
        Public bAlert As Boolean = False
        Public sAlertMsg As String = ""
        Protected app As String = ""
        Public Shared sAlertMessage() As String = {"Sorry, you don\'t have authority to access to this application. Please contact your system admin.", _
                                                   "Sorry, you havn\'t been assigned to any business functions yet, please contact your system administrator.", _
                                                   "Sorry, user details inforamtion is not found, please contact your PMA system administrator."}

        Dim userService As IUserService = New UserService
        Dim pmaUserService As IPmaUserService = New PmaUserService
        Dim pmaTeamService As IPmaTeamService = New PmaTeamService
        Dim pmaProjectService As IPmaProjectService = New PmaProjectService
        Dim logService As ILogService = New LogService
        Dim logHelper As LogHelper = New LogHelper
        'Private Shared ReadOnly logInfo As ILog = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)
        'Private Shared ReadOnly logError As ILog = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            If Not Page.IsPostBack Then

                Dim logonUser As String = ""
                Dim env As String = ""
                Dim dbUser As String = ""
                Dim dbPsw As String = ""
                Dim key As String = ""

                Try
                    If Session("logon_id") Is Nothing Then

                        Dim propertyFile As String = Server.MapPath("~/system.properties")
                        Dim propertyHelper As PropertyHelper = New PropertyHelper


                        If File.Exists(propertyFile) Then
                            Dim sr As New StreamReader(propertyFile)
                            propertyHelper.Load(sr)
                            env = propertyHelper.GetProperty("[env]")
                            
                            dbUser = propertyHelper.GetProperty("[db_user]")
                            dbPsw = propertyHelper.GetProperty("[db_psw]")
                            key = propertyHelper.GetProperty("[key]")
                            sr.Close()
                        Else
                            logHelper.WriteLog("System properties file is not found.")
                            sAlertMsg = "Oops, system encounters a problem now."
                            Return
                        End If

                        If String.IsNullOrEmpty(dbUser) Or String.IsNullOrEmpty(dbPsw) Then
                            logHelper.WriteLog("Database connection is not yet set.")
                            sAlertMsg = "Oops, system encounters a problem now."
                            Return
                        End If

                        If Not String.IsNullOrEmpty(env) Then
                            'Use windows ID to logon application.
                            If env.Trim.ToUpper = "PRD" Then
                                logonUser = Request.LogonUserIdentity.Name
                                If logonUser.LastIndexOf("\") >= 0 Then
                                    logonUser = logonUser.Substring(logonUser.LastIndexOf("\") + 1)
                                End If
                                logonUser = logonUser.ToUpper
                            End If
                        End If
                    Else
                        logonUser = Session("logon_id")
                    End If

                    If Not String.IsNullOrEmpty(logonUser) Then

                        If Trim(logonUser).Length = 0 Then
                            sAlertMsg = sAlertMessage(0)
                            isValidDashboardUser = False
                        ElseIf Not ValidateLogon(logonUser) Then
                            sAlertMsg = sAlertMessage(1)
                            isValidDashboardUser = False
                        End If

                        If isValidDashboardUser Then
                            Session("logon_id") = logonUser
                            'Response.Write("<script>window.location.href = '../../Default.aspx';</script>")
                            logService.WriteTranLog("LOGIN", logonUser, "Log on successfully.")
                            'logHelper.WriteLog(logonUser & " logged in successfully.")
                        Else
                            logService.WriteTranLog("LOGIN", logonUser, "Failed to logon application.")
                            'logHelper.WriteLog(logonUser & " failed to login.")
                        End If

                    End If
                Catch ex As Exception
                    logHelper.WriteLog("Failed to logon application", ex)

                End Try
                
                If Not Session("logon_id") Is Nothing Then
                    Server.Transfer("~/Default.aspx")
                End If


            End If
        End Sub

        Private Sub InitVariables()
            sAlertMsg = ""
        End Sub

        'Logon Buttong
        Private Sub btnLogin_Click(sender As Object, e As System.EventArgs) Handles btnLogin.Click
            Dim sPmaLogonId As String = txtUserName.Value.ToUpper

            If Trim(sPmaLogonId).Length = 0 Then
                sAlertMsg = sAlertMessage(0)
                isValidDashboardUser = False

            ElseIf Not ValidateLogon(sPmaLogonId) Then
                sAlertMsg = sAlertMessage(1)
                isValidDashboardUser = False
            End If

            If isValidDashboardUser Then
                Session("logon_id") = sPmaLogonId
                Response.Redirect("../../Default.aspx")

            End If
        End Sub

        Function ValidateLogon(ByVal sLogon As String) As Boolean
            Dim sUserRoleString As String = ""

            'Step 1: Check if valid dashboard user
            If userService.IsValidDashboardUser(sLogon) Then
                'Retrieve user roles list

                sUserRoleString = userService.GetUserRoleString(sLogon)
                If sUserRoleString = "" Then
                    sAlertMsg = sAlertMessage(0)
                    Return False
                End If
                Return True
            End If

            'Step 2: Check PMA
            Dim dtPmaUser As DataTable = pmaUserService.GetActiveUserByLogonId(sLogon)
            If dtPmaUser Is Nothing Then
                Return False
            ElseIf dtPmaUser.Rows.Count = 0 Then
                Return False
            End If

            'Step 3: Check PMA role/Team
            Dim slogonIdCard As String = dtPmaUser.Rows(0).Item("id_card").ToString.Trim
            Dim iTeamCode As Integer = dtPmaUser.Rows(0).Item("team_code")
            'Dim dtTeam As DataTable = pmaTeamService.GetTeam(iTeamCode)
            Dim dtTeam As DataTable = pmaTeamService.GetMyLeadTeams(sLogon, slogonIdCard, iTeamCode)
            If Not dtTeam Is Nothing Then
                For Each drTeam As DataRow In dtTeam.Rows
                    If drTeam("team_code") = pmaTeamService.GetTopTeamCode() Then
                        If String.IsNullOrEmpty(sUserRoleString) Then
                            sUserRoleString = DASHBORADROLES.GM
                        ElseIf Not sUserRoleString.Contains(DASHBORADROLES.GM) Then
                            sUserRoleString = sUserRoleString & "," & DASHBORADROLES.GM
                        End If

                        Continue For
                    End If

                    If IIf(IsDBNull(drTeam("is_func")), "", drTeam("is_func")).ToString.ToUpper = "Y" Then
                        If String.IsNullOrEmpty(sUserRoleString) Then
                            sUserRoleString = DASHBORADROLES.FH
                        ElseIf Not sUserRoleString.Contains(DASHBORADROLES.FH) Then
                            sUserRoleString = sUserRoleString & "," & DASHBORADROLES.FH
                        End If

                        Continue For
                    End If

                    If IIf(IsDBNull(drTeam("is_dept")), "", drTeam("is_dept")).ToString.ToUpper = "Y" Then
                        If String.IsNullOrEmpty(sUserRoleString) Then
                            sUserRoleString = DASHBORADROLES.SBUH
                        ElseIf Not sUserRoleString.Contains(DASHBORADROLES.SBUH) Then
                            sUserRoleString = sUserRoleString & "," & DASHBORADROLES.SBUH
                        End If

                        Continue For
                    End If

                    If ((IIf(IsDBNull(drTeam("tl_id")), "", drTeam("tl_id")).ToString.ToUpper = sLogon.ToUpper) Or _
                                            (IIf(IsDBNull(drTeam("dtl_id")), "", drTeam("dtl_id")).ToString.ToUpper = sLogon.ToUpper)) Then

                        If String.IsNullOrEmpty(sUserRoleString) Then
                            sUserRoleString = DASHBORADROLES.TL
                        ElseIf Not sUserRoleString.Contains(DASHBORADROLES.TL) Then
                            sUserRoleString = sUserRoleString & "," & DASHBORADROLES.TL
                        End If

                        Continue For
                    End If

                Next
            End If

            'Step 4: Check PMA PM role
            If String.IsNullOrEmpty(sUserRoleString) Then
                If pmaProjectService.IsProjectManager(sLogon, slogonIdCard) Then
                    sUserRoleString = DASHBORADROLES.PM
                End If
            End If

            If String.IsNullOrEmpty(sUserRoleString) Then
                sAlertMsg = sAlertMessage(0)
                Return False
            Else
                Session("userRoles") = sUserRoleString
                logHelper.WriteLog("sucessfully logon.")
                Return True
            End If
        End Function
    End Class
End Namespace
