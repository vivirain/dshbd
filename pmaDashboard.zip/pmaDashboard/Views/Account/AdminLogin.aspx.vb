﻿Imports System.Web
Imports System.IO


Namespace Account
    Public Class AdminLogin
        Inherits System.Web.UI.Page

        Public isValidDashboardUser As Boolean = True
        Public bAlert As Boolean = False
        Public sAlertMsg As String = ""
        Protected app As String = ""
        Public Shared sAlertMessage() As String = {"Sorry, you don\'t have authority to access to this application. Please contact your system admin.", _
                                                   "Sorry, you havn\'t been assigned to any business functions yet, please contact your system administrator.", _
                                                   "Sorry, user details inforamtion is not found, please contact your PMA system administrator."}

        Dim userService As IUserService = New UserService
        Dim pmaUserService As IPmaUserService = New PmaUserService
        Dim pmaTeamService As IPmaTeamService = New PmaTeamService
        Dim pmaProjectService As IPmaProjectService = New PmaProjectService
        Dim logHelper As LogHelper = New LogHelper

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            If Not Page.IsPostBack Then

                Dim logonUser As String = ""
                Dim env As String = ""
                Dim dbUser As String = ""
                Dim dbPsw As String = ""
                Dim key As String = ""

                Session("logon_id") = Nothing
                Try
                    If Session("logon_id") Is Nothing Then


                    Else
                        logonUser = Session("logon_id")
                    End If

                    If Not String.IsNullOrEmpty(logonUser) Then

                        If Trim(logonUser).Length = 0 Then
                            sAlertMsg = sAlertMessage(0)
                            isValidDashboardUser = False
                        ElseIf Not ValidateLogon(logonUser) Then
                            sAlertMsg = sAlertMessage(1)
                            isValidDashboardUser = False
                        End If

                        If isValidDashboardUser Then
                            Session("logon_id") = logonUser
                            Response.Redirect("../../Default.aspx")
                        End If

                    End If
                Catch ex As Exception
                    logHelper.WriteLog("Failed to logon application", ex)
                End Try


            End If
        End Sub

        Private Sub InitVariables()
            sAlertMsg = ""
        End Sub

        'Logon Buttong
        Private Sub btnLogin_Click(sender As Object, e As System.EventArgs) Handles btnLogin.Click
            Dim sPmaLogonId As String = txtUserName.Value.ToUpper

            If Trim(sPmaLogonId).Length = 0 Then
                sAlertMsg = sAlertMessage(0)
                isValidDashboardUser = False

            ElseIf Not ValidateLogon(sPmaLogonId) Then
                sAlertMsg = sAlertMessage(1)
                isValidDashboardUser = False
            End If

            If isValidDashboardUser Then
                Session("logon_id") = sPmaLogonId
                Response.Redirect("../../Default.aspx")

            End If
        End Sub

        Function ValidateLogon(ByVal sLogon As String) As Boolean
            Dim sUserRoleString As String = ""

            'Step 1: Check if valid dashboard user
            If userService.IsValidDashboardUser(sLogon) Then
                'Retrieve user roles list

                sUserRoleString = userService.GetUserRoleString(sLogon)
                If sUserRoleString = "" Then
                    sAlertMsg = sAlertMessage(0)
                    Return False
                End If
                Return True
            End If

            'Step 2: Check PMA
            Dim dtPmaUser As DataTable = pmaUserService.GetActiveUserByLogonId(sLogon)
            If dtPmaUser Is Nothing Then
                Return False
            ElseIf dtPmaUser.Rows.Count = 0 Then
                Return False
            End If

            'Step 3: Check PMA role/Team
            Dim sLogonIdCard As String = dtPmaUser.Rows(0).Item("id_card").ToString.Trim
            Dim iTeamCode As Integer = dtPmaUser.Rows(0).Item("team_code")
            Dim dtTeam As DataTable = pmaTeamService.GetMyLeadTeams(sLogon, sLogonIdCard, iTeamCode)
            If Not dtTeam Is Nothing Then
                For Each drTeam As DataRow In dtTeam.Rows
                    If drTeam("team_code") = pmaTeamService.GetTopTeamCode() Then
                        If String.IsNullOrEmpty(sUserRoleString) Then
                            sUserRoleString = DASHBORADROLES.GM
                        ElseIf Not sUserRoleString.Contains(DASHBORADROLES.GM) Then
                            sUserRoleString = sUserRoleString & "," & DASHBORADROLES.GM
                        End If

                        Continue For
                    End If

                    If IIf(IsDBNull(drTeam("is_func")), "", drTeam("is_func")).ToString.ToUpper = "Y" Then
                        If String.IsNullOrEmpty(sUserRoleString) Then
                            sUserRoleString = DASHBORADROLES.FH
                        ElseIf Not sUserRoleString.Contains(DASHBORADROLES.FH) Then
                            sUserRoleString = sUserRoleString & "," & DASHBORADROLES.FH
                        End If

                        Continue For
                    End If

                    If IIf(IsDBNull(drTeam("is_dept")), "", drTeam("is_dept")).ToString.ToUpper = "Y" Then
                        If String.IsNullOrEmpty(sUserRoleString) Then
                            sUserRoleString = DASHBORADROLES.SBUH
                        ElseIf Not sUserRoleString.Contains(DASHBORADROLES.SBUH) Then
                            sUserRoleString = sUserRoleString & "," & DASHBORADROLES.SBUH
                        End If

                        Continue For
                    End If

                    If ((IIf(IsDBNull(drTeam("tl_id")), "", drTeam("tl_id")).ToString.ToUpper = sLogon.ToUpper) Or _
                                            (IIf(IsDBNull(drTeam("dtl_id")), "", drTeam("dtl_id")).ToString.ToUpper = sLogon.ToUpper)) Then

                        If String.IsNullOrEmpty(sUserRoleString) Then
                            sUserRoleString = DASHBORADROLES.TL
                        ElseIf Not sUserRoleString.Contains(DASHBORADROLES.TL) Then
                            sUserRoleString = sUserRoleString & "," & DASHBORADROLES.TL
                        End If

                        Continue For
                    End If

                Next
            End If

            'Step 4: Check PMA PM role
            If String.IsNullOrEmpty(sUserRoleString) Then
                If pmaProjectService.IsProjectManager(sLogon, sLogonIdCard) Then
                    sUserRoleString = DASHBORADROLES.PM
                End If
            End If

            If String.IsNullOrEmpty(sUserRoleString) Then
                sAlertMsg = sAlertMessage(0)
                Return False
            Else
                Session("userRoles") = sUserRoleString
                logHelper.WriteLog("sucessfully logon.")
                Return True
            End If
        End Function
    End Class
End Namespace
