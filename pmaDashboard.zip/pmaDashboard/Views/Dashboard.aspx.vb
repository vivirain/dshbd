﻿Public Class Dashboard
    Inherits System.Web.UI.Page

    Private userRoles As String() = Nothing
    Private dataVersion As String = Format(Now, "yyyyMMdd")

    Private dtProfile As DataTable = New DataTable

    Dim prfService As IProfileService = New ProfileService
    Dim pmaTeamService As IPmaTeamService = New PmaTeamService
    Dim pmaUserService As IPmaUserService = New PmaUserService

    Dim logHelper As LogHelper = New LogHelper

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("logon_id") Is Nothing Then
            Return
        End If

        If Not Session("userRoles") Is Nothing Then
            userRoles = Session("userRoles").ToString.Split(",")
        End If

        If Not Page.IsPostBack And Not Session("logon_id") Is Nothing Then
            Session("prf_id") = Nothing

            PrepareMyProfileList()

            If Not dtProfile Is Nothing Then
                PrepareHealthStatusSummary()

                PrepareIssueSummary()
            End If

        End If
    End Sub

    Private Sub PrepareMyProfileList()
        Dim filterString As StringBuilder = New StringBuilder("")
        Dim userRoleFilter As StringBuilder = New StringBuilder("1 = 1 ")
        Dim sPMFilter As StringBuilder = New StringBuilder("")
        Dim sPMList As StringBuilder = New StringBuilder("")
        Dim sTeamPrfList As StringBuilder = New StringBuilder("")

        'userRoles = Session("userRoles").ToString.Split(",")

        filterString.Append(" AND [status] = '" & PROFILESTATUS.SUBMITTED & "' ")

        If Not userRoles Is Nothing Then
            If userRoles.Contains(DASHBORADROLES.GM) Or userRoles.Contains(DASHBORADROLES.EXCO) Or userRoles.Contains(DASHBORADROLES.AM) _
            Or userRoles.Contains(DASHBORADROLES.QAG) Or userRoles.Contains(DASHBORADROLES.ADM) Then

            Else
                sPMFilter.Append(" And ( prj_ld_id = '" & Session("logon_id") & "' OR created_by = '" & Session("logon_id") & "' ")

                If userRoles.Contains(DASHBORADROLES.FH) Or userRoles.Contains(DASHBORADROLES.SBUH) Or userRoles.Contains(DASHBORADROLES.TL) Then

                    prfService.GetMyTeamProfilesHist(sTeamPrfList, Session("my_teams"), dataVersion)

                    If Not String.IsNullOrEmpty(sTeamPrfList.ToString) Then
                        sPMFilter.Append(" OR prf_id in (" & sTeamPrfList.ToString & ") ")
                    End If
                End If

                sPMFilter.Append(" ) ")

                filterString.Append(sPMFilter.ToString)
            End If

            dtProfile = prfService.GetProfileHistViewList(dataVersion, filterString.ToString)
            If dtProfile Is Nothing Then
                Return
            ElseIf dtProfile.Rows.Count = 0 Then
                Return
            End If

        End If
    End Sub

    Private Sub PrepareHealthStatusSummary()

        Dim func_code As String = ""
        Dim sbu_Code As String = ""

        Dim totalStaG As Integer = 0
        Dim totalStaA As Integer = 0
        Dim totalStaR As Integer = 0


        Try


            dtProfile = dtProfile.DefaultView.ToTable(True)

            If dtProfile.Rows.Count = 0 Then
                lblHealthStaRCnt.InnerText = 0
                lblHealthStaACnt.InnerText = 0
                lblHealthStaGCnt.InnerText = 0
                Exit Sub
            End If

            If IsDBNull(dtProfile.Compute("Count(prf_id)", "health_status = 'R'")) Then
                totalStaR = 0
            Else
                totalStaR = dtProfile.Compute("Count(prf_id)", "health_status = 'R'")
            End If

            If IsDBNull(dtProfile.Compute("Count(prf_id)", "health_status = 'A'")) Then
                totalStaA = 0
            Else
                totalStaA = dtProfile.Compute("Count(prf_id)", "health_status = 'A'")
            End If

            If IsDBNull(dtProfile.Compute("Count(prf_id)", "health_status = 'G'")) Then
                totalStaG = 0
            Else
                totalStaG = dtProfile.Compute("Count(prf_id)", "health_status = 'G'")
            End If

            lblHealthStaRCnt.InnerText = totalStaR
            lblHealthStaACnt.InnerText = totalStaA
            lblHealthStaGCnt.InnerText = totalStaG

        Catch ex As Exception
            logHelper.WriteLog("failed to load dashboard data", ex)
        End Try


    End Sub

    Private Sub PrepareIssueSummary()


        If Not dtProfile Is Nothing Then
            Dim dtPrfIssue As DataTable = dtProfile.Copy
            dtPrfIssue.Columns.Add("open_issue_count", GetType(Integer))
            Dim dtProfileG As DataTable = dtPrfIssue.Clone
            Dim dtProfileA As DataTable = dtPrfIssue.Clone
            Dim dtProfileR As DataTable = dtPrfIssue.Clone

            For i As Integer = dtPrfIssue.Rows.Count - 1 To 0 Step -1
                Dim drPrfIssue As DataRow = dtPrfIssue.Rows(i)

                Dim prfIssueService As IProfileIssueService = New ProfileIssueService
                Dim iOpenIssueCount As Integer = prfIssueService.CountOpenProfileIssue(drPrfIssue("prf_id"))

                If iOpenIssueCount = 0 Or IsDBNull(drPrfIssue("health_status")) Then
                    drPrfIssue.Delete()
                Else
                    drPrfIssue("open_issue_count") = iOpenIssueCount

                    If drPrfIssue("health_status") = "G" Then
                        Dim drPrfG As DataRow = dtProfileG.NewRow()
                        drPrfG.ItemArray = drPrfIssue.ItemArray
                        dtProfileG.Rows.Add(drPrfG)
                    ElseIf drPrfIssue("health_status") = "A" Then
                        Dim drPrfA As DataRow = dtProfileA.NewRow()
                        drPrfA.ItemArray = drPrfIssue.ItemArray
                        dtProfileA.Rows.Add(drPrfA)
                    ElseIf drPrfIssue("health_status") = "R" Then
                        Dim drPrfR As DataRow = dtProfileR.NewRow()
                        drPrfR.ItemArray = drPrfIssue.ItemArray
                        dtProfileR.Rows.Add(drPrfR)
                    End If
                End If
            Next

            If Not dtProfileR Is Nothing Then
                If dtProfileR.Rows.Count > 0 Then
                    dtProfileR = dtProfileR.Select("1=1", "open_issue_count desc").CopyToDataTable
                End If
                WebControlHelper.GridViewDataBind(gvIssueR, dtProfileR, False)
            End If

            If Not dtProfileA Is Nothing Then
                If dtProfileA.Rows.Count > 0 Then
                    dtProfileA = dtProfileA.Select("1=1", "open_issue_count desc").CopyToDataTable
                End If
                WebControlHelper.GridViewDataBind(gvIssueA, dtProfileA, False)
            End If

            If Not dtProfileG Is Nothing Then
                If dtProfileG.Rows.Count > 0 Then
                    dtProfileG = dtProfileG.Select("1=1", "open_issue_count desc").CopyToDataTable
                End If
                WebControlHelper.GridViewDataBind(gvIssueG, dtProfileG, False)
            End If
            
        End If

        


    End Sub


    Private Sub lnkViewHealthStaACnt_ServerClick(sender As Object, e As System.EventArgs) Handles lnkViewHealthStaACnt.ServerClick
        HttpContext.Current.Items.Add("fromPg", "Dashboard")
        HttpContext.Current.Items.Add("healthSta", "A")
        Session("prf_id") = Nothing

        Server.Transfer("ProjectProfile/ProfileList.aspx")
    End Sub

    Private Sub lnkViewHealthStaGCnt_ServerClick(sender As Object, e As System.EventArgs) Handles lnkViewHealthStaGCnt.ServerClick
        HttpContext.Current.Items.Add("fromPg", "Dashboard")
        HttpContext.Current.Items.Add("healthSta", "G")

        Server.Transfer("ProjectProfile/ProfileList.aspx")
    End Sub

    Private Sub lnkViewHealthStaRCnt_ServerClick(sender As Object, e As System.EventArgs) Handles lnkViewHealthStaRCnt.ServerClick
        HttpContext.Current.Items.Add("fromPg", "Dashboard")
        HttpContext.Current.Items.Add("healthSta", "R")

        Server.Transfer("ProjectProfile/ProfileList.aspx")
    End Sub

    Private Sub gvIssueR_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvIssueR.RowCommand
        gv_RowCommand(gvIssueR, e)
    End Sub

    Private Sub gv_RowCommand(ByRef gv As GridView, ByRef e As System.Web.UI.WebControls.GridViewCommandEventArgs)
        If e.CommandName = "prfIssues" Then
            Dim index As String = CType(e.CommandArgument(), Integer)
            Dim gvRow As GridViewRow = gv.Rows(index)

            Dim prf_id As Integer = gv.DataKeys(index).Item(0)

            Session("prf_id") = prf_id
            Session("fromPg") = "LIST"
            Session("current_data_version") = Format(Now, "yyyyMMdd")

            Server.Transfer("ProjectProfile/DashboardProfileIssue.aspx")
        End If
    End Sub

    Private Sub gvIssueA_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvIssueA.RowCommand
        gv_RowCommand(gvIssueA, e)
    End Sub

    Private Sub gvIssueG_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvIssueG.RowCommand
        gv_RowCommand(gvIssueG, e)
    End Sub
End Class