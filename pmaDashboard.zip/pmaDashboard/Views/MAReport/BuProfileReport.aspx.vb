﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO


Public Class BuProfileReport
    Inherits System.Web.UI.Page


    Shared dtProfile As DataTable = New DataTable
    Shared dtProfileResult As DataTable = New DataTable

    Shared userRoles() As String = Nothing

    Shared fromPg As String = ""
    Shared buCode As String = ""
    Shared buName As String = ""
    Shared dataVersion As String = ""
    Shared buFilter As String = ""

    Public totalRecords As Integer = 0
    Public iPage As Integer
    Public sAlertMsg As StringBuilder = New StringBuilder("")

    Dim prfService As IProfileService = New ProfileService
    Dim pmaTssPrjService As IPmaTssProjectService = New PmaTssProjectService
    Dim pmaTeamService As IPmaTeamService = New PmaTeamService
    Dim pmaBizUnitService As IPmaBizUnitService = New PmaBizUnitService
    Dim pmaUserService As IPmaUserService = New PmaUserService
    Dim metricService As IMetricService = New MetricService

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Session("userRoles") Is Nothing Then
            userRoles = Session("userRoles").ToString.Split(",")
        End If



        If Not Page.IsPostBack Then

            buCode = HttpContext.Current.Items("buCode")
            buName = HttpContext.Current.Items("buName")
            dataVersion = HttpContext.Current.Items("dataVersion")

            QueryData()

        End If


    End Sub


#Region "Query"
    Sub QueryData()
        Dim filterString As StringBuilder = New StringBuilder("")
        Dim userRoleFilter As StringBuilder = New StringBuilder("1 = 1 ")

        Dim sFilter As String = ""
        Dim dr() As DataRow = Nothing

        filterString.Append(" AND data_version <= '" & dataVersion & "' ")
        filterString.Append(" AND bu_code = '" & buCode & "' ")

        'PM List
        Dim sPMList As StringBuilder = New StringBuilder("")
        If Not userRoles Is Nothing Then
            If userRoles.Contains(DASHBORADROLES.GM) Or userRoles.Contains(DASHBORADROLES.EXCO) Or userRoles.Contains(DASHBORADROLES.AM) _
            Or userRoles.Contains(DASHBORADROLES.QAG) Or userRoles.Contains(DASHBORADROLES.ADM) _
            Or userRoles.Contains(DASHBORADROLES.FH) Or userRoles.Contains(DASHBORADROLES.SBUH) Then

            ElseIf userRoles.Contains(DASHBORADROLES.TL) Then
                GetFilterPMList(sPMList, Session("team_code"))
                If Not String.IsNullOrEmpty(sPMList.ToString) Then
                    filterString.Append(" And prj_ld_id in (" & sPMList.ToString & ") ")
                End If
            ElseIf userRoles.Contains(DASHBORADROLES.PM) Then
                filterString.Append(" And prj_ld_id = '" & Session("logon_id") & "' ")
            End If
        End If


        dtProfile = prfService.GetProfileViewList("S", filterString.ToString)

        If userRoleFilter.ToString.Trim = "1 = 1" Then
            dr = dtProfile.Select
        Else
            dr = dtProfile.Select(userRoleFilter.ToString)
        End If

        If Not dr Is Nothing Then
            If dr.Length = 0 Then
                dtProfileResult = dtProfile.Clone
            ElseIf dr.Length > 0 Then
                dtProfileResult = dr.CopyToDataTable
            End If

        End If
        If Not dtProfileResult Is Nothing Then
            WebControlHelper.GridViewDataBind(gvResultBody, dtProfileResult)
        End If

    End Sub

    Private Sub CalcualteRAGCount(ByVal sSta As String, ByRef iStaRCnt As Integer, ByRef iStaACnt As Integer, ByRef iStaGCnt As Integer)
        Select Case sSta
            Case "R"
                iStaRCnt = iStaRCnt + 1
            Case "A"
                iStaACnt = iStaACnt + 1
            Case "G"
                iStaGCnt = iStaGCnt + 1
        End Select
    End Sub

    Private Function CalulateRAGStatus(ByRef iStaRCnt As Integer, ByRef iStaACnt As Integer, ByRef iStaGCnt As Integer) As String
        Dim sSta As String = ""

        If iStaRCnt > 0 Then
            sSta = "R"
        ElseIf iStaACnt > 0 Then
            sSta = "A"
        ElseIf iStaGCnt > 0 Then
            sSta = "G"
        End If

        CalulateRAGStatus = sSta
    End Function


    Private Sub GetFilterPMList(ByRef sPMList As StringBuilder, ByVal teamCode As String)

        Dim dtPM As DataTable = New DataTable
        dtPM = pmaUserService.GetActiveUserListByTeamCode(teamCode)
        If Not dtPM Is Nothing Then
            For Each drPM As DataRow In dtPM.Rows
                If Not String.IsNullOrEmpty(sPMList.ToString) Then
                    sPMList.Append(", ")
                End If
                sPMList.Append(" '" & drPM("logon_id") & "'")
            Next
        End If

        Dim dtSubTeam As DataTable = New DataTable
        dtSubTeam = pmaTeamService.GetSubTeamList(teamCode)
        If Not dtSubTeam Is Nothing Then
            For Each drSubTeam In dtSubTeam.Rows
                GetFilterPMList(sPMList, drSubTeam("team_code"))
            Next
        End If

    End Sub
#End Region







    Private Sub gvResultBody_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvResultBody.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim index As Integer = e.Row.RowIndex

            'Dim gvr As GridViewRow = gvResultBody.Rows(index)
            'Dim drView As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim sQtySta As String = e.Row.Cells(1).Text

            e.Row.Cells(1).Style.Add("background-color", SetRAGBackColor(e.Row.Cells(1).Text.ToString))
            e.Row.Cells(2).Style.Add("background-color", SetRAGBackColor(e.Row.Cells(2).Text.ToString))
            e.Row.Cells(3).Style.Add("background-color", SetRAGBackColor(e.Row.Cells(3).Text.ToString))
            e.Row.Cells(4).Style.Add("background-color", SetRAGBackColor(e.Row.Cells(4).Text.ToString))
            e.Row.Cells(5).Style.Add("background-color", SetRAGBackColor(e.Row.Cells(5).Text.ToString))



        End If
    End Sub

    Private Function SetRAGBackColor(ByVal sSta As String) As String
        Dim sBackColor As String = ""


        If sSta = "R" Then
            sBackColor = "Red"
        ElseIf sSta = "A" Then
            sBackColor = "#f0ad4e"
        ElseIf sSta = "G" Then
            sBackColor = "Green"
        End If

        SetRAGBackColor = sBackColor

    End Function
End Class