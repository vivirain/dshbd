﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO



Public Class BuReport
    Inherits System.Web.UI.Page


    Shared dtProfile As DataTable = New DataTable
    Shared dtProfileResult As DataTable = New DataTable

    Shared userRoles() As String = Nothing

    Shared dataVersion As String = ""
    Shared buFilter As String = ""

    Public totalRecords As Integer = 0
    Public iPage As Integer
    Public sAlertMsg As StringBuilder = New StringBuilder("")

    Dim rptAsOfDate As Date
    Dim sRptAsOfDate As String


    Dim prfService As IProfileService = New ProfileService
    Dim pmaTssPrjService As IPmaTssProjectService = New PmaTssProjectService
    Dim pmaTeamService As IPmaTeamService = New PmaTeamService
    Dim pmaBizUnitService As IPmaBizUnitService = New PmaBizUnitService
    Dim pmaUserService As IPmaUserService = New PmaUserService
    Dim metricService As IMetricService = New MetricService

    'Dim sqlHelper As SqlHelper
    Dim excelHelper As ExcelHelper = New ExcelHelper
    Dim logHelper As LogHelper

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Session("userRoles") Is Nothing Then
            userRoles = Session("userRoles").ToString.Split(",")
        End If

        Session("prf_id") = Nothing
        Session("tss_prj") = Nothing
        Session("bu_code") = Nothing

        If Not Page.IsPostBack Then
            txtDataReloadDt.Attributes.Add("readonly", True)

            Try
                BindSearchDropDown()

                QueryData()
            Catch ex As Exception
                sAlertMsg = New StringBuilder("Oops, failed to generate report.")
                logHelper.WriteLog("Page_Load: Failed to generate BU report.", ex)

            End Try
           

        End If


    End Sub


#Region "Search_Section_Data"
    Sub BindSearchDropDown()

        'Business Unit
        Dim dtBU As DataTable = New DataTable("BU")
        dtBU = pmaBizUnitService.getBizUnitFilterList(PROFILESTATUS.SUBMITTED)
        If Not dtBU Is Nothing Then
            If dtBU.Rows.Count > 1 Then
                dtBU = dtBU.Select("1=1", "display_name").CopyToDataTable
            End If
            WebControlHelper.ListBoxDataBind(lbBU, dtBU, "display_name", "BU_CODE")

            If dtBU.Rows.Count = 1 Then
                lbBU.SelectedValue = dtBU.Rows(0).Item("bu_code").ToString
            End If
        End If

    End Sub
#End Region

#Region "Search_Section_Buttons"

    Private Sub btnQuery_Click(sender As Object, e As System.EventArgs) Handles btnQuery.Click
        QueryData()
    End Sub

#End Region

#Region "Query"
    Sub QueryData()
        Dim filterString As StringBuilder = New StringBuilder("")
        Dim userRoleFilter As StringBuilder = New StringBuilder("1 = 1 ")
        Dim sPMFilter As StringBuilder = New StringBuilder("")
        Dim sTeamPrfList As StringBuilder = New StringBuilder("")


        Dim sFilter As String = ""
        Dim dr() As DataRow = Nothing

        If Not String.IsNullOrEmpty(txtDataReloadDt.Text) Then
            dataVersion = Format(CDate(txtDataReloadDt.Text), "yyyyMMdd")
            filterString.Append(" AND data_version <= '" & dataVersion & "' ")
        Else
            dataVersion = Format(Now, "yyyyMMdd")
        End If


        buFilter = GetSelectedBU()
        If Not String.IsNullOrEmpty(buFilter) Then
            filterString.Append(" AND bu_code in (" & buFilter & ") ")
        End If

        'PM List
        Dim sPMList As StringBuilder = New StringBuilder("")
        If userRoles Is Nothing Then
            Return
        End If

        If userRoles.Contains(DASHBORADROLES.GM) Or userRoles.Contains(DASHBORADROLES.EXCO) Or userRoles.Contains(DASHBORADROLES.AM) _
        Or userRoles.Contains(DASHBORADROLES.QAG) Or userRoles.Contains(DASHBORADROLES.ADM) Then

        Else
            sPMFilter.Append(" And ( prj_ld_id = '" & Session("logon_id") & "' OR created_by = '" & Session("logon_id") & "' ")

            If userRoles.Contains(DASHBORADROLES.FH) Or userRoles.Contains(DASHBORADROLES.SBUH) Or userRoles.Contains(DASHBORADROLES.TL) Then
                prfService.GetMyTeamProfilesHist(sTeamPrfList, Session("my_teams"), dataVersion)

                If Not String.IsNullOrEmpty(sTeamPrfList.ToString) Then
                    sPMFilter.Append(" OR prf_id in (" & sTeamPrfList.ToString & ") ")
                End If
            End If

            sPMFilter.Append(" ) ")
        End If
        filterString.Append(sPMFilter)


        dtProfile = prfService.GetProfileViewList("S", filterString.ToString)

        'If Not dtProfile Is Nothing Then
        '    dtProfile.Columns.Add("sbu_code")
        '    dtProfile.Columns.Add("sbu_name")
        '    dtProfile.Columns.Add("func_code")
        '    dtProfile.Columns.Add("func_name")


        '    For Each drProfile As DataRow In dtProfile.Rows
        '        Dim dtSBU As DataTable = New DataTable()
        '        Dim dtFunc As DataTable = New DataTable()

        '        dtSBU = pmaTeamService.GetTeam(drProfile("team_code"), TEAMLEVEL.SBU)
        '        If Not dtSBU Is Nothing Then
        '            If dtSBU.Rows.Count > 0 Then
        '                drProfile("sbu_code") = dtSBU.Rows(0).Item("team_code")
        '                drProfile("sbu_name") = dtSBU.Rows(0).Item("team_name")
        '            End If
        '        End If

        '        dtFunc = pmaTeamService.GetTeam(drProfile("team_code"), TEAMLEVEL.FUNC)
        '        If Not dtFunc Is Nothing Then
        '            If dtFunc.Rows.Count > 0 Then
        '                drProfile("func_code") = dtFunc.Rows(0).Item("team_code")
        '                drProfile("func_name") = dtFunc.Rows(0).Item("team_name")
        '            End If
        '        End If
        '    Next
        'End If

        If userRoleFilter.ToString.Trim = "1 = 1" Then
            dr = dtProfile.Select
        Else
            dr = dtProfile.Select(userRoleFilter.ToString)
        End If

        If Not dr Is Nothing Then
            If dr.Length = 0 Then
                dtProfileResult = dtProfile.Clone
            ElseIf dr.Length > 0 Then
                dtProfileResult = dr.CopyToDataTable
            End If

        End If

        Dim dtBuList As DataTable = New DataTable("BizUnit")
        dtBuList = pmaBizUnitService.getBizUnitFilterList(PROFILESTATUS.SUBMITTED)

        Dim dtBuReportView As DataTable = New DataTable
        Dim buCode As String = ""

        'Retrieve bu list for display
        If Not dtBuList Is Nothing Then
            dtBuReportView = dtBuList.Clone

            If dtBuList.Rows.Count > 0 Then
                Dim i As Integer = 0
                For i = dtBuList.Rows.Count - 1 To 0 Step -1
                    Dim drBu As DataRow = dtBuList.Rows(i)
                    Dim drBuReport As DataRow
                    buCode = drBu("bu_code")

                    If String.IsNullOrEmpty(buFilter) Then
                        drBuReport = dtBuReportView.NewRow
                        drBuReport.ItemArray = drBu.ItemArray

                        dtBuReportView.Rows.Add(drBuReport)
                    ElseIf buFilter.IndexOf(buCode) >= 0 Then
                        drBuReport = dtBuReportView.NewRow
                        drBuReport.ItemArray = drBu.ItemArray

                        dtBuReportView.Rows.Add(drBuReport)
                    End If
                Next
            End If
        End If

        If Not dtBuReportView Is Nothing Then
            dtBuReportView.Columns.Add("quality_sta")
            dtBuReportView.Columns.Add("scope_sta")
            dtBuReportView.Columns.Add("cost_sta")
            dtBuReportView.Columns.Add("schedule_sta")
            dtBuReportView.Columns.Add("resource_sta")

            dtBuReportView.Columns.Add("quality_sta_display")
            dtBuReportView.Columns.Add("scope_sta_display")
            dtBuReportView.Columns.Add("cost_sta_display")
            dtBuReportView.Columns.Add("schedule_sta_display")
            dtBuReportView.Columns.Add("resource_sta_display")

            dtBuReportView.Columns.Add("css_score")
            dtBuReportView.Columns.Add("data_version")

            For Each drBuRpt As DataRow In dtBuReportView.Rows
                buCode = drBuRpt("bu_code")
                drBuRpt("data_version") = dataVersion

                Dim iQtyStaRCnt As Integer = 0
                Dim iQtyStaACnt As Integer = 0
                Dim iQtyStaGCnt As Integer = 0

                Dim iScopeStaRCnt As Integer = 0
                Dim iScopeStaACnt As Integer = 0
                Dim iScopeStaGCnt As Integer = 0

                Dim iCostStaRCnt As Integer = 0
                Dim iCostStaACnt As Integer = 0
                Dim iCostStaGCnt As Integer = 0

                Dim iScheduleStaRCnt As Integer = 0
                Dim iScheduleStaACnt As Integer = 0
                Dim iScheduleStaGCnt As Integer = 0

                Dim iResourceStaRCnt As Integer = 0
                Dim iResourceStaACnt As Integer = 0
                Dim iResourceStaGCnt As Integer = 0

                Dim prjCodeArray As String() = {}
                Dim iUpperBound As Integer = 0

                If Not dtProfileResult Is Nothing Then
                    For Each drPrfResult As DataRow In dtProfileResult.Rows
                        Dim tssPrj As String = drPrfResult("tss_prj").ToString
                        If drPrfResult("bu_code") = buCode Then
                            If Not IsDBNull(drPrfResult("quality_status")) Then
                                CalcualteRAGCount(drPrfResult("quality_status"), iQtyStaRCnt, iQtyStaACnt, iQtyStaGCnt)
                            End If

                            If Not IsDBNull(drPrfResult("scope_status")) Then
                                CalcualteRAGCount(drPrfResult("scope_status"), iScopeStaRCnt, iScopeStaACnt, iScopeStaGCnt)
                            End If

                            If Not IsDBNull(drPrfResult("cost_status")) Then
                                CalcualteRAGCount(drPrfResult("cost_status"), iCostStaRCnt, iCostStaACnt, iCostStaGCnt)
                            End If

                            If Not IsDBNull(drPrfResult("schedule_status")) Then
                                CalcualteRAGCount(drPrfResult("schedule_status"), iScheduleStaRCnt, iScheduleStaACnt, iScheduleStaGCnt)
                            End If

                            If Not IsDBNull(drPrfResult("resource_status")) Then
                                CalcualteRAGCount(drPrfResult("resource_status"), iResourceStaRCnt, iResourceStaACnt, iResourceStaGCnt)
                            End If

                            Dim prjCodes As String = drPrfResult("prj_codes")
                            If Not String.IsNullOrEmpty(prjCodes) Then
                                Dim prjCodeList As String() = prjCodes.Split(",")
                                For Each prjCode As String In prjCodeList
                                    iUpperBound = IIf(prjCodeArray.Length <= 0, 0, prjCodeArray.Length)
                                    ReDim Preserve prjCodeArray(iUpperBound)
                                    prjCodeArray(iUpperBound) = prjCode
                                Next
                            End If

                        End If

                    Next 'End For Each drPrfResult As DataRow In dtProfileResult.Rows

                End If 'End If Not dtProfileResult Is Nothing Then

                drBuRpt("quality_sta") = CalulateRAGStatus(iQtyStaRCnt, iQtyStaACnt, iQtyStaGCnt)
                drBuRpt("scope_sta") = CalulateRAGStatus(iScopeStaRCnt, iScopeStaACnt, iScopeStaGCnt)
                drBuRpt("cost_sta") = CalulateRAGStatus(iCostStaRCnt, iCostStaACnt, iCostStaGCnt)
                drBuRpt("schedule_sta") = CalulateRAGStatus(iScheduleStaRCnt, iScheduleStaACnt, iScheduleStaGCnt)
                drBuRpt("resource_sta") = CalulateRAGStatus(iResourceStaRCnt, iResourceStaACnt, iResourceStaGCnt)

                drBuRpt("quality_sta_display") = RAGHelper.RAGDesc(drBuRpt("quality_sta").ToString)
                drBuRpt("scope_sta_display") = RAGHelper.RAGDesc(drBuRpt("scope_sta").ToString)
                drBuRpt("cost_sta_display") = RAGHelper.RAGDesc(drBuRpt("cost_sta").ToString)
                drBuRpt("schedule_sta_display") = RAGHelper.RAGDesc(drBuRpt("schedule_sta").ToString)
                drBuRpt("resource_sta_display") = RAGHelper.RAGDesc(drBuRpt("resource_sta").ToString)


                Dim prjMetricRawService As IProjectMetricRawService = New ProjectMetricRawService
                Dim prjMetricService As IProjectMetricService = New ProjectMetricService
                Dim dtBuPrjMetricRaw As DataTable = New DataTable
                If prjCodeArray.Length > 0 Then
                    'dtBuPrjMetricRaw = prjMetricRawService.GetProjectMetricRawHistList(prjCodeArray, dataVersion, True)
                    dtBuPrjMetricRaw = prjMetricRawService.GetProjectMetricRawHistListByMetric(prjCodeArray, METRICCODE.CSS, dataVersion, True)
                    If Not dtBuPrjMetricRaw Is Nothing Then
                        If dtBuPrjMetricRaw.Rows.Count > 0 Then
                            drBuRpt("css_score") = FormatNumber(prjMetricService.CalculateMetricValue(METRICCODE.CSS, dtBuPrjMetricRaw), 2)
                        End If
                    End If
                End If


            Next 'End  For Each drBuRpt As DataRow In dtBuReportView.Rows

        End If

        If Not dtBuReportView Is Nothing Then
            If dtBuReportView.Rows.Count > 0 Then
                dtBuReportView = dtBuReportView.Select("1=1", "bu_name").CopyToDataTable
            End If
        End If
        WebControlHelper.GridViewDataBind(gvResultBody, dtBuReportView)

    End Sub

    Private Sub CalcualteRAGCount(ByVal sSta As String, ByRef iStaRCnt As Integer, ByRef iStaACnt As Integer, ByRef iStaGCnt As Integer)
        Select Case sSta
            Case "R"
                iStaRCnt = iStaRCnt + 1
            Case "A"
                iStaACnt = iStaACnt + 1
            Case "G"
                iStaGCnt = iStaGCnt + 1
        End Select
    End Sub

    Private Function CalulateRAGStatus(ByRef iStaRCnt As Integer, ByRef iStaACnt As Integer, ByRef iStaGCnt As Integer) As String
        Dim sSta As String = ""

        If iStaRCnt > 0 Then
            sSta = "R"
        ElseIf iStaACnt > 0 Then
            sSta = "A"
        ElseIf iStaGCnt > 0 Then
            sSta = "G"
        End If

        CalulateRAGStatus = sSta
    End Function


    Private Function GetSelectedBU() As String
        Dim sBUSelected As String = ""

        For i As Integer = 0 To lbBU.Items.Count - 1
            If lbBU.Items(i).Selected = True Then
                sBUSelected = sBUSelected & IIf(sBUSelected = "", "'", ", '") & lbBU.Items(i).Value & "'"
            End If
        Next

        GetSelectedBU = sBUSelected
    End Function

    Private Sub GetFilterPMList(ByRef sPMList As StringBuilder, ByVal teamCode As String)

        Dim dtPM As DataTable = New DataTable
        dtPM = pmaUserService.GetActiveUserListByTeamCode(teamCode)
        If Not dtPM Is Nothing Then
            For Each drPM As DataRow In dtPM.Rows
                If Not String.IsNullOrEmpty(sPMList.ToString) Then
                    sPMList.Append(", ")
                End If
                sPMList.Append(" '" & drPM("logon_id") & "'")
            Next
        End If

        Dim dtSubTeam As DataTable = New DataTable
        dtSubTeam = pmaTeamService.GetSubTeamList(teamCode)
        If Not dtSubTeam Is Nothing Then
            For Each drSubTeam In dtSubTeam.Rows
                GetFilterPMList(sPMList, drSubTeam("team_code"))
            Next
        End If

    End Sub
#End Region

    Private Sub gvResultBody_DataBound(sender As Object, e As System.EventArgs) Handles gvResultBody.DataBound
        gvResultBody.Columns(7).Visible = False
        gvResultBody.Columns(8).Visible = False
        gvResultBody.Columns(9).Visible = False
        gvResultBody.Columns(10).Visible = False
        gvResultBody.Columns(11).Visible = False
        gvResultBody.Columns(12).Visible = False
        gvResultBody.Columns(13).Visible = False


    End Sub

    Private Sub gvResultBody_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvResultBody.RowCommand
        If e.CommandName = "viewBuPrfSta" Then


            Dim index As String = CType(e.CommandArgument(), Integer)
            Dim gvRow As GridViewRow = gvResultBody.Rows(index)

            Dim buCode As String = gvResultBody.DataKeys(index).Item(0)

            'Dim lbtnBuCode As LinkButton = gvResultBody.Rows(index).FindControl("")

            HttpContext.Current.Items.Remove("buCode")
            HttpContext.Current.Items.Add("buCode", buCode)
            'Server.Transfer("BuProfileReport.aspx")
        End If
    End Sub



    Private Sub gvResultBody_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvResultBody.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim index As Integer = e.Row.RowIndex

            If DataFormatHelper.StringTrim(e.Row.Cells(1).Text) = "" And DataFormatHelper.StringTrim(e.Row.Cells(2).Text) = "" _
                And DataFormatHelper.StringTrim(e.Row.Cells(3).Text) = "" And DataFormatHelper.StringTrim(e.Row.Cells(4).Text) = "" _
                And DataFormatHelper.StringTrim(e.Row.Cells(5).Text) = "" Then
                e.Row.Style.Add("display", "none")
                Return
            End If

            Dim sQtySta As String = e.Row.Cells(1).Text

            'e.Row.Cells(1).Style.Add("background-color", RAGHelper.RAGColor(DataFormatHelper.StringTrim(e.Row.Cells(9).Text)))
            'e.Row.Cells(2).Style.Add("background-color", RAGHelper.RAGColor(DataFormatHelper.StringTrim(e.Row.Cells(10).Text)))
            'e.Row.Cells(3).Style.Add("background-color", RAGHelper.RAGColor(DataFormatHelper.StringTrim(e.Row.Cells(11).Text)))
            'e.Row.Cells(4).Style.Add("background-color", RAGHelper.RAGColor(DataFormatHelper.StringTrim(e.Row.Cells(12).Text)))
            'e.Row.Cells(5).Style.Add("background-color", RAGHelper.RAGColor(DataFormatHelper.StringTrim(e.Row.Cells(13).Text)))

        End If
    End Sub

    Private Sub btnExport_Click(sender As Object, e As System.EventArgs) Handles btnExport.Click
        Dim fileName As String = "BU Report_" & Format(Now, "yyyyMMddHHmmss") & ".xlsx"

        ExportToExcel(fileName)
    End Sub

    Sub ExportToExcel(ByVal fileName As String)
        Dim bReturn As Boolean = False
        Dim dtExportAll As DataTable = New DataTable("dtExport")

        dtExportAll.Columns.Add("BU")
        dtExportAll.Columns.Add("Quality")
        dtExportAll.Columns.Add("Scope")
        dtExportAll.Columns.Add("Cost")
        dtExportAll.Columns.Add("Schedule")
        dtExportAll.Columns.Add("Resource")
        dtExportAll.Columns.Add("CSS")
        'dtExportAll.Columns.Add("Overall_Health")
        dtExportAll.Columns.Add("Data_Reload_Date")



        Dim sSelPrfId As StringBuilder = New StringBuilder("")
        For iRow As Integer = 0 To gvResultBody.Rows.Count - 1

            If gvResultBody.Rows(iRow).Style.Item("display") = "none" Then
                Continue For
            End If

            Dim drExport As DataRow = dtExportAll.NewRow

            'drExport("BU") = DataFormatHelper.StringTrim(gvResultBody.Rows(iRow).Cells(7).Text)
            drExport("BU") = DataFormatHelper.StringTrim(gvResultBody.Rows(iRow).Cells(0).Text)

            drExport("Quality") = DataFormatHelper.StringTrim(gvResultBody.Rows(iRow).Cells(1).Text())
            drExport("Scope") = DataFormatHelper.StringTrim(gvResultBody.Rows(iRow).Cells(2).Text())
            drExport("Cost") = DataFormatHelper.StringTrim(gvResultBody.Rows(iRow).Cells(3).Text())
            drExport("Schedule") = DataFormatHelper.StringTrim(gvResultBody.Rows(iRow).Cells(4).Text())
            drExport("Resource") = DataFormatHelper.StringTrim(gvResultBody.Rows(iRow).Cells(5).Text())

            drExport("CSS") = DataFormatHelper.StringTrim(gvResultBody.Rows(iRow).Cells(6).Text)
            'drExport("Data_Reload_Date") = DataFormatHelper.StringTrim(gvResultBody.Rows(iRow).Cells(8).Text)
            drExport("Data_Reload_Date") = DataFormatHelper.StringTrim(dataVersion)

            dtExportAll.Rows.Add(drExport)

        Next

        If Not dtExportAll Is Nothing Then
            If dtExportAll.Rows.Count > 0 Then
                'Export all rows
                excelHelper.NpoiDataTable2Excel(fileName, {New ExcelSheetContent("BU_Report", dtExportAll)})
            End If
        End If

    End Sub
End Class