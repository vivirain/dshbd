﻿Imports System.IO

Imports NPOI
Imports NPOI.SS
Imports NPOI.SS.UserModel
Imports NPOI.HSSF
Imports NPOI.HSSF.UserModel
Imports NPOI.HPSF
Imports NPOI.Util


Public Class MetricDataUpload
    Inherits System.Web.UI.Page



    Shared dtRole As DataTable = New DataTable

    Dim sAlertMsg As String = ""

    Dim sAlertScript As String = "<script>alert('{0}');</script>"

    Dim excelHelper As ExcelHelper = New ExcelHelper
    Dim dtBAU As DataTable = New DataTable("rawDataBAU")
    Dim dtPrj As DataTable = New DataTable("rawDataPrj")


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then


        End If
    End Sub



    Private Sub btnUpload_Click(sender As Object, e As System.EventArgs) Handles btnUpload.Click

        Try
            'Get full name
            Dim excelFile As String = rawDataFileUpload.PostedFile.FileName

            'Get file name without file extension.
            Dim excelFileName As String = Path.GetFileNameWithoutExtension(excelFile)

            'Get file extention.
            Dim extensionName = excelFile.Substring(excelFile.LastIndexOf(".") + 1)

            If Not ValidateFileCheck(excelFileName, extensionName) Then
                Return
            End If

            'New file name
            Dim nowDateTime As String = Now.ToString("yyyyMMddHHmmssffff")
            Dim newFileName = Session("logon_id") & nowDateTime & "." & extensionName

            'Save to stage folder
            Dim fileSavedPath As String = Server.MapPath("..\\..\tmpUpload") & "\" & newFileName
            rawDataFileUpload.PostedFile.SaveAs(fileSavedPath)

            'Retrieve excel data to datatale
            'Dim sSQL As String = "SELECT * FROM [{0}$]"
            'dtBAU = excelHelper.ExecuteOleDbAdapterQuery(String.Format(sSQL, "Raw Data-BAU"), fileSavedPath)
            'dtPrj = excelHelper.ExecuteOleDbAdapterQuery(String.Format(sSQL, "Raw Data-DEV"), fileSavedPath)
            dtBAU = excelHelper.NpoiExcel2DataTable(fileSavedPath, "Raw Data-BAU", True)
            dtPrj = excelHelper.NpoiExcel2DataTable(fileSavedPath, "Raw Data-DEV", True)


            'Check if file format is changed by manually.
            Dim prjMetricRawService As IProjectMetricRawService = New ProjectMetricRawService
            Dim dtRaw As DataTable = prjMetricRawService.GetBlankProjectMetricRaw()
            Dim bGood As Boolean = True

            Dim sScript As String = "<script>alert('Data layout is aleady modified, please double check before try it again.');</script>"

            If Not dtBAU Is Nothing And Not dtRaw Is Nothing Then
                For i As Integer = 9 To dtBAU.Columns.Count - 1
                    If Not dtBAU.Columns(i).ColumnName = dtRaw.Columns(i - 8).ColumnName Then
                        bGood = False
                        Exit For
                    End If
                Next

                If bGood Then
                    dtRaw.Merge(dtBAU, True, MissingSchemaAction.Ignore)
                Else
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", sScript, False)
                    Return
                End If
            End If

            If Not dtPrj Is Nothing And Not dtRaw Is Nothing Then
                For i As Integer = 9 To dtPrj.Columns.Count - 1
                    If Not dtPrj.Columns(i).ColumnName = dtRaw.Columns(i - 8).ColumnName Then
                        bGood = False
                        Exit For
                    End If
                Next
                If bGood Then
                    dtRaw.Merge(dtPrj, True, MissingSchemaAction.Ignore)
                Else
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", sScript, False)
                    Return
                End If
            End If


            If dtRaw.Rows.Count > 0 Then
                'Update all datarows' datarowstate to ADD
                For Each drRaw As DataRow In dtRaw.Rows
                    If drRaw.RowState = DataRowState.Unchanged Then
                        drRaw.SetAdded()
                    End If
                Next

                'Process DB Changes
                If WritetoDB(dtRaw) Then
                    DeleteTempFile(fileSavedPath)
                Else
                    sAlertMsg = "Failed to write data into database, please double check data and retry it again."
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", String.Format(sAlertScript, sAlertMsg), False)
                End If
            Else
                'Delete temp file
                DeleteTempFile(fileSavedPath)
            End If

        Catch ex As Exception
            sAlertMsg = "Data layout is aleady modified, please double check before try it again."
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", String.Format(sAlertScript, sAlertMsg), False)
        Finally

        End Try


    End Sub


    Private Function WritetoDB(ByRef dtRaw As DataTable) As Boolean
        Dim bWrite As Boolean = False
        'Update datatable into Project Project Metric Raw Table
        Dim sqlHelper As SqlHelper = New SqlHelper
        Dim sTable As String = "tpma_dshbd_prj_qty_metric_raw"
        Dim sRawSQL As String = "SELECT * FROM " & sTable
        If Not dtRaw Is Nothing Then
            If dtRaw.Rows.Count > 0 Then
                Dim sqlAdapterUpd As SqlAdapterUpdate() = {New SqlAdapterUpdate(sRawSQL, dtRaw)}
                bWrite = sqlHelper.ExecuteAdapterUpdate(sqlAdapterUpd)
            End If
        End If

        'Calcualte Project Metric
        If bWrite Then
            bWrite = UpdateProjectMetric(dtRaw)
        End If

        WritetoDB = bWrite

    End Function

    Private Sub DeleteTempFile(ByVal fileSavedPath As String)
        If (File.Exists(fileSavedPath)) Then
            File.Delete(fileSavedPath)
        End If
    End Sub


    Private Function ValidateFileCheck(ByVal excelFileName As String, ByVal extensionName As String) As Boolean
        Dim bFileOK As Boolean = True


        'Check if file is empty
        If String.IsNullOrEmpty(excelFileName) Then
            bFileOK = False
            sAlertMsg = "Please choose Excel file!"
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", String.Format(sAlertScript, sAlertMsg), False)

            'Check file type (extension)
        ElseIf extensionName <> "xls" And extensionName <> "xlsx" Then
            bFileOK = False
            sAlertMsg = "Invalid file format. Only Excel file with extension .xls or .xlsx is supported."
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Pop", String.Format(sAlertScript, sAlertMsg), False)
        End If

        ValidateFileCheck = bFileOK


    End Function

    Function UpdateProjectMetric(ByRef dtRaw As DataTable) As Boolean
        Dim bUpdate As Boolean = False

        If dtRaw Is Nothing Then
            Return False
        ElseIf dtRaw.Rows.Count = 0 Then
            Return False
        End If

        Dim prjMetricService As IProjectMetricService = New ProjectMetricService
        For Each drRaw As DataRow In dtRaw.Rows
            Dim dtRawUpdate As DataTable = dtRaw.Clone
            Dim drRawUpdate As DataRow = dtRawUpdate.NewRow()

            drRawUpdate.ItemArray = drRaw.ItemArray

            dtRawUpdate.Rows.Add(drRawUpdate)

            If Not dtRawUpdate Is Nothing Then
                If dtRawUpdate.Rows.Count > 0 Then
                    Dim prjCode As String = dtRawUpdate.Rows(0).Item("prj_code").ToString
                    Dim chgCtlNo As String = dtRawUpdate.Rows(0).Item("chg_ctl_no").ToString
                    bUpdate = prjMetricService.UploadProjectMetric(prjCode, dtRawUpdate)
                End If
            End If

            drRawUpdate.Delete()
            dtRawUpdate.Dispose()

            If Not bUpdate Then
                Exit For
            End If
        Next

        UpdateProjectMetric = bUpdate

    End Function



End Class