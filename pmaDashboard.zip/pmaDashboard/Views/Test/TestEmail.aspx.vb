﻿Imports System.Web
Imports System.Web.Services
Imports System.IO


Public Class TestEmail
    Inherits System.Web.UI.Page

    Public bAlert As Boolean = False
    Public sAlertMsg As String = ""
    Protected app As String = ""

    Dim mailTo As String = ""
    Dim mailCc As String = ""
    Dim mailSubject As String = ""
    Dim mailBody As String = ""

    Dim mailCcList As String() = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            txtMailTo.Text = ""
            txtMailCc.Text = ""
            txtMailSubject.Text = ""
            txtMailBody.Text = ""

            sAlertMsg = ""
        End If
    End Sub

    Public Sub sendInstantEmail()



    End Sub

    Sub PrepareEmailInput()
        mailTo = txtMailTo.Text.ToString.Trim
        mailCc = txtMailCc.Text.ToString.Trim
        mailSubject = txtMailSubject.Text.ToString.Trim
        mailBody = txtMailBody.Text.ToString.Trim

        If Not String.IsNullOrEmpty(mailCc) Then
            mailCcList = mailCc.Split(",")
        End If
    End Sub


    Private Sub btnAsyncEmail_Click(sender As Object, e As System.EventArgs) Handles btnAsyncEmail.Click
        PrepareEmailInput()
        'EmailHelper.SendAsyncEmail(mailTo.Split(","), mailSubject, mailBody, mailCcList)
    End Sub

    Private Sub btnDirectEmail_Click(sender As Object, e As System.EventArgs) Handles btnDirectEmail.Click
        Dim bSent As Boolean = False

        PrepareEmailInput()
        bSent = EmailHelper.SendInstantEmail(mailSubject, mailBody, mailTo.Split(","), mailCcList)

        If bSent Then
            sAlertMsg = "Email is sent out successfully."
        Else
            sAlertMsg = "Failed to sent out email."
        End If

    End Sub
End Class
