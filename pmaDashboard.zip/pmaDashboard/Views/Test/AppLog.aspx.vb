﻿Imports System.Web
Imports System.Web.Services
Imports System.IO


Public Class AppLog
    Inherits System.Web.UI.Page

    Public bAlert As Boolean = False
    Public sAlertMsg As String = ""
    Protected app As String = ""

    Dim mailTo As String = ""
    Dim mailCc As String = ""
    Dim mailSubject As String = ""
    Dim mailBody As String = ""

    Dim mailCcList As String() = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            BindLogFiles(gvInfo, "/Log/LogInfo")
            BindLogFiles(gvError, "/Log/LogErr")
            BindLogFiles(gvFatal, "/Log/LogFatal")
        End If
    End Sub



    Sub BindLogFiles(ByRef gv As GridView, ByVal folder As String)
        Dim folderPath As String = Server.MapPath("~" & folder)


        Dim logFiles As FileInfo() = New DirectoryInfo(folderPath).GetFiles


        If Not logFiles Is Nothing Then
            Dim dtLog As DataTable = New DataTable
            dtLog.Columns.Add("fileName")
            dtLog.Columns.Add("fullName")
            dtLog.Columns.Add("lastModifiedDate")
            dtLog.Columns.Add("size")

            For Each logFile As FileInfo In logFiles
                Dim drLog As DataRow = dtLog.NewRow
                drLog.Item("fileName") = logFile.Name
                drLog.Item("fullName") = logFile.FullName
                drLog.Item("lastModifiedDate") = logFile.LastWriteTime
                drLog.Item("size") = logFile.Length

                dtLog.Rows.Add(drLog)
            Next

            WebControlHelper.GridViewDataBind(gv, dtLog)
        End If
    End Sub

    Private Sub gvInfo_DataBound(sender As Object, e As System.EventArgs) Handles gvInfo.DataBound
        gvInfo.Columns(1).Visible = False
    End Sub

    Private Sub gvInfo_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvInfo.RowCommand
        If e.CommandName = "download" Then
            Dim index As String = CType(e.CommandArgument(), Integer)
            Dim gvRow As GridViewRow = gvInfo.Rows(index)

            Dim fileFullName As String = gvInfo.DataKeys(index).Item(0)

            DownloadFile(fileFullName)

        End If
    End Sub

    Private Sub gvFatal_DataBound(sender As Object, e As System.EventArgs) Handles gvFatal.DataBound
        gvFatal.Columns(1).Visible = False
    End Sub

    Private Sub gvError_DataBound(sender As Object, e As System.EventArgs) Handles gvError.DataBound
        gvError.Columns(1).Visible = False
    End Sub

    Private Sub gvError_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvError.RowCommand
        If e.CommandName = "download" Then
            Dim index As String = CType(e.CommandArgument(), Integer)
            Dim gvRow As GridViewRow = gvError.Rows(index)

            Dim fileFullName As String = gvError.DataKeys(index).Item(0)

            DownloadFile(fileFullName)

        End If
    End Sub

    Sub DownloadFile(ByVal fileFullName As String)
        Dim fileInfo As FileInfo = New FileInfo(fileFullName)
        If fileInfo.Exists() Then
            Response.Clear()
            Response.AddHeader("Content-Disposition", "inline;attachment; filename=" + fileInfo.Name)
            Response.AddHeader("Content-Length", fileInfo.Length.ToString())
            Response.ContentType = "application/octet-stream"
            Response.Flush()
            Response.WriteFile(fileInfo.FullName)
            Response.End()
        End If
    End Sub

    Private Sub gvFatal_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvFatal.RowCommand
        If e.CommandName = "download" Then
            Dim index As String = CType(e.CommandArgument(), Integer)
            Dim gvRow As GridViewRow = gvFatal.Rows(index)

            Dim fileFullName As String = gvFatal.DataKeys(index).Item(0)

            DownloadFile(fileFullName)

        End If
    End Sub
End Class
