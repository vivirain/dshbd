﻿Imports System.Web
Imports System.Web.Services
Imports System.IO


Public Class EmailDistribution
    Inherits System.Web.UI.Page

    Public bAlert As Boolean = False
    Public sAlertMsg As String = ""

    Dim scheduleJobService As IScheduleJobService = New ScheduleJobService

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            BindJobs()

            txtJobName.Text = ""
            txtCronExpress.Text = ""

            ddlJobFreq.SelectedValue = ""
            ddlSendBySbu.SelectedValue = "N"

            GetJob()
        End If
    End Sub



    Sub BindJobs()

        Dim dtJob As DataTable = scheduleJobService.GetEmailScheduleJob

        WebControlHelper.GridViewDataBind(gvCronJob, dtJob)

    End Sub


    Sub GetJob()
        Dim jobId As Integer = ddlJobId.SelectedValue
        Dim dtJob As DataTable = scheduleJobService.GetScheduleJob(jobId)

        If Not dtJob Is Nothing AndAlso dtJob.Rows.Count > 0 Then
            txtJobName.Text = dtJob.Rows(0).Item("job_name_display").ToString.Trim
            txtCronExpress.Text = dtJob.Rows(0).Item("cron_express").ToString.Trim
            ddlJobFreq.SelectedValue = dtJob.Rows(0).Item("job_freq").ToString.Trim
            ddlSendBySbu.SelectedValue = dtJob.Rows(0).Item("send_by_sbu").ToString.Trim
        End If
    End Sub

    Private Sub ddlJobId_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlJobId.SelectedIndexChanged
        GetJob()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As System.EventArgs) Handles btnEdit.Click
        Dim jobId As Integer = ddlJobId.SelectedValue
        Dim jobNameDisplay As String = txtJobName.Text.Trim
        Dim jobCronExpress As String = txtCronExpress.Text.Trim
        Dim jobFreq As String = ddlJobFreq.SelectedValue
        Dim emailSendBySbu As String = ddlSendBySbu.SelectedValue
        Dim bCronExpressChanged As Boolean = False
        Dim bTrue As Boolean = True

        Dim dtJob As DataTable = scheduleJobService.GetScheduleJob(jobId)

        If Not dtJob Is Nothing AndAlso dtJob.Rows.Count > 0 Then
            dtJob.Rows(0).Item("job_name_display") = jobNameDisplay
            dtJob.Rows(0).Item("job_freq") = jobFreq
            dtJob.Rows(0).Item("send_by_sbu") = emailSendBySbu

            If dtJob.Rows(0).Item("cron_express").ToString.Trim <> jobCronExpress Then
                bCronExpressChanged = True
            End If
            dtJob.Rows(0).Item("cron_express") = jobCronExpress

            bTrue = scheduleJobService.SaveScheduleJob(dtJob)
            If True Then
                sAlertMsg = "Schedule job is updated successfully."
            Else
                sAlertMsg = "Failed to update schedule job."
            End If

            If bTrue And bCronExpressChanged Then
                ScheduleJob.ReScheduleJob()
                sAlertMsg = "Cron Job Expression is updated and job is rescheduled."
            End If

            BindJobs()
        End If
    End Sub
End Class
