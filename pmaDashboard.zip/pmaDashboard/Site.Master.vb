﻿Imports System.IO

Public Class Site
    Inherits System.Web.UI.MasterPage

    Dim sbMenu As StringBuilder = New StringBuilder("")

    Public sProfileDesc As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("logon_id") Is Nothing Then
            Dim url As String = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & HttpContext.Current.Request.ApplicationPath
            If ErrorHelper.IsSessionExpired() Then
                'Server.Transfer("~/Views/Account/SessionOut.html")
                'LogHelper.WriteLog(url & "/Views/Account/SessionOut.html")
                Response.Redirect(url & "/Views/Account/SessionOut.html")
            Else
                'Server.Transfer("~/Default.aspx")
                Response.Redirect(url)
            End If

        End If

        If Not Page.IsPostBack And Not Session("logon_id") Is Nothing Then
            Try
                LoadUserMenus()
            Catch ex As Exception
                LogHelper.WriteLog("Failed to Load user menu", ex)
            End Try

        End If
        
    End Sub


    Sub LoadUserMenus()
            If Not Session("myMenu") Is Nothing Then
                sbMenu = New StringBuilder(Session("myMenu").ToString)
        Else
            Try
                Dim menuService As IMenuService = New MenuService
                Dim dtMyMenu As DataTable = New DataTable
                dtMyMenu = menuService.GetUserMenuItems(Session("myMenuString"))

                AddSidebarItem(dtMyMenu, 0, sbMenu)

                Session("myMenu") = sbMenu.ToString

                dtMyMenu.Dispose()
            Catch ex As Exception
            End Try
        End If


            ulMenu.InnerHtml = sbMenu.ToString

        
    End Sub


    Sub AddSidebarItem(ByVal dtMenu As DataTable, ByVal parentId As Integer, ByRef sbMenu As StringBuilder)
        Dim currentPage As String = Path.GetFileName(Request.Url.AbsolutePath)

        For Each drMenu As DataRow In dtMenu.Select("function_top_id = " & parentId)
            Dim bHaveSecondLevel As Boolean = False
            If dtMenu.Select("function_top_id = " & drMenu("function_id")).Length > 0 Then
                bHaveSecondLevel = True
            End If

            sbMenu.Append("<li")
            sbMenu.Append(" class=""")
            If bHaveSecondLevel Then
                sbMenu.Append("dropdown")
            End If
            sbMenu.Append("""")
            sbMenu.Append(">")

            sbMenu.Append("<a")
            If bHaveSecondLevel Then
                sbMenu.Append(" class=""dropdown-toggle"" data-toggle=""dropdown"" role=""button"" aria-haspopup=""true"" aria-expanded=""false""")
            End If
            sbMenu.Append(" href=""")
            If String.IsNullOrEmpty(drMenu("function_url").ToString) Then
                sbMenu.Append("#")
            Else
                sbMenu.Append(Request.ApplicationPath & drMenu("function_url"))
            End If
            sbMenu.Append("""")
            sbMenu.Append(">")
            If Not IsDBNull(drMenu("function_icon")) Then
                If Not String.IsNullOrEmpty(drMenu("function_icon")) Then
                    sbMenu.Append("<i class=" & """" & "fa fa-" & drMenu("function_icon") & """" & "></i> ")
                End If
            End If
            sbMenu.Append(drMenu("function_name"))
            sbMenu.Append("</a>")

            If bHaveSecondLevel Then
                sbMenu.Append("<ul class=" & """" & "dropdown-menu" & """" & " style=" & """" & """" & ">")
                AddSidebarItem(dtMenu, drMenu("function_id"), sbMenu)
                sbMenu.Append("</ul>")
            End If
            sbMenu.Append("</li>")

        Next
    End Sub



    Public Sub endSession()
        Session.Abandon()

        Response.Redirect(Request.Url.GetLeftPart(UriPartial.Authority))
    End Sub

End Class