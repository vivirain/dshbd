﻿Imports System.Web.SessionState
Imports System.IO
Imports log4net
Imports System.Net


Public Class GlobalClass
    Inherits System.Web.HttpApplication

    Private Shared _appUrl As String = String.Empty
    Public Shared ReadOnly Property AppUrl() As String
        Get
            If String.IsNullOrEmpty(_appUrl) Then
                _appUrl = ConfigurationManager.AppSettings("appUrl").ToString
            End If

            Return _appUrl
        End Get
    End Property


    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application is started
        LogHelper.WriteLog("---Application_Start---")
        ' For log
        log4net.Config.XmlConfigurator.ConfigureAndWatch(New FileInfo("log4net.config"))

        ' For Schedule Job
        Application("siteUrl") = appUrl
        LogHelper.WriteLog("Aplication URL: " & AppUrl)
        ScheduleJob.Start(appUrl)

        LogHelper.WriteLog("---Application is started successfully.---")
    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session is started
        Session("prf_id") = Nothing
        Session("bu_code") = Nothing
        Session("tss_prj") = Nothing
        Session("fixed_price_project") = Nothing
        Session("myProfile") = Nothing
        Session("logon_id") = Nothing
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires at the beginning of each request
        'LogHelper.WriteLog("---Application_BeginRequest---")
    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when an error occurs
        LogHelper.WriteLog("---System encounters errors---", Server.GetLastError.GetBaseException)
    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session ends
        LogHelper.WriteLog("Session ends for " & Session("logon_id"))

        Session("prf_id") = Nothing
        Session("bu_code") = Nothing
        Session("tss_prj") = Nothing
        Session("fixed_price_project") = Nothing
        Session("myProfile") = Nothing
        Session("logon_id") = Nothing
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
        LogHelper.WriteLog("---Application is ending now.---")
        ScheduleJob.Shutdown()

        Try
            System.Threading.Thread.Sleep(5000)
            LogHelper.WriteLog("---Try to restart application automatically.---")
            Dim appUrl As String = Application("siteUrl")
            If String.IsNullOrEmpty(appUrl) Then
                appUrl = AppUrl
            End If

            LogHelper.WriteLog("Aplication URL: " & appUrl)
            If String.IsNullOrEmpty(appUrl) Then
                LogHelper.WriteLog("App Url is empty.")
            Else
                Dim dummyUrl As String = appUrl.Trim
                If dummyUrl.Last() = "/" Then
                    dummyUrl = dummyUrl & "dummy.aspx"
                Else
                    dummyUrl = dummyUrl & "/dummy.aspx"
                End If
                Dim _httpWebRequest As HttpWebRequest = WebRequest.Create(appUrl)
                _httpWebRequest.UseDefaultCredentials = True
                _httpWebRequest.PreAuthenticate = True
                _httpWebRequest.Credentials = CredentialCache.DefaultCredentials

                Dim _httpWebResponse As HttpWebResponse = _httpWebRequest.GetResponse
                Dim _stream As Stream = _httpWebResponse.GetResponseStream
            End If

        Catch ex As Exception
            LogHelper.WriteLog("--Failed to restart application automatically.---", ex)
        End Try

    End Sub

End Class