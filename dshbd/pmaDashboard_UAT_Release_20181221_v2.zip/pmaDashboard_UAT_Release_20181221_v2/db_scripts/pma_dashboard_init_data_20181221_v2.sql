update [dbo].[tpma_dshbd_metric_raw] set [desc] = 'Actual Labor Cost' where [code] = 'ac'
go