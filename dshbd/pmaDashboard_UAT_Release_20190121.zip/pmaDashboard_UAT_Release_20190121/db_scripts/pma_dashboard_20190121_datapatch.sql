update [dbo].[tpma_dshbd_prj_issue]
set issue_owner_id_card = staff.id_card
from tpma_StaffBasic staff, tpma_dshbd_prj_issue issue
where staff.logon_id = issue.issue_owner
and staff.status = 'A'
