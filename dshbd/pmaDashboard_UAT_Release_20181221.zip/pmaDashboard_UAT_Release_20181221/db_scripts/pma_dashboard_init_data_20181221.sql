update [dbo].[tpma_dshbd_metric_raw] set [desc] = 'Cumulative Actual Effort' where [code] = 'actual_effort'
go
update [dbo].[tpma_dshbd_metric_raw] set [desc] = 'Total Number of Executed UAT Test Cases (exclude retest case)' where [code] = 'uat_test_cases_executed'
go