delete from tpma_email_template where tmp_id in (21, 22, 23)
go
insert into tpma_email_template values(
21, 'Profile_New_Submitted', '{0}:  New profiles submitted in the week of [{1}]', '<!DOCTYPE html>
<head>
<style>
    table {
        font-family:Arial, Helvetica, sans-serif;
        font-size:10px;
        width:100%;
		}
    .prfBgColor {
        background-color: #B4B4B4;
    }
</style>
</head>
<body style="background-color:#efefef;">
    <p>Please click <a href="{2}"><strong><u>HERE</u></strong></a> to access Delivery Dashboard.</p><br/>
	<table align="center">
                <tr style="font-size:12px">
                    <th style="width:20%"><u>TEAM</u></th>
                    <th style="width:32%" class="prfBgColor"><u>PROJECT NAME</u></th>
                    <th style="width:8%"><u>QUALITY</u></th>
                    <th style="width:8%"><u>SCHEDULE</u></th>
                    <th style="width:8%"><u>COST</u></th>
                    <th style="width:8%"><u>RESOURCE</u></th>
                    <th style="width:8%"><u>SCOPE</u></th>
                    <th style="width:8%"><u>CSS</u></th>
                </tr>
                {3}               
        <table>
</body>
</html>','', '')
go
insert into tpma_email_template values(
22, 'Profile_Update_1', '{0}: **Reminder** Update Profiles by [{1}]', '<!DOCTYPE html>
<head>
    <style>
    body {
        background-color:#efefef; 
        font-size:10px;
        font-family:Arial, Helvetica, sans-serif;
    }
    table {
        width:100%;
        font-size:10px;
    }
    thead {
        background-color: #878787;
        color:white;
        text-align:center;
        font-size:12px;
    }
    tbody {
        background-color:white;
    }
    .yellowText {
        color:#DEBA1F;
    }
    </style>
</head>
<body>
    <p>Please click <a href="{2}"><strong><u>HERE</u></strong></a> to access Delivery Dashboard.</p>
    <div>
        <p style="text-align:center; font-weight:bold; font-size:10px">**Ensure to PRESS ''SUBMIT'' or the version shall still remain in DRAFT FOLDER only, and the profile is NOT considered updated.</p>
        <table>
            <thead>
                <tr>
                    <th style="width:23%">TEAM</th>
                    <th style="width:25%">Below <span class="yellowText">Draft Updates</span> are <br/>pending for SUBMIT in DRAFT FOLDER</th>
                    <th style="width:27%">Below <span class="yellowText">pending Risks/Issues</span> <br/>DO NOT have Follow-up actions OR are overdue.</th>
                    <th style="width:25%">Below profile progress/status <br/>are <span class="yellowText">aging for 1+ weeks</span></th>
                </tr>
            </thead>
            <tbody>
                {3}
            </tbody>
        </table>
    </div>
    <div>{4}</div>
</body>
</html>','', '')
go
insert into tpma_email_template values(
23, 'Profile_Update_2', '{0}: ****FINAL CALL**** Update Profiles by [{1}]', '<!DOCTYPE html>
<head>
    <style>
    body {
        background-color:#efefef; 
        font-size:10px;
        font-family:Arial, Helvetica, sans-serif;
    }
    table {
        width:100%;
        font-size:10px;
    }
    thead {
        background-color: #878787;
        color:white;
        text-align:center;
        font-size:12px;
    }
    tbody {
        background-color:white;
    }
    .yellowText {
        color:#DEBA1F;
    }
    </style>
</head>
<body>
    <p>Please click <a href="{2}"><strong><u>HERE</u></strong></a> to access Delivery Dashboard.</p>
    <div>
        <p style="text-align:center; font-weight:bold; font-size:10px">**Ensure to PRESS ''SUBMIT'' or the version shall still remain in DRAFT FOLDER only, and the profile is NOT considered updated.</p>
        <table>
            <thead>
                <tr>
                    <th style="width:23%">TEAM</th>
                    <th style="width:25%">Below <span class="yellowText">Draft Updates</span> are <br/>pending for SUBMIT in DRAFT FOLDER</th>
                    <th style="width:27%">Below <span class="yellowText">pending Risks/Issues</span> <br/>DO NOT have Follow-up actions OR are overdue.</th>
                    <th style="width:25%">Below profile progress/status <br/>are <span class="yellowText">aging for 1+ weeks</span></th>
                </tr>
            </thead>
            <tbody>
                {3}
            </tbody>
        </table>
    </div>
    <div>{4}</div>
</body>
</html>','', '')
go