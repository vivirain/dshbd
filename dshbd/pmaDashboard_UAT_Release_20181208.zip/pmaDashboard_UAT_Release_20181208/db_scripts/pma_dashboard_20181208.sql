

/*********************************************************************************************************************
 *
 * Table
 *
 *********************************************************************************************************************/


/*******************************************************************
 * Project Profile
 *******************************************************************/
alter table [dbo].[tpma_dshbd_profile] add column [prj_ld_id_card_no] varchar(18)
go
alter table [dbo].[tpma_dshbd_profile_hist] add column [prj_ld_id_card_no] varchar(18)
go
alter table [dbo].[tpma_dshbd_prj_metric_raw_hist] drop constraint pk_dshbd_prj_metric_raw_hist
go
alter table [dbo].[tpma_dshbd_prj_metric_raw_hist] add constraint pk_dshbd_prj_metric_raw_hist primary key([id], [data_version])
go

/*********************************************************************************************************************
 *
 * View
 *
 *********************************************************************************************************************/
if exists (select 1 from sys.views where name = 'vpma_dshbd_project')
	drop view [dbo].[vpma_dshbd_project]
go
create view [dbo].[vpma_dshbd_project] as 
SELECT prj.*
	, masterPrj.prj_ld_id as master_pm, masterPrj.prj_ld_id_card_no as master_pm_id_card_no
	, [staff_name] as pm_name, staff.[status] as pm_status
	, staff.[team_code], team.[team_name]
	, bu.bu_name, bu.bu_full_name
    , tssprj.name as [tss_prj_name]
	, currency.[currency_name]   
FROM  (
SELECT [prj_code], [chg_ctl_no], [bill_approach], [system_bill_approach], (case when isnull([bill_approach],'') = 'S' and isnull([system_bill_approach],'') = 'F' then 'Y' else '' end) as fixed_price_prj
	   , [outsource_prj_code], [master_prj_code], [status]
       , [prj_dictor], [prj_ld_id], [prj_ld_id_card_no]
       , [prj_desc], [desc_detail], [prj_desc_chn], [desc_detail_chn]
	   , [bu_code], [tss_prj], [currency]
       , [est_tot_cost], [prj_tot_est_cost], [atl_cost], [atl_snp_cost], [atl_other_cost]
       , [est_tot_hour], [prj_tot_est_hour], [atl_hour]	
       , [est_strt_date], [est_cmpl_date], [atl_start], [atl_finish]
FROM [dbo].[tpma_project] a
WHERE EXISTS(
	SELECT 1 FROM (SELECT [prj_code], MAX(chg_ctl_no) as chg_ctl_no FROM [dbo].[tpma_project] GROUP BY [prj_code]) b
	WHERE [prj_code] = a.[prj_code] AND [chg_ctl_no] = a.[chg_ctl_no]
)
AND ISNULL([tss_prj], '') <> ''
) prj 
left join tpma_tss_prj masterPrj
on prj.master_prj_code = masterPrj.prj_code 
left join tpma_StaffBasic staff
on staff.logon_id = prj.prj_ld_id
and staff.id_card = prj.prj_ld_id_card_no 
and staff.[status] = 'A'
left join tpma_team team
on staff.team_code = team.team_code
--and team.[status] = 'A' 
--and team.chargeable = 'Y'
left join tpma_business_unit bu
on prj.bu_code = bu.bu_code 
--and [active] = 'Y'
left join tpma_tss_project tssprj
on prj.tss_prj = tssprj.code
--and [active] = 'Y' 
left join tpma_currency currency
on prj.currency = currency.currency_code 
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_profile')
	drop view [dbo].[vpma_dshbd_profile]
go
create view [dbo].[vpma_dshbd_profile] as 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, team_code, tssPrj.name as tssPrj_Name
from [tpma_dshbd_profile] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
--and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
and prf.prj_ld_id_card_no = staff.id_card
--and staff.status = 'A'
left join [tpma_tss_project] tssPrj
on prf.tss_prj = tssPrj.code 
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_profile_hist')
	drop view [dbo].[vpma_dshbd_profile_hist]
go
create view [dbo].[vpma_dshbd_profile_hist] as 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, team_code, tssPrj.name as tssPrj_Name  
from [tpma_dshbd_profile_hist] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
--and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
and prf.prj_ld_id_card_no = staff.id_card
--and staff.status = 'A'
left join [tpma_tss_project] tssPrj
on prf.tss_prj = tssPrj.code 
go
  