1. Add condition "id_card" while joining table tpma_staffbasic:
   - view: vpma_dshbd_project
2. Add new column "prj_ld_id_card_no" into tpma_dshbd_profile and tpma_dshbd_profile_hist:
   - table: tpma_dshbd_profile, tpma_dshbd_profile_hist;
   - view: vpma_dshbd_profile, vpma_dshbd_profile_hist
3. Add desc sorting withing dashboard page
4. Allow TL or above, system admin to modify profile project leader
5. Profile Basic Information Tab: 
   - Remove [Team]
   - Add [Fixed Price Project]
   - Move row [project leader] above [project name]
6. Fix can't re-submit profile issue, updating primary key constraint:
   - table: tpma_dshbd_prj_metric_raw_hist
7. Fix bugs within Issues tab
8. Fix bug - Failed to create profile after sorting within SR selection page
9. Fix bug - metric value with percentage type has only 2 values: 100% or 0%