delete tpma_dshbd_prj_schedule
go
delete tpma_dshbd_prj_issue
go
delete tpma_dshbd_prj_metric_raw_hist
go
delete tpma_dshbd_prj_metric_raw
go
delete tpma_dshbd_prj_metric_hist
go
delete tpma_dshbd_prj_metric
go
delete tpma_dshbd_profile_hist
go
delete tpma_dshbd_profile
go