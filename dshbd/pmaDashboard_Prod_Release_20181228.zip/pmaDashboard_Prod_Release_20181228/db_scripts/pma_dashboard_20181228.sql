/***********************************************************************************************
*
* [vv] - [Dec27,2018] - Add prj_stage_desc within view 'vpma_dshbd_profile' & 'vpma_dshbd_profile_hist'
* [vv] - [Dec28,2018] - Add issue_desc_sys within table 'tpma_dshbd_prj_issue' and view 'vpma_dshbd_prj_issue'
*
*********************************************************************************************************************/
/*********************************************************************************************************************
 *
 * Table
 *
 *********************************************************************************************************************/
alter table [dbo].[tpma_dshbd_prj_issue] add [issue_desc_sys] nvarchar(100)
go

/*********************************************************************************************************************
 *
 * View
 *
 *********************************************************************************************************************/
if exists (select 1 from sys.views where name = 'vpma_dshbd_profile')
	drop view [dbo].[vpma_dshbd_profile]
go
create view [dbo].[vpma_dshbd_profile] as 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, team_code, tssPrj.name as tssPrj_Name,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'STAGE' and lookup_code = prf.prj_stage) as prj_stage_desc
from [tpma_dshbd_profile] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
--and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
and prf.prj_ld_id_card_no = staff.id_card
--and staff.status = 'A'
left join [tpma_tss_project] tssPrj
on prf.tss_prj = tssPrj.code 
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_profile_hist')
	drop view [dbo].[vpma_dshbd_profile_hist]
go
create view [dbo].[vpma_dshbd_profile_hist] as 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, team_code, tssPrj.name as tssPrj_Name,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'STAGE' and lookup_code = prf.prj_stage) as prj_stage_desc  
from [tpma_dshbd_profile_hist] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
--and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
and prf.prj_ld_id_card_no = staff.id_card
--and staff.status = 'A'
left join [tpma_tss_project] tssPrj
on prf.tss_prj = tssPrj.code 
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_prj_issue')
	drop view [dbo].[vpma_dshbd_prj_issue]
go
create view [dbo].[vpma_dshbd_prj_issue] as
select issue.*
, lookup_a.lookup_name as issue_status_desc
, lookup_b.lookup_name as issue_track_status_desc
, lookup_c.lookup_name as issue_severity_desc
, lookup_d.lookup_name as issue_probability_desc
, lookup_e.lookup_name as issue_cate_desc
, lookup_f.lookup_name as issue_tag_desc
, staff.staff_name as issue_owner_name
from 
tpma_dshbd_prj_issue issue
left join tpma_dshbd_lookup lookup_a
on lookup_a.lookup_code = issue.issue_status 
and lookup_a.lookup_type = 'B'
and lookup_a.category = 'ISSUESTA'
left join tpma_dshbd_lookup lookup_b
on lookup_b.lookup_code = issue.issue_trace_status 
and lookup_b.lookup_type = 'B'
and lookup_b.category = 'STATUS'
left join tpma_dshbd_lookup lookup_c
on lookup_c.lookup_code = issue.issue_severity 
and lookup_c.lookup_type = 'B'
and lookup_c.category = 'SEVERITY'
left join tpma_dshbd_lookup lookup_d
on lookup_d.lookup_code = issue.issue_probability 
and lookup_d.lookup_type = 'B'
and lookup_d.category = 'SEVERITY'
left join tpma_dshbd_lookup lookup_e
on lookup_e.lookup_code = issue.issue_category 
and lookup_e.lookup_type = 'B'
and lookup_e.category = 'ISSUECATE'
left join tpma_dshbd_lookup lookup_f
on lookup_f.lookup_code = issue.issue_tag
and lookup_f.lookup_type = 'B'
and lookup_f.category = 'ISSUETAG'
left join tpma_StaffBasic staff 
on staff.logon_id = issue.issue_owner 
go