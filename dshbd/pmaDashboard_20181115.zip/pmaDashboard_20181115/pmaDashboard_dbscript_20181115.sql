/**************************************************************************************
--Lookup Table
 **************************************************************************************/
 DELETE FROM [dbo].[tpma_dshbd_lookup] WHERE [lookup_type] = 'S'
GO


INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'SYSCATE', 'System Category', 'EMAIL', 'Email', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'EMAIL', 'Email', 'email_from_account', '', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'EMAIL', 'Email', 'email_host_ip', '', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'EMAIL', 'Email', 'email_template_name', '', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'SYSCATE', 'System Category', 'AUTHORITY', 'Authority', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'AUTHORITY', 'Authority', 'ROLE', 'Role Users', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'AUTHORITY', 'Authority', 'BU', 'BU Users', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'SYSCATE', 'System Category', 'MISC', 'misc', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'DATE_FORMAT', 'yyyyMMdd', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'Show_Metric_Per_Profile', 'Y', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'Save_Metric_Raw_Directly', 'Y', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'Risk_No', 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'Issue_No', 1, 'Y', 'SYSTEM')
GO


/**************************************************************************************
--function
 **************************************************************************************/
DELETE FROM [dbo].[tpma_dshbd_function] WHERE [function_top_id] = 5
GO

INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (51, 'Quality Metrics', 51, 5, 'Y', '/Views/Housekeeping/Metrics.aspx', '', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (52, 'Quality Metrics Target', 52, 5, 'Y', '/Views/Housekeeping/MetricsTarget.aspx', '', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (53, 'Menu Functions', 53, 5, 'Y', '/Views/Housekeeping/MenuFunction.aspx', '', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (54, 'Authority', 54, 5, 'Y', '/Views/Housekeeping/Authority.aspx', '', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (55, 'Reference Data', 55, 5, 'Y', '/Views/Housekeeping/ReferenceDataCategory.aspx', '', 'N', 'Y', 'SYSTEM')
GO


/**************************************************************************************
--function auth
 **************************************************************************************/
DELETE FROM [dbo].[tpma_dshbd_function_auth] WHERE [function_id] > 50 AND [role_id] = 1
GO

INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (51, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (52, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (53, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (54, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (55, 1, 'Y', 'SYSTEM')
GO