update [dbo].[tpma_project]
set [status] = '02'
where prj_code in ('2180165', '2180437','2170330','2170019','3180072')
and chg_ctl_no = '00'
and [status] = '10'
go
update [dbo].[tpma_project]
set [status] = '03'
where prj_code in ('2180165', '2180437','2170330','2170019','3180072')
and chg_ctl_no <> '00'
and [status] = '10'
go