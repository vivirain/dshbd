/*******************************************************************************
 * Enlarge profile's field length for:
 *     - Efforts (est_total_hours, actl_total_hours, est_prj_total_hours, actl_prj_total_hours)
 *     - ProjectCodeList (prjcodes) 
 *******************************************************************************/
alter table [dbo].[tpma_dshbd_profile] alter column est_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile] alter column actl_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile] alter column est_prj_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile] alter column actl_prj_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile_hist] alter column est_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile_hist] alter column actl_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile_hist] alter column est_prj_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile_hist] alter column actl_prj_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile] alter column prj_codes varchar(max)
go
alter table [dbo].[tpma_dshbd_profile_hist] alter column prj_codes varchar(max)
go
/*******************************************************************************
 * Fix duplicated issues displayed on page:
 *     - Add a new field issue_owner_id_card
 *     - mapping issue_owner_id_card with staffbasic.id_card
 *******************************************************************************/
alter table [dbo].[tpma_dshbd_prj_issue] add issue_owner_id_card char(18)
go
if exists (select 1 from sys.views where name = 'vpma_dshbd_prj_issue')
	drop view [dbo].[vpma_dshbd_prj_issue]
go
create view [dbo].[vpma_dshbd_prj_issue] as
select issue.*
, lookup_a.lookup_name as issue_status_desc
, lookup_b.lookup_name as issue_track_status_desc
, lookup_c.lookup_name as issue_severity_desc
, lookup_d.lookup_name as issue_probability_desc
, lookup_e.lookup_name as issue_cate_desc
, lookup_f.lookup_name as issue_tag_desc
, staff.staff_name as issue_owner_name
from 
tpma_dshbd_prj_issue issue
left join tpma_dshbd_lookup lookup_a
on lookup_a.lookup_code = issue.issue_status 
and lookup_a.lookup_type = 'B'
and lookup_a.category = 'ISSUESTA'
left join tpma_dshbd_lookup lookup_b
on lookup_b.lookup_code = issue.issue_trace_status 
and lookup_b.lookup_type = 'B'
and lookup_b.category = 'STATUS'
left join tpma_dshbd_lookup lookup_c
on lookup_c.lookup_code = issue.issue_severity 
and lookup_c.lookup_type = 'B'
and lookup_c.category = 'SEVERITY'
left join tpma_dshbd_lookup lookup_d
on lookup_d.lookup_code = issue.issue_probability 
and lookup_d.lookup_type = 'B'
and lookup_d.category = 'SEVERITY'
left join tpma_dshbd_lookup lookup_e
on lookup_e.lookup_code = issue.issue_category 
and lookup_e.lookup_type = 'B'
and lookup_e.category = 'ISSUECATE'
left join tpma_dshbd_lookup lookup_f
on lookup_f.lookup_code = issue.issue_tag
and lookup_f.lookup_type = 'B'
and lookup_f.category = 'ISSUETAG'
left join tpma_StaffBasic staff 
on staff.logon_id = issue.issue_owner
and staff.id_card = issue.issue_owner_id_card 
go
