/*********************************************************************************************************************
 *
 * Table
 *
 *********************************************************************************************************************/
if not exists (
	SELECT 1 FROM SYSOBJECTS t1 INNER JOIN SYSCOLUMNS t2 ON t1.ID=t2.ID WHERE t1.NAME='tpma_dshbd_schedule_job' AND t2.NAME='job_freq'
)
	alter table [dbo].[tpma_dshbd_schedule_job] add job_freq varchar(20)
go
if not exists (
	SELECT 1 FROM SYSOBJECTS t1 INNER JOIN SYSCOLUMNS t2 ON t1.ID=t2.ID WHERE t1.NAME='tpma_dshbd_schedule_job' AND t2.NAME='send_by_sbu'
)
	alter table [dbo].[tpma_dshbd_schedule_job] add send_by_sbu char(1) default 'N'
go

if exists (select 1 from sys.tables where name = 'tpma_dshbd_email_unsubscription')
	drop table [dbo].[tpma_dshbd_email_unsubscription]
go
create table [dbo].[tpma_dshbd_email_unsubscription](
	id int identity(1,1) not null,
	email_tmp_id int,
	email_tmp_name nvarchar(100),
	pma_email varchar(100),
	email_unsubscribed char(1) default 'Y',
	created_by varchar(20),
	created_dt datetime,
	last_updated_by varchar(20),
	last_updated_dt datetime default current_timestamp

	constraint pk_dshbd_email_unsubscription primary key ([id])
)

/*********************************************************************************************************************
 *
 * Stored Procedure
 *
 *********************************************************************************************************************/
if exists (select 1 from sys.procedures where name = 'usp_dshbd_job_profile_new_submitted')
	drop procedure [dbo].[usp_dshbd_job_profile_new_submitted]
go
create procedure [dbo].[usp_dshbd_job_profile_new_submitted]
as
create table #dshbd_prf_new_submitted(prf_id int
	, prf_desc varchar(100)
	, prf_main_code varchar(7)
	, prj_codes varchar(max)
	, bu_code varchar(10)
	, bu_name varchar(100)
	, prj_ld_id varchar(7)
	, prj_ld_id_card_no varchar(18)
	, prj_ld_name char(30)
	, prj_ld_email char(60)
	, team_code int
	, team_name varchar(100)
	, tl_email char(60)
	, dtl_email char(60)
	, sbu_code int
	, sbu_name varchar(100)
	, sbuh_email char(60)
	, dsbuh_email char(60)
	, func_code int
	, func_name varchar(100)
	, funch_email char(60)
	, dfunch_email char(60)
	, prf_health_sta varchar(5)
	, prf_quality_sta varchar(5)
	, prf_schedule_sta varchar(5)
	, prf_scope_sta varchar(5)
	, prf_resource_sta varchar(5)
	, prf_cost_sta varchar(5)
	, prf_css_sta varchar(5) 
	)
 
declare @jobFreq as varchar(20)
select @jobFreq = upper(isnull(job_freq,'DAILY')) from tpma_dshbd_schedule_job where job_id = 1
if @jobFreq = ''
	set @jobFreq = 'DAILY'

declare @jobDate date
declare @lastJobDate date
declare @jobInterval as int
select @jobDate = convert(date, getdate())

select @lastJobDate = (case
	when  @jobFreq = 'DAILY' then dateadd(day, -1, @jobDate) 
	when  @jobFreq = 'WORKDAY' then dateadd(day, -1, @jobDate) 
	when  @jobFreq = 'WEEKLY' then dateadd(week, -1, @jobDate) 
	when  @jobFreq = 'BIWEEKLY' then dateadd(week, -2, @jobDate) 
	when  @jobFreq = 'MONTHLY' then dateadd(MONTH, -1, @jobDate)
	when  @jobFreq = 'YEARLY' then dateadd(YEAR, -1, @jobDate)
	else dateadd(day, -1, @jobDate) 
	end)
if (@jobFreq = 'WORKDAY' and DATEPART(weekday, CONVERT(datetime, @jobdate, 112)) = 2)
	select @lastJobDate = DATEADD(day, -3, @jobdate)

insert into #dshbd_prf_new_submitted(prf_id
	, prf_desc
	, prf_main_code
	, prj_codes
	, bu_code
	, bu_name
	, prj_ld_id
	, prj_ld_id_card_no
	, prj_ld_name
	, team_code
	, team_name
	, sbu_code
	, sbu_name
	, func_code
	, func_name
	, prf_health_sta
	, prf_quality_sta
	, prf_schedule_sta
	, prf_scope_sta
	, prf_resource_sta
	, prf_cost_sta
	, prf_css_sta
	 )
select prf_id
	, prf_desc
	, prf_main_code 
	, prj_codes
	, bu_code
	, bu_name
	, prj_ld_id 
	, prj_ld_id_card_no 
	, staff_name
	, team_code
	, team_name
	, sbu_code
	, sbu_name
	, func_code
	, func_name
	, health_status 
	, quality_status 
	, schedule_status 
	, scope_status 
	, resource_status 
	, cost_status
	, css_status  
from vpma_dshbd_profile_hist prf
where [status] = 'S'
and convert(date, data_version,112) < @jobDate 
and convert(date, data_version,112) >= @lastJobDate 
and not exists (select 1 from tpma_dshbd_profile_hist where prf_id = prf.prf_id 
and convert(date, data_version,112) < @lastJobDate) 


update #dshbd_prf_new_submitted 
set prj_ld_email = staff.email
from #dshbd_prf_new_submitted prfNew, tpma_staffbasic staff
where prfNew.prj_ld_id = staff.logon_id
and prfNew.prj_ld_id_card_no = staff.id_card

--TL & DTL Email
update #dshbd_prf_new_submitted 
set tl_email  = staff.email
from #dshbd_prf_new_submitted prfNew, tpma_staffbasic staff, tpma_team team
where prfNew.team_code = team.team_code
and team.tl_id = staff.logon_id and team.tl_id_card = staff.id_card
update #dshbd_prf_new_submitted 
set dtl_email  = staff.email
from #dshbd_prf_new_submitted prfNew, tpma_staffbasic staff, tpma_team team
where prfNew.team_code = team.team_code
and team.dtl_id = staff.logon_id and team.dtl_id_card = staff.id_card

--SBU Head Email
update #dshbd_prf_new_submitted 
set sbuh_email  = staff.email
from #dshbd_prf_new_submitted prfNew, tpma_staffbasic staff, tpma_team team
where prfNew.sbu_code = team.team_code
and team.tl_id = staff.logon_id and team.tl_id_card = staff.id_card
update #dshbd_prf_new_submitted 
set dsbuh_email  = staff.email
from #dshbd_prf_new_submitted prfNew, tpma_staffbasic staff, tpma_team team
where prfNew.sbu_code = team.team_code
and team.dtl_id = staff.logon_id and team.dtl_id_card = staff.id_card

--Function Head Email
update #dshbd_prf_new_submitted 
set funch_email  = staff.email
from #dshbd_prf_new_submitted prfNew, tpma_staffbasic staff, tpma_team team
where prfNew.func_code = team.team_code
and team.tl_id = staff.logon_id and team.tl_id_card = staff.id_card
update #dshbd_prf_new_submitted 
set dfunch_email  = staff.email
from #dshbd_prf_new_submitted prfNew, tpma_staffbasic staff, tpma_team team
where prfNew.func_code = team.team_code
and team.dtl_id = staff.logon_id and team.dtl_id_card = staff.id_card

select * from #dshbd_prf_new_submitted order by func_code, sbu_code, team_code
GO

if exists (select 1 from sys.procedures where name = 'usp_dshbd_profile_push')
	drop procedure [dbo].[usp_dshbd_profile_push]
go
if exists (select 1 from sys.procedures where name = 'usp_dshbd_job_profile_upd_push')
	drop procedure [dbo].[usp_dshbd_job_profile_upd_push]
go
create procedure [dbo].[usp_dshbd_job_profile_upd_push]
	@job_id int
as
create table #dshbd_prf_push(prf_id int
	, prf_desc varchar(100)
	, prf_main_code varchar(7)
	, prj_codes varchar(max)
	, func_code int
	, func_name varchar(100)
	, funch_email char(60)
	, dfunch_email char(60)
	, sbu_code int
	, sbu_name varchar(100)
	, sbuh_email char(60)
	, dsbuh_email char(60)
	, team_code int
	, team_name varchar(100)
	, tl_email char(60)
	, dtl_email char(60)
	, prj_ld_id varchar(7)
	, prj_ld_id_card_no varchar(18)
	, prj_ld_name char(30)
	, prj_ld_email char(60)
	, push_type char(1)
	)

declare @rpt_date_str varchar(16)
declare @rpt_date date
declare @last_rpt_date date
declare @rpt_frequency varchar(10)
declare @rpt_interval int

select @rpt_date_str = [lookup_name] from tpma_dshbd_lookup where lookup_type = 'S' and category = 'MISC' and lookup_code = 'NEXT_REPORT_DATE' and is_active = 'Y'
if (isdate(@rpt_date_str) = 0) begin
	Select @rpt_date = convert(date, getdate())
end
else begin
	select @rpt_date = convert(date,@rpt_date_str)
end

--select @rpt_frequency = upper([lookup_name]) from tpma_dshbd_lookup where lookup_type = 'S' and category = 'MISC' and lookup_code = 'REPORT_FREQUENCY' and is_active = 'Y'
select @rpt_frequency = upper(isnull(job_freq,'WEEKLY')) from tpma_dshbd_schedule_job where job_id = @job_id
if @rpt_frequency = ''
	set @rpt_frequency = 'WEEKLY'

declare @jobDate date
declare @lastJobDate date
declare @jobInterval as int
select @jobDate = convert(date, getdate())

select @last_rpt_date = (case
	when  @rpt_frequency = 'DAILY' then dateadd(day, -1, @rpt_date) 
	when  @rpt_frequency = 'WORKDAY' then dateadd(day, -1, @rpt_date) 
	when  @rpt_frequency = 'WEEKLY' then dateadd(week, -1, @rpt_date) 
	when  @rpt_frequency = 'BIWEEKLY' then dateadd(week, -2, @rpt_date) 
	when  @rpt_frequency = 'MONTHLY' then dateadd(MONTH, -1, @rpt_date)
	when  @rpt_frequency = 'YEARLY' then dateadd(YEAR, -1, @rpt_date)
	else dateadd(week, -1, @rpt_date) 
	end)
if (@rpt_frequency = 'WORKDAY' and DATEPART(weekday, CONVERT(datetime, @jobdate, 112)) = 2)
	select @lastJobDate = DATEADD(day, -3, @jobdate)

--Draft profile in DRAFT FOLDER
insert into #dshbd_prf_push(prf_id
	, prf_desc
	, prf_main_code
	, prj_codes
	, prj_ld_id
	, prj_ld_id_card_no
	, prj_ld_name
	, team_code
	, team_name
	, sbu_code
	, sbu_name
	, func_code
	, func_name
	, push_type )
select distinct prf_id
	, prf_desc
	, prf_main_code 
	, prj_codes
	, prj_ld_id 
	, prj_ld_id_card_no 
	, staff_name
	, team_code
	, team_name
	, sbu_code
	, sbu_name
	, func_code
	, func_name
	, 'D' 
from vpma_dshbd_profile prf
where [status] = 'D'
and not exists (select 1 from tpma_dshbd_profile_hist where prf_id = prf.prf_id)

--Outdated profiles
insert into #dshbd_prf_push(prf_id
	, prf_desc
	, prf_main_code
	, prj_codes
	, prj_ld_id
	, prj_ld_id_card_no
	, prj_ld_name
	, team_code
	, team_name
	, sbu_code
	, sbu_name
	, func_code
	, func_name
	, push_type )
select distinct prf_id
	, prf_desc
	, prf_main_code 
	, prj_codes
	, prj_ld_id 
	, prj_ld_id_card_no 
	, staff_name
	, team_code
	, team_name
	, sbu_code
	, sbu_name
	, func_code
	, func_name
	, 'S' 
from vpma_dshbd_profile_hist  prf
where [status] = 'S'
and data_version <= (Select convert(char(8), @last_rpt_date,112))
and not exists (select 1 from tpma_dshbd_profile_hist where prf_id = prf.prf_id and data_version > (Select convert(char(8), dateadd(day, 1,@last_rpt_date),112)))

--Profiles pending for risk/issue follow-up
insert into #dshbd_prf_push(prf_id
	, prf_desc
	, prf_main_code
	, prj_codes
	, prj_ld_id
	, prj_ld_id_card_no
	, prj_ld_name
	, team_code
	, team_name
	, sbu_code
	, sbu_name
	, func_code
	, func_name
	, push_type )
select distinct prf_id
	, prf_desc
	, prf_main_code 
	, prj_codes
	, prj_ld_id 
	, prj_ld_id_card_no 
	, staff_name
	, team_code
	, team_name
	, sbu_code
	, sbu_name
	, func_code
	, func_name
	, 'I' 
from vpma_dshbd_profile_hist  prf
where [status] = 'S'
and data_version = (
	select data_version from (select prf_id, max(data_version) as data_version from vpma_dshbd_profile_hist group by prf_id) b where b.prf_id = prf.prf_id )
and exists (
select 1 from tpma_dshbd_prj_issue issue where isnull(parent_issue_no,'') = '' and (issue_status = 'O' or issue_status = 'P')
and (
not exists (select 1 from tpma_dshbd_prj_issue where isnull(parent_issue_no,'') = issue.issue_no and issue_status in ('O', 'P', 'C'))
or
	exists (select 1 from tpma_dshbd_prj_issue where isnull(parent_issue_no,'') = issue.issue_no and issue_status in ('O', 'P') and issue_est_end_dt <= convert(date, @rpt_date))
))

--PM email
update #dshbd_prf_push 
set prj_ld_email = staff.email
from #dshbd_prf_push prfPush, tpma_staffbasic staff
where prfPush.prj_ld_id = staff.logon_id
and prfPush.prj_ld_id_card_no = staff.id_card

--TL & DTL Email
update #dshbd_prf_push 
set tl_email  = staff.email
from #dshbd_prf_push prfPush, tpma_staffbasic staff, tpma_team team
where prfPush.team_code = team.team_code
and team.tl_id = staff.logon_id and team.tl_id_card = staff.id_card
update #dshbd_prf_push 
set dtl_email  = staff.email
from #dshbd_prf_push prfPush, tpma_staffbasic staff, tpma_team team
where prfPush.team_code = team.team_code
and team.dtl_id = staff.logon_id and team.dtl_id_card = staff.id_card

--SBU Head Email
update #dshbd_prf_push 
set sbuh_email  = staff.email
from #dshbd_prf_push prfPush, tpma_staffbasic staff, tpma_team team
where prfPush.sbu_code = team.team_code
and team.tl_id = staff.logon_id and team.tl_id_card = staff.id_card
update #dshbd_prf_push 
set dsbuh_email  = staff.email
from #dshbd_prf_push prfPush, tpma_staffbasic staff, tpma_team team
where prfPush.sbu_code = team.team_code
and team.dtl_id = staff.logon_id and team.dtl_id_card = staff.id_card

--Function Head Email
update #dshbd_prf_push 
set funch_email  = staff.email
from #dshbd_prf_push prfPush, tpma_staffbasic staff, tpma_team team
where prfPush.func_code = team.team_code
and team.tl_id = staff.logon_id and team.tl_id_card = staff.id_card
update #dshbd_prf_push 
set dfunch_email  = staff.email
from #dshbd_prf_push prfPush, tpma_staffbasic staff, tpma_team team
where prfPush.func_code = team.team_code
and team.dtl_id = staff.logon_id and team.dtl_id_card = staff.id_card

select * from #dshbd_prf_push order by func_code, sbu_code, team_code, push_type
GO