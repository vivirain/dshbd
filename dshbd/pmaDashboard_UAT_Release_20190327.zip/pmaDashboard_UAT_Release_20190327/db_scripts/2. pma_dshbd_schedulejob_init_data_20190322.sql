delete from tpma_email_template where tmp_id in (21, 22, 23)
go
insert into tpma_email_template values(
21, 'Profile_New_Submitted', 'New submitted profiles on Delivery Dashboard on [{1}]', '<head>
<style>
    table {
        font-family:Arial, Helvetica, sans-serif;
        font-size:10px;
        width:100%;
		}
    .prfBgColor {
        background-color: #B4B4B4;
    }
    .trBgColor{
        background-color: white;
    }
</style>
</head>
<body style="background-color:#efefef;">
    <p>Please click <a href="{2}"><strong><u>HERE</u></strong></a> to access Delivery Dashboard.</p><br/>
	<table align="center">
        <tr style="font-size:10px; color:white" class="prfBgColor">
            <th style="width:20%"><u>TEAM</u></th>
            <th style="width:32%" class="prfBgColor"><u>PROJECT NAME</u></th>
            <th style="width:8%"><u>QUALITY</u></th>
            <th style="width:8%"><u>SCHEDULE</u></th>
            <th style="width:8%"><u>COST</u></th>
            <th style="width:8%"><u>RESOURCE</u></th>
            <th style="width:8%"><u>SCOPE</u></th>
            <th style="width:8%"><u>CSS</u></th>
        </tr>
        {3}               
    </table>
    <p>{4}</p>
</body>','2,3', '4,5,6,7,8,9')
go
insert into tpma_email_template values(
22, 'Profile_Update', '**Reminder** Delivery Dashboard requests for updates by [{1}]', '<head>
    <style>
    .yellowText {
        color:#DEBA1F;
    }
    .tdBgColor {
        background-color: white;
    }
    </style>
</head>
<body style="background-color: #EFEFEF; font-family:Arial, Helvetica, sans-serif; font-size:10px">
    <p style="font-size:10px;">Please click <a href="{2}"><strong><u>HERE</u></strong></a> to access Delivery Dashboard.</p><br/>
    <p style="text-align:center; font-size:10px; font-weight:bold">**Ensure to PRESS ''SUBMIT'' or the version shall still remain in DRAFT FOLDER only, and the profile is NOT considered updated.</p>
    <table style="width:100%; font-size:10px">
        <tr style="font-size:10px; background-color: #878787; color:white; font-weight: bold; text-align:center">
            <td style="width:13%">TEAM</td>
            <td style="width:25%">Below <span class="yellowText">Draft Updates</span> <br/>are pending for SUBMIT in DRAFT FOLDER</td>
            <td style="width:27%">Below <span class="yellowText">pending Risks/Issues</span> <br/>DO NOT have Follow-up actions OR are overdue.</td>
            <td style="width:25%">Below profile progress/status are <span class="yellowText"><br/>aging for 1+ weeks</span></td>
        </tr>
        {3}                   
	</table>
	<p>{4}</p>
</body>','2,3', '')
go
insert into tpma_email_template values(
23, 'Profile_Overdue', '{0}: **Overdue** Delivery Dashboard requests for updates by [{1}]', '<head>
    <style>
    .yellowText {
        color:#DEBA1F;
    }
    .tdBgColor {
        background-color: white;
    }
    </style>
</head>
<body style="background-color: #EFEFEF; font-family:Arial, Helvetica, sans-serif; font-size:10px">
    <p style="font-size:10px;">Please click <a href="{2}"><strong><u>HERE</u></strong></a> to access Delivery Dashboard.</p><br/>
    <p style="text-align:center; font-size:10px; font-weight:bold">**Ensure to PRESS ''SUBMIT'' or the version shall still remain in DRAFT FOLDER only, and the profile is NOT considered updated.</p>
    <table style="width:100%; font-size:10px">
        <tr style="font-size:10px; background-color: #878787; color:white; font-weight: bold; text-align:center">
            <td style="width:13%">TEAM</td>
            <td style="width:25%">Below <span class="yellowText">Draft Updates</span> <br/>are pending for SUBMIT in DRAFT FOLDER</td>
            <td style="width:27%">Below <span class="yellowText">pending Risks/Issues</span> <br/>DO NOT have Follow-up actions OR are overdue.</td>
            <td style="width:25%">Below profile progress/status are <span class="yellowText"><br/>aging for 1+ weeks</span></td>
        </tr>
        {3}                  
	</table>
	<p>{4}</p>
</body>','2,3', '4')
go

delete from [dbo].[tpma_dshbd_schedule_job] where job_id in (1, 2, 3, 4)
go 
insert into tpma_dshbd_schedule_job(job_id, job_cate, job_name, job_name_display, cron_express, job_seq, is_active, created_by, created_dt, last_updated_by, job_freq, send_by_sbu)
values(1, 'EMAIL', 'PROFILENEWSUBMITTED', 'New Submitted Profile', '0 0 8 ? * 1,2,3,4,5', 1, 'Y', 'SYSTEM', getdate(), 'SYSTEM', 'WORKDAY', 'N')
go
insert into tpma_dshbd_schedule_job(job_id, job_cate, job_name, job_name_display, cron_express, job_seq, is_active, created_by, created_dt, last_updated_by, job_freq, send_by_sbu)
values(2, 'EMAIL', 'PROFILEUPDATE', 'Profile Progress Update Reminder', '0 0 8 ? * 6', 2, 'Y', 'SYSTEM', getdate(), 'SYSTEM', 'WEEKLY', 'N')
go
insert into tpma_dshbd_schedule_job(job_id, job_cate, job_name, job_name_display, cron_express, job_seq, is_active, created_by, created_dt, last_updated_by, job_freq, send_by_sbu)
values(3, 'EMAIL', 'PROFILEOVERDUE', 'Profile Progress Update Overdue Reminder', '0 0 8 ? * 2', 3, 'Y', 'SYSTEM', getdate(), 'SYSTEM', 'WEEKLY', 'Y')
go
insert into tpma_dshbd_schedule_job(job_id, job_cate, job_name, job_name_display, cron_express, job_seq, is_active, created_by, created_dt, last_updated_by, job_freq)
values(4, 'EMAIL', 'UPDPROFILEDUEDATE', 'Update Next Report Date', '0 0 8 ? * 3', 3, 'Y', 'SYSTEM', getdate(), 'SYSTEM', 'WEEKLY')
go

delete from tpma_dshbd_lookup where lookup_code in ('NEXT_REPORT_DATE', 'EMAIL_REMINDER_BEFORE_DAYS', 'REPORT_FREQUENCY', 'EMAIL_DATE_FORMAT')
go
insert into tpma_dshbd_lookup(lookup_type, category, category_desc, lookup_code, lookup_name, is_active, created_by, created_dt, last_updated_by, last_updated_dt)
values('S', 'MISC', 'misc', 'NEXT_REPORT_DATE', '03/29/2019', 'Y', 'SYSTEM', CURRENT_TIMESTAMP, 'SYSTEM', CURRENT_TIMESTAMP)
go
insert into tpma_dshbd_lookup(lookup_type, category, category_desc, lookup_code, lookup_name, is_active, created_by, created_dt, last_updated_by, last_updated_dt)
values('S', 'MISC', 'misc', 'REPORT_FREQUENCY', 'WEEKLY', 'Y', 'SYSTEM', CURRENT_TIMESTAMP, 'SYSTEM', CURRENT_TIMESTAMP)
go
insert into tpma_dshbd_lookup(lookup_type, category, category_desc, lookup_code, lookup_name, is_active, created_by, created_dt, last_updated_by, last_updated_dt)
values('S', 'EMAIL', 'email', 'EMAIL_DATE_FORMAT', 'ddMMyyyy', 'Y', 'SYSTEM', CURRENT_TIMESTAMP, 'SYSTEM', CURRENT_TIMESTAMP)
go