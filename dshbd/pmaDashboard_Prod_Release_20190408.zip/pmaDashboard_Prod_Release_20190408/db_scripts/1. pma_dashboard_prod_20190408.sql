/*********************************************************************************************************************
 *
 * Table
 *
 *********************************************************************************************************************/
if not exists( SELECT 1 FROM SYSOBJECTS T1 INNER JOIN SYSCOLUMNS T2 ON T1.ID=T2.ID)
	alter table [dbo].[tpma_dshbd_user_role] add pma_logon_id_card char(18) not null default ''
go
update [dbo].[tpma_dshbd_user_role]
set pma_logon_id_card = staff.id_card 
from [dbo].[tpma_dshbd_user_role] usrRole, [dbo].[tpma_StaffBasic] staff
where usrRole.pma_logon_id = staff.logon_id 
and staff.status = 'A'
go

/*********************************************************************************************************************
 *
 * Function
 *
 *********************************************************************************************************************/
if object_id('dbo.usf_dshbd_get_func') is not null
	drop function dbo.[usf_dshbd_get_func]
go
CREATE function [dbo].[usf_dshbd_get_func](
@teamCode int
)
returns int
as
begin

	declare @funcCode int
	declare @parentTeam int
	declare @isFunc char(1)

	select @funcCode = team_code, @parentTeam = subordinate, @isFunc = is_func
	from tpma_team
	where team_code = @teamCode and status = 'A'

	if (@isFunc <> 'Y' and @funcCode > 0)
	begin
		set @funcCode =  dbo.usf_dshbd_get_func(@parentTeam)
	end
		
	return @funcCode
end
GO

if object_id('dbo.usf_dshbd_get_sbu') is not null
	drop function dbo.[usf_dshbd_get_sbu]
go
CREATE function [dbo].[usf_dshbd_get_sbu](
@teamCode int
)
returns int
as
begin

	declare @sbuCode int
	declare @parentTeam int
	declare @isDept char(1)

	select @sbuCode = team_code, @parentTeam = subordinate, @isDept = is_dept 
	from tpma_team
	where team_code = @teamCode and status = 'A'

	if (@isDept <> 'Y' and @sbuCode > 0)
	begin
		set @sbuCode =  dbo.usf_dshbd_get_sbu(@parentTeam)
	end
		
	return @sbuCode
end
GO

if object_id('dbo.usf_dshbd_get_staff_func') is not null
	drop function dbo.[usf_dshbd_get_staff_func]
go
CREATE function [dbo].[usf_dshbd_get_staff_func](
@logonId char(7),
@logonIdCard char(18)
)
returns int
as
begin

	declare @teamCode int
	declare @funcCode int


	select @teamCode = team_code
	from tpma_StaffBasic 
	where logon_id = @logonId and id_card = @logonIdCard and [status] = 'A'

	if @teamCode >= 0
	begin
		set @funcCode = dbo.usf_dshbd_get_func(@teamCode)
	end
		
	return @funcCode
end
GO

if object_id('dbo.usf_dshbd_get_staff_sbu') is not null
	drop function dbo.[usf_dshbd_get_staff_sbu]
go
CREATE function [dbo].[usf_dshbd_get_staff_sbu](
@logonId char(7),
@logonIdCard char(18)
)
returns int
as
begin

	declare @teamCode int
	declare @sbuCode int


	select @teamCode = team_code
	from tpma_StaffBasic 
	where logon_id = @logonId and id_card = @logonIdCard and [status] = 'A'

	if @teamCode >= 0
	begin
		set @sbuCode = dbo.usf_dshbd_get_sbu(@teamCode)
	end
		
	return @sbuCode
end
GO


/*********************************************************************************************************************
 *
 * View
 *
 *********************************************************************************************************************/
if exists (select 1 from sys.views where name = 'vpma_dshbd_profile')
	drop view [dbo].[vpma_dshbd_profile]
go
CREATE view [dbo].[vpma_dshbd_profile] as
select prf_view.*
, (select team_name from tpma_team where team_code = prf_view.team_code) as team_name
, (select team_name from tpma_team where team_code = prf_view.sbu_code) as sbu_name
, (select team_name from tpma_team where team_code = prf_view.func_code) as func_name
from 
( 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, 
staff.team_code,
dbo.usf_dshbd_get_sbu(team_code) as sbu_code,
dbo.usf_dshbd_get_func(team_code) as func_code,
tssPrj.name as tssPrj_Name,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'STAGE' and lookup_code = prf.prj_stage) as prj_stage_desc
from [tpma_dshbd_profile] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
--and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
and prf.prj_ld_id_card_no = staff.id_card
--and staff.status = 'A'
left join [tpma_tss_project] tssPrj
on prf.tss_prj = tssPrj.code 
) prf_view

GO

if exists (select 1 from sys.views where name = 'vpma_dshbd_profile_hist')
	drop view [dbo].[vpma_dshbd_profile_hist]
go
CREATE view [dbo].[vpma_dshbd_profile_hist] as
select prf_view.*
, (select team_name from tpma_team where team_code = prf_view.team_code) as team_name
, (select team_name from tpma_team where team_code = prf_view.sbu_code) as sbu_name
, (select team_name from tpma_team where team_code = prf_view.func_code) as func_name
from 
( 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, 
team_code, 
dbo.usf_dshbd_get_sbu(team_code) as sbu_code,
dbo.usf_dshbd_get_func(team_code) as func_code,
tssPrj.name as tssPrj_Name,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'STAGE' and lookup_code = prf.prj_stage) as prj_stage_desc  
from [tpma_dshbd_profile_hist] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
--and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
and prf.prj_ld_id_card_no = staff.id_card
--and staff.status = 'A'
left join [tpma_tss_project] tssPrj
on prf.tss_prj = tssPrj.code 
) prf_view
GO