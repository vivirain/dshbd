delete from tpma_email_template where tmp_id in (21, 22, 23)
go
insert into tpma_email_template values(
21, 'Profile_New_Submitted', '{0}:  New profiles submitted in the week of [{1}]', '<p>
    <table style="background-color:#DADADA" border="1">
        <tbody>
			<tr>
				<th>TEAM</th><th>PROJECT NAME</th><th></th>
				<th>QUALITY</th><th>SCHEDULE</th><th>COST</th><th>RESOURCE</th><th>SCOPE</th><th>CSS</th>
			</tr>
			{2}
        </tbody>
    </table>
</p>','', '')
go
insert into tpma_email_template values(
22, 'Profile_Update_1', '{0}: **Reminder** Update Profiles by [{1}]', '<h4>View more on <a href=''{2}'' target="_blank">Delivery Dashboard</a></h4>
<p>
    <table border="1">
		<tr>
			<th>TEAM</th>
			<th>Below Draft Updates are pending for SUBMIT in DRAFT FOLDER</th>
			<th>Below Pending Risks/Issues DO NOT have follow-up actions or are OVERDUE</th>
			<th>Below profile progress/status are aging for 1+ weeks</th>
		</tr>
		{3}
    </table>
</p>','', '')
go
insert into tpma_email_template values(
23, 'Profile_Update_2', '{0}: ****FINAL CALL**** Update Profiles by [{1}]', '<h4>View more on <a href=''{2}'' target="_blank">Delivery Dashboard</a></h4>
<p>
    <table border="1">
		<tr>
			<th>TEAM</th>
			<th>Below Draft Updates are pending for SUBMIT in DRAFT FOLDER</th>
			<th>Below Pending Risks/Issues DO NOT have follow-up actions or are OVERDUE</th>
			<th>Below profile progress/status are aging for 1+ weeks</th>
		</tr>
		{3}
    </table>
</p>','', '')
go

delete from [dbo].[tpma_dshbd_schedule_job] where job_id in (1, 2, 3)
go 
insert into tpma_dshbd_schedule_job(job_id, job_cate, job_name, job_name_display, cron_express, job_seq, is_active, created_by, created_dt, last_updated_by)
values(1, 'EMAIL', 'PROFILENEWSUBMITTED', 'New Submitted Profile', '0 0 8 ? * 7', 1, 'Y', 'SYSTEM', getdate(), 'SYSTEM')
go
insert into tpma_dshbd_schedule_job(job_id, job_cate, job_name, job_name_display, cron_express, job_seq, is_active, created_by, created_dt, last_updated_by)
values(2, 'EMAIL', 'PROFILEUPDATE1', 'Profile Progress Update Reminder 1', '0 0 8 ? * *', 2, 'Y', 'SYSTEM', getdate(), 'SYSTEM')
go
insert into tpma_dshbd_schedule_job(job_id, job_cate, job_name, job_name_display, cron_express, job_seq, is_active, created_by, created_dt, last_updated_by)
values(3, 'EMAIL', 'PROFILEUPDATE2', 'Profile Progress Update Reminder 2', '0 0 8 ? * *', 3, 'Y', 'SYSTEM', getdate(), 'SYSTEM')
go

delete from tpma_dshbd_lookup where lookup_code in ('NEXT_REPORT_DATE', 'EMAIL_REMINDER_BEFORE_DAYS', 'REPORT_FREQUENCY')
go
insert into tpma_dshbd_lookup(lookup_type, category, category_desc, lookup_code, lookup_name, is_active, created_by, created_dt, last_updated_by, last_updated_dt)
values('S', 'MISC', 'misc', 'NEXT_REPORT_DATE', '03/08/2019', 'Y', 'SYSTEM', CURRENT_TIMESTAMP, 'SYSTEM', CURRENT_TIMESTAMP)
go
insert into tpma_dshbd_lookup(lookup_type, category, category_desc, lookup_code, lookup_name, is_active, created_by, created_dt, last_updated_by, last_updated_dt)
values('S', 'MISC', 'misc', 'EMAIL_REMINDER_BEFORE_DAYS', '2', 'Y', 'SYSTEM', CURRENT_TIMESTAMP, 'SYSTEM', CURRENT_TIMESTAMP)
go
insert into tpma_dshbd_lookup(lookup_type, category, category_desc, lookup_code, lookup_name, is_active, created_by, created_dt, last_updated_by, last_updated_dt)
values('S', 'MISC', 'misc', 'REPORT_FREQUENCY', 'WEEKLY', 'Y', 'SYSTEM', CURRENT_TIMESTAMP, 'SYSTEM', CURRENT_TIMESTAMP)
go