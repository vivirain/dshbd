

/*********************************************************************************************************************
 *
 * Table
 *
 *********************************************************************************************************************/

/*********************************************************************
 * Authentication
 *********************************************************************/
 -- role
if exists (select 1 from sys.tables where name = 'tpma_dshbd_role')
	drop table [dbo].[tpma_dshbd_role]
go
create table [dbo].[tpma_dshbd_role] (
	[role_id] int not null,
	[role_code] varchar(10) not null,
	[role_name] varchar(100),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

	constraint pk_dshbd_role primary key ([role_id])
)
go

--user role
if exists (select 1 from sys.tables where name = 'tpma_dshbd_user_role')
	drop table [dbo].[tpma_dshbd_user_role]
go
create table [dbo].[tpma_dshbd_user_role] (
	[user_role_id] int identity(1,1) not null,
	--[user_id] int not null,
	[role_id] int not null,
	[pma_logon_id] varchar(20) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] varchar(20),

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp
	
	constraint pk_dshbd_user_role primary key ([user_role_id]),
	constraint ix_dshbd_user_role unique ([role_id], [pma_logon_id])
)
go

--user BU
if exists (select 1 from sys.tables where name = 'tpma_dshbd_user_bu')
	drop table [dbo].[tpma_dshbd_user_bu]
go
create table [dbo].[tpma_dshbd_user_bu] (
	[user_bu_id] int identity(1,1) not null,

	[bu_code] varchar(10) not null,
	[pma_logon_id] varchar(20) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] varchar(20),

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp
	
	constraint pk_dshbd_user_bu primary key ([user_bu_id]),
	constraint ix_dshbd_user_bu unique ([bu_code], [pma_logon_id])
)
go

--function
if exists (select 1 from sys.tables where name = 'tpma_dshbd_function')
	drop table [dbo].[tpma_dshbd_function]
go
create table [dbo].[tpma_dshbd_function] (
	[function_id] int not null,
	[function_name] varchar(30) not null,
	[function_seq] int not null, 
	[function_top_id] int,
	[is_link] char(1) default 'Y',
	[function_url] varchar(100),
	[function_icon] varchar(50),

	[show_badges] char(1) default 'N',

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_function primary key (function_id)
)
go

--function_auth
if exists (select 1 from sys.tables where name = 'tpma_dshbd_function_auth')
	drop table [dbo].[tpma_dshbd_function_auth]
go
create table [dbo].[tpma_dshbd_function_auth] (
	[function_auth_id] int identity(1,1) not null,
	[function_id] int not null,
	[role_id] int ,
	[pma_logon_id] varchar(20),
	
	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_function_auth primary key ([function_auth_id])
)
go

/*********************************************************************
 * Reference Data
 *********************************************************************/
 --lookup
if exists (select 1 from sys.tables where name = 'tpma_dshbd_lookup')
	drop table [dbo].[tpma_dshbd_lookup]
go
create table [dbo].[tpma_dshbd_lookup](
	[lookup_id] int identity(1,1),
	[lookup_type] char(1) not null,
	[category] varchar(20) not null,
	[category_desc] varchar(100),
	[sub_category] varchar(20),
	[sub_category_desc] varchar(100),
	[lookup_code] varchar(30) not null,
	[lookup_name] varchar(100) not null,

	[remark] varchar(1000),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_lookup primary key([lookup_id]),
		constraint ix_dshbd_lookup unique ([lookup_type], [category], [lookup_code])
)
go

--metric raw
if exists (select 1 from sys.tables where name = 'tpma_dshbd_metric_raw')
	drop table [dbo].[tpma_dshbd_metric_raw]
go
create table [dbo].[tpma_dshbd_metric_raw](
	[id] int identity(1,1) not null,
	[code] varchar(50) not null,
	[desc] varchar(100),
	[tips] varchar(max),

	[data_type] char(1) not null default 'N',
	[data_precision] int not null default 0,

	[data_source] char(1),

	[effect_begin_dt] datetime not null default current_timestamp,
	[effect_end_dt] datetime,
		
	[is_active] char(1) not null default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_metric_raw primary key([id]),
		constraint ix_dshbd_metric_raw_code unique ([code])
)
go

--metric
if exists (select 1 from sys.tables where name = 'tpma_dshbd_metric')
	drop table [dbo].[tpma_dshbd_metric]
go	
create table [dbo].[tpma_dshbd_metric] (
	[metric_code] char(2) not null,
	[metric_name] varchar(100),
	[metric_desc] varchar(max),

	[metric_category] char(2) not null,
	[metric_category_desc] varchar(100),

	[metric_val_type] varchar(10),
	[metric_val_precision] int,
	[metric_val_update_mode] char(1),

	[fixed_price_project] char(1) default 'N',
	[tss_prj_json] varchar(max) not null,
	[metric_raw_json] varchar(max),

	[effect_begin_dt] datetime not null default current_timestamp,
	[effect_end_dt] datetime,
	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_metric primary key([metric_code])
)
go

--metric raw mapping
if exists (select 1 from sys.tables where name = 'tpma_dshbd_metric_raw_mapping')
	drop table [dbo].[tpma_dshbd_metric_raw_mapping]
go	
create table [dbo].[tpma_dshbd_metric_raw_mapping] (
	[mapping_id] int identity(1,1) not null,
	[metric_code] char(2) not null,
	[metric_raw_code] varchar(50) not null,

	[effect_begin_dt] datetime not null default current_timestamp,
	[effect_end_dt] datetime,
	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_metric_raw_mapping primary key([mapping_id]),
		constraint ix_dshbd_metric_raw_mapping unique ([metric_code], [metric_raw_code])
)
go

/*******************************************************************
 * Metric Target (Will be maintained yearly within housekeeping)
 *******************************************************************/
if exists (select 1 from sys.tables where name = 'tpma_dshbd_metric_target')
	drop table [dbo].[tpma_dshbd_metric_target]
go
create table [dbo].[tpma_dshbd_metric_target] (
	[metric_target_id] int identity(1,1),

	[metric_year] char(4) not null,
	[tss_prj] varchar(2) not null,
	[metric_code] char(2) not null,

	[metric_val] numeric(15,4),
	[metric_val_sign] char(2),
	[metric_val_green] numeric(15,4),
	[metric_val_amber] numeric(15,4),
	[metric_val_red] numeric(15,4),
	[metric_val_grey] numeric(15,4),

	[metric_val_green_enabled] char(1),
	[metric_val_amber_enabled] char(1),
	[metric_val_red_enabled] char(1),
	[metric_val_grey_enabled] char(1),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_metric_target primary key([metric_target_id]),
		constraint ix_dshbd_metric_target unique ([metric_year], [tss_prj], [metric_code])
)
go


/*******************************************************************
 * Project Profile
 *******************************************************************/
if exists (select 1 from sys.tables where name = 'tpma_dshbd_profile')
	drop table [dbo].[tpma_dshbd_profile]
go
create table [dbo].[tpma_dshbd_profile](
	[prf_id] int identity(1,1) not null,
	[prf_main_code] varchar(10) not null,
	[prf_desc] varchar(100), 
	[prf_desc_detail] text,
	[prf_desc_chn] nvarchar(100),
	[prf_desc_chn_detail] nvarchar(600),
	[prj_codes] varchar(100) not null,
	[prj_master_code] varchar(7), 

	[fixed_price_project] char(1),

	[tss_prj] varchar(2),
	[bu_code] varchar(10),

	[prj_ld_id] varchar(7),

	[est_start_dt] datetime,
	[est_end_dt] datetime,
	[actl_start_dt] datetime,
	[actl_end_dt] datetime,

	[currency] char(3), 

	[est_total_hours] numeric(7,1),
	[actl_total_hours] numeric(7,1),
	[est_prj_total_hours] numeric(7,1),
	[actl_prj_total_hours] numeric(7,1),

	[est_total_cost] numeric(11,2),
	[actl_total_cost] numeric(11,2),
	[actl_total_cost_billed] numeric(11,2),

	[status] char(2),

	[health_status] varchar(5),
	[quality_status] varchar(5),
	[schedule_status] varchar(5),
	[scope_status] varchar(5),
	[resource_status] varchar(5),
	[cost_status] varchar(5),
	[css_status] varchar(5),

	[prj_stage] varchar(5),
	[prj_status_remark] text,

	[data_version] char(8), 

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

	constraint pk_dshbd_profile primary key ([prf_id])
)
go
--profile hist
if exists (select 1 from sys.tables where name = 'tpma_dshbd_profile_hist')
	drop table [dbo].[tpma_dshbd_profile_hist]
go
create table [dbo].[tpma_dshbd_profile_hist](
	[prf_id] int not null,

	[prf_main_code] varchar(10) not null,
	[prf_desc] varchar(100), 
	[prf_desc_detail] text,
	[prf_desc_chn] nvarchar(100),
	[prf_desc_chn_detail] nvarchar(600),
	[prj_codes] varchar(100) not null,
	[prj_master_code] varchar(7), 

	[fixed_price_project] char(1),

	[tss_prj] varchar(2),
	[bu_code] varchar(10),

	[prj_ld_id] varchar(7),

	[est_start_dt] datetime,
	[est_end_dt] datetime,
	[actl_start_dt] datetime,
	[actl_end_dt] datetime,

	[currency] char(3), 

	[est_total_hours] numeric(7,1),
	[actl_total_hours] numeric(7,1),
	[est_prj_total_hours] numeric(7,1),
	[actl_prj_total_hours] numeric(7,1),

	[est_total_cost] numeric(11,2),
	[actl_total_cost] numeric(11,2),
	[actl_total_cost_billed] numeric(11,2),

	[status] char(2),

	[health_status] varchar(5),
	[quality_status] varchar(5),
	[schedule_status] varchar(5),
	[scope_status] varchar(5),
	[resource_status] varchar(5),
	[cost_status] varchar(5),
	[css_status] varchar(5),

	[prj_stage] varchar(5),
	[prj_status_remark] text,

	[data_version] char(8) not null, 

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

	constraint pk_dshbd_profile_hist primary key ([prf_id], [data_version])
)
go


--project raw
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw')
	drop table [dbo].[tpma_dshbd_prj_metric_raw]
go
create table [dbo].[tpma_dshbd_prj_metric_raw] (
	[id] int identity(1,1) not null,

	[prj_code] char(7) not null,
	[metric_raw_code] varchar(50) not null,

	[metric_raw_val] numeric(15,4),

	[data_version] char(8),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw primary key([id]),
		constraint ix_dshbd_prj_metric_raw unique([prj_code], [metric_raw_code])
)
go
--project metric raw hist
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_hist')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_hist]
go
create table [dbo].[tpma_dshbd_prj_metric_raw_hist] (
	[id] int not null,

	[prj_code] char(7) not null,
	--[metric_code] char(2) not null,
	[metric_raw_code] varchar(50) not null,

	[metric_raw_val] numeric(15,4),

	[data_version] char(8) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_hist primary key([id]),
		constraint ix_dshbd_prj_metric_raw_hist unique([prj_code], [metric_raw_code], [data_version])
)
go
--project metric
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric')
	drop table [dbo].[tpma_dshbd_prj_metric]
go
create table [dbo].[tpma_dshbd_prj_metric] (
	[id] int identity(1,1) not null,

	[prj_code] char(7) not null,
	[metric_code] char(2) not null,

	[metric_val] numeric(15,4),
	[metric_raw_val_json] varchar(max),

	[metric_status] varchar(5),

	[data_version] char(8),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric primary key([id]),
		constraint ix_dshbd_prj_metric unique([prj_code], [metric_code])
)
go
--project metric hist
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_hist')
	drop table [dbo].[tpma_dshbd_prj_metric_hist]
go
create table [dbo].[tpma_dshbd_prj_metric_hist] (
	[id] int not null,

	[prj_code] char(7) not null,
	[metric_code] char(2) not null,

	[metric_val] numeric(15,4),
	[metric_raw_val_json] varchar(max),

	[metric_status] varchar(5),

	[data_version] char(8) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_hist primary key([id], [data_version]),
		constraint ix_dshbd_prj_metric_hist unique([prj_code], [metric_code], [data_version])
)
go
--project metric raw mapping
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_mapping')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_mapping]
go	
create table [dbo].[tpma_dshbd_prj_metric_raw_mapping] (
	[prj_mapping_id] int identity(1,1) not null,

	[prj_code] char(7) not null,
	[metric_code] char(2) not null,
	[metric_raw_code] varchar(50) not null,
	
	[metric_raw_val] numeric(15,4),

	[data_version] char(8),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_mapping primary key([prj_mapping_id]),
		constraint ix_dshbd_prj_metric_raw_mapping unique ([prj_code], [metric_code], [metric_raw_code])
)
go
--project metric raw mapping hist
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_mapping_hist')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_mapping_hist]
go	
create table [dbo].[tpma_dshbd_prj_metric_raw_mapping_hist] (
	[prj_mapping_id] int not null,

	[prj_code] char(7) not null,
	[metric_code] char(2) not null,
	[metric_raw_code] varchar(50) not null,
	
	[metric_raw_val] numeric(15,4),

	[data_version] char(8) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_mapping_hist primary key([prj_mapping_id], [data_version]),
		constraint ix_dshbd_prj_metric_raw_mapping_hist unique ([prj_code], [metric_code], [metric_raw_code], [data_version])
)
go

/*******************************************************************
 * Project Quality Raw Data for upload (phased out within phase 1)
 *******************************************************************/
if exists (select 1 from sys.tables where name = 'tpma_dshbd_tran_log')
	drop table [dbo].[tpma_dshbd_tran_log]
go
create table [dbo].[tpma_dshbd_tran_log] (
	[log_id] int identity(1,1) not null,

	[tran_type] varchar(10) not null,
	[tran_log] text,
	[tran_err] text,

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp
)
go	

/*******************************************************************
 * Project Quality Raw Data for upload (phased out within phase 1)
 *******************************************************************/
 /*
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_upload')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_upload]
go
create table [dbo].[tpma_dshbd_prj_metric_raw_upload] (

	[id] int identity(1,1) not null,

	[prj_code] char(7),
	[chg_ctl_no] char(2),
	[sit_by_test_team] char(1),
	[sit_defect] int,
	[uat_critical_defect] int,
	[uat_major_defect] int,
	[uat_minor_defect] int,
	[uat_trivial_defect] int,
	[prod_critical_defect] int,
	[prod_major_defect] int,
	[prod_minor_defect] int,
	[prod_trivial_defect] int,
	[actual_effort] numeric(7,1), 
	[earned_value] decimal(11,2),
	[planned_value] decimal(11,2),
	[actual_cost] decimal(11,2),
	[good_quality_effort] numeric(7,1),
	[failure_effort] numeric(7,1),
	[req_defect] int,
	[design_defect] int,
	[code_defect] int,
	[comp_task] int,
	[comp_task_und_ctrl] int,
	[S1] int,
	[S2] int,
	[received_incident] int,
	[response_on_time] int,
	[resolution_on_time] int,
	[uat_test_cases_1st_time_passed] int,
	[uat_test_cases] int,
	[uat_test_cases_executed] int,
	[reopen_uat_defect] int,

	[css_score] numeric(7,1),

	[data_version] char(8),

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(10),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_upload primary key([id])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_hist')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_hist]
go
create table [dbo].[tpma_dshbd_prj_metric_raw_hist] (

	[id] int not null,

	[prj_code] char(7),
	[chg_ctl_no] char(2),
	[sit_by_test_team] char(1),
	[sit_defect] int,
	[uat_critical_defect] int,
	[uat_major_defect] int,
	[uat_minor_defect] int,
	[uat_trivial_defect] int,
	[prod_critical_defect] int,
	[prod_major_defect] int,
	[prod_minor_defect] int,
	[prod_trivial_defect] int,
	[actual_effort] numeric(7,1), 
	[earned_value] decimal(11,2),
	[planned_value] decimal(11,2),
	[actual_cost] decimal(11,2),
	[good_quality_effort] numeric(7,1),
	[failure_effort] numeric(7,1),
	[req_defect] int,
	[design_defect] int,
	[code_defect] int,
	[comp_task] int,
	[comp_task_und_ctrl] int,
	[S1] int,
	[S2] int,
	[received_incident] int,
	[response_on_time] int,
	[resolution_on_time] int,
	[uat_test_cases_1st_time_passed] int,
	[uat_test_cases] int,
	[uat_test_cases_executed] int,
	[reopen_uat_defect] int,

	[css_score] numeric(7,1),

	[data_version] char(8) not null,

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(10),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_Hist primary key([id], [data_version])
)
go
*/


/*******************************************************************
 * Project Profile RiskIssue, Milestone
 *******************************************************************/

if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_issue')
	drop table [dbo].[tpma_dshbd_prj_issue]
go
create table [dbo].[tpma_dshbd_prj_issue] (

	[issue_no] varchar(20) not null,

	[issue_category] varchar(30) not null,
	[issue_desc_short] nvarchar(100) not null,
	[issue_desc_long] text,
	[issue_severity] char(1),
	[issue_probability] char(1),
	[issue_reported_by] varchar(20),
	[issue_reported_dt] datetime,
	[issue_owner] varchar(20),
	[issue_trace_status] char(1),
	[issue_status] char(1),

	[issue_est_start_dt] date,
	[issue_est_end_dt] date,
	[issue_actl_start_dt] date,
	[issue_actl_end_dt] date,

	[parent_issue_no] varchar(30),
	[issue_tag] varchar(10),
	[issue_progress] numeric(15,4),

	[prj_code] char(7),
	[prf_id] int,

	[created_by] varchar(20),
	[created_dt] datetime,
	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_issue primary key([issue_no])
)
go

if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_issue_comment')
	drop table [dbo].[tpma_dshbd_prj_issue_comment]
go
create table [dbo].[tpma_dshbd_prj_issue_comment] (

	[issue_comment_id] int identity(1,1) not null,

	[issue_no] varchar(20) not null,

	[issue_comment] text not null,
	[issue_comment_by] varchar(20),
	--[risk_action_trace_status] char(1),

	[issue_comment_status] char(1),

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_issue_comment primary key([issue_comment_id])
)
go

if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_schedule')
	drop table [dbo].[tpma_dshbd_prj_schedule]
go
create table [dbo].[tpma_dshbd_prj_schedule] (

	[schedule_no] varchar(30) not null,
	[schedule_stage] nvarchar(100) not null,

	[schedule_est_start_dt] date,
	[schedule_est_end_dt] date,
	[schedule_actl_start_dt] date,
	[schedule_actl_end_dt] date,

	[schedule_progress] numeric(15,4),
	[schedule_status] char(1),
	[schedule_trace_status] char(1),

	[prj_code] char(7),
	[prf_id] int,

	
	[schedule_comment] varchar(max),

	[created_by] varchar(20),
	[created_dt] datetime,
	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_shedule primary key([schedule_no])
)
go

if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_schedule_comment')
	drop table [dbo].[tpma_dshbd_prj_schedule_comment]
go
create table [dbo].[tpma_dshbd_prj_schedule_comment] (
	[schedule_comment_id] int identity(1,1) not null,

	[schedule_no] varchar(30) not null,

	[schedule_comment] text not null,
	[schedule_comment_by] varchar(20),

	[schedule_comment_status] char(1),

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_schedule_comment primary key([schedule_comment_id])
)
go


/*********************************************************************************************************************
 *
 * View
 *
 *********************************************************************************************************************/
if exists (select 1 from sys.views where name = 'vpma_dshbd_project')
	drop view [dbo].[vpma_dshbd_project]
go
create view [dbo].[vpma_dshbd_project] as 
SELECT prj.[prj_code], [chg_ctl_no], [bill_approach], [system_bill_approach], [outsource_prj_code],   
       prj.[prj_dictor], prj.[status], 
       prj.[prj_desc], [desc_detail], [prj_desc_chn], [desc_detail_chn], 
       prj.[est_strt_date], prj.[est_cmpl_date], [atl_start], [atl_finish], 
       [est_tot_cost], prj.[atl_cost], [atl_snp_cost], [atl_other_cost], [prj_tot_est_cost], 
       [est_tot_hour], prj.[atl_hour], [prj_tot_est_hour],
	   prj.[bu_code], bu.bu_name, bu.bu_full_name, 
	   prj.[prj_ld_id], [staff_name] as pm_name, staff.[status] as pm_status,
	   staff.[team_code], team.[team_name],
	   prj.[tss_prj], tssprj.name as [tss_prj_name], 
	   [currency], currency.[currency_name],
	   [master_prj_code], masterPrj.prj_ld_id as master_pm,
	   (case when isnull([bill_approach],'') = 'S' and isnull([system_bill_approach],'') = 'F' then 'Y' else '' end) as fixed_price_prj
FROM tpma_project prj
left join tpma_StaffBasic staff
on staff.logon_id = prj.prj_ld_id 
left join tpma_team team
on staff.team_code = team.team_code 
left join tpma_business_unit bu
on prj.bu_code = bu.bu_code 
left join tpma_tss_project tssprj
on prj.tss_prj = tssprj.code 
left join tpma_currency currency
on prj.currency = currency.currency_code 
left join tpma_tss_prj masterPrj
on prj.master_prj_code = masterPrj.prj_code 
where exists (select 1 from (select prj_code, max(chg_ctl_no) as chg_ctl_no from tpma_project group by prj_code) b where b.prj_code = prj.prj_code and b.chg_ctl_no = prj.chg_ctl_no )
and isnull(prj.[tss_prj],'') <> ''
--and team.chargeable = 'Y'
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_metric_target')
	drop view [dbo].[vpma_dshbd_metric_target]
go
create view [dbo].[vpma_dshbd_metric_target] as 
select qtyMetric.*, 
metric_target_id, metric_year, tss_prj, metric_val, metric_val_sign, 
metric_val_green, metric_val_amber, metric_val_red, metric_val_grey, 
metric_val_green_enabled, metric_val_amber_enabled, metric_val_red_enabled, metric_val_grey_enabled,
qtyMetricTarget.is_active as metric_target_active,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'METRICVALTYPE' and lookup_code = qtyMetric.metric_val_type) as metric_val_type_desc,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'METRICVALPREC' and lookup_code = qtyMetric.metric_val_precision) as metric_val_precision_desc,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'METRICVALUPDMODE' and lookup_code = qtyMetric.metric_val_update_mode ) as metric_val_update_mode_desc,
case when qtyMetricTarget.is_active = 'Y' then 'Yes' when qtyMetricTarget.is_active = 'N' then 'No' end as metric_target_active_desc
from tpma_dshbd_metric qtyMetric
left join tpma_dshbd_metric_target qtyMetricTarget
on qtyMetric.metric_code = qtyMetricTarget.metric_code
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_profile')
	drop view [dbo].[vpma_dshbd_profile]
go
create view [dbo].[vpma_dshbd_profile] as 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, team_code, tssPrj.name as tssPrj_Name
from [tpma_dshbd_profile] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
--and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
--and staff.status = 'A'
left join [tpma_tss_project] tssPrj
on prf.tss_prj = tssPrj.code 
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_profile_hist')
	drop view [dbo].[vpma_dshbd_profile_hist]
go
create view [dbo].[vpma_dshbd_profile_hist] as 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, team_code, tssPrj.name as tssPrj_Name  
from [tpma_dshbd_profile_hist] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
--and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
--and staff.status = 'A'
left join [tpma_tss_project] tssPrj
on prf.tss_prj = tssPrj.code 
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_metric_raw_mapping')
	drop view [dbo].[vpma_dshbd_metric_raw_mapping]
go
create view [dbo].[vpma_dshbd_metric_raw_mapping] as
select mapping.mapping_id, mapping.metric_code, mapping.metric_raw_code,
	metric.metric_name, metric_category, metric_category_desc, metric_val_type, metric_val_precision, fixed_price_project, tss_prj_json, metric_raw_json, 
	metric_raw.[desc], metric_raw.data_type, metric_raw.data_precision, metric_raw.data_source
 from tpma_dshbd_metric_raw_mapping mapping, tpma_dshbd_metric metric, tpma_dshbd_metric_raw metric_raw
where mapping.metric_code = metric.metric_code
  and mapping.metric_raw_code = metric_raw.code 
  and mapping.is_active = 'Y'
  and metric.is_active = 'Y'
  and metric_raw.is_active = 'Y'
  go
  if exists (select 1 from sys.views where name = 'vpma_dshbd_prj_metric_raw_mapping')
	drop view [dbo].[vpma_dshbd_prj_metric_raw_mapping]
go
create view [dbo].[vpma_dshbd_prj_metric_raw_mapping] as
select mapping.prj_mapping_id, mapping.metric_code, mapping.metric_raw_code,
	metric.metric_name, metric_category, metric_category_desc, metric_val_type, metric_val_precision, fixed_price_project, tss_prj_json, metric_raw_json, 
	metric_raw.[desc], metric_raw.data_type, metric_raw.data_precision, metric_raw.data_source
 from tpma_dshbd_prj_metric_raw_mapping mapping, tpma_dshbd_metric metric, tpma_dshbd_metric_raw metric_raw
where mapping.metric_code = metric.metric_code
  and mapping.metric_raw_code = metric_raw.code 
  and mapping.is_active = 'Y'
  and metric.is_active = 'Y'
  and metric_raw.is_active = 'Y'
  go

if exists (select 1 from sys.views where name = 'vpma_dshbd_prj_issue')
	drop view [dbo].[vpma_dshbd_prj_issue]
go
create view [dbo].[vpma_dshbd_prj_issue] as
select issue.*
, lookup_a.lookup_name as issue_status_desc
, lookup_b.lookup_name as issue_track_status_desc
, lookup_c.lookup_name as issue_severity_desc
, lookup_d.lookup_name as issue_probability_desc
, lookup_e.lookup_name as issue_cate_desc
, lookup_f.lookup_name as issue_tag_desc
, staff.staff_name as issue_owner_name
from 
tpma_dshbd_prj_issue issue
left join tpma_dshbd_lookup lookup_a
on lookup_a.lookup_code = issue.issue_status 
and lookup_a.lookup_type = 'B'
and lookup_a.category = 'ISSUESTA'
left join tpma_dshbd_lookup lookup_b
on lookup_b.lookup_code = issue.issue_trace_status 
and lookup_b.lookup_type = 'B'
and lookup_b.category = 'STATUS'
left join tpma_dshbd_lookup lookup_c
on lookup_c.lookup_code = issue.issue_severity 
and lookup_c.lookup_type = 'B'
and lookup_c.category = 'SEVERITY'
left join tpma_dshbd_lookup lookup_d
on lookup_d.lookup_code = issue.issue_probability 
and lookup_d.lookup_type = 'B'
and lookup_d.category = 'SEVERITY'
left join tpma_dshbd_lookup lookup_e
on lookup_e.lookup_code = issue.issue_category 
and lookup_e.lookup_type = 'B'
and lookup_e.category = 'ISSUECATE'
left join tpma_dshbd_lookup lookup_f
on lookup_f.lookup_code = issue.issue_tag
and lookup_f.lookup_type = 'B'
and lookup_f.category = 'ISSUETAG'
left join tpma_StaffBasic staff 
on staff.logon_id = issue.issue_owner 
go


/*********************************************************************************************************************
 *
 * Stored Procedure
 *
 *********************************************************************************************************************/
if exists (select 1 from sys.procedures where name = 'usp_dshbd_prj_kpi')
	drop procedure [dbo].[usp_dshbd_prj_kpi]
go
create procedure [dbo].[usp_dshbd_prj_kpi]
	@prj_code char(7),
	@to_date datetime
	as
create table #prj_status_rpt(prj_code varchar(7)
                                                ,prj_desc varchar(100)
                                                ,task_id varchar(7)
                                                ,Parent_id varchar(7)
                                                ,order_no int
                                                ,layer_no int
                                                ,leaf_flag int
                                                ,status char(2)
                                                ,task_name varchar(50)
                                                ,org_end_date char(10)
                                                ,act_end_date char(10)
                                                ,PV decimal(10,2)
                                                ,EV decimal(10,2)
                                                ,AC decimal(10,2)
                                                ,SV decimal(10,2)
                                                ,CV decimal(10,2)
                                                ,SPI decimal(10,2)
                                                ,CPI decimal(10,2)
                                                )
 
insert into #prj_status_rpt(prj_code
                                                ,task_id
                                                ,Parent_id
                                                ,order_no
                                                ,layer_no
                                                ,leaf_flag
                                                ,status
                                                ,task_name
                                                ,org_end_date
                                                ,act_end_date
                                                ,PV
                                                ,EV)
       select prj_code
                     ,task_id
                     ,Parent_id
                     ,order_No
                     ,Layer_No
                     ,leaf_flag
                     ,status
                     ,task_name
                     ,isnull(convert(char(10),org_complete,101),'') as org_complete
                     ,case
                           when status = 'C' and act_complete <= @to_date then convert(char(10),act_complete,101)
                           else ''
                     end
 
 
                     ,case
                           when org_complete <= @to_date then isnull(baseline_cost,0)
                           else 0
                     end
                     ,case
                           when status = 'C' and act_complete <= @to_date and org_complete is not null then isnull(baseline_cost,0)
                           else 0
                     end
       from tpma_task
       where prj_code = @prj_code
       order by order_no
 
update a
       set AC = isnull((select sum(cost) from tpma_daily where prj_code = a.prj_code and task_id = a.task_id and trace_date <= @to_date), 0)
       from #prj_status_rpt a
 
declare @layer_no_count int
select @layer_no_count = isnull((select max(layer_no) from #prj_status_rpt), 0) - 1
 
while @layer_no_count >=0
begin
       update t
              set PV = isnull((select sum(PV) from #prj_status_rpt where Parent_id = t.task_id),0)
              ,EV = isnull((select sum(EV) from #prj_status_rpt where Parent_id = t.task_id),0)
              ,AC = isnull((select sum(AC) from #prj_status_rpt where Parent_id = t.task_id),0)
              from #prj_status_rpt t
              where Leaf_flag = 0
              and layer_no = @layer_no_count
 
       select @layer_no_count = @layer_no_count - 1
end
 
if (select count(1) from #prj_status_rpt) > 0
begin
insert into #prj_status_rpt (prj_code
                     ,task_name
                     ,order_no
                     ,layer_no
                     ,leaf_flag
                     ,PV
                     ,EV
                     ,AC)
       select @prj_code
                     ,'Project Total'
                     ,0
                     ,-1
                     ,0
                     ,isnull((select sum(PV) from #prj_status_rpt where leaf_flag = 1),0)
                     ,isnull((select sum(EV) from #prj_status_rpt where leaf_flag = 1),0)
                     ,isnull((select sum(AC) from #prj_status_rpt where leaf_flag = 1),0)
end
 
update #prj_status_rpt
       set SV = EV-PV
              ,CV = EV-AC
              ,SPI = case PV
                           when 0 then null
                           else EV/PV
                        end
              ,CPI = case AC
                           when 0 then null
                           else EV/AC
                           end
              ,layer_no = layer_no + 1
 
update #prj_status_rpt
       set prj_desc = p.prj_desc
       from tpma_project p
       where p.prj_code = @prj_code
       and p.chg_ctl_no = (select max(chg_ctl_no) from tpma_project where prj_code = p.prj_code)
 
select * from #prj_status_rpt order by order_no
  