--use db_pma
go


/*********************************************************************
 * Authentication
 *********************************************************************/
if exists (select 1 from sys.tables where name = 'tpma_dshbd_role')
	drop table [dbo].[tpma_dshbd_role]
go
create table [dbo].[tpma_dshbd_role] (
	[role_id] int not null,
	[role_code] varchar(10) not null,
	[role_name] varchar(100),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

	constraint pk_dshbd_role primary key ([role_id])
)
go

--user role
if exists (select 1 from sys.tables where name = 'tpma_dshbd_user_role')
	drop table [dbo].[tpma_dshbd_user_role]
go
create table [dbo].[tpma_dshbd_user_role] (
	[user_role_id] int identity(1,1) not null,
	--[user_id] int not null,
	[role_id] int not null,
	[pma_logon_id] varchar(20) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] varchar(20),

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp
	
	constraint pk_dshbd_user_role primary key ([user_role_id]),
	constraint ix_dshbd_user_role unique ([role_id], [pma_logon_id])
)
go

--user BU
if exists (select 1 from sys.tables where name = 'tpma_dshbd_user_bu')
	drop table [dbo].[tpma_dshbd_user_bu]
go
create table [dbo].[tpma_dshbd_user_bu] (
	[user_bu_id] int identity(1,1) not null,

	[bu_code] varchar(10) not null,
	[pma_logon_id] varchar(20) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] varchar(20),

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp
	
	constraint pk_dshbd_user_bu primary key ([user_bu_id]),
	constraint ix_dshbd_user_bu unique ([bu_code], [pma_logon_id])
)
go

if exists (select 1 from sys.tables where name = 'tpma_dshbd_function')
	drop table [dbo].[tpma_dshbd_function]
go
create table [dbo].[tpma_dshbd_function] (
	[function_id] int not null,
	[function_name] varchar(30) not null,
	[function_seq] int not null, 
	[function_top_id] int,
	[is_link] char(1) default 'Y',
	[function_url] varchar(100),
	[function_icon] varchar(50),

	[show_badges] char(1) default 'N',

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_function primary key (function_id)
)
go


if exists (select 1 from sys.tables where name = 'tpma_dshbd_function_auth')
	drop table [dbo].[tpma_dshbd_function_auth]
go
create table [dbo].[tpma_dshbd_function_auth] (
	[function_auth_id] int identity(1,1) not null,
	[function_id] int not null,
	[role_id] int ,
	[pma_logon_id] varchar(20),
	
	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_function_auth primary key ([function_auth_id])
)
go


if exists (select 1 from sys.tables where name = 'tpma_dshbd_lookup')
	drop table [dbo].[tpma_dshbd_lookup]
go
create table [dbo].[tpma_dshbd_lookup](
	[lookup_id] int identity(1,1),
	[lookup_type] char(1) not null,
	[category] varchar(20) not null,
	[category_desc] varchar(100),
	[sub_category] varchar(20),
	[sub_category_desc] varchar(100),
	[lookup_code] varchar(30) not null,
	[lookup_name] varchar(100) not null,

	[remark] varchar(1000),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_lookup primary key([lookup_id]),
		constraint ix_dshbd_lookup unique ([lookup_type], [category], [lookup_code])
)
go


if exists (select 1 from sys.tables where name = 'tpma_dshbd_metric_raw')
	drop table [dbo].[tpma_dshbd_metric_raw]
go
create table [dbo].[tpma_dshbd_metric_raw](
	[id] int identity(1,1) not null,
	[code] varchar(50) not null,
	[desc] varchar(100),
	[tips] varchar(max),

	[data_type] char(1) not null default 'N',
	[data_precision] int not null default 0,

	[data_source] char(1),

	[effect_begin_dt] datetime not null default current_timestamp,
	[effect_end_dt] datetime,
		
	[is_active] char(1) not null default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_metric_raw primary key([id]),
		constraint ix_dshbd_metric_raw_code unique ([code])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_metric')
	drop table [dbo].[tpma_dshbd_metric]
go	
create table [dbo].[tpma_dshbd_metric] (
	[metric_code] char(2) not null,
	[metric_name] varchar(100),
	[metric_desc] varchar(max),

	[metric_category] char(2) not null,
	[metric_category_desc] varchar(100),

	[metric_val_type] varchar(10),
	[metric_val_precision] int,
	[metric_val_update_mode] char(1),

	[fixed_price_project] char(1) default 'N',
	[tss_prj_json] varchar(max) not null,
	[metric_raw_json] varchar(max),

	[effect_begin_dt] datetime not null default current_timestamp,
	[effect_end_dt] datetime,
	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_metric primary key([metric_code])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_metric_raw_mapping')
	drop table [dbo].[tpma_dshbd_metric_raw_mapping]
go	
create table [dbo].[tpma_dshbd_metric_raw_mapping] (
	[mapping_id] int identity(1,1) not null,
	[metric_code] char(2) not null,
	[metric_raw_code] varchar(50) not null,

	[effect_begin_dt] datetime not null default current_timestamp,
	[effect_end_dt] datetime,
	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_metric_raw_mapping primary key([mapping_id]),
		constraint ix_dshbd_metric_raw_mapping unique ([metric_code], [metric_raw_code])
)
go

if exists (select 1 from sys.tables where name = 'tpma_dshbd_metric_target')
	drop table [dbo].[tpma_dshbd_metric_target]
go
create table [dbo].[tpma_dshbd_metric_target] (
	[metric_target_id] int identity(1,1),

	[metric_year] char(4) not null,
	[tss_prj] varchar(2) not null,
	[metric_code] char(2) not null,

	[metric_val] numeric(9,4),
	[metric_val_sign] char(2),
	[metric_val_green] numeric(9,4),
	[metric_val_amber] numeric(9,4),
	[metric_val_red] numeric(9,4),
	[metric_val_grey] numeric(9,4),

	[metric_val_green_enabled] char(1),
	[metric_val_amber_enabled] char(1),
	[metric_val_red_enabled] char(1),
	[metric_val_grey_enabled] char(1),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_metric_target primary key([metric_target_id]),
		constraint ix_dshbd_metric_target unique ([metric_year], [tss_prj], [metric_code])
)
go



/*******************************************************************
 * Project Profile
 *******************************************************************/
if exists (select 1 from sys.tables where name = 'tpma_dshbd_profile')
	drop table [dbo].[tpma_dshbd_profile]
go
create table [dbo].[tpma_dshbd_profile](
	[prf_id] int identity(1,1) not null,
	[prf_main_code] varchar(10) not null,
	[prf_desc] varchar(100), 
	[prf_desc_detail] text,
	[prf_desc_chn] nvarchar(100),
	[prf_desc_chn_detail] nvarchar(600),
	[prj_codes] varchar(100) not null,
	[prj_master_code] varchar(7), 

	[fixed_price_project] char(1),

	[tss_prj] varchar(2),
	[bu_code] varchar(10),

	[prj_ld_id] varchar(7),

	[est_start_dt] datetime,
	[est_end_dt] datetime,
	[actl_start_dt] datetime,
	[actl_end_dt] datetime,

	[currency] char(3), 

	[est_total_hours] numeric(7,1),
	[actl_total_hours] numeric(7,1),
	[est_prj_total_hours] numeric(7,1),
	[actl_prj_total_hours] numeric(7,1),

	[est_total_cost] numeric(11,2),
	[actl_total_cost] numeric(11,2),
	[actl_total_cost_billed] numeric(11,2),

	[status] char(2),

	[health_status] varchar(5),
	[quality_status] varchar(5),
	[schedule_status] varchar(5),
	[scope_status] varchar(5),
	[resource_status] varchar(5),
	[cost_status] varchar(5),
	[css_status] varchar(5),

	[prj_stage] varchar(5),
	[prj_status_remark] text,

	[data_version] char(8), 

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

	constraint pk_dshbd_profile primary key ([prf_id])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_profile_hist')
	drop table [dbo].[tpma_dshbd_profile_hist]
go
create table [dbo].[tpma_dshbd_profile_hist](
	[prf_id] int not null,

	[prf_main_code] varchar(10) not null,
	[prf_desc] varchar(100), 
	[prf_desc_detail] text,
	[prf_desc_chn] nvarchar(100),
	[prf_desc_chn_detail] nvarchar(600),
	[prj_codes] varchar(100) not null,
	[prj_master_code] varchar(7), 

	[fixed_price_project] char(1),

	[tss_prj] varchar(2),
	[bu_code] varchar(10),

	[prj_ld_id] varchar(7),

	[est_start_dt] datetime,
	[est_end_dt] datetime,
	[actl_start_dt] datetime,
	[actl_end_dt] datetime,

	[currency] char(3), 

	[est_total_hours] numeric(7,1),
	[actl_total_hours] numeric(7,1),
	[est_prj_total_hours] numeric(7,1),
	[actl_prj_total_hours] numeric(7,1),

	[est_total_cost] numeric(11,2),
	[actl_total_cost] numeric(11,2),
	[actl_total_cost_billed] numeric(11,2),

	[status] char(2),

	[health_status] varchar(5),
	[quality_status] varchar(5),
	[schedule_status] varchar(5),
	[scope_status] varchar(5),
	[resource_status] varchar(5),
	[cost_status] varchar(5),
	[css_status] varchar(5),

	[prj_stage] varchar(5),
	[prj_status_remark] text,

	[data_version] char(8) not null, 

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

	constraint pk_dshbd_profile_hist primary key ([prf_id], [data_version])
)
go



if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw')
	drop table [dbo].[tpma_dshbd_prj_metric_raw]
go
create table [dbo].[tpma_dshbd_prj_metric_raw] (
	[id] int identity(1,1) not null,

	[prj_code] char(7) not null,
	[metric_raw_code] varchar(50) not null,

	[metric_raw_val] numeric(9,4),

	[data_version] char(8),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw primary key([id]),
		constraint ix_dshbd_prj_metric_raw unique([prj_code], [metric_raw_code])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_hist')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_hist]
go
create table [dbo].[tpma_dshbd_prj_metric_raw_hist] (
	[id] int not null,

	[prj_code] char(7) not null,
	--[metric_code] char(2) not null,
	[metric_raw_code] varchar(50) not null,

	[metric_raw_val] numeric(9,4),

	[data_version] char(8) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_hist primary key([id]),
		constraint ix_dshbd_prj_metric_raw_hist unique([prj_code], [metric_raw_code], [data_version])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric')
	drop table [dbo].[tpma_dshbd_prj_metric]
go
create table [dbo].[tpma_dshbd_prj_metric] (
	[id] int identity(1,1) not null,

	[prj_code] char(7) not null,
	[metric_code] char(2) not null,

	[metric_val] numeric(9,4),
	[metric_raw_val_json] varchar(max),

	[metric_status] varchar(5),

	[data_version] char(8),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric primary key([id]),
		constraint ix_dshbd_prj_metric unique([prj_code], [metric_code])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_hist')
	drop table [dbo].[tpma_dshbd_prj_metric_hist]
go
create table [dbo].[tpma_dshbd_prj_metric_hist] (
	[id] int not null,

	[prj_code] char(7) not null,
	[metric_code] char(2) not null,

	[metric_val] numeric(9,4),
	[metric_raw_val_json] varchar(max),

	[metric_status] varchar(5),

	[data_version] char(8) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_hist primary key([id], [data_version]),
		constraint ix_dshbd_prj_metric_hist unique([prj_code], [metric_code], [data_version])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_mapping')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_mapping]
go	
create table [dbo].[tpma_dshbd_prj_metric_raw_mapping] (
	[prj_mapping_id] int identity(1,1) not null,

	[prj_code] char(7) not null,
	[metric_code] char(2) not null,
	[metric_raw_code] varchar(50) not null,
	
	[metric_raw_val] numeric(9,4),

	[data_version] char(8),

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_mapping primary key([prj_mapping_id]),
		constraint ix_dshbd_prj_metric_raw_mapping unique ([prj_code], [metric_code], [metric_raw_code])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_mapping_hist')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_mapping_hist]
go	
create table [dbo].[tpma_dshbd_prj_metric_raw_mapping_hist] (
	[prj_mapping_id] int not null,

	[prj_code] char(7) not null,
	[metric_code] char(2) not null,
	[metric_raw_code] varchar(50) not null,
	
	[metric_raw_val] numeric(9,4),

	[data_version] char(8) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_mapping_hist primary key([prj_mapping_id], [data_version]),
		constraint ix_dshbd_prj_metric_raw_mapping_hist unique ([prj_code], [metric_code], [metric_raw_code], [data_version])
)
go

/*******************************************************************
 * Project Quality Raw Data
 *******************************************************************/
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_upload')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_upload]
go
create table [dbo].[tpma_dshbd_prj_metric_raw_upload] (

	[id] int identity(1,1) not null,

	[prj_code] char(7),
	[chg_ctl_no] char(2),
	[sit_by_test_team] char(1),
	[sit_defect] int,
	[uat_critical_defect] int,
	[uat_major_defect] int,
	[uat_minor_defect] int,
	[uat_trivial_defect] int,
	[prod_critical_defect] int,
	[prod_major_defect] int,
	[prod_minor_defect] int,
	[prod_trivial_defect] int,
	[actual_effort] numeric(7,1), 
	[earned_value] decimal(11,2),
	[planned_value] decimal(11,2),
	[actual_cost] decimal(11,2),
	[good_quality_effort] numeric(7,1),
	[failure_effort] numeric(7,1),
	[req_defect] int,
	[design_defect] int,
	[code_defect] int,
	[comp_task] int,
	[comp_task_und_ctrl] int,
	[S1] int,
	[S2] int,
	[received_incident] int,
	[response_on_time] int,
	[resolution_on_time] int,
	[uat_test_cases_1st_time_passed] int,
	[uat_test_cases] int,
	[uat_test_cases_executed] int,
	[reopen_uat_defect] int,

	[css_score] numeric(7,1),

	[data_version] char(8),

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(10),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_upload primary key([id])
)
go
if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_hist')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_hist]
go
create table [dbo].[tpma_dshbd_prj_metric_raw_hist] (

	[id] int not null,

	[prj_code] char(7),
	[chg_ctl_no] char(2),
	[sit_by_test_team] char(1),
	[sit_defect] int,
	[uat_critical_defect] int,
	[uat_major_defect] int,
	[uat_minor_defect] int,
	[uat_trivial_defect] int,
	[prod_critical_defect] int,
	[prod_major_defect] int,
	[prod_minor_defect] int,
	[prod_trivial_defect] int,
	[actual_effort] numeric(7,1), 
	[earned_value] decimal(11,2),
	[planned_value] decimal(11,2),
	[actual_cost] decimal(11,2),
	[good_quality_effort] numeric(7,1),
	[failure_effort] numeric(7,1),
	[req_defect] int,
	[design_defect] int,
	[code_defect] int,
	[comp_task] int,
	[comp_task_und_ctrl] int,
	[S1] int,
	[S2] int,
	[received_incident] int,
	[response_on_time] int,
	[resolution_on_time] int,
	[uat_test_cases_1st_time_passed] int,
	[uat_test_cases] int,
	[uat_test_cases_executed] int,
	[reopen_uat_defect] int,

	[css_score] numeric(7,1),

	[data_version] char(8) not null,

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(10),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_Hist primary key([id], [data_version])
)
go


/*******************************************************************
 * Project Profile Risk, Issue, Milestone
 *******************************************************************/

if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_issue')
	drop table [dbo].[tpma_dshbd_prj_issue]
go
create table [dbo].[tpma_dshbd_prj_issue] (

	[issue_no] varchar(20) not null,

	[issue_category] varchar(30) not null,
	[issue_desc_short] nvarchar(100) not null,
	[issue_desc_long] text,
	[issue_severity] char(1),
	[issue_probability] char(1),
	[issue_reported_by] varchar(20),
	[issue_reported_dt] datetime,
	[issue_owner] varchar(20),
	[issue_trace_status] char(1),
	[issue_status] char(1),

	[issue_est_start_dt] date,
	[issue_est_end_dt] date,
	[issue_actl_start_dt] date,
	[issue_actl_end_dt] date,

	[parent_issue_no] varchar(30),
	[issue_tag] varchar(10),
	[issue_progress] numeric(9,4),

	[prj_code] char(7),
	[prf_id] int,

	[created_by] varchar(20),
	[created_dt] datetime,
	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_issue primary key([issue_no])
)
go

if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_issue_comment')
	drop table [dbo].[tpma_dshbd_prj_issue_comment]
go
create table [dbo].[tpma_dshbd_prj_issue_comment] (

	[issue_comment_id] int identity(1,1) not null,

	[issue_no] varchar(20) not null,

	[issue_comment] text not null,
	[issue_comment_by] varchar(20),
	--[risk_action_trace_status] char(1),

	[issue_comment_status] char(1),

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_issue_comment primary key([issue_comment_id])
)
go

if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_schedule')
	drop table [dbo].[tpma_dshbd_prj_schedule]
go
create table [dbo].[tpma_dshbd_prj_schedule] (

	[schedule_no] varchar(30) not null,
	[schedule_stage] nvarchar(100) not null,

	[schedule_est_start_dt] text,
	[schedule_est_end_dt] char(1),
	[schedule_actl_start_dt] char(1),
	[schedule_actl_end_dt] varchar(20),

	[schedule_status] char(1),

	[schedule_trace_status] char(1),

	[prj_code] char(7),
	[prf_id] int,

	[schedule_comment] varchar(max),

	[created_by] varchar(20),
	[created_dt] datetime,
	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_shedule primary key([schedule_no])
)
go

if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_schedule_comment')
	drop table [dbo].[tpma_dshbd_prj_schedule_comment]
go
create table [dbo].[tpma_dshbd_prj_schedule_comment] (
	[schedule_comment_id] int identity(1,1) not null,

	[schedule_no] varchar(30) not null,

	[schedule_comment] text not null,
	[schedule_comment_by] varchar(20),

	[schedule_comment_status] char(1),

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_schedule_comment primary key([schedule_comment_id])
)
go


/*******************************************************************
 * View
 *******************************************************************/
if exists (select 1 from sys.views where name = 'vpma_dshbd_metric_target')
	drop view [dbo].[vpma_dshbd_metric_target]
go
create view [dbo].[vpma_dshbd_metric_target] as 
select qtyMetric.*, 
metric_target_id, metric_year, tss_prj, metric_val, metric_val_sign, 
metric_val_green, metric_val_amber, metric_val_red, metric_val_grey, 
metric_val_green_enabled, metric_val_amber_enabled, metric_val_red_enabled, metric_val_grey_enabled,
qtyMetricTarget.is_active as metric_target_active,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'METRICVALTYPE' and lookup_code = qtyMetric.metric_val_type) as metric_val_type_desc,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'METRICVALPREC' and lookup_code = qtyMetric.metric_val_precision) as metric_val_precision_desc,
(select lookup_name from tpma_dshbd_lookup where lookup_type = 'B' and category = 'METRICVALUPDMODE' and lookup_code = qtyMetric.metric_val_update_mode ) as metric_val_update_mode_desc,
case when qtyMetricTarget.is_active = 'Y' then 'Yes' when qtyMetricTarget.is_active = 'N' then 'No' end as metric_target_active_desc
from tpma_dshbd_metric qtyMetric
left join tpma_dshbd_metric_target qtyMetricTarget
on qtyMetric.metric_code = qtyMetricTarget.metric_code
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_profile')
	drop view [dbo].[vpma_dshbd_profile]
go
create view [dbo].[vpma_dshbd_profile] as 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, team_code  
from [tpma_dshbd_profile] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
and staff.status = 'A'
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_profile_hist')
	drop view [dbo].[vpma_dshbd_profile_hist]
go
create view [dbo].[vpma_dshbd_profile_hist] as 
select prf.*, bu.bu_name, bu.bu_full_name, staff_name, team_code  
from [tpma_dshbd_profile_hist] prf
left join [tpma_business_unit] bu
on prf.bu_code = bu.bu_code
and bu.active = 'Y'
left join [tpma_StaffBasic] staff
on prf.prj_ld_id =  staff.logon_id
and staff.status = 'A'
go

if exists (select 1 from sys.views where name = 'vpma_dshbd_metric_raw_mapping')
	drop view [dbo].[vpma_dshbd_metric_raw_mapping]
go
create view [dbo].[vpma_dshbd_metric_raw_mapping] as
select mapping.mapping_id, mapping.metric_code, mapping.metric_raw_code,
	metric.metric_name, metric_category, metric_category_desc, metric_val_type, metric_val_precision, fixed_price_project, tss_prj_json, metric_raw_json, 
	metric_raw.[desc], metric_raw.data_type, metric_raw.data_precision, metric_raw.data_source
 from tpma_dshbd_metric_raw_mapping mapping, tpma_dshbd_metric metric, tpma_dshbd_metric_raw metric_raw
where mapping.metric_code = metric.metric_code
  and mapping.metric_raw_code = metric_raw.code 
  and mapping.is_active = 'Y'
  and metric.is_active = 'Y'
  and metric_raw.is_active = 'Y'
  go
  if exists (select 1 from sys.views where name = 'vpma_dshbd_prj_metric_raw_mapping')
	drop view [dbo].[vpma_dshbd_prj_metric_raw_mapping]
go
create view [dbo].[vpma_dshbd_prj_metric_raw_mapping] as
select mapping.prj_mapping_id, mapping.metric_code, mapping.metric_raw_code,
	metric.metric_name, metric_category, metric_category_desc, metric_val_type, metric_val_precision, fixed_price_project, tss_prj_json, metric_raw_json, 
	metric_raw.[desc], metric_raw.data_type, metric_raw.data_precision, metric_raw.data_source
 from tpma_dshbd_prj_metric_raw_mapping mapping, tpma_dshbd_metric metric, tpma_dshbd_metric_raw metric_raw
where mapping.metric_code = metric.metric_code
  and mapping.metric_raw_code = metric_raw.code 
  and mapping.is_active = 'Y'
  and metric.is_active = 'Y'
  and metric_raw.is_active = 'Y'
  go

if exists (select 1 from sys.views where name = 'vpma_dshbd_prj_issue')
	drop view [dbo].[vpma_dshbd_prj_issue]
go
create view [dbo].[vpma_dshbd_prj_issue] as
select issue.*
, lookup_a.lookup_name as issue_status_desc
, lookup_b.lookup_name as issue_track_status_desc
, lookup_c.lookup_name as issue_severity_desc
, lookup_d.lookup_name as issue_probability_desc
, lookup_e.lookup_name as issue_cate_desc
, lookup_f.lookup_name as issue_tag_desc
, staff.staff_name as issue_owner_name
from 
tpma_dshbd_prj_issue issue
left join tpma_dshbd_lookup lookup_a
on lookup_a.lookup_code = issue.issue_status 
and lookup_a.lookup_type = 'B'
and lookup_a.category = 'ISSUESTA'
left join tpma_dshbd_lookup lookup_b
on lookup_b.lookup_code = issue.issue_trace_status 
and lookup_b.lookup_type = 'B'
and lookup_b.category = 'STATUS'
left join tpma_dshbd_lookup lookup_c
on lookup_c.lookup_code = issue.issue_severity 
and lookup_c.lookup_type = 'B'
and lookup_c.category = 'SEVERITY'
left join tpma_dshbd_lookup lookup_d
on lookup_d.lookup_code = issue.issue_probability 
and lookup_d.lookup_type = 'B'
and lookup_d.category = 'SEVERITY'
left join tpma_dshbd_lookup lookup_e
on lookup_e.lookup_code = issue.issue_category 
and lookup_e.lookup_type = 'B'
and lookup_e.category = 'ISSUECATE'
left join tpma_dshbd_lookup lookup_f
on lookup_f.lookup_code = issue.issue_tag
and lookup_f.lookup_type = 'B'
and lookup_f.category = 'ISSUETAG'
left join tpma_StaffBasic staff 
on staff.logon_id = issue.issue_owner 
go

  /*
  select prj.*, staff.staff_name, tssprj.name
from 
(
select prj_code, chg_ctl_no, prj_ld_id, status, master_prj_code, outsource_prj_code, tss_prj, bu_code from tpma_project a
where exists (
select 1 from (
select prj_code, max(chg_ctl_no) as chg_ctl_no from tpma_project group by prj_code) b where b.prj_code = a.prj_code and b.chg_ctl_no = a.chg_ctl_no)
and prj_ld_id = 'gispm3'

union

select prj_code, chg_ctl_no, prj_ld_id, status, master_prj_code, outsource_prj_code, tss_prj from tpma_project a
where master_prj_code is not null
and exists(
select 1 from (
select prj_code, max(chg_ctl_no) as chg_ctl_no from tpma_project group by prj_code) b where b.prj_code = a.prj_code and b.chg_ctl_no = a.chg_ctl_no)
and exists(
select 1 from
	(select distinct master_prj_code from tpma_project where master_prj_code is not null and prj_ld_id = 'gispm3') c where c.master_prj_code = a.master_prj_code
)
union

select prj_code, chg_ctl_no, prj_ld_id, status, master_prj_code, outsource_prj_code, tss_prj from tpma_project a
where outsource_prj_code  is not null
and exists(
select 1 from (
select prj_code, max(chg_ctl_no) as chg_ctl_no from tpma_project group by prj_code) b where b.prj_code = a.prj_code and b.chg_ctl_no = a.chg_ctl_no)
and exists(
select 1 from
	(select distinct prj_code from tpma_project where prj_ld_id = 'gispm3') b where b.prj_code = a.outsource_prj_code 
)
) prj
left join tpma_StaffBasic staff
on prj.prj_ld_id = staff.logon_id 
and staff.status = 'A'
left join tpma_tss_project tssprj
on tssprj.code = prj.tss_prj 


select a.* from
(select * from tpma_project a
where master_prj_code is not null) a
where exists (
select 1 from (
select master_prj_code, prj_code, max(chg_ctl_no) as chg_ctl_no from tpma_project where master_prj_code is not null group by master_prj_code, prj_code) b where b.master_prj_code = a.master_prj_code)
*/
  