use [db_pma]
go
/*
 * Initial Dashboard Data
 */
/**************************************************************************************
--role
 **************************************************************************************/
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (1, 'ADM', 'System Admin', 'Y')
GO
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (2, 'PM', 'Project Manager', 'Y')
GO
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (3, 'TL', 'Team Leader', 'Y')
GO
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (4, 'SBUH', 'SBU Head', 'Y')
GO
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (5, 'FH', 'Function Head', 'Y')
GO
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (6, 'GM', 'General Manager', 'Y')
GO
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (7, 'EXCO', 'EXCO Member', 'Y')
GO
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (8, 'QAG', 'QAG Member', 'Y')
GO
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (9, 'AM', 'Account Manager', 'Y')
GO
INSERT INTO [dbo].[tpma_dshbd_role] ([role_id], [role_code], [role_name], [is_active]) VALUES (10, 'SADM', 'Super System Admin', 'Y')
GO

/**************************************************************************************
--user
 **************************************************************************************/


/**************************************************************************************
--user role
 **************************************************************************************/
INSERT INTO [dbo].[tpma_dshbd_user_role] ([pma_logon_id], [role_id], [is_active]) VALUES ('admin01', 1, 'Y')
GO
 
/**************************************************************************************
--function
 **************************************************************************************/
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (1, 'Dashboard Overview', 1, 0, 'Y', '/Views/Dashboard.aspx', 'home', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (2, 'Profile Filter', 2, 0, 'Y', '/Views/ProjectProfile/ProfileList.aspx', 'glasses', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (21, 'Draft', 21, 2, 'Y', '/Views/ProjectProfile/ProfileDraft.aspx', 'exclamation', 'Y', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (3, 'Report', 3, 0, 'Y', '/Views/MAReport/BuReport.aspx', 'lightbulb', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (31, 'Report', 31, 0, 'Y', '/Views/MAReport/BuReport.aspx', 'lightbulb', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (4, 'Quality Raw Data', 4, 0, 'Y', '/Views/MAReport/MetricDataUpload.aspx', 'file-upload', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (5, 'Housekeeping', 5, 0, 'N', '', 'cogs', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (51, 'Quality Metrics', 51, 5, 'Y', '/Views/Housekeeping/Metrics.aspx', '', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (52, 'Quality Metrics Target', 52, 5, 'Y', '/Views/Housekeeping/MetricsTarget.aspx', '', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (53, 'Menu Functions', 53, 5, 'Y', '/Views/Housekeeping/MenuFunction.aspx', '', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (54, 'Authority', 54, 5, 'Y', '/Views/Housekeeping/Authority.aspx', '', 'N', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function] ([function_id], [function_name], [function_seq], [function_top_id], [is_link], [function_url], [function_icon], [show_badges], [is_active], [created_by]) VALUES (55, 'Reference Data', 55, 5, 'Y', '/Views/Housekeeping/ReferenceDataCategory.aspx', '', 'N', 'Y', 'SYSTEM')
GO

/**************************************************************************************
--function auth
 **************************************************************************************/
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (21, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (4, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (5, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (51, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (52, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (53, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (54, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (55, 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 2, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 2, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (21, 2, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 2, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (4, 2, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 3, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 3, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (21, 3, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 3, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (4, 3, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 4, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 4, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 4, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 5, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 5, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 5, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 6, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 6, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 6, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 7, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 7, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 7, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 8, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 8, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 8, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (4, 8, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (5, 8, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (51, 8, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (52, 8, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 9, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 9, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 9, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (1, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (2, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (21, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (3, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (4, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (5, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (51, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (52, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (53, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (54, 10, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_function_auth] ([function_id], [role_id], [is_active], [created_by]) VALUES (55, 10, 'Y', 'SYSTEM')
GO


/**************************************************************************************
--Lookup Table
 **************************************************************************************/
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'STAGE', 'Project Stage', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '01', 'Initialization', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '02', 'Requirement', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '03', 'Design', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '04', 'Construction', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '05', 'Testing', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '06', 'UAT', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '07', 'Deployment', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '08', 'Closing', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '09', 'BAU', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STAGE', 'Project Stage', '10', 'By Phase', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'STATUS', 'Status', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STATUS', 'Status', 'G', 'On Track', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STATUS', 'Status', 'A', 'At Risk', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'STATUS', 'Status', 'R', 'Critical', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'METRICCATE', 'Metric Category', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICCATE', 'Metric Category', '01', 'Customer Satisfaction', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICCATE', 'Metric Category', '02', 'Quality', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICCATE', 'Metric Category', '03', 'Production Service', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICCATE', 'Metric Category', '04', 'Project Management', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'METRICVALTYPE', 'Metric Value Type', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALTYPE', 'Metric Value Type', 'N', 'Numeric', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALTYPE', 'Metric Value Type', 'P', 'Percentage', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'METRICVALPREC', 'Metric Value Precision', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALPREC', 'Metric Value Precision', '0', '0', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALPREC', 'Metric Value Precision', '1', '1', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALPREC', 'Metric Value Precision', '2', '2', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALPREC', 'Metric Value Precision', '3', '3', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALPREC', 'Metric Value Precision', '4', '4', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'METRICVALUPDMODE', 'Metric Value Update Mode', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALUPDMODE', 'Metric Value Update Mode', 'U', 'Upload', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALUPDMODE', 'Metric Value Update Mode', 'M', 'Manual', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALUPDMODE', 'Metric Value Update Mode', 'B', 'Both', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'METRICVALSIGN', 'Metric Value Indicator Sign', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALSIGN', 'Metric Value Indicator Sign', '1', '=', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALSIGN', 'Metric Value Indicator Sign', '2', '<>', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALSIGN', 'Metric Value Indicator Sign', '3', '>=', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALSIGN', 'Metric Value Indicator Sign', '4', '>', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALSIGN', 'Metric Value Indicator Sign', '5', '<=', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'METRICVALSIGN', 'Metric Value Indicator Sign', '6', '<', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'ISSUECATE', 'Issue Category', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'ISSUECATE', 'Issue Category', 'RISK', 'Risk', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'ISSUECATE', 'Issue Category', 'ISSUE', 'Issue', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'SEVERITY', 'Severity', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'SEVERITY', 'Severity', 'H', 'High', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'SEVERITY', 'Severity', 'M', 'Medium', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'SEVERITY', 'Severity', 'L', 'Low', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'ISSUETAG', 'Issue Tag', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'ISSUETAG', 'Issue Tag', 'QUALITY', 'Quality', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'ISSUETAG', 'Issue Tag', 'SCHEDULE', 'Schedule', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'ISSUESTA', 'Issue State', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'ISSUESTA', 'Issue Tag', 'O', 'Open', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'ISSUESTA', 'Issue Tag', 'P', 'In Progress', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'ISSUESTA', 'Issue Tag', 'C', 'Close', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'BIZCATE', 'Business Category', 'ACTIVE', 'Active', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'ACTIVE', 'Active', 'Y', 'Yes', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('B', 'ACTIVE', 'Active', 'N', 'No', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'SYSCATE', 'System Category', 'EMAIL', 'Email', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'EMAIL', 'Email', 'email_from_account', '', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'EMAIL', 'Email', 'email_host_ip', '', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'EMAIL', 'Email', 'email_template_name', '', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'SYSCATE', 'System Category', 'AUTHORITY', 'Authority', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'AUTHORITY', 'Authority', 'ROLE', 'Role Users', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'AUTHORITY', 'Authority', 'BU', 'BU Users', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'SYSCATE', 'System Category', 'MISC', 'misc', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'DATE_FORMAT', 'yyyyMMdd', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'Show_Metric_Per_Profile', 'Y', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'Save_Metric_Raw_Directly', 'Y', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'Risk_No', 1, 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_lookup] ([lookup_type], [category], [category_desc], [lookup_code], [lookup_name], [is_active], [created_by]) VALUES ('S', 'MISC', 'misc', 'Issue_No', 1, 'Y', 'SYSTEM')
GO
/**************************************************************************************
--Quality Metric Raw
 **************************************************************************************/
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('css_score', 'CSS Score', 1, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('s1', '# of S1 Incident', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('s2', '# of S2 Incident', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('sit_defect', '# of SIT Defect', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('uat_critical_defect', '# of UAT Critical Defect', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('uat_major_defect', '# of UAT Major Defect', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('uat_minor_defect', '# of UAT Minor Defect', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('uat_trivial_defect', '# of UAT Trivial Defect', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('prd_critical_defect', '# of Production Critical Defect', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('prd_major_defect', '# of Production Major Defect', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('prd_minor_defect', '# of Production Minor Defect', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('prd_trivial_defect', '# of Production Trivial Defect', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('reopen_uat_defects', '# of Re-Open UAT Defects', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('1st_time_passed_uat_test_cases', '# of 1st Time Passed UAT Test Cases', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('uat_test_cases_executed', 'Total Number of UAT Test Cases (exclude retest case)', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('comp_task', '# of Completed Task', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('comp_task_und_ctrl', '# of Completed Task On Schedule', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('received_incident', '# of Received Incident', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('response_on_time', '# of Incident Within Response Time', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('resolution_on_time', '# of Incident Within Resolution Time', 0, 'M', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('failure_effort', 'Failure Effort', 1, 'S', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('actual_effort', 'Cumulative Actual Effort', 1, 'S', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('pv', 'PV', 2, 'S', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('ev', 'EV', 2, 'S', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw] ([code], [desc], [data_precision], [data_source], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('ac', 'Actual Cost', 2, 'S', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO

/**************************************************************************************
--Quality Metric
 **************************************************************************************/
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('11', '[{"tss_prj":"01", "selected": "Y"}, {"tss_prj":"02", "selected": "Y"}, {"tss_prj":"03", "selected": "Y"}, {"tss_prj":"04", "selected": "Y"}]', '01', 'Customer Satisfaction', 'User Survey Result', 'N', 1, 'B', 'N', '[{"code":"css_score"}, {"code":"actual_effort"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('21', '[{"tss_prj":"01", "selected": "Y"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "N"}, {"tss_prj":"04", "selected": "N"}]', '02', 'Quality', '# SEV 1 Incident', 'N', 0, 'B', 'N', '[{"code":"s1"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('22', '[{"tss_prj":"01", "selected": "Y"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "N"}, {"tss_prj":"04", "selected": "N"}]', '02', 'Quality', '# SEV 2 Incident', 'N', 0, 'B', 'N', '[{"code":"s2"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('23', '[{"tss_prj":"01", "selected": "N"}, {"tss_prj":"02", "selected": "Y"}, {"tss_prj":"03", "selected": "N"}, {"tss_prj":"04", "selected": "N"}]', '02', 'Quality', 'Post Release Defect Rate (UAT)', 'N', 2, 'B', 'N', '[{"code":"uat_critical_defect"}, {"code":"uat_major_defect"}, {"code": "uat_minor_defect"}, {"code":"uat_trivial_defect"}, {"code":"actual_effort"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('24', '[{"tss_prj":"01", "selected": "N"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "Y"}, {"tss_prj":"04", "selected": "Y"}]', '02', 'Quality', 'Post Release Defect Rate (UAT + Production)', 'N', 2, 'B', 'N', '[{"code":"uat_critical_defect"}, {"code":"uat_major_defect"}, {"code": "uat_minor_defect"}, {"code":"uat_trivial_defect"}, {"code":"prd_critical_defect"}, {"code":"prd_major_defect"}, {"code": "prd_minor_defect"}, {"code":"prd_trivial_defect"}, {"code":"actual_effort"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('25', '[{"tss_prj":"01", "selected": "N"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "Y"}, {"tss_prj":"04", "selected": "Y"}]', '02', 'Quality', 'Defect Removal Efficiency', 'P', 0, 'B', 'N', '[{"code":"sit_defect"}, {"code":"uat_critical_defect"}, {"code":"uat_major_defect"}, {"code": "uat_minor_defect"}, {"code":"uat_trivial_defect"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('27', '[{"tss_prj":"01", "selected": "N"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "Y"}, {"tss_prj":"04", "selected": "Y"}]', '02', 'Quality', 'UAT Defect Re-open Ratio', 'P', 1, 'B', 'N', '[{"code":"reopen_uat_defects"}, {"code":"uat_critical_defect"}, {"code":"uat_major_defect"}, {"code": "uat_minor_defect"}, {"code":"uat_trivial_defect"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('26', '[{"tss_prj":"01", "selected": "N"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "Y"}, {"tss_prj":"04", "selected": "Y"}]', '02', 'Quality', 'UAT Initial Pass Ratio', 'P', 0, 'B', 'N', '[{"code":"1st_time_passed_uat_test_cases"}, {"code":"uat_test_cases_executed"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('28', '[{"tss_prj":"01", "selected": "N"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "Y"}, {"tss_prj":"04", "selected": "Y"}]', '02', 'Quality', 'Cost of Poor Quality', 'P', 0, 'B', 'Y', '[{"code":"failure_effort"}, {"code":"actual_effort"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('31', '[{"tss_prj":"01", "selected": "Y"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "N"}, {"tss_prj":"04", "selected": "N"}]', '03', 'Production Service', 'On-time Response Rate', 'P', 0, 'B', 'N', '[{"code":"response_on_time"}, {"code":"received_incident"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('32', '[{"tss_prj":"01", "selected": "Y"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "N"}, {"tss_prj":"04", "selected": "N"}]', '03', 'Production Service', 'On-time Resolution Rate', 'P', 0, 'B', 'N', '[{"code":"resolution_on_time"}, {"code":"received_incident"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('41', '[{"tss_prj":"01", "selected": "N"}, {"tss_prj":"02", "selected": "Y"}, {"tss_prj":"03", "selected": "N"}, {"tss_prj":"04", "selected": "N"}]', '04', 'Project Management', 'Task On Schedule Rate', 'P', 0, 'B', 'N', '[{"code":"comp_task_und_ctrl"}, {"code":"comp_task"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('42', '[{"tss_prj":"01", "selected": "N"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "Y"}, {"tss_prj":"04", "selected": "Y"}]', '04', 'Project Management', 'Schedule Performance Index (SPI=EV/PV)', 'N', 1, 'B', 'N', '[{"code":"ev"}, {"code":"pv"}]', 'Y', 'SYSTEM')
GO
INSERT INTO [dbo].[tpma_dshbd_metric] ([metric_code], [tss_prj_json], [metric_category], [metric_category_desc], [metric_name], [metric_val_type], [metric_val_precision], [metric_val_update_mode], [fixed_price_project], [metric_raw_json], [is_active], [created_by]) VALUES ('43', '[{"tss_prj":"01", "selected": "N"}, {"tss_prj":"02", "selected": "N"}, {"tss_prj":"03", "selected": "Y"}, {"tss_prj":"04", "selected": "Y"}]', '04', 'Project Management', 'Cost Performance Index (CPI)', 'N', 1, 'B', 'N', '[{"code":"ev"}, {"code":"ac"}]', 'Y', 'SYSTEM')
GO
/**************************************************************************************
--Quality Metric Raw Mapping
 **************************************************************************************/
 INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('11', 'css_score', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('11', 'actual_effort', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('21', 's1', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('22', 's2', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('23', 'uat_critical_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('23', 'uat_major_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('23', 'uat_minor_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('23', 'uat_trivial_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('23', 'actual_effort', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('24', 'uat_critical_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('24', 'uat_major_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('24', 'uat_minor_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('24', 'uat_trivial_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('24', 'prd_critical_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('24', 'prd_major_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('24', 'prd_minor_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('24', 'prd_trivial_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('24', 'actual_effort', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('25', 'sit_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('25', 'uat_critical_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('25', 'uat_major_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('25', 'uat_minor_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('25', 'uat_trivial_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('27', 'reopen_uat_defects', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('27', 'uat_critical_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('27', 'uat_major_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('27', 'uat_minor_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('27', 'uat_trivial_defect', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('26', '1st_time_passed_uat_test_cases', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('26', 'uat_test_cases_executed', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('41', 'comp_task', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('41', 'comp_task_und_ctrl', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('31', 'received_incident', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('31', 'response_on_time', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('32', 'received_incident', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('32', 'resolution_on_time', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('28', 'failure_effort', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('28', 'actual_effort', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('42', 'pv', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('42', 'ev', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('43', 'ac', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO
INSERT INTO [dbo].[tpma_dshbd_metric_raw_mapping] ([metric_code], [metric_raw_code], [created_by], [created_dt], [last_updated_by], [last_updated_dt]) VALUES ('43', 'ev', 'SYSTEM', Current_TimeStamp, 'SYSTEM', Current_TimeStamp)
GO