if exists (select 1 from sys.tables where name = 'tpma_dshbd_prj_metric_raw_hist')
	drop table [dbo].[tpma_dshbd_prj_metric_raw_hist]
go
create table [dbo].[tpma_dshbd_prj_metric_raw_hist] (
	[id] int not null,

	[prj_code] char(7) not null,
	--[metric_code] char(2) not null,
	[metric_raw_code] varchar(50) not null,

	[metric_raw_val] numeric(9,4),

	[data_version] char(8) not null,

	[is_active] char(1) default 'Y',

	[created_by] varchar(20),
	[created_dt] datetime,

	[last_updated_by] varchar(20),
	[last_updated_dt] datetime default current_timestamp

		constraint pk_dshbd_prj_metric_raw_hist primary key([id], [data_version]),
		constraint ix_dshbd_prj_metric_raw_hist unique([prj_code], [metric_raw_code], [data_version])
)
go