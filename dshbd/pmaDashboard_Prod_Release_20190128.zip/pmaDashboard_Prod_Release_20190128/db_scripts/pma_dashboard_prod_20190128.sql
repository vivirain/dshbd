/*******************************************************************************
 * Enlarge profile's field length for:
 *     - Efforts (est_total_hours, actl_total_hours, est_prj_total_hours, actl_prj_total_hours)
 *******************************************************************************/
alter table [dbo].[tpma_dshbd_profile] alter column est_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile] alter column actl_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile] alter column est_prj_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile] alter column actl_prj_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile_hist] alter column est_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile_hist] alter column actl_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile_hist] alter column est_prj_total_hours numeric(15,1)
go
alter table [dbo].[tpma_dshbd_profile_hist] alter column actl_prj_total_hours numeric(15,1)
go
/*******************************************************************************
 * Enlarge log file's field length for:
 *******************************************************************************/
alter table [dbo].tpma_dshbd_tran_log alter column tran_type varchar(50)
go
